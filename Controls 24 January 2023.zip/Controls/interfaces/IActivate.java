package interfaces;

public interface IActivate {
    void setActive(boolean value);
}
