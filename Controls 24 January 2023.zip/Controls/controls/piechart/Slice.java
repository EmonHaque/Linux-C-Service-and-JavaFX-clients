package controls.piechart;

import javafx.animation.Animation;
import javafx.animation.FillTransition;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.geometry.Point2D;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.util.Duration;
import model.PieSeries;

import java.util.Random;

public class Slice extends Path {
    private double dx, dy, startAngle, endAngle;
    private TranslateTransition translate;
    private FillTransition fill;
    private Color color;
    private PieSeries series;
    private MoveTo move;
    private LineTo startLine, endLine;
    private ArcTo arc;
    private boolean isSelected;

    public Slice(double startAngle, double endAngle, boolean isLarge, PieSeries s) {
        this.startAngle = startAngle;
        this.endAngle = endAngle;
        this.series = s;
        move = new MoveTo();
        startLine = new LineTo();
        endLine = new LineTo();
        arc = new ArcTo();
        arc.setLargeArcFlag(isLarge);
        arc.setSweepFlag(true);
        getElements().addAll(move, startLine, arc, endLine);
        var rand = new Random();
        color = Color.rgb(rand.nextInt(255), rand.nextInt(255), rand.nextInt(255));

        setFill(color);
        setStroke(null);
        addEventHandler(MouseEvent.ANY, this::onMouse);

        translate = new TranslateTransition(Duration.millis(500));
        translate.setInterpolator(Interpolator.EASE_BOTH);
        translate.setNode(this);
        fill = new FillTransition(Duration.millis(500));
        fill.setInterpolator(Interpolator.EASE_BOTH);
        fill.setShape(this);
    }

    public PieSeries getSeries() {
        return series;
    }

    public void setValue(Point2D center, double radius) {
        var start = new Point2D(center.getX() + radius * Math.cos(startAngle), center.getY() + radius * Math.sin(startAngle));
        var end = new Point2D(center.getX() + radius * Math.cos(startAngle + endAngle), center.getY() + radius * Math.sin(startAngle + endAngle));
        move.setX(center.getX());
        move.setY(center.getY());
        startLine.setX(start.getX());
        startLine.setY(start.getY());
        arc.setRadiusX(radius);
        arc.setRadiusY(radius);
        arc.setX(end.getX());
        arc.setY(end.getY());
        endLine.setX(center.getX());
        endLine.setY(center.getY());
        dx = 10 * Math.cos(startAngle + endAngle / 2);
        dy = 10 * Math.sin(startAngle + endAngle / 2);
    }

    void onMouse(MouseEvent e) {
        if (e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            if (isSelected)
                return;
            reveal();
        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
            if (isSelected)
                return;
            conceal();
        }
        else if (e.getEventType() == MouseEvent.MOUSE_RELEASED) {
            isSelected = !isSelected;
        }
    }

    private void checkState() {
        if (translate.getStatus() == Animation.Status.RUNNING)
            translate.stop();
        if (fill.getStatus() == Animation.Status.RUNNING)
            fill.stop();
    }

    private void reveal() {
        checkState();
        fill.setToValue(Color.GRAY);
        translate.setByX(dx - getTranslateX());
        translate.setByY(dy - getTranslateY());
        translate.play();
        fill.play();
    }

    private void conceal() {
        checkState();
        fill.setToValue(color);
        translate.setByX(-getTranslateX());
        translate.setByY(-getTranslateY());
        translate.play();
        fill.play();
    }

    public boolean getSelected() {
        return isSelected;
    }

    public void setSelected(boolean value) {
        isSelected = value;
        if (!isSelected)
            conceal();
        else
            reveal();
    }

}
