package controls;

import controls.buttons.ActionButton;
import controls.texts.SuggestionBoxLess;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.converter.NumberStringConverter;
import model.SumBoxModel;
import skinned.ExtendedListView;
import skins.ExtendedTextFieldSkin;

public class SumBox<T> extends GridPane {
    private String suggestionProperty, suggestionTemplate;
    private ObservableList<T> suggestionList;
    private ObservableList<SumBoxModel> list;
    private ExtendedListView<SumBoxModel> listView;
    private ActionButton addButton, removeButton;
    private Text particulars, amount, totalText, totalValue;
    private double total;

    public SumBox(ObservableList<T> suggestionList, String suggestionProperty, String suggestionTemplate) {
        this.suggestionList = suggestionList;
        this.suggestionProperty = suggestionProperty;
        this.suggestionTemplate = suggestionTemplate;

        addButtons();
        addTexts();

        list = FXCollections.observableArrayList();
        listView = new ExtendedListView<>(list);
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setCellFactory(v -> new CellTemplate());
        add(listView, 0, 2, 2, 1);
        GridPane.setVgrow(listView, Priority.ALWAYS);

        var colCon1 = new ColumnConstraints();
        var colCon2 = new ColumnConstraints(70);
        colCon1.setHgrow(Priority.ALWAYS);

        getColumnConstraints().addAll(colCon1, colCon2);
    }

    private void onValueChanged(ObservableValue<?> o, Number ov, Number nv) {
        total -= ov.doubleValue();
        total += nv.doubleValue();
        totalValue.setText(String.format("%,.2f", total));
    }

    private void addNewRow() {
        var newitem = new SumBoxModel("", 0);
        newitem.value.addListener(this::onValueChanged);

        list.add(newitem);
        listView.getSelectionModel().select(newitem);
        listView.scrollTo(newitem);
        // listView.getSelectionModel().select(list.size() - 1);
    }

    private void removeSelectedRow() {
        var index = listView.getSelectionModel().getSelectedIndex();
        if (index == -1)
            return;

        var pair = list.get(index);
        total -= pair.value.get();

        totalValue.setText(String.format("%,.2f", total));
        list.remove(index);
        if (index > 0) {
            index--;
            listView.getSelectionModel().select(index);
        }
    }

    private void addTexts() {
        particulars = new Text("Particulars");
        amount = new Text("Amount");
        totalText = new Text("Total");
        totalValue = new Text(String.format("%,.2f", total));

        particulars.setFill(Color.WHITE);
        amount.setFill(Color.WHITE);
        totalText.setFill(Color.WHITE);
        totalValue.setFill(Color.WHITE);

        var topBorder = new StackPane();
        var bottomBorder = new StackPane();
        topBorder.setBorder(Constants.BottomBorder);
        bottomBorder.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0))));

        add(topBorder, 0, 1, 2, 1);
        add(particulars, 0, 1);
        add(amount, 1, 1);

        add(bottomBorder, 0, 3, 2, 1);
        add(totalText, 0, 3);
        add(totalValue, 1, 3);

        GridPane.setHalignment(amount, HPos.RIGHT);
        GridPane.setHalignment(totalValue, HPos.RIGHT);
        GridPane.setMargin(amount, new Insets(0, Constants.ScrollBarSize, 0, 0));
        GridPane.setMargin(totalValue, new Insets(0, Constants.ScrollBarSize, 0, 0));
    }

    private void addButtons() {
        addButton = new ActionButton(Icons.PlusCircle, 16, "add");
        removeButton = new ActionButton(Icons.MinusCircle, 16, "remove");

        addButton.setAction(this::addNewRow);
        removeButton.setAction(this::removeSelectedRow);

        var hBox = new HBox(addButton, removeButton);
        hBox.setAlignment(Pos.CENTER_RIGHT);
        add(hBox, 0, 0, 2, 1);

        GridPane.setHalignment(hBox, HPos.RIGHT);
        GridPane.setMargin(hBox, new Insets(0, Constants.ScrollBarSize, 0, 0));
    }

    private class CellTemplate extends ListCell<SumBoxModel> {
        private SuggestionBoxLess<T> keyField;
        private TextField valueField;
        private GridPane grid;

        public CellTemplate() {
            setPadding(new Insets(1, 0, 1, 0));
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setBackground(null);

            keyField = new SuggestionBoxLess<>(suggestionList, suggestionProperty,
                    suggestionTemplate);
            valueField = new TextField();
            valueField.setSkin(new ExtendedTextFieldSkin(valueField));
            keyField.setPadding(new Insets(0));
            valueField.setPadding(new Insets(0));
            valueField.setAlignment(Pos.CENTER_RIGHT);

            grid = new GridPane();
            grid.add(keyField, 0, 0);
            grid.add(valueField, 1, 0);

            var col1Con = new ColumnConstraints();
            var col2Con = new ColumnConstraints(70);
            col1Con.setHgrow(Priority.ALWAYS);

            grid.getColumnConstraints().addAll(col1Con, col2Con);

            itemProperty().addListener((o, ov, nv) -> {
                if (ov != null) {
                    keyField.textProperty().unbindBidirectional(ov.key);
                    valueField.textProperty().unbindBidirectional(ov.value);
                    setOnKeyPressed(null);
                }
                if (nv != null) {
                    keyField.textProperty().bindBidirectional(nv.key);
                    valueField.textProperty().bindBidirectional(nv.value, new NumberStringConverter());
                    setOnKeyPressed(this::onKeyPressed);
                }
            });
        }

        private void onKeyPressed(KeyEvent e) {
            if (!e.isControlDown())
                return;
            var code = e.getCode();
            // NUMPAD
            if (code == KeyCode.ADD) {
                addNewRow();
            }
            if (code == KeyCode.SUBTRACT) {
                removeSelectedRow();
            }
        }

        @Override
        protected void updateItem(SumBoxModel item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
                return;
            }
            setGraphic(grid);
            if (isSelected()) {
                keyField.requestFocus();
                keyField.end();
            }
        }
    }
}
