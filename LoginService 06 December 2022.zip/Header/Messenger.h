#pragma once
#include <string.h>
#include "Defined.h"

int sendString(int, char*);
int sendByte(int, byte);
int sendInt(int, int);
