#pragma once
#include "Structures.h"
#include "BlockingQueue.h"

extern int maxAttemptId;
extern BlockingQueue attempts, logouts;

void initializeDatabase();
int mallocate(char*, char**);
Login* getLogin(char*, char*);
int getAppId(char*);
int getAddressId(char*);
Client* getClient(int);
char* getTime();
char* getDate();
