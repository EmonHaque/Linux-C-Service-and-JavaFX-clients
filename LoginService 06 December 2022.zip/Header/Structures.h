#pragma once
#include <pthread.h>
#include "List.h"
#include "Defined.h"

typedef enum {
    None,
    Super,
    Admin,
    Executive
} Role;

typedef struct {
    int socket;
    pthread_t thread;
    char* ip4Address;
    int port;
} Client;

typedef struct {
    int id;
    char* name;
    char* userName;
    char* password;
    Role role;
    byte isActive;
} Login;

typedef struct {
    int id;
    int userId;
    int appId;
    int addressId;
    int port;
    char* userName;
    char* password;
    char* dateIn;
    char* timeIn;
    byte isSuccess;
} Attempt;

typedef struct {
    Role role;
    int userId;
    byte isSuccess;
} LoginResult;

typedef struct {
    int Id;
    Login *Login;
    char* dateIn;
    char* timeIn;
    char* dateOut;
    char* timeOut;
} Online;

typedef struct {
    int id;
    char* name;
} App;

typedef struct {
    int id;
    char* IP;
} Address;