#pragma once
typedef unsigned char byte ;
typedef unsigned long ulong;
typedef unsigned int uint;
typedef void Action();

#define CLIENT_SIZE sizeof(Client)
#define LOGIN_SIZE sizeof(Login)
#define ATTEMPT_SIZE sizeof(Attempt)
#define ONLINE_SIZE sizeof(Online)
#define APP_SIZE sizeof(App)
#define ADDRESS_SIZE sizeof(Address)
#define POINTER_SIZE sizeof(void*)