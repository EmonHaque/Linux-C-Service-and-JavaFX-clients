#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <signal.h>

#include "Messenger.h"
#include "Database.h"
#include "Structures.h"
#include "List.h"
#include "BlockingQueue.h"


#pragma region variables
extern int maxAttemptId;
extern BlockingQueue attempts, logouts;

int server;
pthread_t attemptThread;
pthread_mutex_t criticalClient;
byte isRunning;
List clients, onlines;
#pragma endregion

#pragma region protos
static void initialize();
static void acceptClient();
#pragma endregion

void onTerminate(int s){
    isRunning = 0;
    close(server);
    int **lstClient = clients.data;
    for (int i = 0; i < clients.count; i++) {
        int client = *lstClient[i];
        shutdown(client, SHUT_RDWR);
        close(client);
    }
}

int main() {
    signal(SIGTERM, onTerminate);
    initialize();
    acceptClient();
    // shutDownProgram();
    // ShutdownDatabase();
	return 0;
}

static void* handleAttempt(void* p) {
	int client = *(int*)p;

	Client* c = getClient(client);
	char header[4];
	int accumulated, read;
	byte isSuccess = 0;

	accumulated = recv(client, header, 4, 0);
	if (accumulated <= 0)  goto onDisconnect;
	while (accumulated < 4) {
		read = recv(client, &header[accumulated], 4 - accumulated, 0);
		if (read <= 0)  goto onDisconnect;
		accumulated += read;
	}
	int packetSize;
	memcpy(&packetSize, header, 4);
	char *packet = malloc(packetSize);
	accumulated = read = 0;
	while (accumulated < packetSize) {
		read = recv(client, &packet[accumulated], packetSize - accumulated, 0);
		if (read <= 0) {
			free(packet);
			goto onDisconnect;
		}
		accumulated += read;
	}
    pthread_mutex_lock(&criticalClient);
	maxAttemptId++;
    pthread_mutex_unlock(&criticalClient);

	char* appName, * user, * pass;
	appName = strtok_r(packet, "", &pass), pass++;
	user = strtok_r(0, "", &pass), pass++;

	int appId = getAppId(appName);
	int addressId = getAddressId(c->ip4Address);
	Login* login = getLogin(user, pass);

	LoginResult result;
	Attempt* attempt = malloc(ATTEMPT_SIZE);
	attempt->id = maxAttemptId;
	attempt->appId = appId;
	attempt->addressId = addressId;
	attempt->port = c->port;
	attempt->timeIn = getTime();
	attempt->dateIn = getDate();

	Online* online = malloc(ONLINE_SIZE);
	if (login) {
		result.userId = attempt->userId = login->id;
		result.isSuccess = attempt->isSuccess = isSuccess = 1;
		result.role = login->role;

		online->Id = attempt->id;
		online->Login = login;
		mallocate(attempt->dateIn, &online->dateIn);
		mallocate(attempt->timeIn, &online->timeIn);

        pthread_mutex_lock(&criticalClient);
		addToList(&onlines, online);
        pthread_mutex_unlock(&criticalClient);
	}
	else {
		result.role = result.userId = result.isSuccess =
			attempt->isSuccess = attempt->userId = 0;
		mallocate(user, &attempt->userName);
		mallocate(pass, &attempt->password);
		free(online);
	}
	free(packet);
	sendInt(client, 9);
	sendInt(client, result.role);
	sendInt(client, result.userId);
	sendByte(client, result.isSuccess);

	putInto(&attempts, attempt);
	if (isSuccess) {
		recv(client, header, 1, 0); // wait for disconnection
		online->timeOut = getTime();
		online->dateOut = getDate();
		
        pthread_mutex_lock(&criticalClient);
		removeFromList(&onlines, online);
		putInto(&logouts, online);
        pthread_mutex_unlock(&criticalClient);
	}

onDisconnect:
    close(client);
	// CloseHandle(c->thread);

    pthread_mutex_lock(&criticalClient);
	removeFromList(&clients, c);
    pthread_mutex_unlock(&criticalClient);
	free(c);
	return 0;
}
static void initialize() {
	const char* IP = "127.0.0.1";
	int PORT = 5556;

    struct sockaddr_in address;
    address.sin_family = AF_INET;
    address.sin_port = htons(PORT);
    address.sin_addr.s_addr = inet_addr(IP);

	server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int));

	bind(server, &address, sizeof(address));
	listen(server, SOMAXCONN);
	isRunning = 1;

	initializeDatabase();

	onlines.count = clients.count = 0;
	onlines.capacity = clients.capacity = 5;
	clients.data = malloc(5 * POINTER_SIZE);
	onlines.data = malloc(5 * POINTER_SIZE);

    pthread_mutex_init(&criticalClient, 0);
}
static void acceptClient() {
	while (isRunning) {
		struct sockaddr_in from;
		socklen_t length = sizeof(from);

		int client = accept(server, &from, &length);
		char ipv4[INET_ADDRSTRLEN];
		inet_ntop(AF_INET, &(from.sin_addr), ipv4, INET_ADDRSTRLEN);
		setsockopt(client, IPPROTO_TCP, TCP_NODELAY, &(int){1}, sizeof(int));

        pthread_mutex_lock(&criticalClient);

        pthread_create(&attemptThread, 0, handleAttempt, &client);
		Client* c = malloc(CLIENT_SIZE);
		c->socket = client;
		c->thread = attemptThread;
		mallocate(ipv4, &c->ip4Address);
		c->port = from.sin_port;
		addToList(&clients, c);

        pthread_mutex_unlock(&criticalClient);
	}
}