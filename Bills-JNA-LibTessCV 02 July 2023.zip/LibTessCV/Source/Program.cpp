#include <cstring>
#include <leptonica/allheaders.h>
#include <opencv2/opencv.hpp>
#include <tesseract/baseapi.h>

#include "Program.h"
#include "opencv2/imgcodecs.hpp"

using namespace std;
using namespace cv;
using namespace tesseract;

TessBaseAPI *tess;
Mat current;
vector<uchar> buffer;
ImageCV *image = {0};
FXMat *fxMat = {0};
char *text = {0};

ImageCV *getImage() {
    if (image) free(image);

    image = (ImageCV *)malloc(sizeof(ImageCV));
    image->size = (int)buffer.size();
    image->data = buffer.begin().base();

    return image;
}

FXMat *getMat(int type) {
    if (fxMat) {
        free(fxMat->data);
        free(fxMat);
    }
    Mat x;
    switch (type) {
        case 0: cvtColor(current, x, COLOR_BGR2RGB);; break;
        case 1: {
            Mat gray;
            cvtColor(current, gray, COLOR_BGR2GRAY);
            bitwise_not(gray, x);
        } break;
        default: {
            Mat gray, binary;
            cvtColor(current, gray, COLOR_BGR2GRAY);
            threshold(gray, binary, 200, 255, THRESH_BINARY);
            bitwise_not(binary, x);
        }
        break;
    }
    fxMat = (FXMat*)malloc(sizeof(FXMat));
    fxMat->width = x.cols;
    fxMat->height = x.rows;
    fxMat->channels = x.channels();
    fxMat->size = x.step[0] * x.rows;
    fxMat->data = (unsigned char*)malloc(fxMat->size);
    memcpy(fxMat->data, x.data, fxMat->size);
    return fxMat;
}

extern "C" void initialize(char *dataPath, char *language) {
    tess = new TessBaseAPI();
    tess->Init(dataPath, language, OEM_LSTM_ONLY);
}

extern "C" void setWhiteList(char *characters) {
    tess->SetVariable("tessedit_char_whitelist", characters);
}

extern "C" char *getText(char *file) {
    if (text) delete[] text;
    // Does it binarize it by default?

    Mat gray = imread(file, IMREAD_GRAYSCALE);
    Mat binary;
    threshold(gray, binary, 200, 255, THRESH_BINARY);
    tess->SetImage(binary.data, binary.cols, binary.rows, binary.channels(), binary.step);

    // Mat source = imread(file, IMREAD_UNCHANGED);
    // tess->SetImage(source.data, source.cols, source.rows, source.channels(), source.step);

    tess->SetSourceResolution(96);
    text = tess->GetUTF8Text();
    return text;
}

extern "C" void setImageFile(char *file) {
    current = imread(file, IMREAD_UNCHANGED);
}

extern "C" void setImageBuffer(int size, char *data) {
    Mat rawData(1, size, CV_8SC1, data);
    current = imdecode(rawData, IMREAD_UNCHANGED);
}

extern "C" ImageCV *getOriginalImage() {
    imencode(".png", current, buffer);

    return getImage();
}

extern "C" ImageCV *getInvertedGrayImage() {
    Mat gray, inverted;
    cvtColor(current, gray, COLOR_BGR2GRAY);
    bitwise_not(gray, inverted);
    imencode(".png", inverted, buffer);

    return getImage();
}

extern "C" ImageCV *getInvertedBinaryImage() {
    Mat gray, binary, inverted;
    cvtColor(current, gray, COLOR_BGR2GRAY);
    threshold(gray, binary, 200, 255, THRESH_BINARY);
    bitwise_not(binary, inverted);
    imencode(".png", inverted, buffer);

    return getImage();
}

extern "C" FXMat *getOriginalMat() {
    return getMat(0);
}

extern "C" FXMat *getInvertedGrayMat() {
    return getMat(1);
}

extern "C" FXMat *getInvertedBinaryMat() {
    return getMat(2);
}

extern "C" void destroyTesseract() {
    tess->End();
    if (text) delete[] text;
    delete tess;
}

extern "C" void destroyImage() {
    if (image) free(image);
    if (fxMat) free(fxMat);
}