#pragma once

typedef struct {
    int size;
    unsigned char *data;
} ImageCV;

typedef struct{
    int width;
    int height;
    int size;
    int channels;
    unsigned char * data;
} FXMat;