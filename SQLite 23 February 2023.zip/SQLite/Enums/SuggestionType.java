package Enums;

public enum SuggestionType {
    Keyword,
    Aggregate,
    DateTime,
    JSON,
    Math,
    Scalar,
    Window,
    DataType,
    Table,
    View,
    Column
}
