package Enums;

public enum DBObjectType {
    Table,
    View,
    Index,
    Trigger
}
