package Views;

import Abstracts.View;
import Controls.*;
import Helpers.Icons;

public class Query extends View {
    @Override
    protected String getIcon() {
        return Icons.SelectSearch;
    }

    @Override
    protected String getTip() {
        return "SQL";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        setCenter(new QueryTabs());
    }
}
