package Skins;

import javafx.geometry.Insets;
import javafx.scene.AccessibleAttribute;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.skin.TextAreaSkin;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

public class ExtendedTextAreaSkin extends TextAreaSkin {
    boolean isLoaded;

    public ExtendedTextAreaSkin(TextArea control) {
        super(control);
        control.setBackground(null);
        setTextFill(Color.WHITE);
        setHighlightFill(Color.rgb(0, 0, 0, 0.5));
    }

    @Override
    protected void layoutChildren(double contentX, double contentY, double contentWidth, double contentHeight) {
        if (!isLoaded) {
            applySkin();
            isLoaded = true;
        }
        super.layoutChildren(contentX, contentY, contentWidth, contentHeight);
    }

    private void applySkin() {
        var pane = (ScrollPane) getNode().lookup(".scroll-pane");
        var corner = (StackPane) pane.lookup(".corner");
        var port = (Region) pane.lookup(".viewport");
        var content = (Region) pane.getContent();

        content.setPadding(new Insets(0, 0, 0, 5));
        content.setBackground(null);
        port.setBackground(null);
        corner.setBackground(null);

        var vBar = (ScrollBar) pane.queryAccessibleAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR);
        var hBar = (ScrollBar) pane.queryAccessibleAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR);
        vBar.setSkin(new ExtendedScrollBarSkin(vBar));
        hBar.setSkin(new ExtendedScrollBarSkin(hBar));
    }
}
