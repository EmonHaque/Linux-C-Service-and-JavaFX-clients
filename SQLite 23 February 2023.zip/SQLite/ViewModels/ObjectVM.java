package ViewModels;

import Enums.DBObjectType;
import Enums.SuggestionType;
import Model.DBObject;
import Model.Suggestion;
import com.sun.jna.ptr.PointerByReference;
import javafx.beans.property.*;
import javafx.concurrent.Task;
import javafx.stage.FileChooser;
import javafx.util.Pair;
import ridiculous.AppData;
import ridiculous.SQLiteWrapper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ObjectVM {
    public StringProperty status, fullPath;
    public BooleanProperty isRunning;
    public ObjectProperty<List<DBObject>> objects;
    public File database;
    private ConnectionTask task;
    private boolean isRefreshing;

    public ObjectVM() {
        status = new SimpleStringProperty("");
        fullPath = new SimpleStringProperty("");
        objects = new SimpleObjectProperty<>();
        isRunning = new SimpleBooleanProperty();
    }

    public void choose() {
        var chooser = new FileChooser();
        database = chooser.showOpenDialog(null);
        if (database == null) return;

        scheduleTask();
    }

    public void refresh() {
        if (database == null) {
            status.unbind();
            status.set("choose a database");
            return;
        }
        isRefreshing = true;
        scheduleTask();
    }

    public void scheduleTask() {
        if (task != null && task.isRunning()) {
            task.setOnCancelled(e -> {
                task.setOnCancelled(null);
                startTask();
            });
            task.cancel();
        }
        else startTask();
    }

    private void startTask() {
        task = new ConnectionTask();
        status.bind(task.messageProperty());
        isRunning.bind(task.runningProperty());
        new Thread(task) {{setDaemon(true);}}.start();
    }

    private class ConnectionTask extends Task<Void> {
        private boolean isConnected = true;
        private int pointerLength, numColumn;
        private List<String> columns;
        private List<Pair<String, String>> dbInfo;
        private List<DBObject> objectInfo;
        private String current, error;
        private SQLiteWrapper.columnCallback columnCallback;
        private SQLiteWrapper.rowCallBack rowCallBack;
        private SQLiteWrapper.errorCallback errorCallback;

        private void getColumnNames(int count, PointerByReference values, int length) {
            numColumn = count;
            pointerLength = length;
        }

        private void getError(String error) {
            if (error == null) return;
            isConnected = false;
            this.error = error;
        }

        private void getDBInfo(PointerByReference values) {
            var pointers = values.getPointer().getPointerArray(0, pointerLength);
            var array = new String[numColumn];
            for (int i = 0; i < numColumn; i++) {
                array[i] = pointers[i].getString(0);
            }
            dbInfo.add(new Pair<>(array[0], array[1]));
        }

        private void getTable(PointerByReference values) {
            var pointers = values.getPointer().getPointerArray(0, pointerLength);
            var array = new String[numColumn];
            for (int i = 0; i < numColumn; i++) {
                array[i] = pointers[i].getString(0);
            }
            objectInfo.add(new DBObject() {{
                setName(current);
                setType(DBObjectType.Table);
                setColumnName(array[0]);
                setDataType(array[1]);
                setIsPrimaryKey(array[2].equals("1"));
            }});
            if(!columns.contains(array[0])) columns.add(array[0]);
        }

        private void getView(PointerByReference values) {
            var pointers = values.getPointer().getPointerArray(0, pointerLength);
            var array = new String[numColumn];
            for (int i = 0; i < numColumn; i++) {
                array[i] = pointers[i].getString(0);
            }
            objectInfo.add(new DBObject() {{
                setName(current);
                setType(DBObjectType.View);
                setColumnName(array[0]);
                setDataType(array[1]);
                setIsPrimaryKey(array[2].equals("1"));
            }});
        }

        private void getIndex(PointerByReference values) {
            var pointers = values.getPointer().getPointerArray(0, pointerLength);
            var array = new String[numColumn];
            for (int i = 0; i < numColumn; i++) {
                array[i] = pointers[i].getString(0);
            }
            var table = dbInfo.stream().filter(x -> x.getValue().contains(current)).findFirst().get().getValue().split(",")[1];
            objectInfo.add(new DBObject() {{
                setName(current + " ON " + table);
                setType(DBObjectType.Index);
                setColumnName(array[0]);
            }});
        }

        @Override
        protected Void call() throws Exception {
            updateMessage("acquiring key");
            synchronized (SQLiteWrapper.key) {
                var filePath = database.getAbsolutePath();
                errorCallback = this::getError;
                SQLiteWrapper.setCErrorCallback(errorCallback);
                if (!isRefreshing) {
                    SQLiteWrapper.openDatabase(filePath);
                    if (!isConnected) return null;
                }
                else isRefreshing = false;

                updateMessage("requesting database info");
                Thread.sleep(500);
                dbInfo = new ArrayList<>();
                objectInfo = new ArrayList<>();
                columns = new ArrayList<>();

                // can these callbacks be garbage collected?

                columnCallback = this::getColumnNames;
                rowCallBack = this::getDBInfo;
                SQLiteWrapper.setColumnCallback(columnCallback);
                SQLiteWrapper.setRowCallback(rowCallBack);
                SQLiteWrapper.execute("SELECT type, name || ',' || tbl_name from sqlite_master");

                for (var item : dbInfo) {
                    var splits = item.getValue().split(",");
                    current = splits[0];
                    if (item.getKey().equals("table")) {
                        rowCallBack = this::getTable;
                        SQLiteWrapper.setRowCallback(rowCallBack);
                        SQLiteWrapper.execute("SELECT name, type, pk FROM pragma_table_info('" + current + "')");
                    }
                    else if (item.getKey().equals("view")) {
                        rowCallBack = this::getView;
                        SQLiteWrapper.setRowCallback(rowCallBack);
                        SQLiteWrapper.execute("SELECT name, type, pk FROM pragma_table_info('" + current + "')");
                    }
                    else if (item.getKey().equals("index")) {
                        rowCallBack = this::getIndex;
                        SQLiteWrapper.setRowCallback(rowCallBack);
                        SQLiteWrapper.execute("SELECT name FROM pragma_index_info('" + current + "')");
                    }
                    else if (item.getKey().equals("trigger")) {
                        objectInfo.add(new DBObject() {{
                            setType(DBObjectType.Trigger);
                            setName(splits[0] + " ON " + splits[1]);
                        }});
                    }
                }
            }
            updateMessage("successfully processed");
            Thread.sleep(500);
            return null;
        }

        @Override
        protected void succeeded() {
            if (!isConnected) {
                objects.set(null);
                updateMessage(error);
            }
            else {
                updateMessage(database.getName());
                fullPath.set(database.getAbsolutePath());
                objects.set(objectInfo);

                var old = AppData.suggestions.stream().filter(x -> x.getType() == SuggestionType.Column
                        || x.getType() == SuggestionType.Table
                        || x.getType() == SuggestionType.View
                ).toList();
                AppData.suggestions.removeAll(old);
                for(var item : dbInfo){
                    if (item.getKey().equals("table")){
                        var splits = item.getValue().split(",");
                        AppData.suggestions.add(new Suggestion(SuggestionType.Table, splits[0]));
                    }
                    else if(item.getKey().equals("view")){
                        var splits = item.getValue().split(",");
                        AppData.suggestions.add(new Suggestion(SuggestionType.View, splits[0]));
                    }
                }
                for(var item : columns){
                    AppData.suggestions.add(new Suggestion(SuggestionType.Column, item));
                }
            }
        }
    }
}
