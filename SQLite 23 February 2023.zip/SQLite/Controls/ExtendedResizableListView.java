package Controls;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.Skin;
import javafx.scene.control.skin.VirtualFlow;
import Skins.ExtendedResizableListViewSkin;

public class ExtendedResizableListView<T> extends ListView<T> {
    private final ObservableList<T> list;
    private VirtualFlow<?> vFlow;
    private ScrollBar vBar;
    private boolean isLoaded;

    public ExtendedResizableListView(ObservableList<T> list) {
        super(list);
        this.list = list;
        setBackground(null);
        setPadding(new Insets(0));
    }

    private void resetHeight(){
        double height = 0;
        for(int i = 0; i < list.size(); i++){
            height += vFlow.getCell(i).getHeight();
        }
        vBar.setOpacity(height < getMaxHeight() ? 0 : 1);
        setPrefHeight(Math.min(getMaxHeight(), height));
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if(!isLoaded){
            isLoaded = true;
            vBar = ((ExtendedResizableVirtualFlow <?>)vFlow).vBar;
            list.addListener((ListChangeListener.Change<? extends T> change) -> resetHeight());
            Platform.runLater(this::resetHeight);
        }
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        var skin = new ExtendedResizableListViewSkin<>(this);
        vFlow = skin.flow;
        return skin;
    }
}
