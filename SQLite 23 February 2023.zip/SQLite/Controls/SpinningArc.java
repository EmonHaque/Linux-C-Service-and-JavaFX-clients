package Controls;

import javafx.animation.*;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.util.Duration;

public class SpinningArc extends StackPane {
    private double radius = 5;
    private ParallelTransition anim;

    public SpinningArc() {
        var size = radius * 2;
        setMinSize(size, size);
        setPrefSize(size, size);
        setMaxSize(size, size);
        setVisible(false);

        var arc = new Arc(radius, radius, radius, radius, 0, 0);
        arc.setType(ArcType.ROUND);
        arc.setFill(Color.WHITE);
        arc.setManaged(false);
        getChildren().add(arc);

        var kv = new KeyValue(arc.lengthProperty(), 360);
        var kf = new KeyFrame(Duration.seconds(1), kv);
        var angleAnim = new Timeline(kf);

        var fillAnim = new FillTransition(Duration.seconds(1), Color.WHITE, Color.CORAL);
        fillAnim.setShape(arc);

        anim = new ParallelTransition(fillAnim, angleAnim);
        anim.setCycleCount(ParallelTransition.INDEFINITE);
        anim.setInterpolator(Interpolator.EASE_OUT);

        visibleProperty().addListener((o, ov, nv) -> {
            if(nv){
                anim.play();
            }
            else{
                anim.stop();
                arc.setLength(0);
                arc.setFill(Color.WHITE);
            }
        });
    }
}
