package Helpers;

import javafx.scene.input.DataFormat;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class Constants {
    public static double hintShiftX = 5;
    public static double hintShiftY = 20;
    public static double CardMargin = 2.5;
    public static double CardRadius = 5;
    public static double ScrollBarSize = 10;
    public static double CellPadding = 4;

    public static Border BottomBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0,0,0.25,0)));
    public static Border TopBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25,0,0,0)));
    public static Border DoubleBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25,0,0.25,0)));
    public static Border BottomLineHighlight = new Border(new BorderStroke(Color.CORNFLOWERBLUE, BorderStrokeStyle.SOLID, null, new BorderWidths(0,0,0.5,0)));

    public static Color BackgroundColor = Color.rgb(50, 50, 50);
    public static Color BackgroundColorLight = Color.rgb(60, 60, 60);

    public static Font Bold = Font.font(null, FontWeight.BOLD, -1);
    public static Font Normal = Font.font(null, FontWeight.NORMAL, -1);
    public static Font Italic = Font.font(null, FontPosture.REGULAR, -1);
}
