package Interfaces;

public interface IExecute {
    void execute();
}
