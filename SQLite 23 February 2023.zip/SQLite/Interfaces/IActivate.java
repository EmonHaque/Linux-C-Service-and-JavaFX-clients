package Interfaces;

public interface IActivate {
    void setActive(boolean value);
}
