#pragma once

typedef unsigned char byte;
typedef unsigned int uint;
typedef unsigned long ulong;

#define POINTER_SIZE sizeof(void*)
#define SENDER_SIZE sizeof(Sender)
#define REQUEST_SIZE sizeof(Request)
#define RESPONSE_PERSONAL_SIZE sizeof(ResponsePersonal)
#define RESPONSE_PUBLIC_SIZE sizeof(ResponsePublic)
#define SHORT_MESSAGE_SIZE sizeof(ShortMessage)