#pragma once
#include <string.h>
#include <sys/socket.h>
#include "CommonDefined.h"

int sendString(int, char*);
int sendByte(int, byte);
int sendInt(int, int);
