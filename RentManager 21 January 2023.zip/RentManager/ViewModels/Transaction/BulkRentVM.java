package ViewModels.Transaction;

import Enums.Function;
import Models.Lease;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import ridiculous.AppData;
import ridiculous.Jar;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;

public class BulkRentVM {
    public FilteredList<Lease> leases;
    public ObservableList<Lease> excluded;
    public ObjectProperty<LocalDate> selectedDate;
    public StringProperty statusProperty, queryProperty;
    public BooleanProperty isRunningProperty;

    public BooleanProperty dialogTrigger;
    public String dialogMessage;
    public boolean dialogResult;

    private final DateTimeFormatter formatter;
    private LocalDate lastDay;

    public BulkRentVM() {
        formatter = DateTimeFormatter.ofPattern("MMMM, yyyy");
        statusProperty = new SimpleStringProperty("");
        queryProperty = new SimpleStringProperty("");
        isRunningProperty = new SimpleBooleanProperty();
        dialogTrigger = new SimpleBooleanProperty();

        var nameAscending = Comparator.comparing(Lease::getPlotName).thenComparing(Lease::getSpaceName);
        var source = new Jar<>(AppData.leases, o -> new Observable[]{
                o.isExpiredProperty(),
                queryProperty
        });
        leases = new FilteredList<>(source.sorted(nameAscending), this::filter);
        excluded = FXCollections.observableArrayList();
        selectedDate = new SimpleObjectProperty<>();
    }

    private boolean filter(Lease lease) {
        var trimmed = queryProperty.get().trim();
        if (trimmed.isEmpty()) return !lease.isIsExpired();

        trimmed = trimmed.toLowerCase();
        return !lease.isIsExpired() &&
                (lease.getPlotName().toLowerCase().contains(trimmed)
                || lease.getSpaceName().toLowerCase().contains(trimmed)
                || lease.getTenantName().toLowerCase().contains(trimmed));
    }

    public void add() {
        var numDays = selectedDate.get().getMonth().length(selectedDate.get().isLeapYear());
        lastDay = LocalDate.of(selectedDate.get().getYear(), selectedDate.get().getMonthValue(), numDays);
        var size = leases.size() - excluded.size();

        dialogMessage = "Rent of " + lastDay.format(formatter) + "\n\n for " + size + " leases shall be charged \n\n Are you Sure? ";
        dialogTrigger.set(true);
        if(!dialogResult) return;

        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private class ResponseTask extends Task<Boolean> {
        int entries;

        @Override
        protected Boolean call() throws Exception {
            updateMessage("processing entries ...");
            Thread.sleep(500);

            var bytes = getBytes();
            var request = new Request(Function.AddBulkRent.ordinal(), bytes);

            updateMessage("requesting ...");
            Thread.sleep(500);
            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return false;
            }
            var isSuccess = response.getPacket()[0] != 0;
            updateMessage(isSuccess ? "successfully added " + entries + " entries" : "failed to add entries");
            Thread.sleep(500);
            return isSuccess;
        }

        private ByteBuffer getBytes() {
            var dateBytes = (lastDay.toString() + '\0').getBytes(StandardCharsets.US_ASCII);
            var narrationBytes = (lastDay.format(formatter) + '\0').getBytes(StandardCharsets.US_ASCII);

            int total = 29 + dateBytes.length + narrationBytes.length;
            int size = 0;
            entries = 0;
            var buffers = new ArrayList<ByteBuffer>();
            for (var lease : leases) {
                if (excluded.contains(lease)) continue;
                for (var rec : lease.getFixedReceivables()) {
                    entries++;
                    size += total;
                    buffers.add(ByteBuffer.allocate(total)
                            .order(ByteOrder.LITTLE_ENDIAN)
                            .putInt(0)
                            .putInt(lease.getPlotId())
                            .putInt(lease.getSpaceId())
                            .putInt(lease.getTenantId())
                            .putInt(AppData.controlIdOfReceivable)
                            .putInt(rec.getHeadId())
                            .putInt(rec.getAmount())
                            .put((byte) 1)
                            .put(dateBytes)
                            .put(narrationBytes)
                    );
                }
            }
            var bytes = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
            for (var buffer : buffers) bytes.put(buffer.array());
            return bytes;
        }
    }
}
