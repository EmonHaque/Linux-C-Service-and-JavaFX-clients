package Views.Report;

import CellTemplates.SelectionBox.TenantTemplate;
import CellTemplates.Visual.TenantVisual;
import Models.Tenant;
import ViewModels.Report.BaseLedgerVM;
import ViewModels.Report.TenantLedgerVM;
import abstracts.View;
import helpers.Icons;
import interfaces.ISetSelectionBoxContent;

public class TenantLedger extends BaseLedger<Tenant> {

    @Override
    protected String getIcon() {
        return Icons.Tenant;
    }

    @Override
    protected ISetSelectionBoxContent<Tenant> getVisual() {
        return new TenantVisual();
    }

    @Override
    protected String getTemplate() {
        return TenantTemplate.class.getName();
    }

    @Override
    protected BaseLedgerVM<Tenant> getViewModel() {
        return new TenantLedgerVM();
    }
}
