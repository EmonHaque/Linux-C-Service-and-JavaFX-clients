package trees;

import Models.Lease;
import abstracts.WrapTreeCellBase;
import controls.SVGRegion;
import controls.texts.HiTexts;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import ridiculous.AppData;
import skinned.ExtendedSeparator;
import skinned.ExtendedTreeView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class BulkRentTree extends ExtendedTreeView<Lease> {
    public ObservableList<Lease> selectedItems;
    private boolean isFiltering;
    private final FilteredList<Lease> leases;

    public BulkRentTree(FilteredList<Lease> leases, StringProperty query) {
        this.leases = leases;
        setRoot(new TreeItem<>());
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        setCellFactory(v -> new LeaseCell(query));

        addItems(leases);
        selectedItems = FXCollections.observableArrayList();
        getSelectionModel().getSelectedItems().addListener(this::onSelectionChanged);
        leases.addListener(this::onItemsChanged);
    }

    private void onSelectionChanged(ListChangeListener.Change<? extends TreeItem<Lease>> change) {
        // all levels can be selected
        // if you setDisable(true) in TreeCell, you can't collapse/expand branch
        // that's an issue
        if (isFiltering) return;
        while (change.next()) {
            if (change.wasAdded()) {
                if (change.getRemovedSize() > 0) {
                    for (var tree : change.getRemoved()) {
                        if (getTreeItemLevel(change.getRemoved().get(0)) != 1) {
                            selectedItems.remove(tree.getValue());
                        }
                    }
                }
                if (getTreeItemLevel(change.getAddedSubList().get(0)) != 1) {
                    selectedItems.add(change.getAddedSubList().get(0).getValue());
                }
            }
            else if (change.wasRemoved()) {
                if (getTreeItemLevel(change.getRemoved().get(0)) != 1) {
                    selectedItems.remove(change.getRemoved().get(0).getValue());
                }
            }
        }
    }

    private void onItemsChanged(ListChangeListener.Change<? extends Lease> change) {
        // first part
        isFiltering = true;
        getSelectionModel().clearSelection();
        while (change.next()) {
            if (change.wasAdded()) {
                if (change.getRemovedSize() > 0) {
                    removeItems((List<Lease>) change.getRemoved());
                }
                addItems((List<Lease>) change.getAddedSubList());
            }
            else if (change.wasRemoved()) {
                removeItems((List<Lease>) change.getRemoved());
            }
        }
        sort();
        for (var item : selectedItems) {
            for (var branch : getRoot().getChildren()) {
                for (var leaf : branch.getChildren()) {
                    if (!leaf.getValue().equals(item)) continue;
                    getSelectionModel().select(leaf);
                }
            }
        }
        isFiltering = false;

        // second part
//        isFiltering = true;
//        getSelectionModel().clearSelection();
//        getRoot().getChildren().clear();
//        var newList = new ArrayList<>(leases);
//        newList.sort(Comparator.comparing(Lease::getPlotName).thenComparing(Lease::getSpaceName));
//        addItems(newList);
//        isFiltering = false;
    }

    private void addItems(List<Lease> leases) {
        for (var lease : leases) {
            var hasIt = false;
            TreeItem<Lease> plot = null;
            for (var item : getRoot().getChildren()) {
                if (item.getValue().getPlotName().equals(lease.getPlotName())) {
                    plot = item;
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                plot = new TreeItem<>(lease);
                plot.setExpanded(true);
                getRoot().getChildren().add(plot);
            }
            var leaf = new TreeItem<>(lease);
            plot.getChildren().add(leaf);
        }
    }

    private void removeItems(List<Lease> leases) {
        for (var lease : leases) {
            TreeItem<Lease> plot = null;
            TreeItem<Lease> leaf = null;
            var found = false;
            for (var group : getRoot().getChildren()) {
                for (var item : group.getChildren()) {
                    if (!item.getValue().equals(lease)) continue;
                    leaf = item;
                    found = true;
                    break;
                }
                if (found) {
                    plot = group;
                    break;
                }
            }
            plot.getChildren().remove(leaf);
            if (plot.getChildren().size() == 0) getRoot().getChildren().remove(plot);
        }
    }

    private void sort() {
        getRoot().getChildren().sort(Comparator.comparing(x -> x.getValue().getPlotName()));
        for (var item : getRoot().getChildren()) {
            // what's the problem with x?
            //item.getChildren().sort(Comparator.comparing(x -> x.getValue().getSpaceName()));
            item.getChildren().sort(Comparator.comparing(y -> y.getValue().getSpaceName()));
        }
    }

    private class LeaseCell extends WrapTreeCellBase<Lease> {
        private HiTexts hiContent;
        private Text space, tenant;
        private Popup toolTip;
        private GridPane popGrid;
        private final StringProperty query;
        private ColumnConstraints firstColumn;

        public LeaseCell(StringProperty query) {
            //super();
            this.query = query;
        }

        @Override
        protected void initializeUI() {
            space = new Text() {{setFill(Color.WHITE);}};
            tenant = new Text() {{setFill(Color.WHITE);}};
            hiContent = new HiTexts(space, tenant);

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().add(firstColumn);
                add(hiContent, 0, 0);
            }};

            popGrid = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setMinWidth(100); setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}}
                );
                add(new Text("Head") {{setFill(Color.WHITE);}}, 0, 0);
                add(new Text("Amount") {{setFill(Color.WHITE);}}, 1, 0);
                add(new ExtendedSeparator(), 0, 1, 2, 1);

                setPadding(new Insets(5));
                setBackground(Background.fill(Constants.BackgroundColor));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
            }};
            toolTip = new Popup() {{getContent().add(popGrid);}};
        }

        @Override
        protected void resetValues(Lease oldValue) {
            hiContent.queryProperty().unbind();
            hiContent.queryProperty().set("");
            hiContent.removeEventHandler(MouseEvent.MOUSE_ENTERED, this::onMouseEnter);
            hiContent.removeEventHandler(MouseEvent.MOUSE_EXITED, this::onMouseExit);
        }

        @Override
        protected void setValues(Lease nv) {
            if (level == 1) {
                space.textProperty().bind(nv.plotNameProperty().concat(" ("));
                tenant.textProperty().bind(Bindings.size(item.getChildren()).asString().concat(")"));
                space.setFont(Font.font(null, FontWeight.BOLD, -1));
                tenant.setFont(Font.font(null, FontPosture.REGULAR, -1));
            }
            else if (level == 2) {
                space.textProperty().bind(nv.spaceNameProperty().concat(" - "));
                tenant.textProperty().bind(nv.tenantNameProperty());
                space.setFont(Font.font(null, FontWeight.NORMAL, -1));
                tenant.setFont(Font.font(null, FontPosture.ITALIC, -1));
                setToolTip();
                hiContent.addEventHandler(MouseEvent.MOUSE_ENTERED, this::onMouseEnter);
                hiContent.addEventHandler(MouseEvent.MOUSE_EXITED, this::onMouseExit);
            }
            hiContent.queryProperty().bind(query);
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth();
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            hiContent.setPrefWidth(remainder);
            return hiContent.prefHeight(remainder);
        }

        private void setToolTip() {
            var receivables = AppData.leases.stream().filter(x -> x.getId() == getItem().getId()).findFirst().get().getFixedReceivables();
            int row = 2;
            int total = 0;
            if (popGrid.getRowCount() > row) {
                popGrid.getChildren().remove(3, popGrid.getChildren().size());
            }
            for (var receivable : receivables) {
                var head = new Text(AppData.heads.stream().filter(x -> x.getId() == receivable.getHeadId()).findFirst().get().getName()) {{
                    setFill(Color.WHITE);
                }};
                var amount = new Text(String.format("%,d", receivable.getAmount())) {{setFill(Color.WHITE);}};
                popGrid.add(head, 0, row);
                popGrid.add(amount, 1, row);
                total += receivable.getAmount();
                row++;
            }
            if (row == 3) return;
            popGrid.add(new ExtendedSeparator(), 0, row, 2, 1);
            popGrid.add(new Text("Total") {{setFill(Color.WHITE);}}, 0, row + 1);
            popGrid.add(new Text(String.format("%,d", total)) {{setFill(Color.WHITE);}}, 1, row + 1);
        }

        private void onMouseEnter(MouseEvent e) {
            if (level == 1) return;
            if (!isSelected()) {
                setBackground(Background.fill(Constants.BackgroundColorLight));
            }
            toolTip.show(hiContent, e.getScreenX() + 20, e.getScreenY() + 10);
        }

        private void onMouseExit(MouseEvent e) {
            if (level == 1) return;
            toolTip.hide();
            if (!isSelected()) setBackground(null);
        }
    }
}
