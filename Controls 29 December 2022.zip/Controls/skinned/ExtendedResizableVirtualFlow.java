package skinned;

import helpers.Constants;
import javafx.scene.control.IndexedCell;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.skin.VirtualFlow;
import skins.ExtendedScrollBarSkin;

@SuppressWarnings("rawtypes")
public class ExtendedResizableVirtualFlow<T extends IndexedCell> extends VirtualFlow<T> {
    public ScrollBar vBar;

    public ExtendedResizableVirtualFlow() {
        vBar = getVbar();
        var hBar = getHbar();

        vBar.setSkin(new ExtendedScrollBarSkin(vBar));
        hBar.setSkin(new ExtendedScrollBarSkin(hBar));
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        fitCellWidths();
    }

    private void fitCellWidths() {
        if (!isVertical() || getVbar().isVisible())
            return;
        double width = getWidth() - Constants.ScrollBarSize;
        for (T cell : getCells()) {
            cell.resize(width, cell.getHeight());
        }
    }
}
