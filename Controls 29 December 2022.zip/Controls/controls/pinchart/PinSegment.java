package controls.pinchart;

import javafx.animation.Animation;
import javafx.animation.ScaleTransition;
import javafx.animation.StrokeTransition;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.util.Duration;

public class PinSegment extends Line {
    private Color normal, highlight;
    private StrokeTransition strokeAnim;
    private ScaleTransition scaleAnim;
    public PinSegment(Color normal, Color highlight) {
        this.normal = normal;
        this.highlight = highlight;
        strokeAnim = new StrokeTransition(Duration.millis(500), this);
        scaleAnim = new ScaleTransition(Duration.millis(500), this);
       
        setStroke(normal);
        setStrokeWidth(1.5);
    }
    public void setValue(double x, double yStart, double yEnd){
        setStartX(x);
        setEndX(x);
        setStartY(yStart);
        setEndY(yEnd);
    }
    public void highlightColor() {
        scaleAnim.setToX(1.5);
        animate(highlight);
    }

    public void normalColor() {
        scaleAnim.setToX(1);
        animate(normal);
    }

    private void animate(Color color) {
        if (strokeAnim.getStatus() == Animation.Status.RUNNING) {
            strokeAnim.stop();
            scaleAnim.stop();
        }
        
        strokeAnim.setFromValue((Color) getStroke());
        strokeAnim.setToValue(color);
        strokeAnim.play();
        scaleAnim.play();
    }
}
