package controls;

import javafx.animation.FadeTransition;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.util.Duration;
import model.PinSeries;

import java.util.ArrayList;
import java.util.List;

import controls.areachart.AreaStroke;
import controls.pinchart.PinStack;

public class Lines extends Region {
    private boolean isLoaded;
    private int numLines = 6;
    private List<PinSeries> series;
    private double y1LabelWidth, y2LabelWidth, xLabelWidth, xLabelHeight, y1Min, y1Max, y2Min, y2Max;
    private double availableWidth, availableHeight;
    private Text leftTitle, rightTitle;

    private Group xLabels, y1Labels, y2Labels, yMajors;
    private AreaStroke line;
    private List<PinStack> pins;

    private Rectangle widthClip;
    private FadeTransition y1Anim, y2Anim;
    private ScaleTransition yMajorAnim;
    private Timeline lineAnim;

    public ObjectProperty<List<PinSeries>> seriesProperty;

    public Lines(String y1Title, String y2Title) {
        xLabels = new Group();
        xLabels.setManaged(false);
        getChildren().add(xLabels);

        addYs();
        pins = new ArrayList<>();
        line = new AreaStroke();
        line.getTransforms().add(new Scale(1, -1));
        getChildren().add(line);
        line.setManaged(false);

        leftTitle = new Text(y1Title);
        leftTitle.setFill(Color.WHITE);
        leftTitle.setFont(Font.font(null, FontWeight.BOLD, -1));
        leftTitle.setRotate(-90);
        getChildren().add(leftTitle);

        rightTitle = new Text(y2Title);
        rightTitle.setFill(Color.WHITE);
        rightTitle.setFont(Font.font(null, FontWeight.BOLD, -1));
        rightTitle.setRotate(90);
        getChildren().add(rightTitle);

        leftTitle.setManaged(false);
        rightTitle.setManaged(false);

        seriesProperty = new SimpleObjectProperty<>();
        seriesProperty.addListener(this::onSeriesChanged);

        widthClip = new Rectangle(0, 0, 0, 0);
        line.setClip(widthClip);

        y1Anim = new FadeTransition(Duration.millis(500), y1Labels);
        y2Anim = new FadeTransition(Duration.millis(500), y2Labels);
        yMajorAnim = new ScaleTransition(Duration.millis(500), yMajors);
        lineAnim = new Timeline();
        lineAnim.setDelay(Duration.millis(500));

        y1Anim.setDelay(Duration.millis(500));
        y1Anim.setFromValue(0);
        y1Anim.setToValue(1);

        y2Anim.setDelay(Duration.millis(500));
        y2Anim.setFromValue(0);
        y2Anim.setToValue(1);

        yMajorAnim.setFromY(0);
        yMajorAnim.setToY(1);

        lineAnim.setOnFinished(e -> line.setClip(null));
    }

    private void onSeriesChanged(ObservableValue<?> obs, List<PinSeries> ov, List<PinSeries> nv) {
        for (var n : pins) {
            getChildren().remove(n);
        }
        pins.clear();
        xLabels.getChildren().clear();
        yMajors.setScaleY(0);
        y1Labels.setOpacity(0);
        y2Labels.setOpacity(0);

        if (nv == null) {
            line.clear();
        }
        else {
            series = nv;
            setMinMax();
            double y1Step = y1Max / 5;
            double y2Step = y2Max / 5;
            double y1Current = y1Min;
            double y2Current = y2Min;
            for (int i = 0; i < numLines; i++) {
                var y1 = (Text) y1Labels.getChildren().get(i);
                var y2 = (Text) y2Labels.getChildren().get(i);
                y1.setText(String.format("%.1f", y1Current));
                y2.setText(String.format("%.1f", y2Current));

                y1LabelWidth = y1.prefWidth(-1);
                y2LabelWidth = y2.prefWidth(-1);

                y1Current += y1Step;
                y2Current += y2Step;
            }
            line.setData(series.stream().map(x -> x.getLineValue()).toList());

            pins = new ArrayList<>();
            for (var s : series) {
                var pin = new PinStack(s);
                getChildren().add(pin);
                pins.add(pin);
                pin.setManaged(false);
            }
            line.toFront();
           
            yMajorAnim.play();
            y1Anim.play();
            y2Anim.play();
            if (isLoaded) {
                resetLineAnim();
                lineAnim.play();
            }
        }
    }

    private void resetLineAnim(){
        widthClip.setWidth(0);
        widthClip.setHeight(availableHeight);
        line.setClip(widthClip);

        lineAnim.getKeyFrames().clear();
        var widthkey = new KeyValue(widthClip.widthProperty(), availableWidth, Interpolator.EASE_IN);
        var widthFrame = new KeyFrame(Duration.millis(1000), widthkey);
        lineAnim.getKeyFrames().add(widthFrame);
    }

    private void setMinMax() {
        y1Max = y2Max = 0;
        xLabelHeight = xLabelWidth = 0;
        for (int i = 0; i < series.size(); i++) {
            var y1Total = series.get(i).getValues().stream().mapToDouble(x -> x).sum();
            if (y1Max < y1Total)
                y1Max = y1Total;
            var y2value = series.get(i).getLineValue();
            if (y2Max < y2value)
                y2Max = y2value;

            var xLabel = new Text(series.get(i).getName());
            xLabel.setFill(Color.WHITE);
            xLabel.setRotate(-90);
            xLabel.setManaged(false);
            xLabels.getChildren().add(xLabel);

            if (xLabelHeight < xLabel.prefHeight(-1))
                xLabelHeight = xLabel.prefHeight(-1);
            if (xLabelWidth < xLabel.prefWidth(-1))
                xLabelWidth = xLabel.prefWidth(-1);
        }
    }

    private void addYs() {
        yMajors = new Group();
        y1Labels = new Group();
        y2Labels = new Group();
        getChildren().addAll(yMajors, y1Labels, y2Labels);
        yMajors.setManaged(false);
        y1Labels.setManaged(false);
        y2Labels.setManaged(false);

        for (int i = 0; i < numLines; i++) {
            var line = new Line();
            line.setStroke(Color.GRAY);
            line.getStrokeDashArray().addAll(5d, 2d);
            yMajors.getChildren().add(line);

            var y1Label = new Text();
            y1Label.setFill(Color.WHITE);
            y1Labels.getChildren().add(y1Label);

            var y2Label = new Text();
            y2Label.setFill(Color.WHITE);
            y2Labels.getChildren().add(y2Label);

            line.setManaged(false);
            y1Label.setManaged(false);
            y2Label.setManaged(false);

            line.setMouseTransparent(true);
            y1Label.setMouseTransparent(true);
            y2Label.setMouseTransparent(true);
        }
    }

    @Override
    protected void layoutChildren() {
        // if (!y1Labels.isVisible()) {
        // return;
        // }
        var height = getHeight();
        var width = getWidth();
        double bottomMargin = 10;
        double leftRightMargin = 5;

        var leftTitleWidth = leftTitle.prefHeight(-1);
        var rightTitleWidth = rightTitle.prefHeight(-1);
        availableHeight = height - xLabelWidth - bottomMargin;

        var colWidth = (width - leftTitleWidth - rightTitleWidth - y1LabelWidth - y2LabelWidth - 2 * leftRightMargin) / series.size();
        var vSpace = availableHeight / numLines;

        double pinX = leftTitleWidth + y1LabelWidth + leftRightMargin;
        double lineX = pinX;
        double lineY = availableHeight;
        double xLabelX = pinX + colWidth / 2;

        availableWidth = width - leftTitleWidth - y1LabelWidth - y2LabelWidth - rightTitleWidth - 2 * leftRightMargin;

        for (int i = 0; i < numLines; i++) {
            var line = (Line) yMajors.getChildren().get(i);
            var y1 = (Text) y1Labels.getChildren().get(i);
            var text = (Text) y2Labels.getChildren().get(i);

            var labelY = lineY - 2;
            var startX = leftTitleWidth + leftRightMargin;
            var endX = width - rightTitleWidth - leftRightMargin;

            line.setStartX(startX);
            line.setEndX(endX);
            line.setStartY(lineY);
            line.setEndY(lineY);

            y1.setX(startX);
            y1.setY(labelY);

            text.setX(endX - text.prefWidth(-1));
            text.setY(labelY);

            lineY -= vSpace;
        }

        double numDataPoints = pins.size();
        for (int i = 0; i < numDataPoints; i++) {
            var text = (Text) xLabels.getChildren().get(i);
            var pin = pins.get(i);

            text.setY(height - xLabelHeight - bottomMargin + 3); // fix the alignment
            text.setX(xLabelX - text.prefWidth(-1) / 2);
            xLabelX += colWidth;

            var h = pin.getTotal() * (availableHeight - vSpace) / y1Max;
            pin.makePin(colWidth, h);
            pin.resizeRelocate(pinX, availableHeight, colWidth, h);
            pinX += colWidth;
        }
        if (!isLoaded) {
            isLoaded = true;
            resetLineAnim();
            lineAnim.play();
        }
        line.setTranslateX(lineX + colWidth / 2);
            line.setTranslateY(availableHeight);
            line.setValue(availableWidth - colWidth, availableHeight - vSpace, y2Max);

        leftTitle.setTranslateX(-leftTitle.prefWidth(-1) / 2 + leftTitleWidth / 2);
        leftTitle.setTranslateY(availableHeight / 2 - leftTitleWidth / 2);

        rightTitle.setTranslateX(width - rightTitle.prefWidth(-1) / 2 - leftTitleWidth / 2);
        rightTitle.setTranslateY(availableHeight / 2 - rightTitleWidth / 2);
    }
}
