package controls.daymonth;

import helpers.Constants;
import javafx.animation.FillTransition;
import javafx.animation.ParallelTransition;
import javafx.geometry.Pos;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class DayLabel extends StackPane {
    private int day;
    private Text dayText;
    private Circle circle;
    private FillTransition dayAnim, circleAnim;
    private ParallelTransition transitAnim;
    private DropShadow effect;
    private boolean isSelected, isToday;

    public DayLabel(int day) {
        this.day = day;
        dayText = new Text(String.valueOf(day));
        dayText.setFill(Color.WHITE);
        circle = new Circle();
        circle.setRadius(20);
        circle.setFill(Constants.BackgroundColorLight);

        dayText.setMouseTransparent(true);
        circle.setMouseTransparent(true);

        effect = new DropShadow();
        dayAnim = new FillTransition(Duration.millis(500));
        circleAnim = new FillTransition(Duration.millis(500));
        dayAnim.setShape(dayText);
        circleAnim.setShape(circle);
        transitAnim = new ParallelTransition(circleAnim, dayAnim);
        getChildren().addAll(circle, dayText);
        setAlignment(Pos.CENTER);
        addEventHandler(MouseEvent.ANY, this::handleMouse);
    }

    private void handleMouse(MouseEvent e){
        if(isSelected || isToday) return;
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED){
            e.consume();
            transitAnim.stop();
            circleAnim.setToValue(Constants.BackgroundColor);
            dayAnim.setToValue(Color.WHEAT);
            transitAnim.play();
            setEffect(effect);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED){
            e.consume();
            transitAnim.stop();
            circleAnim.setToValue(Constants.BackgroundColorLight);
            dayAnim.setToValue(Color.WHITE);
            transitAnim.play();
            setEffect(null);
        }
    }
    public void setSelected(boolean value){
        isSelected = value;
        if(isSelected){
            circle.setFill(Color.CORNFLOWERBLUE);
            dayText.setFill(Color.BLACK);
            setEffect(effect);
        }
        else{
            circle.setFill(Constants.BackgroundColorLight);
            dayText.setFill(Color.WHITE);
            setEffect(null);
        }
    }
    public void setToday(boolean value){
        isToday = value;
        if(isSelected) return;
        if(isToday){
            circle.setFill(Color.CORAL);
            dayText.setFill(Color.BLACK);
            setEffect(effect);
        }
        else{
            circle.setFill(Constants.BackgroundColorLight);
            dayText.setFill(Color.WHITE);
            setEffect(null);
        }
    }
    public int getDayNo(){
        return day;
    }
}
