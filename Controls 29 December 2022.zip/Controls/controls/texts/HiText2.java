package controls.texts;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

public class HiText2 extends TextFlow {
    private final StringProperty queryProperty;
    private final Text element;

    public HiText2() {
        queryProperty = new SimpleStringProperty("");
        element = new Text(""){{ setFill(Color.WHITE);}};
        getChildren().add(element);
        queryProperty.addListener(this::onQueryChanged);
    }

    public void setText(String text){ element.setText(text);}

    public StringProperty textProperty() { return element.textProperty(); }

    public StringProperty queryProperty() { return queryProperty; }

    public ObjectProperty<Paint> fillProperty() { return element.fillProperty(); }

    public void setFill(Color color){ element.setFill(color); }

    private void onQueryChanged(ObservableValue<?> o, String ov, String nv){
        getChildren().clear();
        if(nv == null || nv.isEmpty() || nv.isBlank()){
            getChildren().add(element);
        }
        else{
            int index = 0;
            var filter = queryProperty.get().toLowerCase();
            int filterLength = filter.length();

            var content = element.getText();
            var text = content.toLowerCase();

            for (int i = text.indexOf(filter); i > -1; i = text.indexOf(filter, i + 1)) {
                var unmatchedContent = content.substring(index, i);
                if (unmatchedContent.length() > 0) {
                    var unmatched = new Text(unmatchedContent);
                    unmatched.setFill(element.getFill());
                    getChildren().add(unmatched);
                }
                var match = new Text(content.substring(i, i + filterLength));
                match.setFont(Font.font(null, FontWeight.BOLD, -1));
                match.setFill(Color.CORNFLOWERBLUE);

                match.setUnderline(true);
                getChildren().add(match);
                index = i + filterLength;
            }
            if (index < text.length()) {
                var unmatched = new Text(content.substring(index));
                unmatched.setFill(element.getFill());
                getChildren().add(unmatched);
            }
        }
    }
}
