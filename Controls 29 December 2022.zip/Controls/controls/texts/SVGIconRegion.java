package controls.texts;

import javafx.scene.layout.Background;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;

public class SVGIconRegion extends Region {
    private SVGPath svg;

    public SVGIconRegion(String path) {
        svg = new SVGPath();
        svg.setContent(path);

        fixSize(12);
        setShape(svg);
        setBackground(Background.fill(Color.WHITE));
    }

    public SVGIconRegion(String path, double size) {
        this(path);
        fixSize(size);
    }

    public void setContent(String path){
        svg.setContent(path);
    }

    public void setFill(Color color){
        setBackground(Background.fill(color));
    }

    private void fixSize(double size){
        setPrefSize(size, size);
        setMaxSize(size, size);
        setMinSize(size, size);
    }
}
