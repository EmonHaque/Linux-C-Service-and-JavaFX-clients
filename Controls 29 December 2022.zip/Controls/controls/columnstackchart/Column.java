package controls.columnstackchart;

import javafx.animation.Animation;
import javafx.animation.FillTransition;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.util.Duration;

public class Column extends Path {
    private MoveTo move;
    private LineTo leftLine, topLine, rightLine;
    private ArcTo arc;
    private Color normal, highlight;
    private boolean isRound;
    private FillTransition anim;

    public Column(Color normal, Color highlight, boolean isRound) {
        this.normal = normal;
        this.highlight = highlight;
        this.isRound = isRound;

        move = new MoveTo();
        leftLine = new LineTo();
        rightLine = new LineTo();

        if (isRound) {
            arc = new ArcTo();
            getElements().addAll(move, leftLine, arc, rightLine);
        }
        else {
            topLine = new LineTo();
            getElements().addAll(move, leftLine, topLine, rightLine);
        }

        setFill(normal);
        setStroke(null);
        anim = new FillTransition(Duration.millis(500), this);
    }

    public void setValue(double x, double y, double width, double height) {
        move.setX(x);
        move.setY(y);

        double xEnd = x + width;
        double yEnd = isRound ? y + height * 0.8 : y + height;

        leftLine.setX(x);
        leftLine.setY(yEnd);
        rightLine.setX(xEnd);
        rightLine.setY(y);

        if (isRound) {
            arc.setX(xEnd);
            arc.setY(yEnd);
            arc.setRadiusX(width / 2);
            arc.setRadiusY(height * 0.2);
        }
        else {
            topLine.setX(xEnd);
            topLine.setY(yEnd);
        }
    }

    public void highlightColor() {
        animate(highlight);
        setStroke(Color.WHITE);
    }

    public void normalColor() {
        animate(normal);
        setStroke(null);
    }

    private void animate(Color color) {
        if (anim.getStatus() == Animation.Status.RUNNING) {
            anim.stop();
        }
        anim.setFromValue((Color) getFill());
        anim.setToValue(color);
        anim.play();
    }
}
