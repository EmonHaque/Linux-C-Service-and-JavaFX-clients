package editables;

import controls.SVGIcon;
import controls.texts.IntegerBox;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class EditInteger extends GridPane {
    private final Text label, content;
    private final IntegerBox box;
    private final SVGIcon icon;
    private final EditPane parent;

    private final StringProperty textProperty;

    public EditInteger(String hint, String icon, boolean isRequired, EditPane parent) {
        this.parent = parent;
        box = new IntegerBox(hint, icon, isRequired){{ setVisible(false);}};
        this.icon = new SVGIcon(icon);
        label = new Text(hint) {{setFill(Color.GRAY);}};
        content = new Text() {{setFill(Color.WHITE);}};

        add(box, 0, 0, 2, 2);
        add(this.icon, 0, 0);
        add(label, 1, 0);
        add(content, 0, 1, 2, 1);

        getColumnConstraints().addAll(
                new ColumnConstraints(),
                new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}}
        );
        setVgap(5);
        setHgap(5);

        textProperty = new SimpleStringProperty("");
        parent.isOnEditProperty().addListener(this::onIsOnEditChanged);
        textProperty.addListener(this::onTextChanged);
    }
    private void onIsOnEditChanged(Observable o) {
        if (parent.isOnEditProperty().get()) {
            icon.setVisible(false);
            label.setVisible(false);
            content.setVisible(false);
            box.setVisible(true);
        }
        else {
            box.setVisible(false);
            icon.setVisible(true);
            label.setVisible(true);
            content.setVisible(true);
        }
    }

    private void onTextChanged(Observable o) {
        content.setText(textProperty.get());
        box.setText(textProperty.get());
    }

    public StringProperty textProperty() {return textProperty;}
}
