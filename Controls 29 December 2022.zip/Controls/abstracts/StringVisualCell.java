package abstracts;

import controls.texts.HiText2;
import helpers.Constants;
import interfaces.IReturnNameAndId;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;

public class StringVisualCell<T extends IReturnNameAndId<T>> extends ListCell<T> {
    private final StringProperty query;
    private final HiText2 text;

    public StringVisualCell(StringProperty query, boolean needPad) {
        this.query = query;
        text = new HiText2();

        if (needPad) setPadding(new Insets(2.5, 0, 2.5, 0));

        setBackground(null);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        itemProperty().addListener(this::onItemChanged);
        hoverProperty().addListener(this::onHover);
    }

    private void onItemChanged(ObservableValue<?> o, T ov, T nv) {
        if (ov != null) {
            text.textProperty().unbind();
            text.queryProperty().unbind();
        }
        if (nv != null) {
            text.textProperty().bind(nv.nameProperty());
            text.queryProperty().bind(query);
        }
    }

    private void onHover(ObservableValue<?> o, boolean ov, boolean nv) {
        if (nv && !isEmpty()) {
            if (!isSelected())
                setBackground(Background.fill(Constants.BackgroundColorLight));
        }
        else {
            if (!isSelected())
                setBackground(null);
        }
    }

    @Override
    protected void updateItem(T item, boolean empty) {
        super.updateItem(item, empty);
        if (empty) {
            setGraphic(null);
            setBackground(null);
        }
        else {
            setGraphic(text);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}
