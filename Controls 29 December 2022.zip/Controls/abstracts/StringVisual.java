package abstracts;

import controls.texts.HiText;
import interfaces.IReturnNameAndId;
import interfaces.ISetSelectionBoxContent;
import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class StringVisual<T extends IReturnNameAndId<T>> extends HiText implements ISetSelectionBoxContent<T> {
    protected Text text;
    private T content;
    public StringVisual() {
        text = new Text(){{setFill(Color.WHITE);}};
    }

    @Override
    public void setContent(T item) {
        this.content = item;
        text.textProperty().unbind(); // ?
        text.textProperty().bind(item.nameProperty());
    }

    @Override
    public T getContent() {
        return content;
    }

    @Override
    public Node getVisual() {
        return text;
    }
}
