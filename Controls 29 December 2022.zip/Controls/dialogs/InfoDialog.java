package dialogs;

import abstracts.DialogBase;
import controls.buttons.ActionButton;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;

public class InfoDialog extends DialogBase {
    ActionButton closeButton;

    public InfoDialog(String title, String message) {
        super();
        titlelabel.setText(title);
        var messageLabel = new Label(message);
        messageLabel.setTextFill(Color.WHITE);
        root.setCenter(messageLabel);

        closeButton = new ActionButton(Icons.CloseCircle, 16, "close");
        closeButton.setAction(this::closeDialog);
        
        buttonsPane.getChildren().add(closeButton);
        GridPane.setHgrow(closeButton, Priority.ALWAYS);
        GridPane.setHalignment(closeButton, HPos.RIGHT);
        GridPane.setMargin(closeButton, new Insets(5, 5, 5, 0));
    }

    @Override
    public void showDialog(double width, double height) {
        super.showDialog(width, height);
        show();
    }

}
