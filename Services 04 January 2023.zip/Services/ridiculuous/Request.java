package ridiculuous;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class Request {
    private int method;
    private ByteBuffer bytes;

    public Request(int method, ByteBuffer bytes) {
        this.method = method;
        this.bytes = bytes;
    }

    public byte[] getBytes() {
        var buffer = ByteBuffer.allocate(12 + bytes.array().length).order(ByteOrder.LITTLE_ENDIAN);
        buffer.putInt(8 + bytes.array().length);
        buffer.putInt(Channels.getInstance().userId);
        buffer.putInt(method);
        buffer.put(bytes.array());
        return buffer.array();
    }
}
