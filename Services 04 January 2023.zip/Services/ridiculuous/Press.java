package ridiculuous;

import javafx.print.Printer;
import javafx.print.PrinterJob;

import java.util.ArrayList;
import java.util.List;

public class Press {
    private List<Printer> printers;
    private boolean isAvailable;

    public Press() {
        printers = new ArrayList<>();
        var iterator = Printer.getAllPrinters().iterator();
        while (iterator.hasNext()) {
            printers.add(iterator.next());
        }
        isAvailable = printers.size() > 0;
    }

    public boolean available(){ return isAvailable; };
    public List<Printer> getPrinters() { return printers; }
    public PrinterJob getPrinter(Printer printer){
        return PrinterJob.createPrinterJob(printer);
    }
}
