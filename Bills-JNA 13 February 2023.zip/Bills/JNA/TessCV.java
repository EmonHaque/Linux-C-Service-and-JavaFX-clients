package JNA;

import com.sun.jna.Library;

public interface TessCV extends Library {
    void initialize(String dataPath, String language);
    void setWhiteList(String characters);
    String getText(String file);

    void setImageFile(String file);
    void setImageBuffer(int size, byte[] data);

    ImageCV getOriginalImage();
    ImageCV getInvertedGrayImage();
    ImageCV getInvertedBinaryImage();

    FXMat getOriginalMat();
    FXMat getInvertedGrayMat();
    FXMat getInvertedBinaryMat();

    void destroyTesseract();
    void destroyImage();
}
