package Views.Accounts;

import Model.Mobile;
import ViewModels.Accounts.EditBaseVM;
import ViewModels.Accounts.EditMobileVM;
import abstracts.ListCellBase;
import controls.buttons.ActionButton;
import controls.texts.TextBoxClean;
import helpers.Icons;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import ridiculous.AppData;
import skinned.ExtendedListView;

public class Mobiles extends EditBase<Mobile> {
    private EditMobileVM vm;

    @Override
    protected String getHeader() {
        return "Mobiles";
    }

    @Override
    protected EditBaseVM<Mobile> getViewModel() {
        vm = new EditMobileVM();
        return vm;
    }

    @Override
    protected Node getCentralNode() {
        return new ExtendedListView<>(AppData.mobiles){{
            setEditable(true);
            setPadding(new Insets(5,0,0,0));
            setCellFactory(v -> new ListCellBase<>() {
                private Text name, number;
                private TextBoxClean editName, editNumber;
                private ActionButton edit, cancel, save;
                private GridPane root;
                private HBox buttons;

                @Override
                protected void initializeUI() {
                    name = new Text(){{ setFill(Color.WHITE);}};
                    number = new Text(){{ setFill(Color.WHITE);}};
                    editName = new TextBoxClean();
                    editNumber = new TextBoxClean(){{ setAlignment(Pos.CENTER_RIGHT);}};

                    edit = new ActionButton(Icons.Pencil, 16, "edit"){{ setAction(() -> startEdit());}};
                    cancel = new ActionButton(Icons.CloseCircle, 16, "edit"){{ setAction(() -> cancelEdit());}};
                    save = new ActionButton(Icons.CheckCircle, 16, "edit"){{
                        setAction(() ->{
                            vm.edited = new Mobile(getItem().getId(), editName.getText().trim(), editNumber.getText().trim());
                            vm.startTask();
                            cancelEdit();
                        });
                    }};
                    buttons = new HBox(save, cancel){{ setSpacing(2.5);}};
                    root = new GridPane(){{
                        getColumnConstraints().addAll(
                                new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                                new ColumnConstraints(){{ setHalignment(HPos.RIGHT);}},
                                new ColumnConstraints(){{ setHalignment(HPos.RIGHT);}}
                        );
                        add(name, 0, 0);
                        add(number, 1, 0);
                        add(edit, 2, 0);
                        setMargin(edit, new Insets(0,0,0,5));
                    }};
                }

                @Override
                protected void onItemChanged(ObservableValue<?> o, Mobile ov, Mobile nv) {
                    if(ov != null){
                        name.textProperty().unbind();
                        number.textProperty().unbind();
                        name.setText(null);
                        number.setText(null);
                        edit.visibleProperty().unbind();
                        edit.setVisible(false);
                    }
                    if(nv != null){
                        name.textProperty().bind(nv.nameProperty());
                        number.textProperty().bind(nv.numberProperty());
                        edit.visibleProperty().bind(hoverProperty());
                    }
                }

                @Override
                protected Node getRootNode() {
                    return root;
                }

                @Override
                public void startEdit() {
                    root.getChildren().clear();
                    editName.setText(name.getText());
                    editNumber.setText(number.getText());
                    root.add(editName, 0, 0);
                    root.add(editNumber, 1, 0);
                    root.add(buttons, 2, 0);
                    save.disableProperty().bind(editName.isEmpty().or(editNumber.isEmpty()));
                    GridPane.setMargin(buttons, new Insets(0, 0, 0, 5));
                    editName.requestFocus();
                }

                @Override
                public void cancelEdit() {
                    root.getChildren().clear();
                    root.add(name, 0, 0);
                    root.add(number, 1, 0);
                    root.add(edit, 2, 0);
                    GridPane.setMargin(edit, new Insets(0, 0, 0, 5));
                }
            });
        }};
    }
}
