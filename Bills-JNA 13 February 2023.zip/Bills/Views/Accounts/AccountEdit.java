package Views.Accounts;

import ViewModels.Accounts.AccountEditVM;
import abstracts.View;
import controls.SpinningArc;
import controls.states.BiState;
import editables.EditPane;
import editables.EditText;
import editables.EditTextMultiline;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class AccountEdit extends View {
    private BiState isWrong;
    private EditText accountNo, name;
    private EditTextMultiline address;
    private Text status;
    private SpinningArc spinner;
    private EditPane editPane;
    private AccountEditVM vm;

    @Override
    protected String getHeader() {
        return "Edit Account";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new AccountEditVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        editPane = new EditPane(vm::save);
        accountNo = new EditText("Account", Icons.ControlHead, true, editPane);
        name = new EditText("Holder", Icons.Tenant, true, editPane);
        address = new EditTextMultiline("Address", Icons.Description, true, editPane);
        isWrong = new BiState(false, "Is wrong") {{setAlignment(Pos.CENTER_RIGHT);}};
        editPane.setCenter(new VBox(accountNo, name, address, isWrong) {{
            setSpacing(5);
            setVgrow(address, Priority.ALWAYS);
            setPadding(new Insets(5, 0, 5, 0));
        }});
        setCenter(editPane);

        status = new Text(){{ setFill(Color.WHITE);}};
        spinner = new SpinningArc();
        addAction(status);
        addAction(spinner);
    }

    private void bind() {
        editPane.canEditProperty().bind(AccountEditVM.selected.isNotNull());
        vm.isOnEdit.bind(editPane.isOnEditProperty());
        status.textProperty().bind(vm.status);
        spinner.visibleProperty().bind(vm.isRunning);

        AccountEditVM.selected.addListener((o, ov, nv) -> {
            if (editPane.onEdit()) editPane.setIsOnEdit(false);

            if (ov != null) {
                accountNo.textProperty().unbind();
                name.textProperty().unbind();
                address.textProperty().unbind();
                isWrong.isCheckedProperty.unbind();
            }

            if (nv != null) {
                accountNo.textProperty().bind(AccountEditVM.selected.get().nameProperty());
                name.textProperty().bind(AccountEditVM.selected.get().holderProperty());
                address.textProperty().bind(AccountEditVM.selected.get().addressProperty());
                isWrong.isCheckedProperty.bind(AccountEditVM.selected.get().isWrongProperty());
            }
        });

        vm.isOnEdit.addListener((o, ov, nv) -> {
            if (nv) {
                accountNo.textProperty().unbind();
                name.textProperty().unbind();
                address.textProperty().unbind();
                isWrong.isCheckedProperty.unbind();

                accountNo.textProperty().bindBidirectional(vm.edited.get().nameProperty());
                name.textProperty().bindBidirectional(vm.edited.get().holderProperty());
                address.textProperty().bindBidirectional(vm.edited.get().addressProperty());
                isWrong.isCheckedProperty.bindBidirectional(vm.edited.get().isWrongProperty());

                editPane.canSaveProperty().bind(
                        accountNo.isEmpty().not()
                                .and(name.isEmpty().not())
                                .and(address.isEmpty().not())
                );
            }
            else {
                accountNo.textProperty().unbindBidirectional(vm.edited.get().nameProperty());
                name.textProperty().unbindBidirectional(vm.edited.get().holderProperty());
                address.textProperty().unbindBidirectional(vm.edited.get().addressProperty());
                isWrong.isCheckedProperty.unbindBidirectional(vm.edited.get().isWrongProperty());

                accountNo.textProperty().bind(AccountEditVM.selected.get().nameProperty());
                name.textProperty().bind(AccountEditVM.selected.get().holderProperty());
                address.textProperty().bind(AccountEditVM.selected.get().addressProperty());
                isWrong.isCheckedProperty.bind(AccountEditVM.selected.get().isWrongProperty());
            }
        });
    }
}
