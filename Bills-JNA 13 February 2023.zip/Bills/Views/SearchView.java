package Views;

import Views.Search.*;
import abstracts.View;
import abstracts.ViewContainer;
import helpers.Icons;

public class SearchView extends ViewContainer {
    private final View mobile;

    public SearchView() {
        mobile = new MobileSearch();
        addView(mobile);
        addView(new DateSearch());
        addView(new Wasa());
        addView(new Desco());
        addView(new Tgcl());
        addView(new Btcl());
    }

    @Override
    protected String getIcon() {
        return Icons.Ledger;
    }

    @Override
    protected String getTip() {
        return "Reports";
    }

    @Override
    public View initialView() {
        return mobile;
    }
}
