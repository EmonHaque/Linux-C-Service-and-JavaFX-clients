package Views.Search;

import ViewModels.Search.BtclVM;
import ViewModels.Search.DepartmentSearchVM;
import helpers.Icons;

public class Btcl extends DepartmentSearch{
    @Override
    protected String getIcon() {
        return Icons.Telephone;
    }

    @Override
    protected DepartmentSearchVM getViewModel() {
        return new BtclVM();
    }
}
