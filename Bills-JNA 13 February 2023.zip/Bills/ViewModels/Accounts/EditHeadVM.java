package ViewModels.Accounts;

import Enums.Function;
import Model.Head;
import javafx.collections.ObservableList;
import ridiculous.AppData;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class EditHeadVM extends EditBaseVM<Head>{
    @Override
    public ObservableList<Head> getList() {
        return AppData.heads;
    }

    @Override
    protected int function() {
        return Function.EditHead.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var nameBytes = (edited.getName().trim() + '\0').getBytes(StandardCharsets.UTF_8);
        return ByteBuffer.allocate(4 + nameBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(edited.getId())
                .put(nameBytes);
    }
}
