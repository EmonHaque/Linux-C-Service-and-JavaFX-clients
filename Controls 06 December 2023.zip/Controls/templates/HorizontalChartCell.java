package templates;

import controls.HorizontalListChart;
import controls.texts.HiText;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import model.HorizontalSeries;

public class HorizontalChartCell extends StackPane {
    private HiText hiText;
    private Rectangle value1, value2;
    private Line value3;
    private Circle ball;
    private HorizontalSeries item, previous;
    private double percentOfChartArea, topBottomPadding, topMax, bottomMax;

    private Popup pop;
    private VBox content;
    private Text  popTitle, popValue1, popValue2, popValue3;

    private HorizontalListChart chart;
    private boolean isSet;
    private double width, height, paddedHeight, startX, chartArea, total, totalWidth, value1Width, value2Width;

    public HorizontalChartCell() {
        hiText = new HiText();
        //name = new Text();
        value1 = new Rectangle();
        value2 = new Rectangle();
        value3 = new Line();
        ball = new Circle();

        //name.setFill(Color.WHITE);
        value1.setFill(Color.GRAY);
        value2.setFill(Color.GREEN);
        value3.setStroke(Color.WHITE);
        ball.setFill(Color.CORAL);

        value1.setOpacity(0.2);
        value2.setOpacity(0.2);
        value3.setStrokeWidth(1);
        ball.setRadius(3);

        hiText.setManaged(false);
        value1.setManaged(false);
        value2.setManaged(false);
        value3.setManaged(false);
        ball.setManaged(false);

        hiText.setMouseTransparent(true);
        value1.setMouseTransparent(true);
        value2.setMouseTransparent(true);
        value3.setMouseTransparent(true);
        ball.setMouseTransparent(true);

        getChildren().addAll(hiText, value1, value2, ball);

        popTitle = new Text();
        popValue1 = new Text();
        popValue2 = new Text();
        popValue3 = new Text();

        content = new VBox(popTitle, new Separator(), popValue1, popValue2, popValue3);
        // content = new VBox(new Text(item.getTitle()), new Separator());
        content.setPadding(new Insets(10));
        content.setAlignment(Pos.CENTER);
        content.setBackground(new Background(new BackgroundFill(Color.CORAL, new CornerRadii(10), null)));

        pop = new Popup();
        pop.getContent().add(content);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseExited(this::onMouseExited);
    }

    public void setValue(HorizontalSeries item, HorizontalSeries previous, double percentOfChartArea, double topBottomPadding, double topMax, double bottomMax) {
        this.item = item;
        this.previous = previous;
        this.percentOfChartArea = percentOfChartArea;
        this.topBottomPadding = topBottomPadding;
        this.topMax = topMax;
        this.bottomMax = bottomMax;

        hiText.setText(item.getTitle());
        if (chart != null) {
            hiText.queryProperty().bind(chart.queryProperty);
        }
        if (previous != null) {
            getChildren().add(value3);
        }

        popTitle.setText(item.getTitle());
        popValue1.setText("Value 1 is " + String.format("%.1f", item.getValue1()));
        popValue2.setText("Value 2 is " + String.format("%.1f", item.getValue2()));
        popValue3.setText("Value 3 is " + String.format("%.1f", item.getValue3()));

        isSet = true;
        requestLayout();
    }

    public void resetValue() {
        hiText.queryProperty().unbind();
        hiText.setText("");

        getChildren().remove(value3);

        popTitle.setText(null);
        popValue1.setText(null);
        popValue2.setText(null);
        popValue3.setText(null);

        isSet = false;
        requestLayout();
    }

    private void compute() {
        value1.setX(startX);
        value1.setY(topBottomPadding);
        value1.setHeight(paddedHeight);
        value1.setWidth(value1Width);

        value2.setX(startX + value1.getWidth());
        value2.setY(topBottomPadding);
        value2.setHeight(paddedHeight);
        value2.setWidth(value2Width);

        layoutInArea(hiText, 0, topBottomPadding, startX, paddedHeight, 0, HPos.LEFT, VPos.CENTER);

        var x2 = startX + item.getValue3() / bottomMax * chartArea;
        var y2 = height / 2;
        ball.setCenterX(x2);
        ball.setCenterY(y2);

        if (previous != null) {
            var prevText = new Text(previous.getTitle());
            prevText.setWrappingWidth(startX);
            var prevHeight = prevText.prefHeight(-1) + 2 * topBottomPadding;

            var x1 = startX + previous.getValue3() / bottomMax * chartArea;
            var y1 = -prevHeight / 2;

            value3.setStartX(x1);
            value3.setEndX(x2);
            value3.setStartY(y1);
            value3.setEndY(y2);
        }
    }

    private void zero() {
        value1.setX(0);
        value1.setY(0);
        value1.setHeight(0);
        value1.setWidth(0);

        value2.setX(0);
        value2.setY(0);
        value2.setHeight(0);
        value2.setWidth(0);

        layoutInArea(hiText, 0, 0, 0, 0, 0, HPos.LEFT, VPos.CENTER);

        ball.setCenterX(0);
        ball.setCenterY(0);
    }

    private void onMouseEntered(MouseEvent e) {
        var point = localToScreen(e.getX(), e.getY());
        var x = point.getX() - content.prefWidth(-1) / 2;
        var y = point.getY() - content.prefHeight(-1) - 15;
        pop.show(this, x, y);
    }

    private void onMouseExited(MouseEvent e) {
        pop.hide();
    }

    public boolean isSet(){
        return isSet;
    }

    @Override
    protected void layoutChildren() {
        if (chart == null) {
            var instance = getParent();
            while (!(instance instanceof HorizontalListChart)) {
                instance = instance.getParent();
            }
            chart = (HorizontalListChart) instance;
            hiText.queryProperty().bind(chart.queryProperty);
        }
        if (width != getWidth() || height != getHeight()) {
            width = getWidth();
            height = getHeight();
            paddedHeight = height - 2 * topBottomPadding;

            startX = width * (1 - percentOfChartArea);
            chartArea = width - startX;
            total = item.getValue1() + item.getValue2();
            totalWidth = chartArea / topMax * total;
            value1Width = item.getValue1() / total * totalWidth;
            value2Width = item.getValue2() / total * totalWidth;
        }
        if (isSet) {
            compute();
        }
        else {
            zero();
        }
    }
}
