package controls.states;

import controls.SVGIcon;
import helpers.Icons;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;

public class ExpandedState extends StackPane {
    private SVGIcon icon;
    private boolean isExpanded;
    public BooleanProperty isExpandedProperty;

    public ExpandedState(boolean isExpanded) {
        this.isExpanded = isExpanded;
        icon = new SVGIcon(isExpanded ? Icons.PlusCircle : Icons.MinusCircle);

        icon.setMouseTransparent(true);
        getChildren().add(icon);

        isExpandedProperty = new SimpleBooleanProperty();
        isExpandedProperty.set(isExpanded);
        setOnMouseClicked(this::onClicked);
    }

    private void onClicked(MouseEvent e) {
        isExpanded = !isExpanded;
        icon.setContent(isExpanded ? Icons.PlusCircle : Icons.MinusCircle);
        isExpandedProperty.set(isExpanded);
    }
}
