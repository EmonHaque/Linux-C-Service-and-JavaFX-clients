package dialogs;

import controls.buttons.ActionButton;
import helpers.Constants;
import helpers.Icons;
import javafx.animation.Interpolator;
import javafx.animation.ScaleTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.print.Paper;
import javafx.print.Printer;
import javafx.scene.Scene;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import skinned.ExtendedListView;

public class PrinterSelectionDialog extends Stage {
    private final BorderPane root;
    private final GridPane listViews;
//    private final ExtendedListView<Printer> printersView;
//    private final ExtendedListView<Paper> paperView;
    private Printer selectedPrinter;
    private Paper selectedPaper;
    private final ObservableList<Paper> papers;

    public PrinterSelectionDialog(ObservableList<Printer> printers) {
        initStyle(StageStyle.TRANSPARENT);
        initModality(Modality.APPLICATION_MODAL);

        papers = FXCollections.observableArrayList();

        var radius = Constants.CardRadius;
        var titlePane = new StackPane() {{
            getChildren().add(
                    new Text("Select a printer") {{
                        setFill(Color.WHITE);
                        setFont(Font.font(null, FontWeight.BOLD, 18));
                    }}
            );
            setPadding(new Insets(5));
            setBorder(Constants.BottomLine);
            setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 1), new CornerRadii(radius, radius, 0, 0, false), null)));
        }};

        var okButton = new ActionButton(Icons.CheckCircle, 16, "ok");
        var cancelButton = new ActionButton(Icons.CloseCircle, 16, "cancel");
        okButton.setAction(this::closeDialog);
        cancelButton.setAction(this::cancel);
        var buttonPane = new GridPane() {{
            getColumnConstraints().add(new ColumnConstraints() {{
                setPercentWidth(100);
            }});
            add(okButton, 0, 0);
            add(cancelButton, 0, 0);

            setHalignment(cancelButton, HPos.LEFT);
            setHalignment(okButton, HPos.RIGHT);
            setPadding(new Insets(5));
            setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 1), new CornerRadii(0, 0, radius, radius, false), null)));
        }};
        var printersView = new ExtendedListView<>(printers) {{
            setCellFactory(v -> new PrinterCell());
            getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            getSelectionModel().selectedItemProperty().addListener(o -> {
                selectedPrinter = getSelectionModel().getSelectedItem();
                papers.clear();
                if (selectedPrinter != null)
                    papers.addAll(selectedPrinter.getPrinterAttributes().getSupportedPapers());
            });
        }};
        var paperView = new ExtendedListView<>(papers) {{
            setCellFactory(v -> new PaperCell());
            getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            getSelectionModel().selectedItemProperty().addListener(o -> {
                selectedPaper = getSelectionModel().getSelectedItem();
            });
        }};

        listViews = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setPercentWidth(50);}},
                    new ColumnConstraints(){{ setPercentWidth(50);}}
            );
            add(printersView, 0, 0);
            add(paperView, 1,0);
            setHgap(10);
            setPadding(new Insets(0,5,0,5));
            setBackground(Background.fill(Color.BLACK));
        }};
        root = new BorderPane() {{
            setTop(titlePane);
            setCenter(listViews);
            setBottom(buttonPane);
            setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 0, 0.5), new CornerRadii(radius, false), null)));
        }};
        setOnShown(this::animateShow);
    }

    public Printer getSelectedPrinter() {return selectedPrinter;}
    public Paper getSelectedPaper() {return selectedPaper; }

    public void showDialog(double left, double top, double width, double height) {
        listViews.setMaxHeight(height / 3);
        listViews.setMinHeight(height / 3);
        listViews.setPrefHeight(height / 3);

        listViews.setLayoutX(width / 3);
        listViews.setLayoutY(height / 3);

        var scene = new Scene(root, width, height);
        scene.setFill(Color.TRANSPARENT);
        setScene(scene);
        setX(left);
        setY(top);
        showAndWait();
    }

    public void closeDialog() {
        var animation = new ScaleTransition(Duration.millis(500), root);
        animation.setInterpolator(Interpolator.EASE_IN);
        animation.setFromX(1);
        animation.setFromY(1);
        animation.setToX(0);
        animation.setToY(0);
        animation.play();
        animation.setOnFinished(e -> close());
    }

    private void cancel() {
        selectedPrinter = null;
        closeDialog();
    }

    private void animateShow(WindowEvent e) {
        var animation = new ScaleTransition(Duration.millis(500), root);
        animation.setInterpolator(Interpolator.EASE_IN);
        animation.setFromX(0);
        animation.setFromY(0);
        animation.setToX(1);
        animation.setToY(1);
        animation.play();
    }

    private class PrinterCell extends ListCell<Printer> {
        public PrinterCell() {
            setContentDisplay(ContentDisplay.TEXT_ONLY);
            setAlignment(Pos.CENTER);
            setTextFill(Color.WHITE);
        }

        @Override
        protected void updateItem(Printer item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setText(null);
                setBackground(null);
            }
            else {
                setPrefWidth(0);
                setText(item.getName());
                setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
                if (isHover()) {
                    if (isSelected()) return;
                    setBackground(isHover() ? Background.fill(Constants.BackgroundColorLight) : null);
                }
            }
        }
    }

    private class PaperCell extends ListCell<Paper> {
        public PaperCell() {
            setContentDisplay(ContentDisplay.TEXT_ONLY);
            setAlignment(Pos.CENTER_LEFT);
            setTextFill(Color.WHITE);
            setWrapText(true);
        }

        @Override
        protected void updateItem(Paper item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setText(null);
                setBackground(null);
            }
            else {
                setPrefWidth(0);
                setText(item.toString());
                //setText(item.getName());
                setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
                if (isHover()) {
                    if (isSelected()) return;
                    setBackground(isHover() ? Background.fill(Constants.BackgroundColorLight) : null);
                }
            }
        }
    }
}
