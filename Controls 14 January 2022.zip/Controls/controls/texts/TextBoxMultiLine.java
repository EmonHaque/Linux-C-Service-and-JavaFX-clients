package controls.texts;

import abstracts.HintedControlBase;
import helpers.Constants;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.control.TextArea;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Priority;
import skins.ExtendedTextAreaSkin;

public class TextBoxMultiLine extends HintedControlBase {
    protected TextArea input;

    public TextBoxMultiLine(String hint, String icon, boolean isRequired) {
        super(hint, icon, isRequired);
        hintBox.setAlignment(Pos.TOP_LEFT);
        setPadding(new Insets(Constants.hintShiftY, 0, 0, 0));
        leftIcon.setTranslateY(1);
        input = new TextArea();
        input.setSkin(new ExtendedTextAreaSkin(input));
        input.setContextMenu(null);

        add(input, 1, 0);
        setHgrow(input, Priority.ALWAYS);
        setVgrow(input, Priority.ALWAYS);
        setValignment(leftIcon, VPos.TOP);
        //setValignment(hintBox, VPos.TOP);

        addEventHandler(MouseEvent.ANY, this::onMouseEvents);
        input.addEventFilter(ContextMenuEvent.CONTEXT_MENU_REQUESTED, Event::consume);
        input.focusedProperty().addListener(this::onFocusChanged);
        input.textProperty().addListener(this::onTextChanged);

        setFocusTraversable(false);
    }
    
    private void onMouseEvents(MouseEvent e) {
        var event = e.getEventType();
        if (event == MouseEvent.MOUSE_ENTERED) {
            input.requestFocus();
        }
        else if (event == MouseEvent.MOUSE_EXITED) {
            leftIcon.requestFocus();
        }
    }

    protected void onTextChanged(ObservableValue<?> observable, String oldValue, String newValue) {
        if (textIsNullOrEmpty(newValue)) {
            if (isHintMoved && !input.isFocused()) {
                moveHintDown();
            }
        }
        else {
            if (!isHintMoved) {
                moveHintUp();
            }
        }
    }

    protected void onFocusChanged(ObservableValue<?> observable, Boolean oldValue, Boolean newValue) {
        if (newValue) {
            setFocusColor();
            if (!isHintMoved)
                moveHintUp(); 
        }
        else {
            resetFocusColor();
            if (textIsNullOrEmpty(input.getText())) {
                if (isHintMoved)
                    moveHintDown();
            }
        }
    }

    protected boolean textIsNullOrEmpty(String text) {
        return text == null || text.isEmpty() || text.isBlank();
    }

    public StringProperty textProperty(){ return input.textProperty();}

    public String getText() {
        return input.getText();
    }

    public void setText(String value) {
        input.setText(value);
    }

    public void setReadOnly(boolean value){
        input.setEditable(!value);
    }

    public BooleanBinding isEmpty(){ return textProperty().isEmpty();}
}
