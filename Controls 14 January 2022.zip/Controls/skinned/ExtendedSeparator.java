package skinned;

import helpers.Constants;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.control.Separator;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;

public class ExtendedSeparator extends Separator {
    private boolean isLoaded;

    public ExtendedSeparator() {
        setBorder(null);
    }

    @Override
    protected void layoutChildren() {
        if (!isLoaded) {
            isLoaded = true;
            var line = (Region) lookup(".line");
            var orientation = getOrientation();
            if (orientation == Orientation.HORIZONTAL) {
                setPadding(new Insets(2.5, 0, 2.5, 0));
                line.setBorder(Constants.BottomLine);
            }
            else {
                setPadding(new Insets(0, 2.5, 0, 2.5));
                line.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0, 0.25, 0, 0))));
            }
        }
        super.layoutChildren();
    }
}
