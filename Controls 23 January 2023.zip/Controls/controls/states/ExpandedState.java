package controls.states;

import controls.SVGIcon;
import controls.SVGRegion;
import helpers.Icons;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

public class ExpandedState extends StackPane {
    private final SVGRegion icon;
    private boolean isExpanded;
    public BooleanProperty isExpandedProperty;

    public ExpandedState(boolean isExpanded) {
        this.isExpanded = isExpanded;
        icon = new SVGRegion(isExpanded ? Icons.PlusCircle : Icons.MinusCircle);

        icon.setMouseTransparent(true);
        getChildren().add(icon);

        isExpandedProperty = new SimpleBooleanProperty();
        isExpandedProperty.set(isExpanded);
        setOnMouseClicked(this::onClicked);
        setOnMouseEntered(e -> icon.animate(Color.CORAL));
        setOnMouseExited(e -> icon.animate(Color.WHITE));
    }

    private void onClicked(MouseEvent e) {
        isExpanded = !isExpanded;
        icon.setContent(isExpanded ? Icons.PlusCircle : Icons.MinusCircle);
        isExpandedProperty.set(isExpanded);
    }
}
