package controls.pinchart;

import javafx.animation.*;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Scale;
import javafx.stage.Popup;
import javafx.util.Duration;
import model.PinColors;

import java.util.ArrayList;
import java.util.List;

public class PinStack extends StackPane {
    private boolean isLoaded, isPinned;
    private final double total, radius = 3;
    private final List<Double> values;
    private final Circle ball;
    private final List<PinSegment> pinSegments;

    private Timeline anim;
    private final DoubleProperty pinHeight;
    private TranslateTransition ballAnim;

    private final Rectangle clip;

    private Popup popup;

    public PinStack(List<Double> values, List<PinColors> colors) {
        this.values = values;
        getTransforms().add(new Scale(1, -1));
        total = values.stream().mapToDouble(s -> s).sum();

        ball = new Circle() {{
            setFill(Color.CORNFLOWERBLUE);
            setRadius(radius);
            setManaged(false);
            setMouseTransparent(true);
        }};

        pinSegments = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) {
            var color = colors.get(i);
            var segment = new PinSegment(color.getNormal(), color.getHighlight());
            pinSegments.add(segment);
            getChildren().add(segment);
            segment.setManaged(false);
            segment.setMouseTransparent(true);
        }
        getChildren().add(ball);
        pinHeight = new SimpleDoubleProperty(0);
        clip = new Rectangle();
        setClip(clip);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseClicked(this::onClicked);
        setOnMouseExited(this::onMouseExited);
    }

    public List<Double> getValues(){ return values; }

    public void makePin(double width, double height, double yMax) {
        double midPoint = width / 2;
        double totalHeight = total * height / yMax;
        clip.setWidth(width);

        double y = 0;
        for (int i = 0; i < values.size(); i++) {
            var h = totalHeight / total * values.get(i);
            var pin = pinSegments.get(i);
            pin.setValue(midPoint, y, y + h);
            y += h;
        }
        ball.setCenterX(midPoint);
        ball.setCenterY(y);
        var ballY = y;

        if(!isLoaded){
            isLoaded = true;
            pinHeight.addListener((o, ov, nv) -> clip.setHeight(nv.doubleValue()));
            var key = new KeyValue(pinHeight, height, Interpolator.EASE_IN);
            var frame = new KeyFrame(Duration.millis(500), key);
            anim = new Timeline(frame);
            anim.setDelay(Duration.millis(500));

            ball.setOpacity(0);
            ballAnim = new TranslateTransition(Duration.millis(500), ball);
            ballAnim.setToY(0);

            anim.play();
            anim.setOnFinished(e -> {
                setClip(null);
                ball.setOpacity(1);
                ball.setTranslateY(height - ballY);
                ballAnim.play();
                anim.setOnFinished(null);
            });
        }
    }

    private void onMouseEntered(MouseEvent e) {
        if (isPinned) return;
        for (var segment : pinSegments) {
            segment.highlightColor();
        }
        if(popup != null)
            popup.show(this, e.getScreenX() + 20, e.getScreenY() + 20);
    }

    private void onClicked(MouseEvent e) { isPinned = !isPinned;  }

    private void onMouseExited(MouseEvent e) {
        if (isPinned) return;
        for (var segment : pinSegments) {
            segment.normalColor();
        }
        if(popup != null)
            popup.hide();
    }

    public void setToolTip(Popup popup){
        this.popup = popup;
    }
}
