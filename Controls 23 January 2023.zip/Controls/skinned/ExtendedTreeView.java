package skinned;

import javafx.geometry.Insets;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.Skin;
import javafx.scene.control.TreeView;
import skins.ExtendedTreeViewSkin;

public class ExtendedTreeView<T> extends TreeView<T> {
    public ScrollBar vBar;
    public ExtendedTreeView() {
        super();
        setBackground(null);
        setPadding(new Insets(0));
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        var skin = new ExtendedTreeViewSkin<>(this);
        vBar = skin.vBar;
        return skin;
    }
}
