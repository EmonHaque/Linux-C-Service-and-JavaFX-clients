package Views.Report.BalancesViews;

import Models.Balance;
import Models.Plot;
import ViewModels.Report.ReportBalanceVM;
import abstracts.View;
import controls.SelectionBox;
import controls.buttons.CommandButton;
import controls.states.BiState;
import helpers.Icons;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import skinned.ExtendedListView;

public class ReportBalance extends View {
    private ReportBalanceVM vm;
    private Text status;
    private BiState hasLeft;
    private SelectionBox<Plot> selection;
    private ExtendedListView<Balance> list;
    private CommandButton refresh;

    @Override
    protected String getHeader() {
        return "Balance";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new ReportBalanceVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        selection = new SelectionBox<>("Plot", Icons.Plot, vm.plots, false);
        hasLeft = new BiState(false, "has left");
        refresh = new CommandButton(Icons.Reload, 16, "Reload");
        var hBox = new HBox(selection, hasLeft, refresh){{ setSpacing(5);}};
        list = new ExtendedListView<>(vm.balances);

        var box = new VBox(hBox, list){{
            setSpacing(5);
            setVgrow(list, Priority.ALWAYS);
        }};
        setCenter(box);

        status = new Text(){{ setFill(Color.WHITE);}};
        addAction(status);
    }

    private void bind(){
        vm.selectedPlotProperty.bind(selection.selectedValueProperty());
        vm.hasLeftProperty.bind(hasLeft.isCheckedProperty);
        status.textProperty().bind(vm.statusProperty);
        refresh.setAction(vm::updateReportable);
    }
}
