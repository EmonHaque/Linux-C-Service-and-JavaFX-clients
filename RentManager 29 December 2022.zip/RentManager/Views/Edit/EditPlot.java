package Views.Edit;

import ViewModels.Edit.EditBaseVM;
import abstracts.StringVisualCell;
import editables.EditPane;
import editables.EditText;
import editables.EditTextMultiline;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.control.ListCell;
import javafx.scene.layout.*;
import Models.Plot;
import ViewModels.Edit.EditPlotVM;

public class EditPlot extends EditBase<Plot> {
    private EditPlotVM vm;
    private EditText name;
    private EditTextMultiline address;

    @Override
    protected String getHeader() {return "Plot";}

    @Override
    protected String getIcon() {
        return Icons.Plot;
    }

    @Override
    protected String getTip() {
        return "Plot";
    }

    @Override
    protected EditBaseVM<Plot> getViewModel() {
        vm = new EditPlotVM();
        return vm;
    }

    @Override
    protected boolean isEditableList() {
        return true;
    }

    @Override
    protected ListCell<Plot> getListCellTemplate() {
        return new StringVisualCell<>(query.textProperty(), true);
    }

    @Override
    protected void initializeEditPane(EditPane pane) {
        name = new EditText("Name", Icons.Plot, true, pane);
        address = new EditTextMultiline("Address", Icons.Description, true, pane);
        pane.setCenter(new VBox(name, address) {{
            setSpacing(10);
            setPadding(new Insets(10, 0, 0, 0));
        }});
    }

    @Override
    protected void onSelectionChanged(Plot item) {
        name.textProperty().unbindBidirectional(vm.edited.nameProperty());
        address.textProperty().unbindBidirectional(vm.edited.descriptionProperty());

        name.textProperty().bind(item.nameProperty());
        address.textProperty().bind(item.descriptionProperty());
    }

    @Override
    protected void onIsOnEditChanged() {
        name.textProperty().unbind();
        address.textProperty().unbind();

        name.textProperty().bindBidirectional(vm.edited.nameProperty());
        address.textProperty().bindBidirectional(vm.edited.descriptionProperty());
    }
}
