package Views.Edit;

import Models.ControlHead;
import Models.Head;
import ViewModels.Edit.EditBaseVM;
import ViewModels.Edit.EditHeadVM;
import abstracts.StringVisualCell;
import controls.SelectionBox;
import editables.EditPane;
import editables.EditSelection;
import editables.EditText;
import editables.EditTextMultiline;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.control.ListCell;
import javafx.scene.layout.VBox;

public class EditHead extends EditBase<Head> {
    private EditHeadVM vm;
    private SelectionBox<ControlHead> controls;

    private EditSelection<ControlHead> editControls;
    private EditText name;
    private EditTextMultiline description;

    @Override
    protected String getHeader() {
        return "Head";
    }

    @Override
    protected String getIcon() {
        return Icons.Head;
    }

    @Override
    protected String getTip() {
        return "Head";
    }

    @Override
    protected EditBaseVM<Head> getViewModel() {
        vm = new EditHeadVM();
        return vm;
    }

    @Override
    protected boolean isEditableList() {
        return true;
    }

    @Override
    protected ListCell<Head> getListCellTemplate() {
        return new StringVisualCell<>(query.textProperty(), true);
    }

    @Override
    protected void onSelectionChanged(Head item) {
        editControls.valueProperty().unbindBidirectional(vm.edited.controlIdProperty());
        name.textProperty().unbindBidirectional(vm.edited.nameProperty());
        description.textProperty().unbindBidirectional(vm.edited.descriptionProperty());

        editControls.valueProperty().bind(vm.selected.controlIdProperty());
        name.textProperty().bind(vm.selected.nameProperty());
        description.textProperty().bind(vm.selected.descriptionProperty());
    }

    @Override
    protected void onIsOnEditChanged() {
        editControls.valueProperty().unbind();
        name.textProperty().unbind();
        description.textProperty().unbind();

        editControls.valueProperty().bindBidirectional(vm.edited.controlIdProperty());
        name.textProperty().bindBidirectional(vm.edited.nameProperty());
        description.textProperty().bindBidirectional(vm.edited.descriptionProperty());
    }

    @Override
    protected void initializeUI() {
        super.initializeUI();
        controls = new SelectionBox<>("Control", Icons.ControlHead, vm.controls, false);
        leftBox.getChildren().add(0, controls);
    }

    @Override
    protected void bind() {
        super.bind();
        vm.selectedControlProperty.bind(controls.selectedValueProperty());
    }

    @Override
    protected void initializeEditPane(EditPane pane) {
        editControls = new EditSelection<>("Control", Icons.ControlHead, vm.editControls, true, pane);
        name = new EditText("Name", Icons.Head, true, pane);
        description = new EditTextMultiline("Description", Icons.Description, true, pane);
        var box = new VBox(editControls, name, description) {{
            setSpacing(5);
            setPadding(new Insets(10, 0, 0, 0));
        }};
        pane.setCenter(box);
    }
}
