package Views.Edit;

import CellTemplates.ListView.EditTenantTemplate;
import Models.Tenant;
import ViewModels.Edit.EditBaseVM;
import ViewModels.Edit.EditTenantVM;
import controls.states.BiState;
import controls.states.MultiState;
import editables.EditDate;
import editables.EditPane;
import editables.EditText;
import editables.EditTextMultiline;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ListCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class EditTenant extends EditBase<Tenant> {
    private EditTenantVM vm;
    private MultiState state;

    private EditText name, father, mother, husband, nid, phone;
    private EditTextMultiline address;
    private BiState hasLeft;
    private EditDate date;

    @Override
    protected String getHeader() {return "Tenant";}

    @Override
    protected String getIcon() {
        return Icons.Tenant;
    }

    @Override
    protected String getTip() {
        return "Tenant";
    }

    @Override
    protected EditBaseVM<Tenant> getViewModel() {
        vm = new EditTenantVM();
        return vm;
    }

    @Override
    protected boolean isEditableList() {
        return true;
    }

    @Override
    protected ListCell<Tenant> getListCellTemplate() {
        return new EditTenantTemplate(query.textProperty(), state.stateProperty);
    }

    @Override
    protected void onSelectionChanged(Tenant item) {
        name.textProperty().unbindBidirectional(vm.edited.nameProperty());
        father.textProperty().unbindBidirectional(vm.edited.fatherProperty());
        mother.textProperty().unbindBidirectional(vm.edited.motherProperty());
        husband.textProperty().unbindBidirectional(vm.edited.husbandProperty());
        address.textProperty().unbindBidirectional(vm.edited.addressProperty());
        nid.textProperty().unbindBidirectional(vm.edited.nidProperty());
        phone.textProperty().unbindBidirectional(vm.edited.contactNoProperty());

        hasLeft.isCheckedProperty.unbindBidirectional(vm.edited.hasLeftProperty());
        date.visibleProperty().unbind();
        date.setVisible(false);

        name.textProperty().bind(vm.selected.nameProperty());
        father.textProperty().bind(vm.selected.fatherProperty());
        mother.textProperty().bind(vm.selected.motherProperty());
        husband.textProperty().bind(vm.selected.husbandProperty());
        address.textProperty().bind(vm.selected.addressProperty());
        nid.textProperty().bind(vm.selected.nidProperty());
        phone.textProperty().bind(vm.selected.contactNoProperty());
        hasLeft.isCheckedProperty.bind(vm.selected.hasLeftProperty());
    }

    @Override
    protected void onIsOnEditChanged() {
        name.textProperty().unbind();
        father.textProperty().unbind();
        mother.textProperty().unbind();
        husband.textProperty().unbind();
        address.textProperty().unbind();
        nid.textProperty().unbind();
        phone.textProperty().unbind();
        hasLeft.isCheckedProperty.unbind();

        name.textProperty().bindBidirectional(vm.edited.nameProperty());
        father.textProperty().bindBidirectional(vm.edited.fatherProperty());
        mother.textProperty().bindBidirectional(vm.edited.motherProperty());
        husband.textProperty().bindBidirectional(vm.edited.husbandProperty());
        address.textProperty().bindBidirectional(vm.edited.addressProperty());
        nid.textProperty().bindBidirectional(vm.edited.nidProperty());
        phone.textProperty().bindBidirectional(vm.edited.contactNoProperty());

        hasLeft.isCheckedProperty.bindBidirectional(vm.edited.hasLeftProperty());
        date.visibleProperty().bind(getDateVisibilityBinding());
    }

    @Override
    protected void initializeEditPane(EditPane pane) {
        name = new EditText("Name", Icons.Tenant, true, pane);
        father = new EditText("Father", Icons.Father, true, pane);
        mother = new EditText("Mother", Icons.Mother, false, pane);
        husband = new EditText("Husband", Icons.Husband, false, pane);
        address = new EditTextMultiline("Address", Icons.Description, false, pane);
        nid = new EditText("NID", Icons.ID, false, pane);
        phone = new EditText("Phone", Icons.Mobile, true, pane);
        hasLeft = new BiState(true, "has left") {{setAlignment(Pos.BOTTOM_LEFT);}};
        date = new EditDate("Date", Icons.Month, true, pane);

        var dateBox = new HBox(hasLeft, date) {{
            setHgrow(date, Priority.ALWAYS);
            setSpacing(10);
        }};
        var box = new VBox(name, father, mother, husband, address, nid, phone, dateBox) {{
            setSpacing(5);
            setPadding(new Insets(10, 0, 0, 0));
        }};
        pane.setCenter(box);
    }

    @Override
    protected void initializeUI() {
        super.initializeUI();
        var icons = new String[]{Icons.Existing, Icons.LeftOrExpired, Icons.All};
        var texts = new String[]{"Existing", "Left", "All"};
        state = new MultiState(icons, texts, false) {{setAlignment(Pos.BOTTOM_CENTER);}};
        queryBox.getChildren().add(1, state);
    }

    @Override
    protected void bind() {
        super.bind();
        vm.stateProperty.bind(state.stateProperty);
        vm.selectedDate.bind(date.dateProperty());
        hasLeft.disableProperty().bind(pane.isOnEditProperty().not());
    }

    private BooleanBinding getDateVisibilityBinding() {
        return Bindings.createBooleanBinding(() ->
                        !vm.selected.isHasLeft() && vm.edited.isHasLeft()
                , vm.edited.hasLeftProperty());
    }
}
