package Views.Edit;

import Converters.IntToStringConverter;
import Models.*;
import ViewModels.Edit.EditBaseVM;
import ViewModels.Edit.EditTransactionVM;
import controls.buttons.CommandButton;
import controls.daymonth.DayPicker;
import controls.states.MultiState;
import editables.*;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import trees.EditTransactionTree;

public class EditTransaction extends EditBase<Transaction> {
    private EditTransactionVM vm;
    private DayPicker date;
    private CommandButton refresh;
    private Text status;

    private EditSelection<Tenant> tenant;
    private EditSelection<PlotTransaction> plot;
    private EditSelection<SpaceTransaction> space;
    private EditSelection<ControlHead> control;
    private EditSelection<Head> head;
    private EditDate editDate;
    private EditInteger amount;
    private MultiState isCash;
    private EditTextMultiline narration;

    @Override
    protected String getHeader() {
        return "Transaction";
    }

    @Override
    protected String getIcon() {
        return Icons.Transact;
    }

    @Override
    protected String getTip() {
        return "Transaction";
    }

    @Override
    protected EditBaseVM<Transaction> getViewModel() {
        vm = new EditTransactionVM();
        return vm;
    }

    @Override
    protected boolean isEditableList() {
        return false;
    }

    @Override
    public EditTransactionTree getTree() {
        return new EditTransactionTree(vm.editableList, query.textProperty());
    }

    @Override
    protected void onSelectionChanged(Transaction item) {

    }

    @Override
    protected void onIsOnEditChanged() {

    }

    @Override
    protected void initializeUI() {
        super.initializeUI();
        date = new DayPicker("Date", Icons.Month, false);
        refresh = new CommandButton(Icons.Reload, 16, "refresh");
        var box = new HBox(date, refresh){{
            setSpacing(5);
            setHgrow(date, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_RIGHT);
            setMargin(refresh, new Insets(0, 0, 4, 0));
        }};
        leftBox.getChildren().add(0, box);

        status = new Text() {{setFill(Color.WHITE);}};
        addAction(status);
    }

    @Override
    protected void bind() {
        super.bind();
        vm.dateProperty.bind(date.selectedDateProperty());
        status.textProperty().bind(vm.statusProperty);
        refresh.setAction(vm::refresh);
        refresh.disableProperty().bind(date.isEmpty());
    }

    @Override
    protected void initializeEditPane(EditPane pane) {
        tenant = new EditSelection<>("Tenant", Icons.Tenant, vm.tenants, true, pane);
        plot = new EditSelection<>("Plot", Icons.Plot, vm.plots, true, pane);
        space = new EditSelection<>("Space", Icons.Space, vm.spaces, true, pane);
        control = new EditSelection<>("Control", Icons.ControlHead, vm.controls, true, pane);
        head = new EditSelection<>("Head", Icons.Head, vm.heads, true, pane);
        editDate = new EditDate("Date", Icons.Month, true, pane);
        amount = new EditInteger("Amount", Icons.Amount, true, pane);
        narration = new EditTextMultiline("Narration", Icons.Description, true, pane);
        isCash = new MultiState(new String[]{Icons.Cash, Icons.NonCash, Icons.Mobile}, new String[]{"Cash", "Non cash", "Mobile"}, true) {{
            setAlignment(Pos.BOTTOM_LEFT);
        }};

        var amountBox = new HBox(amount, isCash) {{
            setSpacing(10);
            setHgrow(amount, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_RIGHT);
        }};

        pane.setCenter(new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(50);}},
                    new ColumnConstraints() {{setPercentWidth(50);}}
            );
            add(tenant, 0, 0, 2, 1);
            add(plot, 0, 1);
            add(space, 1, 1);
            add(control, 0, 2);
            add(head, 1, 2);
            add(editDate, 0, 3);
            add(amountBox, 1, 3);
            add(narration, 0, 4, 2, 1);

            setHgap(10);
            setVgap(10);
            setPadding(new Insets(5, 0, 0, 0));
        }});
    }

//    @Override
//    protected void bindEditPaneControls(EditPane pane) {
//        tenant.valueProperty().bindBidirectional(vm.transaction.tenantIdProperty());
//        plot.valueProperty().bindBidirectional(vm.transaction.plotIdProperty());
//        space.valueProperty().bindBidirectional(vm.transaction.spaceIdProperty());
//        control.valueProperty().bindBidirectional(vm.transaction.controlIdProperty());
//        head.valueProperty().bindBidirectional(vm.transaction.headIdProperty());
//        editDate.dateProperty().bindBidirectional(vm.transaction.dateProperty());
//        Bindings.bindBidirectional(amount.textProperty(), vm.transaction.amountProperty(), new IntToStringConverter());
//        isCash.stateProperty.bindBidirectional(vm.transaction.isCashProperty());
//        narration.textProperty().bindBidirectional(vm.transaction.narrationProperty());
//    }
}
