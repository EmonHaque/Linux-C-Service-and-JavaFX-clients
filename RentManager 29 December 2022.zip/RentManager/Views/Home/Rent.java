package Views.Home;

import abstracts.View;

public class Rent extends View {
    @Override
    protected String getHeader() {
        return "Rent, Deposit & Dues";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
    }
}
