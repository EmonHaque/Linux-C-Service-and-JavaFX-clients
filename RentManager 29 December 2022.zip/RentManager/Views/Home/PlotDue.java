package Views.Home;

import abstracts.View;

public class PlotDue extends View {
    @Override
    protected String getHeader() {
        return  "Due & Tenants";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
    }
}
