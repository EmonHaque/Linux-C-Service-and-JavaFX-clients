package Views.Home;

import abstracts.View;
import controls.buttons.ActionButton;
import controls.states.MultiState;
import javafx.scene.chart.PieChart;
import ViewModels.Home.CountsVM;

public class Counts extends View {
    private PieChart pie;
    private MultiState state, selectionState;
    private ActionButton refresh;
    private CountsVM vm;

    @Override
    protected String getHeader() {
        return "Space, Lease & Tenants";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();

    }
}
