package Views.Home;

import abstracts.View;

public class TenantDetail extends View {
    @Override
    protected String getHeader() {
        return "Due & Payments";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
    }
}
