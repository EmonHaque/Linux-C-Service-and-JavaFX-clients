package Views.Home;

import abstracts.View;

public class PlotRent extends View {
    @Override
    protected String getHeader() {
        return "Charge & Collections";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
    }
}
