package Converters;

import javafx.util.StringConverter;

public class IntToStringConverter extends StringConverter<Number> {
    @Override
    public String toString(Number object) {
        return object.intValue() == 0 ? "" : object.toString();
    }

    @Override
    public Number fromString(String string) {
        return string.isEmpty() || string.isBlank() ? 0 : Integer.parseInt(string);
    }
}
