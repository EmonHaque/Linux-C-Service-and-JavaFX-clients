package trees;

import Models.ReceiptPayment;
import controls.SVGRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import skinned.ExtendedTreeView;

import java.text.DecimalFormat;

public class ReceiptPaymentTree extends ExtendedTreeView<ReceiptPayment> {
    private final TreeItem<ReceiptPayment> receipt;
    private final TreeItem<ReceiptPayment> payment;
    public ListProperty<ReceiptPayment> itemsProperty;
    public BooleanProperty isExpandedProperty;

    public ReceiptPaymentTree() {
        receipt = new TreeItem<>(new ReceiptPayment() {{setControl("Receipt");}}){{ setExpanded(true);}};
        payment = new TreeItem<>(new ReceiptPayment() {{setControl("Payment");}}){{ setExpanded(true);}};
        var root = new TreeItem<ReceiptPayment>();
        root.getChildren().addAll(receipt, payment);

        itemsProperty = new SimpleListProperty<>();
        isExpandedProperty = new SimpleBooleanProperty();
        itemsProperty.addListener(this::onItemsChanged);
        setRoot(root);
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new ReceiptPaymentCell());
    }

    private void onItemsChanged(ObservableValue<?> o, ObservableList<ReceiptPayment> ov, ObservableList<ReceiptPayment> nv) {
        resetValues();
        if (nv == null) return;

        for (var e : nv) {
            var control = e.getControl().equals("Receipt") ? receipt : payment;
            var head = getHead(control, e);
            var plot = getPlot(head, e);
            var tenant = getTenant(plot, e);
            tenant.getChildren().add(new TreeItem<>(e));
        }
        removeSingleLeaf(receipt);
        removeSingleLeaf(payment);
    }

    private void removeSingleLeaf(TreeItem<ReceiptPayment> node){
        for(var head : node.getChildren()){
            for(var plot : head.getChildren()){
                for (var tenant: plot.getChildren()){
                    if(tenant.getChildren().size() > 1) continue;
                    var item = tenant.getChildren().get(0).getValue();
                    tenant.getChildren().clear();
                    tenant.getValue().setSpace(item.getSpace());
                }
            }
        }
    }

    private TreeItem<ReceiptPayment> getHead(TreeItem<ReceiptPayment> node, ReceiptPayment entry) {
        var value = node.getValue();
        value.setCash(value.getCash() + entry.getCash());
        value.setKind(value.getKind() + entry.getKind());
        value.setMobile(value.getMobile() + entry.getMobile());
        value.setTotal(value.getTotal() + entry.getTotal());

        var hasIt = false;
        TreeItem<ReceiptPayment> item = null;
        for (var c : node.getChildren()) {
            if (!c.getValue().getHead().equals(entry.getHead())) continue;

            value = c.getValue();
            value.setCash(value.getCash() + entry.getCash());
            value.setKind(value.getKind() + entry.getKind());
            value.setMobile(value.getMobile() + entry.getMobile());
            value.setTotal(value.getTotal() + entry.getTotal());
            hasIt = true;
            item = c;
            break;
        }
        if (!hasIt) {
            item = new TreeItem<>(new ReceiptPayment(){{
                setHead(entry.getHead());
                setCash(entry.getCash());
                setKind(entry.getKind());
                setMobile(entry.getMobile());
                setTotal(entry.getTotal());
            }});
            node.getChildren().add(item);
        }
        return item;
    }

    private TreeItem<ReceiptPayment> getPlot(TreeItem<ReceiptPayment> node, ReceiptPayment entry) {
        var hasIt = false;
        TreeItem<ReceiptPayment> item = null;
        for (var c : node.getChildren()) {
            if (!c.getValue().getPlot().equals(entry.getPlot())) continue;

            var value = c.getValue();
            value.setCash(value.getCash() + entry.getCash());
            value.setKind(value.getKind() + entry.getKind());
            value.setMobile(value.getMobile() + entry.getMobile());
            value.setTotal(value.getTotal() + entry.getTotal());
            hasIt = true;
            item = c;
            break;
        }
        if (!hasIt) {
            item = new TreeItem<>(new ReceiptPayment(){{
                setPlot(entry.getPlot());
                setCash(entry.getCash());
                setKind(entry.getKind());
                setMobile(entry.getMobile());
                setTotal(entry.getTotal());
            }});
            node.getChildren().add(item);
        }
        return item;
    }

    private TreeItem<ReceiptPayment> getTenant(TreeItem<ReceiptPayment> node, ReceiptPayment entry) {
        var hasIt = false;
        TreeItem<ReceiptPayment> item = null;
        for (var c : node.getChildren()) {
            if (!c.getValue().getTenant().equals(entry.getTenant())) continue;

            var value = c.getValue();
            value.setCash(value.getCash() + entry.getCash());
            value.setKind(value.getKind() + entry.getKind());
            value.setMobile(value.getMobile() + entry.getMobile());
            value.setTotal(value.getTotal() + entry.getTotal());
            hasIt = true;
            item = c;
            break;
        }
        if (!hasIt) {
            item = new TreeItem<>(new ReceiptPayment(){{
                setTenant(entry.getTenant());
                setCash(entry.getCash());
                setKind(entry.getKind());
                setMobile(entry.getMobile());
                setTotal(entry.getTotal());
            }});
            node.getChildren().add(item);
        }
        return item;
    }

    private void resetValues() {
        receipt.getChildren().clear();
        payment.getChildren().clear();

        receipt.getValue().setCash(0);
        receipt.getValue().setKind(0);
        receipt.getValue().setMobile(0);
        receipt.getValue().setTotal(0);

        payment.getValue().setCash(0);
        payment.getValue().setKind(0);
        payment.getValue().setMobile(0);
        payment.getValue().setTotal(0);
    }

    private class ReceiptPaymentCell extends TreeCell<ReceiptPayment> {
        private SVGRegion disclosureIcon;
        private GridPane root;
        private Font normal, bold;
        private Border topBorder;
        private Text particulars, cash, kind, mobile, total;
        private TextFlow particularsFlow;
        private DecimalFormat formatter;

        public ReceiptPaymentCell() {
            setBackground(null);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setPadding(new Insets(2.5, 0, 2.5, 2.5));
            setPrefWidth(0);

            initializeUI();
            itemProperty().addListener(this::onItemChanged);
        }

        private void initializeUI() {
            formatter = new DecimalFormat("#,###;(#,###)");

            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0), new Insets(0, 0, 0, -15)));

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            particulars = new Text() {{setFill(Color.WHITE); setFont(bold);}};
            cash = new Text() {{setFill(Color.WHITE);}};
            kind = new Text() {{setFill(Color.WHITE);}};
            mobile = new Text() {{setFill(Color.WHITE);}};
            total = new Text() {{setFill(Color.WHITE);}};
            particularsFlow = new TextFlow(particulars);

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.SOMETIMES); setWrapText(true);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}}
                );
                add(particularsFlow, 0, 0);
                add(cash, 1, 0);
                add(kind, 2, 0);
                add(mobile, 3, 0);
                add(total, 4, 0);
            }};
        }

        private void onItemChanged(ObservableValue<?> o, ReceiptPayment ov, ReceiptPayment nv) {
            if (ov != null) {
                particulars.setFont(bold);
                particulars.setText(null);
                cash.setText(null);
                kind.setText(null);
                mobile.setText(null);
                total.setText(null);

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);
                root.setBorder(null);
                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                if (level == 1) {
                    particulars.setText(nv.getControl() + " (" + item.getChildren().size() + ")");
                }
                else if (level == 2) {
                    particulars.setText(nv.getHead()+ " (" + item.getChildren().size() + ")");
                }
                else if (level == 3) {
                    particulars.setText(nv.getPlot()+ " (" + item.getChildren().size() + ")");
                }
                else if (level == 4) {
                    if(nv.getSpace() != null){
                        particulars.setText(nv.getTenant() + " - " + nv.getSpace());
                        particulars.setFont(normal);
                    }
                    else particulars.setText(nv.getTenant()+ " (" + item.getChildren().size() + ")");
                }
                else if (level == 5) {
                    particulars.setText(nv.getSpace());
                    particulars.setFont(normal);
                }
                cash.setText(nv.getCash() == 0? "   -  " : formatter.format(nv.getCash()));
                kind.setText(nv.getKind() == 0? "   -  " : formatter.format(nv.getKind()));
                mobile.setText(nv.getMobile() == 0? "   -  " : formatter.format(nv.getMobile()));
                total.setText(nv.getTotal() == 0? "   -  " : formatter.format(nv.getTotal()));
            }
        }

        @Override
        protected void updateItem(ReceiptPayment item, boolean empty) {
            super.updateItem(item, empty);
            if (isEmpty()) {
                setBackground(null);
                setGraphic(null);
                return;
            }
            setGraphic(root);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}
