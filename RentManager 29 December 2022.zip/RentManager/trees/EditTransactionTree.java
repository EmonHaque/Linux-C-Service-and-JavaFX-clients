package trees;

import Models.Transaction;
import controls.SVGRegion;
import controls.texts.HiText;
import controls.texts.SVGIconRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import skinned.ExtendedTreeView;

import java.util.List;

public class EditTransactionTree extends ExtendedTreeView<Transaction> {
    private final TreeItem<Transaction> plots;

    public EditTransactionTree(ObservableList<Transaction> list, StringProperty query) {
        plots = new TreeItem<>();
        setRoot(plots);
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new TransactionCell(query));
        list.addListener(this::onItemsChanged);
    }

    private void onItemsChanged(ListChangeListener.Change<? extends Transaction> change) {
        // why while?
        getSelectionModel().clearSelection();
        while (change.next()) {
            if(change.getRemovedSize() > 0){
                removeItems((List<Transaction>) change.getRemoved());
            }
            if(change.getAddedSize() > 0){
                addItems((List<Transaction>) change.getAddedSubList());
            }
        }
    }

    private void removeItems(List<Transaction> list) {
        for(var transaction : list){
            TreeItem<Transaction> plot = null;
            for (var tree : plots.getChildren()){
                if(tree.getValue().getPlotName().equals(transaction.getPlotName())){
                    plot = tree;
                    plot.getValue().setAmount(plot.getValue().getAmount() - transaction.getAmount());
                    break;
                }
            }
            TreeItem<Transaction> leaf = null;
            for(var item : plot.getChildren()){
                if(item.getValue().getId() == transaction.getId()){
                    leaf = item;
                    break;
                }
            }
            plot.getChildren().remove(leaf);
            if(plot.getChildren().size() == 0){
                plots.getChildren().remove(plot);
            }
        }
    }

    private void addItems(List<Transaction> list) {
        for (var transaction : list) {
            var hasIt = false;
            TreeItem<Transaction> item = null;
            for (var tree : plots.getChildren()) {
                if (tree.getValue().getPlotName().equals(transaction.getPlotName())) {
                    item = tree;
                    item.getValue().setAmount(item.getValue().getAmount() + transaction.getAmount());
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                item = new TreeItem<>(new Transaction() {{
                    setPlotName(transaction.getPlotName());
                    setAmount(transaction.getAmount());
                }});
                item.setExpanded(true);
                plots.getChildren().add(item);
            }
            var leaf = new TreeItem<>(transaction);
            item.getChildren().add(leaf);
        }
    }

    private class TransactionCell extends TreeCell<Transaction> {
        private GridPane root;
        private HiText flow;
        private Text space, dash, tenant, control, amount;
        private SVGIconRegion icon;
        private SVGRegion disclosureIcon;
        private Font normal, bold;
        private final StringProperty query;

        public TransactionCell(StringProperty query) {
            this.query = query;
            setPrefWidth(0);
            setPadding(new Insets(2.5, 0, 2.5, 0));
            setBackground(null);

            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            initializeUI();
            itemProperty().addListener(this::onItemChanged);
        }

        private void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            space = new Text() {{setFill(Color.WHITE);}};
            dash = new Text(" - ") {{setFill(Color.WHITE);}};
            tenant = new Text() {{setFill(Color.WHITE);}};
            control = new Text() {{
                setFill(Color.GRAY);
                setFont(Font.font(null, FontPosture.ITALIC, -1));
            }};
            amount = new Text() {{setFill(Color.WHITE);}};
            flow = new HiText();
            icon = new SVGIconRegion(Icons.Cash);

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.SOMETIMES); setWrapText(true);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints() {{setFillWidth(true);}}
                );
                add(flow, 0, 0);
                add(amount, 1, 0);
                add(icon, 2, 0);
                setMargin(icon, new Insets(0, 0, 0, 5));
            }};
        }

        private void onItemChanged(ObservableValue<?> o, Transaction ov, Transaction nv) {
            if (ov != null) {
                flow.clear();
                space.setText(null);
                tenant.setText(null);
                control.setText(null);
                amount.setText(null);

                flow.query.unbind();
                flow.query.set("");

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                if (level == 1) {
                    GridPane.setColumnSpan(amount, 2);
                    flow.addAll(space, tenant);
                    space.setText(nv.getPlotName());
                    space.setFont(bold);
                    amount.setFont(bold);
                    tenant.setText(" (" + item.getChildren().size() + ")");
                    icon.setVisible(false);
                }
                else {
                    GridPane.setColumnSpan(amount, 1);
                    flow.addAll(space, dash, tenant, control);

                    space.setFont(normal);
                    amount.setFont(normal);
                    space.setText(nv.getSpaceName());
                    tenant.setText(nv.getTenantName());
                    control.setText(" " + nv.getControlName());

                    icon.setVisible(true);
                    switch (nv.getIsCash()) {
                        case 0 -> {
                            icon.setContent(Icons.Cash);
                            icon.setFill(Color.LIGHTGREEN);
                        }
                        case 1 -> {
                            icon.setContent(Icons.NonCash);
                            icon.setFill(Color.LIGHTCORAL);
                        }
                        case 2 -> {
                            icon.setContent(Icons.Mobile);
                            icon.setFill(Color.CORNFLOWERBLUE);
                        }
                    }
                    flow.query.set(query.get());
                    flow.query.bind(query);
                }
                amount.setText(String.format("%,d", nv.getAmount()));
            }
        }

        @Override
        protected void updateItem(Transaction item, boolean empty) {
            super.updateItem(item, empty);
            if (isEmpty()) {
                setBackground(null);
                setGraphic(null);
            }
            else {
                setGraphic(root);
                if (getTreeView().getTreeItemLevel(getTreeItem()) == 2) {
                    setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
                    setDisable(false);
                }
                else {
                    setDisable(true);
                }
            }
        }
    }
}
