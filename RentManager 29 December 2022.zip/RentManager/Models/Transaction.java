package Models;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;

import java.time.LocalDate;

public class Transaction {
    private byte isCash;
    private int id, plotId, spaceId, tenantId, controlId, headId, amount;
    private String plotName, spaceName, tenantName, controlName, narration;
    private ObjectProperty<LocalDate> date;

    public Transaction() {
        date = new SimpleObjectProperty<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPlotName(){ return plotName; }

    public String getSpaceName(){ return spaceName; }

    public String getTenantName() {
        return tenantName;
    }

    public String getControlName() { return controlName;}

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public void setPlotName(String value){ plotName = value; }

    public void setSpaceName(String value){ spaceName = value; }

    public void setControlName(String value){ controlName = value; }

    public int getPlotId() {
        return plotId;
    }

    public void setPlotId(int plotId) {
        this.plotId = plotId;
    }

    public int getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }

    public int getTenantId() {
        return tenantId;
    }

    public void setTenantId(int tenantId) {
        this.tenantId = tenantId;
    }

    public int getControlId() {
        return controlId;
    }

    public void setControlId(int controlId) {
        this.controlId = controlId;
    }

    public int getHeadId() {
        return headId;
    }

    public void setHeadId(int headId) {
        this.headId = headId;
    }

    public byte getIsCash() {
        return isCash;
    }

    public void setIsCash(byte isCash) {
        this.isCash = isCash;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getNarration() {
        return narration;
    }

    public void setNarration(String narration) {
        this.narration = narration;
    }

    public LocalDate getDate() {
        return date.get();
    }

    public void setDate(LocalDate date) { this.date.set(date); }
    public ObjectProperty<LocalDate> dateProperty(){return date;}
}
