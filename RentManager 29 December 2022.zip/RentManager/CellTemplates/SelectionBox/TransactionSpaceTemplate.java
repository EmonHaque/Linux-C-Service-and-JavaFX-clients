package CellTemplates.SelectionBox;

import Models.SpaceTransaction;
import abstracts.ListCellBase;
import controls.texts.HiText2;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class TransactionSpaceTemplate extends ListCellBase<SpaceTransaction> {
    private BorderPane root;
    private HiText2 hiName;
    private Text date;
    private final StringProperty query;

    public TransactionSpaceTemplate(StringProperty query) {
        super();
        this.query = query;
        setPadding(new Insets(5));
    }

    @Override
    protected void initializeUI() {
        hiName = new HiText2();
        date = new Text();
        root = new BorderPane(){{
            setCenter(hiName);
            setRight(date);
            setAlignment(hiName, Pos.CENTER_LEFT);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, SpaceTransaction ov, SpaceTransaction nv) {

        if(nv != null){
            hiName.textProperty().bind(nv.nameProperty());
            date.textProperty().bind(nv.startDateProperty());
            if(nv.getIsExpired()){
                hiName.setFill(Color.GRAY);
                date.setFill(Color.GRAY);
            }
            else{
                hiName.setFill(Color.WHITE);
                date.setFill(Color.WHITE);
            }
            hiName.queryProperty().bind(query);
        }
        else {
            hiName.textProperty().unbind();
            date.textProperty().unbind();
            hiName.queryProperty().unbind();
        }
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
