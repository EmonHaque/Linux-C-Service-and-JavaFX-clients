package CellTemplates.SelectionBox;

import Models.Tenant;
import abstracts.ListCellBase;
import controls.texts.HiText2;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class TenantTemplate extends ListCellBase<Tenant> {
    private BorderPane root;
    private HiText2 hiName;
    private Text phone;
    private final StringProperty query;

    public TenantTemplate(StringProperty query) {
        super();
        this.query = query;
        setPadding(new Insets(5));
    }

    @Override
    protected void initializeUI() {
        hiName = new HiText2();
        //name = new Text();
        phone = new Text();
        root = new BorderPane(){{
           setCenter(hiName);
           setRight(phone);
           setAlignment(hiName, Pos.CENTER_LEFT);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Tenant ov, Tenant nv) {
        if(nv != null){
            hiName.textProperty().bind(nv.nameProperty());
            phone.textProperty().bind(nv.contactNoProperty());
            hiName.queryProperty().bind(query);

            if(nv.isHasLeft()){
                hiName.setFill(Color.GRAY);
                phone.setFill(Color.GRAY);
            }
            else{
                hiName.setFill(Color.WHITE);
                phone.setFill(Color.WHITE);
            }
        }
        else {
            hiName.textProperty().unbind();
            phone.textProperty().unbind();
            hiName.queryProperty().unbind();
        }
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
