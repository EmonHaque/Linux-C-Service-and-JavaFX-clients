package CellTemplates.ListView;

import Models.ReportEntry;
import abstracts.ListCellBase;
import controls.texts.HiText2;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

import java.text.DecimalFormat;

public class LedgerTemplate extends ListCellBase<ReportEntry> {
    private GridPane root;
    private Text date, receivable, receipt, balance;
    private HiText2 particulars;
    private DecimalFormat formatter;
    private final StringProperty query;

    public LedgerTemplate(StringProperty query) {
        super();
        this.query = query;
    }

    @Override
    protected void initializeUI() {
        formatter = new DecimalFormat("#,##0;(#,##0)");
        particulars = new HiText2();
        date = new Text() {{setFill(Color.WHITE);}};
        receivable = new Text() {{setFill(Color.WHITE);}};
        receipt = new Text() {{setFill(Color.WHITE);}};
        balance = new Text() {{setFill(Color.WHITE);}};

        root = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints(90) {{setValignment(date, VPos.TOP);}},
                    new ColumnConstraints() {{setHgrow(Priority.SOMETIMES);}},
                    new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}}
            );
            add(date, 0, 0);
            add(particulars, 1, 0);
            add(receivable, 2, 0);
            add(receipt, 3, 0);
            add(balance, 4, 0);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, ReportEntry ov, ReportEntry nv) {
        if (nv == null) return;

        date.setText(nv.getDate().toString());
        particulars.setText(nv.getParticulars());
        receivable.setText(nv.getReceivable() == 0 ? "   -   " : formatter.format(nv.getReceivable()));
        receipt.setText(nv.getReceipt() == 0 ? "   -   " : formatter.format(nv.getReceipt()));
        balance.setText(nv.getBalance() == 0 ? "   -   " : formatter.format(nv.getBalance()));
        particulars.queryProperty().bind(query);
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
