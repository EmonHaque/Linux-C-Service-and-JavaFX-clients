package CellTemplates.ListView;

import Models.Tenant;
import abstracts.ListCellBase;
import controls.texts.HiText2;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class EditTenantTemplate extends ListCellBase<Tenant> {
    private BorderPane root;
    private HiText2 name;
    private Text phone;

    private final StringProperty query;
    private final IntegerProperty state;

    public EditTenantTemplate(StringProperty query, IntegerProperty state) {
        super();
        this.query = query;
        this.state = state;
    }

    @Override
    protected Node getRootNode() {
        return root;
    }

    @Override
    protected void initializeUI() {
        name = new HiText2();
        phone = new Text();
        root = new BorderPane() {{
            setCenter(name);
            setRight(phone);
        }};
        BorderPane.setMargin(phone, new Insets(0, 5, 0, 5));
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Tenant ov, Tenant nv) {
        if (nv == null) return;

        name.textProperty().bind(nv.nameProperty());
        name.queryProperty().bind(query);
        phone.textProperty().bind(nv.contactNoProperty());

        var fillBinding = Bindings.createObjectBinding(() -> {
            if (state.get() != 2) return Color.WHITE;
            return nv.isHasLeft() ? Color.GRAY : Color.WHITE;
        }, state, nv.hasLeftProperty());

        name.fillProperty().bind(fillBinding);
        phone.fillProperty().bind(fillBinding);
    }
}
