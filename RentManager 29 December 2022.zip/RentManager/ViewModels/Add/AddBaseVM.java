package ViewModels.Add;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.concurrent.Task;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.util.concurrent.ExecutionException;

public abstract class AddBaseVM {
    public StringProperty statusProperty;
    public BooleanProperty isRunningProperty;

    public AddBaseVM() {
        statusProperty = new SimpleStringProperty("");
        isRunningProperty = new SimpleBooleanProperty();
    }

    protected abstract int function();

    protected abstract ByteBuffer buffer();

    protected abstract void resetObject();

    public void add() {
        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private class ResponseTask extends Task<Boolean> {
        @Override
        protected Boolean call() throws Exception {
            updateMessage("requesting ...");
            Thread.sleep(500);
            var request = new Request(function(), buffer());
            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return false;
            }
            var isOk = response.getPacket()[0] != 0;
            updateMessage(isOk ? "successfully added" : new String(response.getPacket(), 1, response.getPacket().length - 1));
            Thread.sleep(500);
            return isOk;
        }

        @Override
        protected void succeeded() {
            try {
                if(get()) resetObject();
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
