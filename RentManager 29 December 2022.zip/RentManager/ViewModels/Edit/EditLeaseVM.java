package ViewModels.Edit;

import Enums.Function;
import Models.*;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;
import ridiculous.Jar;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;

public class EditLeaseVM extends EditBaseVM<Lease> {
    private final IntegerProperty editedPlotIdProperty;

    public FilteredList<Plot> plots, editPlot;
    public FilteredList<Space> editSpace;
    public FilteredList<Tenant> editTenant;
    public IntegerProperty selectedPlotIdProperty, stateProperty;
    public BooleanProperty isOnEditProperty;

    public EditLeaseVM() {
        selected = new Lease();
        edited = new Lease();
        stateProperty = new SimpleIntegerProperty();
        selectedPlotIdProperty = new SimpleIntegerProperty();
        editedPlotIdProperty = new SimpleIntegerProperty();
        isOnEditProperty = new SimpleBooleanProperty();

        plots = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.plots));
        editPlot = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.plots));

        var editSpaceSource = new Jar<>(AppData.spaces, o -> new Observable[]{
                selectedPlotIdProperty,
                editedPlotIdProperty
        });
        editSpace = new FilteredList<>(editSpaceSource, x -> isOnEditProperty.get() ?
                x.getPlotId() == editedPlotIdProperty.get() :
                x.getPlotId() == selectedPlotIdProperty.get()
        );
        editTenant = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.tenants));

        var source = new Jar<>(AppData.leases, o -> new Observable[]{
                o.isExpiredProperty(),
                stateProperty,
                queryProperty,
                selectedPlotIdProperty
        });
        editableList = new FilteredList<>(source.sorted(Comparator.comparing(Lease::getSpaceName)), this::filter);
        stateProperty.addListener(this::onQueryEditableListChanged); // when bound filter will be called once
        selectedPlotIdProperty.addListener(this::onQueryEditableListChanged); // when bound filter will be called once more

        isOnEditProperty.addListener(this::onIsOnEditChanged);
    }

    private boolean filter(Lease lease) {
        var isMatch = lease.getPlotId() == selectedPlotIdProperty.get();
        if (!isMatch) return false;
        if (!isQueryEmpty) {
            isMatch = lease.getSpaceName().toLowerCase().contains(trimmedQuery)
                    || lease.getTenantName().toLowerCase().contains(trimmedQuery);
        }
        switch (stateProperty.get()) {
            case 0 -> isMatch = isMatch && !lease.isIsExpired();
            case 1 -> isMatch = isMatch && lease.isIsExpired();
        }
        return isMatch;
    }

    @Override
    protected int function() {
        System.out.println("returned function " + Function.EditLease.ordinal());
        return Function.EditLease.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var expireDate = "";
        var isExpired = false;
        if (!selected.isIsExpired() && edited.isIsExpired()) {
            System.out.println("setting date");
            System.out.println("date: " + edited.getDateEnd());
            expireDate = edited.getDateEnd().toString();
            System.out.println("set date");
            isExpired = true;

        }
        var startDateBytes = (edited.getDateStart().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
        var endDateBytes = (expireDate + '\0').getBytes(StandardCharsets.US_ASCII);
        var businessBytes = (edited.getBusiness() + '\0').getBytes(StandardCharsets.US_ASCII);

        var buffer = ByteBuffer.allocate(17 + edited.getFixedReceivables().size() * 12
                        + startDateBytes.length + endDateBytes.length + businessBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(edited.getId())
                .putInt(edited.getPlotId())
                .putInt(edited.getSpaceId())
                .putInt(edited.getTenantId())
                .put(startDateBytes)
                .put(endDateBytes)
                .put(businessBytes)
                .put(isExpired ? (byte) 1 : 0);

        for (var receivable : edited.getFixedReceivables()) {
            buffer.putInt(receivable.getLeaseId())
                    .putInt(receivable.getHeadId())
                    .putInt(receivable.getAmount());
        }
        return buffer;
    }

    @Override
    public void cloneSelected() {
        edited.plotIdProperty().removeListener(this::onEditedPlotIdChanged);
        edited = new Lease() {{
            setId(selected.getId());
            setPlotId(selected.getPlotId());
            setSpaceId(selected.getSpaceId());
            setTenantId(selected.getTenantId());
            setBusiness(selected.getBusiness());
            setDateStart(selected.getDateStart());
            setDateEnd(selected.getDateEnd());
            setIsExpired(selected.isIsExpired());
        }};
        edited.setFixedReceivables(FXCollections.observableArrayList());
        for (var rec : selected.getFixedReceivables()) {
            edited.getFixedReceivables().add(new Receivable(
                    rec.getLeaseId(),
                    rec.getHeadId(),
                    rec.getAmount()
            ));
        }
        edited.plotIdProperty().addListener(this::onEditedPlotIdChanged);
    }

    private void onIsOnEditChanged(ObservableValue<?> o, boolean ov, boolean nv) {
        if (!nv) {
            System.out.println("editedPlotId " + editedPlotIdProperty.get());
            editedPlotIdProperty.set(selectedPlotIdProperty.get());
        }
    }

    private void onEditedPlotIdChanged(ObservableValue<?> o, Number ov, Number nv) {
        System.out.println("editedPlotId " + editedPlotIdProperty.get());
        editedPlotIdProperty.set(nv.intValue());
    }

    public void removeReceivable(Receivable r) {
        edited.getFixedReceivables().remove(r);
    }
}
