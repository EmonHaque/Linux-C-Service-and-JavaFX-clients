package ViewModels.Edit;

import Enums.Function;
import Models.Plot;
import Models.Space;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;
import ridiculous.Jar;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Comparator;

public class EditSpaceVM extends EditBaseVM<Space> {
    public FilteredList<Plot> plots, editPlots;
    public IntegerProperty selectedPlotProperty, stateProperty;
    public ObjectProperty<LocalDate> selectedDateProperty;

    public EditSpaceVM() {
        edited = new Space();
        selectedPlotProperty = new SimpleIntegerProperty();
        stateProperty = new SimpleIntegerProperty();
        selectedDateProperty = new SimpleObjectProperty<>();

        plots = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.plots));
        editPlots =  new FilteredList<>(FXCollections.synchronizedObservableList(AppData.plots));

        var nameAscending = Comparator.comparing(Space::getName);
        var source = new Jar<>(AppData.spaces, o -> new Observable[]{
                stateProperty,
                queryProperty,
                selectedPlotProperty,
                o.plotIdProperty(),
                o.isVacantProperty()
        });
        editableList = new FilteredList<>(source.sorted(nameAscending), this::filter);
    }

    private boolean filter(Space space) {
        var isMatch = space.getPlotId() == selectedPlotProperty.get();
        if(!isMatch) return false;

        if(!isQueryEmpty){
            isMatch = space.getName().toLowerCase().contains(trimmedQuery);
        }
        switch (stateProperty.get()){
            case 0 ->  isMatch = isMatch && !space.isIsVacant();
            case 1 -> isMatch = isMatch && space.isIsVacant();
        }
        return isMatch;
    }

    @Override
    protected int function() {
        return Function.EditSpace.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var vacatedOn = "";
        byte isVacant = 0;
        if(edited.isIsVacant() && !selected.isIsVacant()){
            vacatedOn =selectedDateProperty.get().toString();
            isVacant = 1;
        }
        var vacatedOnBytes = (vacatedOn + '\0').getBytes(StandardCharsets.US_ASCII);
        var nameBytes = (edited.getName().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
        var descBytes = (edited.getDescription().trim() + '\0').getBytes(StandardCharsets.US_ASCII);

        return ByteBuffer.allocate(9 + vacatedOnBytes.length + nameBytes.length + descBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .put(vacatedOnBytes)
                .putInt(edited.getId())
                .putInt(edited.getPlotId())
                .put(nameBytes)
                .put(descBytes)
                .put(isVacant);
    }

    @Override
    public void cloneSelected() {
        edited = new Space(
          selected.getId(),
          selected.getPlotId(),
          selected.getName(),
          selected.getDescription(),
          selected.isIsVacant()
        );
    }
}
