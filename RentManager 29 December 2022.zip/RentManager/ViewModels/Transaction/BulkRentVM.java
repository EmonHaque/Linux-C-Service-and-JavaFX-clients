package ViewModels.Transaction;

import Enums.Function;
import Models.Lease;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import ridiculous.AppData;
import ridiculous.Jar;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Predicate;

public class BulkRentVM {
    public FilteredList<Lease> leases;
    public ObservableList<Lease> excluded;
    public ObjectProperty<LocalDate> selectedDate;
    public StringProperty statusProperty, queryProperty;
    public BooleanProperty isRunningProperty;

    private final Predicate<Lease> isExpired;

    public BulkRentVM() {
        isExpired = Lease::isIsExpired;
        var nameAscending = Comparator.comparing(Lease::getPlotName).thenComparing(Lease::getSpaceName);
        var source = new Jar<>(AppData.leases, o -> new Observable[]{ o.isExpiredProperty() });
        leases = new FilteredList<>(source.sorted(nameAscending), isExpired.negate());
        excluded = FXCollections.observableArrayList();
        selectedDate = new SimpleObjectProperty<>();

        statusProperty = new SimpleStringProperty("");
        queryProperty = new SimpleStringProperty("");
        isRunningProperty = new SimpleBooleanProperty();

        queryProperty.addListener(this::onQueryChanged);
    }

    private void onQueryChanged(Observable observable) {
        var trimmed = queryProperty.get().trim().toLowerCase();
        var isEmpty = trimmed.isEmpty();
        Predicate<Lease> isMatch = null;
        if(!isEmpty){
            isMatch = x -> x.getPlotName().toLowerCase().contains(trimmed)
                    || x.getSpaceName().toLowerCase().contains(trimmed)
                    || x.getTenantName().toLowerCase().contains(trimmed);
        }
        leases.setPredicate(isEmpty ? isExpired.negate() : isExpired.negate().and(isMatch));
    }

    public void add() {
        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private class ResponseTask extends Task<Boolean>{
        int entries;
        @Override
        protected Boolean call() throws Exception {
            updateMessage("processing entries ...");
            Thread.sleep(500);

            var bytes = getBytes();
            var request = new Request(Function.AddBulkRent.ordinal(), bytes);

            updateMessage("requesting ...");
            Thread.sleep(500);
            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return false;
            }
            var isSuccess = response.getPacket()[0] != 0;
            updateMessage(isSuccess ? "successfully added " + entries + " entries" : "failed to add entries");
            Thread.sleep(500);
            return isSuccess;
        }

        private ByteBuffer getBytes(){
            var formatter = DateTimeFormatter.ofPattern("MMMM, yyyy");
            var numDays = selectedDate.get().getMonth().length(selectedDate.get().isLeapYear());
            var lastDay = LocalDate.of(selectedDate.get().getYear(), selectedDate.get().getMonthValue(), numDays);
            var dateBytes = (lastDay.toString() + '\0').getBytes(StandardCharsets.US_ASCII);
            var narrationBytes = (lastDay.format(formatter) + '\0').getBytes(StandardCharsets.US_ASCII);

            int total = 29 + dateBytes.length + narrationBytes.length;
            int size = 0;
            entries = 0;
            var buffers = new ArrayList<ByteBuffer>();
            for (var lease : leases) {
                if (excluded.contains(lease)) continue;
                for (var rec : lease.getFixedReceivables()) {
                    entries++;
                    size += total;
                    buffers.add(ByteBuffer.allocate(total)
                            .order(ByteOrder.LITTLE_ENDIAN)
                            .putInt(0)
                            .putInt(lease.getPlotId())
                            .putInt(lease.getSpaceId())
                            .putInt(lease.getTenantId())
                            .putInt(AppData.controlIdOfReceivable)
                            .putInt(rec.getHeadId())
                            .putInt(rec.getAmount())
                            .put((byte) 1)
                            .put(dateBytes)
                            .put(narrationBytes)
                    );
                }
            }
            var bytes = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
            for(var buffer : buffers) bytes.put(buffer.array());
            return bytes;
        }
    }
}
