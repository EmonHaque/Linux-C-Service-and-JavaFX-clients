package ViewModels.Home;

public class PlotDueVM {
}
