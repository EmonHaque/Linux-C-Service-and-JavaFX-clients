package ViewModels.Home;

public class RentVM {
}
