package ViewModels.Home;

public class TenantDetailVM {
}
