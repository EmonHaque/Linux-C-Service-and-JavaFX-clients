package ViewModels.Home;

public class PlotRentVM {
}
