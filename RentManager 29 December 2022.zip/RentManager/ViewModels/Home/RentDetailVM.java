package ViewModels.Home;

public class RentDetailVM {
}
