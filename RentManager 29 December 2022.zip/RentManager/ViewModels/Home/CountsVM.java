package ViewModels.Home;

import helpers.Icons;
import javafx.beans.Observable;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.util.Pair;

public class CountsVM {
    public IntegerProperty state, selectionState;
    public ObjectProperty<Pair<String[], String[]>> selectionProperty;
    private String[] selectionStateTexts, selectionStateIcons;

    public CountsVM() {
        state = new SimpleIntegerProperty();
        selectionState = new SimpleIntegerProperty();
        selectionProperty = new SimpleObjectProperty<>();

        selectionState.addListener(this::onSelectionStateChange);
        selectionStateTexts = new String[] { "Occupied", "Vacant", "All" };
        selectionStateIcons = new String[] { Icons.Existing, Icons.LeftOrExpired, Icons.All };
    }

    private void onSelectionStateChange(Observable o) {
        switch (selectionState.get()) {
            case 0:
                getSpaceSummary();
                selectionStateTexts = new String[] { "Occupied", "Vacant", "All" };
                break;
            case 1:
                getLeaseSummary();
                selectionStateTexts = new String[] { "Active", "Expired", "All" };
                break;
            case 2:
                getTenantSummary();
                selectionStateTexts = new String[] { "Existing", "Left", "All" };
                break;
        }
        selectionProperty.set(new Pair<>(selectionStateTexts, selectionStateIcons));
    }

    private void getSpaceSummary(){

    }

    private void getLeaseSummary(){

    }

    private void getTenantSummary(){

    }

    public void refresh(){
        switch (selectionState.get()) {
            case 0: getSpaceSummary(); break;
            case 1: getLeaseSummary(); break;
            case 2: getTenantSummary(); break;
        }
    }
}
