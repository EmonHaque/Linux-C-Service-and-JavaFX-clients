package ViewModels.Search;

import Enums.Function;
import Interfaces.IBillEntry;
import Model.DatePaymentSummary;
import Model.EditedBillInfo;
import Model.ReportEntry;
import javafx.beans.Observable;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import model.PieSeries;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class DateSearchVM extends SearchBaseVM {
    private final ObservableList<ReportEntry> list;
    public final ObservableList<DatePaymentSummary> summaryPaymentList;
    public List<DatePaymentSummary> summary;

    public FilteredList<ReportEntry> reportable;
    public DoubleProperty totalPaymentLeft, totalBillRight, totalPaymentRight;
    public ObjectProperty<LocalDate> selectedDate;
    public ObjectProperty<List<PieSeries>> pieSeries;
    public ObjectProperty<PieSeries> selectedSlice;

    public DateSearchVM() {
        totalPaymentLeft = new SimpleDoubleProperty();
        totalPaymentRight = new SimpleDoubleProperty();
        totalBillRight = new SimpleDoubleProperty();

        selectedDate = new SimpleObjectProperty<>();
        pieSeries = new SimpleObjectProperty<>();
        selectedSlice = new SimpleObjectProperty<>();

        summaryPaymentList = FXCollections.observableArrayList();
        list = FXCollections.observableArrayList();
        reportable = new FilteredList<>(list, x -> {
            if (query.get() == null || query.get().isEmpty() || query.get().isBlank()) return true;
            return x.getPeriod().toLowerCase().contains(query.get().toLowerCase());
        });

        selectedDate.addListener(this::onDateChange);
        selectedSlice.addListener(this::onSliceSelectionChange);
        AppData.onBillInfoEdited.addListener(this::onBillInfoEdited);
        selectedEntry.addListener((o, ov, nv) -> startImageBreakupTask(nv));
    }

    @Override
    protected int getBillIdForBreakup() {
        return selectedEntry.get().getBillId();
    }

    @Override
    protected IBillEntry getEditedEntry(int billId) {
        IBillEntry entry = null;
        if (list.size() == 0) entry = null;
        for (var e : list) {
            if (e.getBillId() != billId) continue;
            entry = e;
            break;
        }
        return entry;
    }

    @Override
    protected String getImageFileName() {
        return selectedEntry.get().getFileName();
    }

    private void onDateChange(Observable o, LocalDate ov, LocalDate nv) {
        if (nv == null) return;
        startEntryTask();
    }

    private void onBillInfoEdited(Observable o, EditedBillInfo ov, EditedBillInfo nv) {
        var entry = list.stream().filter(x -> x.getBillId() == nv.getBillId()).findFirst();
        if (entry.isEmpty()) return;

        var e = entry.get();
        if (nv.isFileRenamed()) {
            if (!nv.getDate().equals(selectedDate.get().toString())) {
                list.remove(e);
            }
            e.setDate(nv.getDate());
            e.setTransactionId(nv.getTransactionId());
            e.setFileName(nv.getNewFile());
        }
        if (e.getMobileId() != nv.getMobileId()) {
            var mobile = AppData.mobiles.stream().filter(x -> x.getId() == nv.getMobileId()).findFirst().get();
            e.setMobileId(mobile.getId());
            e.setMobileNo(mobile.getNumber());
        }
        e.setBillNo(nv.getBillNo());
        e.setPeriod(nv.getPeriod());
    }

    private void onSliceSelectionChange(Observable o, PieSeries ov, PieSeries nv){
        if(nv == null){

        }
        else{
            summaryPaymentList.clear();
            summaryPaymentList.addAll(summary.stream().filter(x -> x.getHead().equals(nv.title)).toList());
            double bill = 0, payment = 0;
            for(var e : summaryPaymentList){
                bill += e.getBill();
                payment += e.getPayment();
            }
            totalBillRight.set(bill);
            totalPaymentRight.set(payment);
        }
    }

    public void refresh() {
        startEntryTask();
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void startEntryTask() {
        if (task != null && task.isRunning()) {
            task.setOnCancelled(e -> {
                task.setOnCancelled(null);
                startTask(new GetEntriesTask());
            });
            task.cancel();
        }
        else startTask(new GetEntriesTask());
    }


    private class GetEntriesTask extends Task<List<ReportEntry>> {
        private int length;
        private double payment;

        @Override
        protected List<ReportEntry> call() {
            try {
                updateMessage("requesting");
                Thread.sleep(250);

                if (isCancelled()) return null;

                var dateBytes = (selectedDate.get().toString() + '\0').getBytes(StandardCharsets.UTF_8);

                var buffer = ByteBuffer.allocate(dateBytes.length)
                        .order(ByteOrder.LITTLE_ENDIAN)
                        .put(dateBytes);
                var request = new Request(Function.GetEntriesByDate.ordinal(), buffer);
                var response = Channels.getInstance().getResponse(request).get();
                length = response.getPacket().length;

                if (isCancelled()) return null;

                updateMessage("received " + String.format("%,d", length) + " bytes");
                Thread.sleep(250);

                updateMessage("processing " + String.format("%,d", length) + " bytes");
                Thread.sleep(250);

                if (isCancelled()) return null;
                buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);

                return getEntries(buffer);
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        protected void succeeded() {
            try {
                var entries = get();
                list.clear();
                list.addAll(entries);

                totalPaymentLeft.set(payment);
                updateMessage("processed " + String.format("%,d", length) + " bytes");

                startTask(new GetPaymentSummaryTask());
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        private List<ReportEntry> getEntries(ByteBuffer buffer) {
            payment = 0;
            var list = new ArrayList<ReportEntry>();
            int start = 0;
            int read = 0;

            while (read < length) {
                if (isCancelled()) break;

                int id = buffer.getInt(start);
                int deptId = buffer.getInt(start + 4);
                int accountId = buffer.getInt(start + 8);
                int mobileId = buffer.getInt(start + 12);

                read += 16;
                start = read;
                int index = 0;
                var segments = new String[6];
                while (read < length) {
                    if (buffer.get(read) != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }

                double bill = buffer.getDouble(read);
                double payment = buffer.getDouble(read + 8);

                read += 16;
                start = read;

                this.payment += payment;

                list.add(new ReportEntry() {{
                    setBillId(id);
                    setDeptId(deptId);
                    setAccountId(accountId);
                    setMobileId(mobileId);
                    setBillNo(segments[0]);
                    setPeriod(segments[1]);
                    setTransactionId(segments[2]);
                    setDate(segments[3]);
                    setFileName(segments[4]);
                    setAccountNo(segments[5]);
                    setBill(bill);
                    setPayment(payment);
                }});
            }

            return list;
        }
    }

    private class GetPaymentSummaryTask extends Task<List<PieSeries>> {
        private int length;

        @Override
        protected List<PieSeries> call() {
            try {
                updateMessage("requesting");
                Thread.sleep(250);

                if (isCancelled()) return null;

                var date = selectedDate.get().toString();
                var dateBytes = (date + '\0').getBytes(StandardCharsets.UTF_8);
                var buffer = ByteBuffer.allocate(dateBytes.length)
                        .order(ByteOrder.LITTLE_ENDIAN)
                        .put(dateBytes);
                var request = new Request(Function.GetDatePaymentSummary.ordinal(), buffer);
                var response = Channels.getInstance().getResponse(request).get();
                length = response.getPacket().length;

                if (isCancelled()) return null;

                updateMessage("received " + String.format("%,d", length) + " bytes");
                Thread.sleep(250);

                updateMessage("processing " + String.format("%,d", length) + " bytes");
                Thread.sleep(250);

                if (isCancelled()) return null;
                buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
                summary = getList(buffer);
                return getSeries(summary);

            } catch (Exception ignored) {

            }
            return null;
        }

        @Override
        protected void succeeded() {
            try {
                pieSeries.set(get());
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        private List<DatePaymentSummary> getList(ByteBuffer buffer) {
            var list = new ArrayList<DatePaymentSummary>();
            int start = 0;
            int read = 0;

            while (read < length) {
                if (isCancelled()) break;
                double bill = buffer.getDouble(read);
                double payment = buffer.getDouble(read + 8);

                read += 16;
                start = read;
                while (buffer.get(read) != 0) read++;
                var dept = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);

                start = ++read;
                while (buffer.get(read) != 0) read++;
                var head = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                read++;
                var e = new DatePaymentSummary() {{
                    setDepartment(dept);
                    setHead(head);
                    setBill(bill);
                    setPayment(payment);
                }};
                list.add(e);
            }
            return list;
        }

        private List<PieSeries> getSeries(List<DatePaymentSummary> list) {
            return list.stream().collect(Collectors.groupingBy(DatePaymentSummary::getHead))
                    .entrySet().stream().map(x -> new PieSeries(
                            0,
                            x.getKey(),
                            x.getValue().stream().mapToDouble(y ->
                                    x.getKey().equals("Amount") ?
                                            y.getBill() :
                                            y.getBill() + y.getPayment()
                            ).sum()
                    )).toList();
        }
    }
}
