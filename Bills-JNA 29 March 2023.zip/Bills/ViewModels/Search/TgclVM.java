package ViewModels.Search;

public class TgclVM extends DepartmentSearchVM {
    @Override
    public String getDepartmentName() {
        return "TGCL";
    }
}
