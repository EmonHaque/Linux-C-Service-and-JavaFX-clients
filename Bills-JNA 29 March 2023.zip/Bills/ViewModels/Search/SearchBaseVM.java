package ViewModels.Search;

import Enums.Function;
import Interfaces.IBillEntry;
import Model.Breakup;
import Model.EditedEntry;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import model.PieSeries;
import model.SumBoxModelDoubleColumn;
import model.ValidationError;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public abstract class SearchBaseVM {
    @SuppressWarnings("rawtypes")
    protected Task task;

    public ObservableList<Breakup> breakups;
    public IntegerProperty selectedId;
    public StringProperty query, status;
    public DoubleProperty totalPayment, breakupBillTotal, breakupPaymentTotal;
    public BooleanProperty isRunning, isInfoOnEdit, isEntryOnEdit, errorTrigger;
    public ObjectProperty<byte[]> imageBuffer;
    public ObjectProperty<List<PieSeries>> breakupSeries;
    public ObjectProperty<IBillEntry> selectedEntry;
    public IBillEntry edited;
    public final ObservableList<ValidationError> errors;
    public ObservableList<SumBoxModelDoubleColumn> entryList;

    public SearchBaseVM() {
        selectedId = new SimpleIntegerProperty();
        status = new SimpleStringProperty("");
        query = new SimpleStringProperty("");
        isRunning = new SimpleBooleanProperty();
        totalPayment = new SimpleDoubleProperty();
        errorTrigger = new SimpleBooleanProperty();
        breakupBillTotal = new SimpleDoubleProperty();
        breakupPaymentTotal = new SimpleDoubleProperty();
        breakupSeries = new SimpleObjectProperty<>();
        imageBuffer = new SimpleObjectProperty<>();
        breakups = FXCollections.observableArrayList();
        selectedEntry = new SimpleObjectProperty<>();
        isInfoOnEdit = new SimpleBooleanProperty();
        isEntryOnEdit = new SimpleBooleanProperty();
        errors = FXCollections.observableArrayList();

        entryList = FXCollections.observableArrayList();

        selectedId.addListener(this::onSelectedIdChange);
        isInfoOnEdit.addListener(this::onInfoIsOnEdit);
        isEntryOnEdit.addListener(this::onEntryIsOnEdit);

        AppData.onBillEntryEdited.addListener(this::onBillEntryEdit);
    }

    @SuppressWarnings("rawtypes")
    protected void startTask(Task newTask) {
        task = newTask;
        status.bind(task.messageProperty());
        isRunning.bind(task.runningProperty());
        new Thread(task) {{setDaemon(true);}}.start();
    }

    @SuppressWarnings("unchecked")
    protected void startImageBreakupTask(Object nv) {
        if (nv != null) {
            if (task != null && task.isRunning()) {
                task.setOnCancelled(e -> {
                    task.setOnCancelled(null);
                    startTask(new GetImageTask());
                });
                task.cancel();
            }
            else startTask(new GetImageTask());
        }
        else {
            imageBuffer.set(null);
            breakupSeries.set(null);
        }
    }

    protected abstract String getImageFileName();

    protected abstract int getBillIdForBreakup();

    protected abstract IBillEntry getEditedEntry(int billId);

    @SuppressWarnings("rawtypes")
    protected Task getEntriesTask() {return null;}

    private void onSelectedIdChange(Observable o, Number ov, Number nv) {
        if (nv.intValue() <= 0) return;
        if (getEntriesTask() == null) return;
        startEntryTask();
    }

    private void onInfoIsOnEdit(Observable o, boolean ov, boolean nv) {
        if (nv) {
            var selected = selectedEntry.get();
            var mobile = AppData.mobiles.stream().filter(x -> x.getId() == selected.getMobileId()).findFirst().get();
            edited = new IBillEntry() {{
                setDeptId(selected.getDeptId());
                setBillId(selected.getBillId());
                setMobileId(selected.getMobileId());
                setDate(selected.getDate());
                setBillNo(selected.getBillNo());
                setTransactionId(selected.getTransactionId());
                setPeriod(selected.getPeriod());
                setMobileNo(mobile.getNumber());
            }};
        }
    }

    private void onEntryIsOnEdit(Observable o, boolean ov, boolean nv) {
        if (!nv) return;
        entryList.clear();
        for (var e : breakups) {
            entryList.add(new SumBoxModelDoubleColumn(e.getHead(), e.getPaymentAmount(), e.getBillAmount()));
        }
    }

    public void saveBillInfo() {
        validateBillInfo();
        if (errors.size() > 0) {
            errorTrigger.set(true);
            return;
        }
        var selected = selectedEntry.get();
        if (!(edited.getDate().equals(selected.getDate()) &&
                edited.getTransactionId().equals(selected.getTransactionId()))) {

            var dept = AppData.departments.stream().filter(x -> x.getId() == edited.getDeptId()).findFirst().get();
            var desiredName = edited.getDate() + "-" + dept.getName() + "-" + edited.getTransactionId() + ".png";
            edited.setFileName(desiredName);
        }
        startTask(new EditBillInfoTask());
    }

    private void validateBillInfo() {
        errors.clear();
        if (edited.getDate().isBlank() || edited.getDate().isEmpty()) {
            errors.add(new ValidationError("Date", "cannot be empty"));
        }
        else {
            try {
                LocalDate.parse(edited.getDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            } catch (Exception e) {
                errors.add(new ValidationError("Date", "YYYY-MM-DD format expected"));
            }
        }
        if (edited.getPeriod().isBlank() || edited.getPeriod().isEmpty()) {
            errors.add(new ValidationError("Period", "cannot be empty"));
        }
        if (edited.getTransactionId().isBlank() || edited.getTransactionId().isEmpty()) {
            errors.add(new ValidationError("Transaction Id", "cannot be empty"));
        }
        if (edited.getMobileNo().isBlank() || edited.getMobileNo().isEmpty()) {
            errors.add(new ValidationError("Mobile", "cannot be empty"));
        }
        else {
            var mobileId = AppData.mobiles.stream().filter(x -> x.getNumber().equals(edited.getMobileNo().trim())).findFirst();
            if (mobileId.isPresent()) return;
            errors.add(new ValidationError("Mobile", edited.getMobileNo() + " doesn't exist"));
        }
    }

    public void saveEntries() {
        errors.clear();
        var heads = new ArrayList<String>();
        for (int i = 0; i < entryList.size(); i++) {
            var e = entryList.get(i);
            var trimmedHead = e.getKey().trim().toLowerCase();
            if (trimmedHead.isEmpty()) {
                errors.add(new ValidationError("Head at " + (i + 1), "cannot be empty"));
            }
            var match = AppData.heads.stream().filter(x -> x.getName().toLowerCase().equals(trimmedHead)).findFirst();
            if (match.isEmpty()) {
                errors.add(new ValidationError("Head at " + (i + 1), e.getKey() + " doesn't exist"));
            }
            if (heads.contains(trimmedHead)) {
                errors.add(new ValidationError("Head at " + (i + 1), "duplicate"));
            }
            if (e.getValue1() <= 0 && e.getValue2() <= 0) {
                errors.add(new ValidationError("Amount at " + (i + 1), "cannot be negative or zero"));
            }
            heads.add(e.getKey().trim().toLowerCase());
        }
        if (errors.size() > 0) {
            errorTrigger.set(true);
            return;
        }
        startTask(new EditBillEntryTask());
    }

    // will be called by all subclasses, one call for all Departmental Views and one for DateSearch view will do
    private void onBillEntryEdit(Observable o, List<EditedEntry> ov, List<EditedEntry> nv) {
        var selected = selectedEntry.get();
        var billId = nv.get(0).getBillId();
        var entry = getEditedEntry(billId);

        double bill = 0, payment = 0;
        for (var e : nv) {
            bill += e.getBill();
            payment += e.getPayment();
        }
        if (entry != null) {
            entry.setPayment(payment);
            entry.setBill(bill);
        }

        if(selected == null) return;
        if (selected.getBillId() != billId) return;

        breakups.clear();
        for (var e : nv) {
            var head = AppData.heads.stream().filter(x -> x.getId() == e.getHeadId()).findFirst().get();
            breakups.add(new Breakup() {{
                setHead(head.getName());
                setBillAmount(e.getBill());
                setPaymentAmount(e.getPayment());
            }});
        }
        breakupBillTotal.set(bill);
        breakupPaymentTotal.set(payment);
    }

    @SuppressWarnings("unchecked")
    protected void startEntryTask() {
        if (task != null && task.isRunning()) {
            task.setOnCancelled(e -> {
                task.setOnCancelled(null);
                startTask(getEntriesTask());
            });
            task.cancel();
        }
        else startTask(getEntriesTask());
    }

    protected class GetBreakupTask extends Task<List<Breakup>> {
        private int length;
        private List<PieSeries> series;
        private double bill, payment;

        @Override
        protected List<Breakup> call() throws Exception {
            updateMessage("requesting breakup");
            Thread.sleep(250);

            var buffer = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(getBillIdForBreakup());
            var request = new Request(Function.GetBreakup.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            length = response.getPacket().length;
            updateMessage("received " + length + " bytes");
            Thread.sleep(250);
            updateMessage("processing " + length + " bytes");

            var list = getList(ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN));
            series = new ArrayList<>();
            for (var item : list) {
                var total = item.getHead().equals("Amount") ?
                        item.getBillAmount() :
                        item.getBillAmount() + item.getPaymentAmount();
                series.add(new PieSeries(0, item.getHead(), total));
            }
            return list;
        }

        private List<Breakup> getList(ByteBuffer buffer) {
            bill = payment = 0;
            var list = new ArrayList<Breakup>();
            int start = 0;
            int read = 0;

            while (read < length) {
                while (buffer.get(read) != 0) read++;
                var head = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                read++;
                int position = read;
                var breakup = new Breakup() {{
                    setHead(head);
                    setBillId(buffer.getInt(position));
                    setPaymentId(buffer.getInt(position + 4));
                    setBillAmount(buffer.getDouble(position + 8));
                    setPaymentAmount(buffer.getDouble(position + 16));
                }};
                list.add(breakup);
                bill += breakup.getBillAmount();
                payment += breakup.getPaymentAmount();
                read += 24;
                start = read;
            }
            return list;
        }

        @Override
        protected void succeeded() {
            breakups.clear();
            try {
                var entries = get();
                breakups.addAll(entries);
                breakupSeries.set(series);
                breakupBillTotal.set(bill);
                breakupPaymentTotal.set(payment);
                updateMessage("processed " + length + " bytes");
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
    }

    protected class GetImageTask extends Task<Void> {
        private int length;
        private byte[] imageBytes;

        @Override
        protected Void call() throws Exception {
            updateMessage("requesting image");
            Thread.sleep(250);
            var nameBytes = (getImageFileName() + '\0').getBytes(StandardCharsets.US_ASCII);
            var buffer = ByteBuffer.allocate(nameBytes.length)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .put(nameBytes);

            var request = new Request(Function.GetImage.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            length = response.getPacket().length;

            updateMessage("received " + length + " bytes");
            Thread.sleep(250);
            imageBytes = response.getPacket();
            return null;
        }

        @Override
        protected void succeeded() {
            imageBuffer.set(imageBytes);
            updateMessage("processed " + length + " bytes");
            startTask(new GetBreakupTask());
        }
    }

    private class EditBillInfoTask extends Task<Void> {

        @Override
        protected Void call() throws Exception {
            byte needFileRename = edited.getFileName().isEmpty() ? (byte) 0 : 1;
            var mobileId = AppData.mobiles.stream().filter(x -> x.getNumber().equals(edited.getMobileNo().trim())).findFirst().get().getId();

            var dateBytes = (edited.getDate().trim() + '\0').getBytes(StandardCharsets.UTF_8);
            var billNoBytes = (edited.getBillNo().trim() + '\0').getBytes(StandardCharsets.UTF_8);

            var transactionBytes = (edited.getTransactionId().trim() + '\0').getBytes(StandardCharsets.UTF_8);
            var periodBytes = (edited.getPeriod().trim() + '\0').getBytes(StandardCharsets.UTF_8);
            var newFileName = (edited.getFileName().trim() + '\0').getBytes(StandardCharsets.UTF_8);
            var oldFileNameBytes = (selectedEntry.get().getFileName() + '\0').getBytes(StandardCharsets.US_ASCII);

            var buffer = ByteBuffer.allocate(
                            4 * 2 + 1
                                    + dateBytes.length
                                    + billNoBytes.length
                                    + transactionBytes.length
                                    + periodBytes.length
                                    + newFileName.length
                                    + oldFileNameBytes.length
                    ).order(ByteOrder.LITTLE_ENDIAN)
                    .putInt(edited.getBillId())
                    .putInt(mobileId)
                    .put(needFileRename)
                    .put(dateBytes)
                    .put(billNoBytes)
                    .put(transactionBytes)
                    .put(periodBytes)
                    .put(newFileName)
                    .put(oldFileNameBytes);

            var request = new Request(Function.EditBillInfo.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            if (response.isSuccess()) {
                var isSuccess = response.getPacket()[0] == 1;
                var message = new String(response.getPacket(), 1, response.getPacket().length - 1, StandardCharsets.US_ASCII);
                updateMessage(message);
                Thread.sleep(500);
            }
            else {
                updateMessage("service down");
                Thread.sleep(500);
            }
            return null;
        }
    }

    private class EditBillEntryTask extends Task<Void> {

        @Override
        protected Void call() throws Exception {
            int billId = selectedEntry.get().getBillId();
            var list = new ArrayList<EditedEntry>();
            for (var e : entryList) {
                var head = AppData.heads.stream().filter(x -> x.getName().equalsIgnoreCase(e.getKey().trim())).findFirst().get();
                list.add(new EditedEntry(billId, head.getId(), e.getValue1(), e.getValue2()));
            }
            var buffer = ByteBuffer.allocate(list.size() * 24).order(ByteOrder.LITTLE_ENDIAN);
            for (var e : list) {
                buffer.putInt(e.getBillId());
                buffer.putInt(e.getHeadId());
                buffer.putDouble(e.getPayment());
                buffer.putDouble(e.getBill());
            }

            var request = new Request(Function.EditBillEntry.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            if (response.isSuccess()) {
                var isSuccess = response.getPacket()[0] == 1;
                var message = new String(response.getPacket(), 1, response.getPacket().length - 1, StandardCharsets.US_ASCII);
                updateMessage(message);
                Thread.sleep(500);
            }
            else {
                updateMessage("service down");
                Thread.sleep(500);
            }
            return null;
        }
    }
}
