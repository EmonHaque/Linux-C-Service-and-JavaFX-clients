package ViewModels;

import Model.BillPaymentSeries;
import Model.DayMonthSummary;
import Model.PaymentSummary;
import Model.PeriodicEntry;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.concurrent.Task;
import model.PieSeries;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class PeriodicVM {
    private List<PeriodicEntry> list;
    public final ObservableList<DayMonthSummary> dayMonthList;
    public final ObservableList<PaymentSummary> paymentList;
    public final ObservableList<PeriodicEntry> secondaryList;
    private GetEntriesTask task;

    private boolean isSorting;
    private DayMonthComparator.Order order;

    public StringProperty status;
    public BooleanProperty isRunning;
    public ObjectProperty<LocalDate> startDate, endDate;
    public IntegerProperty dayMonthState;
    public ObjectProperty<DayMonthSummary> selectedEntry;

    public ObjectProperty<List<BillPaymentSeries>> billPaymentSeries;
    public ObjectProperty<List<PieSeries>> pieSeries;
    public ObjectProperty<PieSeries> selectedSlice;

    public ObservableMap<String, List<DayMonthSummary>> headWiseSummaries;
    public DoubleProperty dayMonthBill, dayMonthPayment;

    public PeriodicVM() {
        order = DayMonthComparator.Order.DESCENDING;

        dayMonthBill = new SimpleDoubleProperty();
        dayMonthPayment = new SimpleDoubleProperty();

        status = new SimpleStringProperty("");
        isRunning = new SimpleBooleanProperty();
        startDate = new SimpleObjectProperty<>(LocalDate.now().minusYears(1));
        endDate = new SimpleObjectProperty<>(LocalDate.now());
        dayMonthState = new SimpleIntegerProperty();
        selectedEntry = new SimpleObjectProperty<>();
        billPaymentSeries = new SimpleObjectProperty<>();
        pieSeries = new SimpleObjectProperty<>();
        selectedSlice = new SimpleObjectProperty<>();

        dayMonthList = FXCollections.observableArrayList();
        paymentList = FXCollections.observableArrayList();
        secondaryList = FXCollections.observableArrayList();

        dayMonthState.addListener(this::onDayMonthStateChange);
        selectedEntry.addListener(this::onSelectionChange);
        selectedSlice.addListener(this::onSliceSelectionChange);

        headWiseSummaries = FXCollections.observableHashMap();
    }

    public void refresh() {
        if (task != null && task.isRunning()) {
            task.setOnCancelled(e -> {
                task.setOnCancelled(null);
                startTask();
            });
            task.cancel();
        }
        else startTask();
    }

    private void startTask() {
        task = new GetEntriesTask();
        isRunning.bind(task.runningProperty());
        status.bind(task.messageProperty());
        new Thread(task) {{setDaemon(true);}}.start();
    }

    public void sortDayMonthList(){
        isSorting = true;
        order = order == DayMonthComparator.Order.ASCENDING ?
                DayMonthComparator.Order.DESCENDING :
                DayMonthComparator.Order.ASCENDING;

        dayMonthList.sort(new DayMonthComparator(dayMonthState.get(), order));
        isSorting = false;
    }

    private void onDayMonthStateChange(Observable o, Number ov, Number nv) {
        if(list == null) return;
        
        dayMonthList.clear();
        var dmState = nv.intValue();
        var comparator = new DayMonthComparator(dmState, order);
        Function<PeriodicEntry, String> func = dmState == 0 ?
                PeriodicEntry::getDate :
                PeriodicEntry::getMonth;

        var summary = list.stream().collect(Collectors.groupingBy(func))
                .entrySet().stream().map(x -> new DayMonthSummary() {{
                            setParticulars(x.getKey());
                            setBill(x.getValue().stream().mapToDouble(PeriodicEntry::getBill).sum());
                            setPayment(x.getValue().stream().mapToDouble(PeriodicEntry::getPayment).sum());
                        }}
                ).sorted(comparator).
                toList();

        var bpSeries = new ArrayList<BillPaymentSeries>();
        int seriesSize = 18;
        if (summary.size() < seriesSize) {
            for (var x : summary) {
                bpSeries.add(new BillPaymentSeries(x.getParticulars(), x.getBill(), x.getPayment()));
            }
        }
        else {
            if(order == DayMonthComparator.Order.DESCENDING){
                for (int i = 0; i < seriesSize; i++) {
                    var x = summary.get(i);
                    bpSeries.add(new BillPaymentSeries(x.getParticulars(), x.getBill(), x.getPayment()));
                }
            }
            else{
                var start = summary.size() - seriesSize;
                for (int i = start; i < summary.size(); i++) {
                    var x = summary.get(i);
                    bpSeries.add(new BillPaymentSeries(x.getParticulars(), x.getBill(), x.getPayment()));
                }
            }
        }
        dayMonthList.addAll(summary);
        billPaymentSeries.set(bpSeries);
    }

    private void onSelectionChange(Observable o, DayMonthSummary ov, DayMonthSummary nv) {
        if(isSorting) return;

        var source = nv == null ? list :
                dayMonthState.get() == 0 ?
                        list.stream().filter(x -> x.getDate().equals(nv.getParticulars())).toList() :
                        list.stream().filter(x -> x.getMonth().equals(nv.getParticulars())).toList();

        secondaryList.clear();
        headWiseSummaries.clear();

        secondaryList.addAll(source);

        var out = source.stream().collect(
                        Collectors.groupingBy(PeriodicEntry::getHead,
                                Collectors.groupingBy(PeriodicEntry::getDepartment)
                        ))
                .entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        x -> x.getValue().entrySet()
                                .stream().map(
                                        y -> new DayMonthSummary() {{
                                            setParticulars(y.getKey());
                                            setBill(y.getValue().stream().mapToDouble(PeriodicEntry::getBill).sum());
                                            setPayment(y.getValue().stream().mapToDouble(PeriodicEntry::getPayment).sum());
                                        }}
                                ).collect(Collectors.toList())
                ));

        for (var e : out.entrySet()) {
            headWiseSummaries.put(e.getKey(), new ArrayList<>(e.getValue()));
        }

        var series = source.stream()
                .collect(Collectors.groupingBy(PeriodicEntry::getDepartment))
                .entrySet().stream().map(
                        x -> new PieSeries(0, x.getKey(),
                                x.getValue().stream().mapToDouble(PeriodicEntry::getPayment).sum()
                        )
                ).collect(Collectors.toList());

        pieSeries.set(series);
    }

    private void onSliceSelectionChange(Observable o, PieSeries ov, PieSeries nv) {
        // change summary computation
        // when it's Amount take bill amount and when it's Fee, Surcharge, etc. sum both bill and payment
        if (nv == null) {
        }
        else {
            Function<PeriodicEntry, Boolean> func = entry ->
                    selectedEntry.get() == null ?
                            entry.getDepartment().equals(nv.title) :
                            dayMonthState.get() == 0 ?
                                    entry.getDate().equals(selectedEntry.get().getParticulars())
                                            && entry.getDepartment().equals(nv.title) :
                                    entry.getMonth().equals(selectedEntry.get().getParticulars())
                                            && entry.getDepartment().equals(nv.title);

            paymentList.clear();
            var summary = list.stream()
                    .filter(func::apply)
                    .collect(Collectors.groupingBy(PeriodicEntry::getHead))
                    .entrySet().stream().map(
                            x -> new PaymentSummary() {{
                                setHead(x.getKey());
                                if (x.getKey().equals("Amount")) {
                                    setAmount(x.getValue().stream().mapToDouble(PeriodicEntry::getBill).sum());
                                }
                                else {
                                    var total = x.getValue().stream().mapToDouble(PeriodicEntry::getPayment).sum() +
                                            x.getValue().stream().mapToDouble(PeriodicEntry::getBill).sum();
                                    setAmount(total);
                                }

                            }}
                    ).toList();


            paymentList.addAll(summary);
        }
    }

    private class DayMonthComparator implements Comparator<DayMonthSummary> {
        private final int state;
        private final DateTimeFormatter formatter;
        private final Order order;

        public DayMonthComparator(int state, Order order) {
            this.state = state;
            this.order = order;
            formatter = state == 0 ?
                    DateTimeFormatter.ofPattern("yyyy-MM-dd") :
                    DateTimeFormatter.ofPattern("yyyy-MM");
        }

        @Override
        public int compare(DayMonthSummary o1, DayMonthSummary o2) {
            if (state == 0){
                if(order == Order.ASCENDING){
                    return LocalDate.parse(o1.getParticulars(), formatter).compareTo(LocalDate.parse(o2.getParticulars(), formatter));
                }
                else{
                    return LocalDate.parse(o2.getParticulars(), formatter).compareTo(LocalDate.parse(o1.getParticulars(), formatter));
                }
            }
            else{
                if(order == Order.ASCENDING){
                    return YearMonth.parse(o1.getParticulars(), formatter).atDay(1).compareTo(YearMonth.parse(o2.getParticulars(), formatter).atDay(1));
                }
                else{
                    return YearMonth.parse(o2.getParticulars(), formatter).atDay(1).compareTo(YearMonth.parse(o1.getParticulars(), formatter).atDay(1));
                }
            }
        }

        public enum Order{
            ASCENDING,
            DESCENDING
        }
    }

    private class GetEntriesTask extends Task<Void> {
        private int length;
        private List<DayMonthSummary> dmList;
        private List<BillPaymentSeries> bpSeries;
        private List<PieSeries> pSeries;
        private final int seriesSize = 18;
        private double dmBill, dmPayment;
        private Map<String, List<DayMonthSummary>> map;

        @Override
        protected Void call() {
            try {
                updateMessage("requesting entries");
                Thread.sleep(250);
                if (isCancelled()) return null;

                var startBytes = (startDate.get().toString() + '\0').getBytes(StandardCharsets.UTF_8);
                var endBytes = (endDate.get().toString() + '\0').getBytes(StandardCharsets.UTF_8);
                var buffer = ByteBuffer.allocate(startBytes.length + endBytes.length)
                        .order(ByteOrder.LITTLE_ENDIAN)
                        .put(startBytes)
                        .put(endBytes);

                var request = new Request(Enums.Function.GetPeriodicEntries.ordinal(), buffer);
                var response = Channels.getInstance().getResponse(request).get();
                if (isCancelled()) return null;

                length = response.getPacket().length;
                updateMessage("received " + length + " bytes");
                Thread.sleep(250);
                updateMessage("processing " + length + " bytes");

                if (isCancelled()) return null;
                list = getList(ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN));

                group(list);
                bpSeries = new ArrayList<>();
                if (dmList.size() < seriesSize) {
                    for (var x : dmList) {
                        bpSeries.add(new BillPaymentSeries(x.getParticulars(), x.getBill(), x.getPayment()));
                    }
                }
                else {
                    if(order == DayMonthComparator.Order.DESCENDING){
                        for (int i = 0; i < seriesSize; i++) {
                            var x = dmList.get(i);
                            bpSeries.add(new BillPaymentSeries(x.getParticulars(), x.getBill(), x.getPayment()));
                        }
                    }
                    else{
                        var start = dmList.size() - seriesSize;
                        for (int i = start; i < dmList.size(); i++) {
                            var x = dmList.get(i);
                            bpSeries.add(new BillPaymentSeries(x.getParticulars(), x.getBill(), x.getPayment()));
                        }
                    }
                }

            } catch (Exception ignored) {
            }
            return null;
        }

        @Override
        protected void succeeded() {
            dayMonthList.clear();
            headWiseSummaries.clear();
            secondaryList.clear();

            secondaryList.addAll(list);
            dayMonthList.addAll(dmList);
            billPaymentSeries.set(bpSeries);

            for (var e : map.entrySet()) {
                headWiseSummaries.put(e.getKey(), new ArrayList<>(e.getValue()));
            }

            pieSeries.set(pSeries);
            dayMonthBill.set(dmBill);
            dayMonthPayment.set(dmPayment);

            updateMessage("processed " + length + " bytes");
        }

        private void group(List<PeriodicEntry> source) {
            var dmState = dayMonthState.get();

            var comparator = new DayMonthComparator(dmState, order);
            Function<PeriodicEntry, String> func = dmState == 0 ?
                    PeriodicEntry::getDate :
                    PeriodicEntry::getMonth;

            dmList = source.stream().collect(Collectors.groupingBy(func))
                    .entrySet().stream().map(x -> new DayMonthSummary() {{
                                setParticulars(x.getKey());
                                setBill(x.getValue().stream().mapToDouble(PeriodicEntry::getBill).sum());
                                setPayment(x.getValue().stream().mapToDouble(PeriodicEntry::getPayment).sum());
                            }}
                    ).sorted(comparator)
                    .collect(Collectors.toList());

            map = source.stream().collect(
                            Collectors.groupingBy(PeriodicEntry::getHead,
                                    Collectors.groupingBy(PeriodicEntry::getDepartment)
                            ))
                    .entrySet().stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            x -> x.getValue().entrySet()
                                    .stream().map(
                                            y -> new DayMonthSummary() {{
                                                setParticulars(y.getKey());
                                                setBill(y.getValue().stream().mapToDouble(PeriodicEntry::getBill).sum());
                                                setPayment(y.getValue().stream().mapToDouble(PeriodicEntry::getPayment).sum());
                                            }}
                                    ).collect(Collectors.toList())
                    ));

            pSeries = source.stream()
                    .collect(Collectors.groupingBy(PeriodicEntry::getDepartment))
                    .entrySet().stream().map(
                            x -> new PieSeries(0, x.getKey(),
                                    x.getValue().stream().mapToDouble(PeriodicEntry::getPayment).sum()
                            )
                    ).collect(Collectors.toList());
        }

        private List<PeriodicEntry> getList(ByteBuffer buffer) {
            dmBill = dmPayment = 0;
            var list = new ArrayList<PeriodicEntry>();
            int read = 0;

            while (read < length) {
                if (isCancelled()) break;

                int accountId = buffer.getInt(read);
                int mobileId = buffer.getInt(read + 4);
                double bill = buffer.getDouble(read + 8);
                double payment = buffer.getDouble(read + 16);

                read += 24;
                int start = read;

                int index = 0;
                var segments = new String[7];
                while (read < length) {
                    if (buffer.get(read) != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }
                var e = new PeriodicEntry() {{
                    setAccountId(accountId);
                    setMobileId(mobileId);
                    setBill(bill);
                    setPayment(payment);
                    setDepartment(segments[0]);
                    setAccountNo(segments[1]);
                    setHolder(segments[2]);
                    setAddress(segments[3]);
                    setHead(segments[4]);
                    setDate(segments[5]);
                    setMonth(segments[6]);
                }};
                list.add(e);

                dmBill += bill;
                dmPayment += payment;
            }
            return list;
        }
    }
}
