package JNA;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

@Structure.FieldOrder({"width", "height", "size", "channels", "data"})
public class FXMat extends Structure {
    public int width;
    public int height;
    public int size;
    public int channels;
    public Pointer data;
}
