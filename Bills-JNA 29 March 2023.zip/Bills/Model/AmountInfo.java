package Model;

public class AmountInfo {
    private int headId;
    private double amount;

    public AmountInfo(int headId, double amount) {
        this.headId = headId;
        this.amount = amount;
    }

    public int getHeadId() {
        return headId;
    }

    public void setHeadId(int headId) {
        this.headId = headId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
