package Converters;

import helpers.Helper;
import javafx.util.StringConverter;
import ridiculous.AppData;

public class DoubleToStringConverter extends StringConverter<Number> {
    @Override
    public String toString(Number object) {
        return Helper.formatNumber(object.doubleValue());
    }

    @Override
    public Number fromString(String string) {
        return string.isEmpty() || string.isBlank() ? 0 : Double.parseDouble(string);
    }
}
