package CellTemplates.ListView;

import Model.Breakup;
import abstracts.ListCellBase;
import helpers.Helper;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class BreakupTemplate extends ListCellBase<Breakup> {
    private GridPane root;
    private Text head, bill, payment;

    @Override
    protected void initializeUI() {
        head = new Text(){{ setFill(Color.WHITE);}};
        bill= new Text(){{ setFill(Color.WHITE);}};
        payment= new Text(){{ setFill(Color.WHITE);}};
        root = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(90){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(90){{ setHalignment(HPos.RIGHT);}}
            );
            add(head, 0, 0);
            add(payment, 1, 0);
            add(bill, 2, 0);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Breakup ov, Breakup nv) {
        if(ov != null){

        }
        if(nv != null){
            head.textProperty().bind(nv.headProperty());
            bill.textProperty().bind(Bindings.createStringBinding(
                    () -> Helper.formatNumber(nv.getBillAmount()),
                    nv.billAmountProperty()
            ));
            payment.textProperty().bind(Bindings.createStringBinding(
                    () -> Helper.formatNumber(nv.getPaymentAmount()),
                    nv.paymentAmountProperty()
            ));
        }
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
