package ChartControls;

import Model.BillPaymentSeries;
import abstracts.XYChartBase;
import controls.areachart.AreaStroke;
import controls.pinchart.Pin;
import controls.pinchart.PinStack;
import helpers.Constants;
import helpers.Helper;
import javafx.animation.*;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.stage.Popup;
import javafx.util.Duration;
import model.PinColors;
import skinned.ExtendedSeparator;

import javax.swing.*;
import java.text.DateFormatSymbols;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class BillPaymentChart extends XYChartBase<BillPaymentSeries> {
    private boolean isLoaded;
    private final AreaStroke line;
    private final List<Pin> pins;
    private final PinColors pinColor;

    private final Rectangle widthClip;
    private final Timeline lineAnim;
    private final String[] months;

    public BillPaymentChart() {
        pinColor = new PinColors(Color.CORNFLOWERBLUE, Color.BLUE);
        pins = new ArrayList<>();
        widthClip = new Rectangle(0, 0, 0, 0);
        line = new AreaStroke() {{
            getTransforms().add(new Scale(1, -1));
            setManaged(false);
            setClip(widthClip);
        }};
        getChildren().add(line);

        months = new DateFormatSymbols().getMonths();

        lineAnim = new Timeline();
        lineAnim.setDelay(Duration.millis(500));
        lineAnim.setOnFinished(e -> line.setClip(null));
    }

    @Override
    protected void setMinMaxAndXLabels() {
        double step = (max - min) / (numLines - 1);
        double current = min;
        for (var t : yLabels.getChildren()) {
            var label = (Text) t;
            label.setText(String.format("%,d", (int) current));
            current += step;
            yLabelWidth = label.prefWidth(-1);
        }
    }

    @Override
    protected void reset() {
        if(lineAnim.getStatus() == Animation.Status.RUNNING) lineAnim.stop();

        for (var pin : pins) {
            getChildren().remove(pin);
        }
        pins.clear();
        line.clear();

        var payments = new ArrayList<Double>();
        for(var item : series){
            var xLabel = new Text(item.getDate());
            xLabel.setFill(Color.WHITE);
            xLabel.setRotate(-90);
            xLabel.setManaged(false);
            xLabels.getChildren().add(xLabel);

            if (xLabelWidth < xLabel.prefWidth(-1))
                xLabelWidth = xLabel.prefWidth(-1);

            payments.add(item.getPayment());
            var pin = new Pin(item.getBill(), pinColor){{
                setManaged(false);
                setToolTip(new Tip(item));
            }};
            pins.add(pin);
            getChildren().add(pin);

            if(min > item.getBill()) min = item.getBill();
            if(min > item.getPayment()) min = item.getPayment();
            if(max < item.getBill()) max = item.getBill();
            if(max < item.getPayment()) max = item.getPayment();
        }

        getChildren().add(line);
        line.setData(payments);
        line.toFront();
        requestLayout();
        if (isLoaded) {
            resetLineAnim();
            lineAnim.play();
        }
    }

    private void resetLineAnim() {
        widthClip.setWidth(0);
        widthClip.setHeight(availableHeight);
        line.setClip(widthClip);

        lineAnim.getKeyFrames().clear();
        var widthKey = new KeyValue(widthClip.widthProperty(), availableWidth, Interpolator.EASE_IN);
        var widthFrame = new KeyFrame(Duration.millis(1000), widthKey);
        lineAnim.getKeyFrames().add(widthFrame);
    }

    @Override
    protected void layoutChildren() {
        if(series == null) return;
        super.layoutChildren();

        var colWidth = availableWidth / pins.size();
        double xLabelX = startX + colWidth / 2;
        double x = startX;

        for (int i = 0; i < pins.size(); i++) {
            var text = (Text) xLabels.getChildren().get(i);
            text.setY(availableHeight + text.prefWidth(-1) / 2 + text.prefHeight(-1) / 2);
            text.setX(xLabelX - text.prefWidth(-1) / 2);

            var bar = pins.get(i);
            bar.makePin(colWidth, availableHeight, max);
            bar.resizeRelocate(x, availableHeight, colWidth, availableHeight);

            xLabelX += colWidth;
            x += colWidth;
        }

        if (!isLoaded) {
            isLoaded = true;
            resetLineAnim();
            lineAnim.play();
        }
        line.setTranslateX(startX + colWidth / 2);
        line.setTranslateY(availableHeight);
        line.setValue(availableWidth - colWidth, availableHeight, max);
    }

    private class Tip extends Popup {
        public Tip(BillPaymentSeries series) {
            String text = "";
            try {
                text = LocalDate.parse(series.getDate()).format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));
            } catch (Exception e){
                var splits = series.getDate().split("-");
                text = months[Integer.parseInt(splits[1]) - 1] + ", " + splits[0];
            }
            var date = new Text(text){{
                setFill(Color.WHITE);
                setFont(Font.font(null, FontPosture.ITALIC, -1));
            }};
            var bill = new Text(Helper.formatNumber(series.getBill())){{ setFill(Color.WHITE);}};
            var payment = new Text(Helper.formatNumber(series.getPayment())){{ setFill(Color.WHITE);}};

            getContent().add(new GridPane(){{
                getColumnConstraints().addAll(
                        new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints(100) {{ setHalignment(HPos.RIGHT);}}
                );
                add(date, 0, 0, 2, 1);
                add(new ExtendedSeparator(), 0, 1, 2, 1);
                add(new Text("Bill"){{ setFill(Color.WHITE);}}, 0, 2);
                add(bill, 1, 2);
                add(new Text("Payment"){{ setFill(Color.WHITE);}}, 0, 3);
                add(payment, 1, 3);

                setVgap(2.5);
                setPadding(new Insets(5));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
                setBackground(Background.fill(Constants.BackgroundColor));

                setHalignment(date, HPos.RIGHT);
            }});
        }
    }
}
