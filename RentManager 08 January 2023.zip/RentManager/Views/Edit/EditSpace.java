package Views.Edit;

import CellTemplates.ListView.EditSpaceTemplate;
import Models.Plot;
import Models.Space;
import ViewModels.Edit.EditBaseVM;
import ViewModels.Edit.EditSpaceVM;
import controls.SelectionBox;
import controls.states.BiState;
import controls.states.MultiState;
import editables.*;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ListCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class EditSpace extends EditBase<Space> {
    private EditSpaceVM vm;
    private SelectionBox<Plot> plots;
    private MultiState state;

    private EditSelection<Plot> editPlots;
    private EditText name;
    private EditTextMultiline description;
    private BiState isVacant;
    private EditDate date;

    @Override
    protected String getHeader() {
        return "Space";
    }

    @Override
    protected String getIcon() {
        return Icons.Space;
    }

    @Override
    protected String getTip() {
        return "Space";
    }

    @Override
    protected EditBaseVM<Space> getViewModel() {
        vm = new EditSpaceVM();
        return vm;
    }

    @Override
    protected boolean isEditableList() {
        return true;
    }

    @Override
    protected ListCell<Space> getListCellTemplate() {
        return new EditSpaceTemplate(query.textProperty(), state.stateProperty);
    }

    @Override
    protected void onSelectionChanged(Space item) {
        editPlots.valueProperty().unbindBidirectional(vm.edited.plotIdProperty());
        name.textProperty().unbindBidirectional(vm.edited.nameProperty());
        description.textProperty().unbindBidirectional(vm.edited.descriptionProperty());
        isVacant.isCheckedProperty.unbindBidirectional(vm.edited.isVacantProperty());
        isVacant.disableProperty().unbind();
        isVacant.setDisable(true);
        date.visibleProperty().unbind();
        date.setVisible(false);

        if(item == null)  return;
        editPlots.valueProperty().bind(vm.selected.plotIdProperty());

        name.textProperty().bind(vm.selected.nameProperty());
        description.textProperty().bind(vm.selected.descriptionProperty());
        isVacant.isCheckedProperty.bind(vm.selected.isVacantProperty());
    }

    @Override
    protected void onIsOnEditChanged() {
        editPlots.valueProperty().unbind();
        name.textProperty().unbind();
        description.textProperty().unbind();
        isVacant.isCheckedProperty.unbind();

        editPlots.valueProperty().bindBidirectional(vm.edited.plotIdProperty());

        name.textProperty().bindBidirectional(vm.edited.nameProperty());
        description.textProperty().bindBidirectional(vm.edited.descriptionProperty());
        isVacant.isCheckedProperty.bindBidirectional(vm.edited.isVacantProperty());
        isVacant.disableProperty().bind(getIsVacantDisabilityBinding());
        date.visibleProperty().bind(getDateVisibilityBinding());
    }

    @Override
    protected void initializeUI() {
        super.initializeUI();
        plots = new SelectionBox<>("Plot", Icons.ControlHead, vm.plots, false);
        leftBox.getChildren().add(0, plots);

        var icons = new String[]{Icons.Existing, Icons.LeftOrExpired, Icons.All};
        var texts = new String[]{"Occupied", "Vacant", "All"};
        state = new MultiState(icons, texts, false) {{setAlignment(Pos.BOTTOM_CENTER);}};
        queryBox.getChildren().add(1, state);
    }

    @Override
    protected void bind() {
        super.bind();
        vm.selectedPlotProperty.bind(plots.selectedValueProperty());
        vm.stateProperty.bind(state.stateProperty);
        vm.selectedDateProperty.bind(date.dateProperty());
    }

    @Override
    protected void initializeEditPane(EditPane pane) {
        editPlots = new EditSelection<>("Plot", Icons.Plot, vm.editPlots, true, pane);
        name = new EditText("Name", Icons.Space, true, pane);
        description = new EditTextMultiline("Description", Icons.Description, true, pane);
        isVacant = new BiState(true, " is vacant") {{setAlignment(Pos.BOTTOM_LEFT);}};
        date = new EditDate("Vacated on", Icons.Month, true, pane) {{ setVisible(false);}};
        var hBox = new HBox(isVacant, date) {{
            setSpacing(10);
            setHgrow(date, Priority.ALWAYS);
        }};

        var rightBox = new VBox(editPlots, name, description, hBox) {{
            setSpacing(10);
            setPadding(new Insets(10, 0, 0, 0));
        }};
        pane.setCenter(rightBox);
    }

    private BooleanBinding getDateVisibilityBinding() {
        return Bindings.createBooleanBinding(() ->
             !vm.selected.getIsVacant() && vm.edited.getIsVacant()
        , vm.edited.isVacantProperty());
    }

    private BooleanBinding getIsVacantDisabilityBinding(){
        return Bindings.createBooleanBinding(() ->{
            if(!pane.onEdit()) return true;
            return vm.selected.isIsVacant();

        }, pane.isOnEditProperty(), vm.selected.isVacantProperty());
    }
}
