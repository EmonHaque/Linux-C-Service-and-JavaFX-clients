package CellTemplates.Visual;

import Models.Tenant;
import interfaces.ISetSelectionBoxContent;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class TenantVisual extends BorderPane implements ISetSelectionBoxContent<Tenant> {
    private final Text name, phone;
    private Tenant item;

    public TenantVisual() {
        name = new Text();
        phone = new Text();
        setCenter(name);
        setRight(phone);
        setAlignment(name, Pos.CENTER_LEFT);
        setAlignment(phone, Pos.CENTER_RIGHT);
    }

    @Override
    public void setContent(Tenant item) {
        name.textProperty().unbind();
        phone.textProperty().unbind();

        this.item = item;
        if(item.isHasLeft()){
            name.setFill(Color.GRAY);
            phone.setFill(Color.GRAY);
        }
        else{
            name.setFill(Color.WHITE);
            phone.setFill(Color.WHITE);
        }
        name.textProperty().bind(item.nameProperty());
        phone.textProperty().bind(item.contactNoProperty());
    }

    @Override
    public Tenant getContent() {
        return item;
    }

    @Override
    public Node getVisual() {
        return this;
    }
}
