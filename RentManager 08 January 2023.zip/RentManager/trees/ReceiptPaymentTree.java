package trees;

import Models.ReceiptPayment;
import controls.SVGRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

import java.util.Comparator;

public class ReceiptPaymentTree extends ExtendedTreeView<ReceiptPayment> {
    private final TreeItem<ReceiptPayment> receipt, payment;
    public ListProperty<ReceiptPayment> itemsProperty;
    public BooleanProperty isExpandedProperty;

    public ReceiptPaymentTree() {
        receipt = new TreeItem<>(new ReceiptPayment() {{setControl("Receipt");}}){{ setExpanded(true);}};
        payment = new TreeItem<>(new ReceiptPayment() {{setControl("Payment");}}){{ setExpanded(true);}};
        var root = new TreeItem<ReceiptPayment>();

        itemsProperty = new SimpleListProperty<>();
        isExpandedProperty = new SimpleBooleanProperty();
        itemsProperty.addListener(this::onItemsChanged);
        setRoot(root);
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new ReceiptPaymentCell());

        isExpandedProperty.addListener(o ->{
            var value = isExpandedProperty.get();
            resetExpandState(receipt, value);
            resetExpandState(payment, value);
        });
    }

    private void resetExpandState(TreeItem<ReceiptPayment> node, boolean value){
        node.setExpanded(value);
        for(var item : node.getChildren()){
            if(item.isLeaf()) continue;
            resetExpandState(item, value);
        }
    }
    @SuppressWarnings("unchecked")
    private void sort(TreeItem<ReceiptPayment> node){
        node.getChildren().sort(
                Comparator.comparing(x -> ((TreeItem<ReceiptPayment>) x).getChildren().size()).reversed()
                        .thenComparing(x -> ((TreeItem<ReceiptPayment>) x).getValue().getHead())
                        .thenComparing(x -> ((TreeItem<ReceiptPayment>) x).getValue().getPlot())
                        .thenComparing(x -> ((TreeItem<ReceiptPayment>) x).getValue().getTenant())
        );
        for (var item : node.getChildren()) sort(item);
    }

    private void onItemsChanged(ObservableValue<?> o, ObservableList<ReceiptPayment> ov, ObservableList<ReceiptPayment> nv) {
        resetValues();
        if (nv == null) return;
        TreeItem<ReceiptPayment> tenant, control = null;
        for (var e : nv) {
            control = e.getControl().equals("Receipt") ? receipt : payment;
            var head = getHead(control, e);
            var plot = getPlot(head, e);
            tenant = getTenant(plot, e);
            tenant.getChildren().add(new TreeItem<>(e));
        }
        if(control == null) return;
        if(!getRoot().getChildren().contains(control)) {
            getRoot().getChildren().add(control);
        }
        removeSingleLeaf(receipt);
        removeSingleLeaf(payment);

        sort(receipt);
        sort(payment);
    }

    private void removeSingleLeaf(TreeItem<ReceiptPayment> node){
        for(var head : node.getChildren()){
            for(var plot : head.getChildren()){
                for (var tenant: plot.getChildren()){
                    if(tenant.getChildren().size() > 1) continue;
                    var item = tenant.getChildren().get(0).getValue();
                    tenant.getChildren().clear();
                    tenant.getValue().setSpace(item.getSpace());
                }
            }
        }
    }

    private TreeItem<ReceiptPayment> getHead(TreeItem<ReceiptPayment> node, ReceiptPayment entry) {
        var value = node.getValue();
        value.setCash(value.getCash() + entry.getCash());
        value.setKind(value.getKind() + entry.getKind());
        value.setMobile(value.getMobile() + entry.getMobile());
        value.setTotal(value.getTotal() + entry.getTotal());

        var hasIt = false;
        TreeItem<ReceiptPayment> item = null;
        for (var c : node.getChildren()) {
            if (!c.getValue().getHead().equals(entry.getHead())) continue;

            value = c.getValue();
            value.setCash(value.getCash() + entry.getCash());
            value.setKind(value.getKind() + entry.getKind());
            value.setMobile(value.getMobile() + entry.getMobile());
            value.setTotal(value.getTotal() + entry.getTotal());
            hasIt = true;
            item = c;
            break;
        }
        if (!hasIt) {
            item = new TreeItem<>(new ReceiptPayment(){{
                setHead(entry.getHead());
                setPlot("");
                setSpace("");
                setTenant("");
                setCash(entry.getCash());
                setKind(entry.getKind());
                setMobile(entry.getMobile());
                setTotal(entry.getTotal());
            }});
            node.getChildren().add(item);
        }
        return item;
    }

    private TreeItem<ReceiptPayment> getPlot(TreeItem<ReceiptPayment> node, ReceiptPayment entry) {
        var hasIt = false;
        TreeItem<ReceiptPayment> item = null;
        for (var c : node.getChildren()) {
            if (!c.getValue().getPlot().equals(entry.getPlot())) continue;

            var value = c.getValue();
            value.setCash(value.getCash() + entry.getCash());
            value.setKind(value.getKind() + entry.getKind());
            value.setMobile(value.getMobile() + entry.getMobile());
            value.setTotal(value.getTotal() + entry.getTotal());
            hasIt = true;
            item = c;
            break;
        }
        if (!hasIt) {
            item = new TreeItem<>(new ReceiptPayment(){{
                setPlot(entry.getPlot());
                setSpace("");
                setHead("");
                setCash(entry.getCash());
                setKind(entry.getKind());
                setMobile(entry.getMobile());
                setTotal(entry.getTotal());
            }});
            node.getChildren().add(item);
        }
        return item;
    }

    private TreeItem<ReceiptPayment> getTenant(TreeItem<ReceiptPayment> node, ReceiptPayment entry) {
        var hasIt = false;
        TreeItem<ReceiptPayment> item = null;
        for (var c : node.getChildren()) {
            if (!c.getValue().getTenant().equals(entry.getTenant())) continue;

            var value = c.getValue();
            value.setCash(value.getCash() + entry.getCash());
            value.setKind(value.getKind() + entry.getKind());
            value.setMobile(value.getMobile() + entry.getMobile());
            value.setTotal(value.getTotal() + entry.getTotal());
            hasIt = true;
            item = c;
            break;
        }
        if (!hasIt) {
            item = new TreeItem<>(new ReceiptPayment(){{
                setHead("");
                setPlot("");
                setTenant(entry.getTenant());
                setCash(entry.getCash());
                setKind(entry.getKind());
                setMobile(entry.getMobile());
                setTotal(entry.getTotal());
            }});
            node.getChildren().add(item);
        }
        return item;
    }

    private void resetValues() {
        receipt.getChildren().clear();
        payment.getChildren().clear();

        receipt.getValue().setCash(0);
        receipt.getValue().setKind(0);
        receipt.getValue().setMobile(0);
        receipt.getValue().setTotal(0);

        payment.getValue().setCash(0);
        payment.getValue().setKind(0);
        payment.getValue().setMobile(0);
        payment.getValue().setTotal(0);

        getRoot().getChildren().clear();
    }

    private class ReceiptPaymentCell extends TreeCell<ReceiptPayment> {
        private SVGRegion disclosureIcon;
        private GridPane root;
        private Font normal, bold;
        private Border topBorder;
        private Text particulars, cash, kind, mobile, total;
        private TextFlow particularsFlow;

        public ReceiptPaymentCell() {
            setBackground(null);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setPadding(new Insets(2.5, 0, 2.5, 0));
            setPrefWidth(0);

            initializeUI();
            itemProperty().addListener(this::onItemChanged);
        }

        private void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0)));

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            particulars = new Text() {{setFill(Color.WHITE);}};
            cash = new Text() {{setFill(Color.WHITE);}};
            kind = new Text() {{setFill(Color.WHITE);}};
            mobile = new Text() {{setFill(Color.WHITE);}};
            total = new Text() {{setFill(Color.WHITE);}};
            particularsFlow = new TextFlow(particulars);

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.SOMETIMES); setWrapText(true);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}}
                );
                add(particularsFlow, 0, 0);
                add(cash, 1, 0);
                add(kind, 2, 0);
                add(mobile, 3, 0);
                add(total, 4, 0);
            }};
            makeFontBold();
        }

        private void onItemChanged(ObservableValue<?> o, ReceiptPayment ov, ReceiptPayment nv) {
            if (ov != null) {
                makeFontBold();
                root.setBorder(null);
                particulars.setText(null);
                cash.setText(null);
                kind.setText(null);
                mobile.setText(null);
                total.setText(null);

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                String text = "";
                switch (level){
                    case 1 -> text = nv.getControl() + " (" + item.getChildren().size() + ")";
                    case 2 -> text = nv.getHead()+ " (" + item.getChildren().size() + ")";
                    case 3 -> text = nv.getPlot()+ " (" + item.getChildren().size() + ")";
                    case 4 -> {
                        text = nv.getSpace() != null ?
                                nv.getTenant() + " - " + nv.getSpace() :
                                nv.getTenant()+ " (" + item.getChildren().size() + ")";
                        makeBorder(item);
                        makeFontNormal();
                    }
                    case 5 -> {
                        text = nv.getSpace();
                        makeBorder(item);
                        makeFontNormal();
                    }
                }
                particulars.setText(text);
                cash.setText(AppData.formatNumber(nv.getCash()));
                kind.setText(AppData.formatNumber(nv.getKind()));
                mobile.setText(AppData.formatNumber(nv.getMobile()));
                total.setText(AppData.formatNumber(nv.getTotal()));
            }
        }

        private void makeFontNormal(){
            particulars.setFont(normal);
            cash.setFont(normal);
            kind.setFont(normal);
            mobile.setFont(normal);
            total.setFont(normal);
        }

        private void makeFontBold(){
            particulars.setFont(bold);
            cash.setFont(bold);
            kind.setFont(bold);
            mobile.setFont(bold);
            total.setFont(bold);
        }

        private void makeBorder(TreeItem<ReceiptPayment> item){
            var siblings = item.getParent().getChildren();
            int index = siblings.indexOf(item);
            if(index == 0){
                root.setBorder(topBorder);
            }
            else if(index == siblings.size() - 1){
                root.setBorder(Constants.BottomLine);
            }
        }

        @Override
        protected void updateItem(ReceiptPayment item, boolean empty) {
            super.updateItem(item, empty);
            if (isEmpty()) {
                setBackground(null);
                setGraphic(null);
                return;
            }
            setGraphic(root);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}
