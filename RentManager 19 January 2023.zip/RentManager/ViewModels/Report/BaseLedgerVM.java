package ViewModels.Report;

import Enums.Function;
import Models.Plot;
import Models.ReportEntry;
import Models.Space;
import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Press;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public abstract class BaseLedgerVM<T> {
    private boolean isLoaded;
    public IntegerProperty idProperty, entriesProperty, receivableProperty, receiptProperty, balanceProperty;
    public ObjectProperty<LocalDate> minDateProperty, maxDateProperty, startDateProperty, endDateProperty;

    public StringProperty particularsQueryProperty, statusProperty, availablePeriodProperty;
    public BooleanProperty isRunningProperty;
    public FilteredList<T> selectionList;
    public FilteredList<ReportEntry> reportable;

    protected String particularsQueryLower;

    private final ObservableList<ReportEntry> reserved;
    private int entries, receivable, receipt, balance;

    private ResponseTask task;

    public Press press;

    public BaseLedgerVM() {
        press = new Press();
        initializeSimples();
        reserved = FXCollections.observableArrayList();
        reportable = new FilteredList<>(reserved);
        selectionList = getSelectionList();
        particularsQueryProperty.addListener(this::onQueryChanged);
    }

    private void initializeSimples() {
        idProperty = new SimpleIntegerProperty();
        entriesProperty = new SimpleIntegerProperty();
        receivableProperty = new SimpleIntegerProperty();
        receiptProperty = new SimpleIntegerProperty();
        balanceProperty = new SimpleIntegerProperty();

        minDateProperty = new SimpleObjectProperty<>();
        maxDateProperty = new SimpleObjectProperty<>();
        startDateProperty = new SimpleObjectProperty<>();
        endDateProperty = new SimpleObjectProperty<>();

        particularsQueryProperty = new SimpleStringProperty("");
        statusProperty = new SimpleStringProperty("");
        availablePeriodProperty = new SimpleStringProperty("");
        isRunningProperty = new SimpleBooleanProperty();

        idProperty.addListener(this::onSelectedIdChanged);
    }

    private void onSelectedIdChanged(ObservableValue<?> o, Number ov, Number nv) {
        if (nv.intValue() <= 0) return;
        update();
    }

    private void onQueryChanged(Observable o) {
        particularsQueryLower = particularsQueryProperty.get().toLowerCase();
        var isEmpty = particularsQueryLower.isEmpty();

        receivable = receipt = balance = entries = 0;
        if (isEmpty) {
            reportable.setPredicate(r -> true);
            for (var e : reportable) {
                receivable += e.getReceivable();
                receipt += e.getReceipt();
                entries++;
            }
        }
        else reportable.setPredicate(this::filterReportable);

        receivableProperty.set(receivable);
        receiptProperty.set(receipt);
        entriesProperty.set(entries);
    }

    private boolean filterReportable(ReportEntry e) {
        if (e.getParticulars().toLowerCase().contains(particularsQueryLower)) {
            receivable += e.getReceivable();
            receipt += e.getReceipt();
            entries++;
            return true;
        }
        return false;
    }

    protected abstract String getWhere();

    public abstract String getHeader();

    protected abstract FilteredList<T> getSelectionList();

    public void refresh() { update(); }

    private void update() {
        statusProperty.unbind();
        isRunningProperty.unbind();
        statusProperty.set("");
        isRunningProperty.set(false);

        if (task != null && task.isRunning()) {
            task.setOnCancelled(e -> {
                task.setOnCancelled(null);
                startTask();
            });
            task.cancel();
        }
        else startTask();
    }

    private void startTask() {
        task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    public void print() {
        press.resetPrinterList();
        if (!press.available()) {
            statusProperty.set("no printer available");
            return;
        }
        press.setSelected(null);
        if (press.getPrinters().size() == 1) {
            press.setSelected(press.getPrinters().get(0));
        }
        else {
            press.dialogTrigger.set(true);
            if (press.getPrinterJob() == null) return;
        }
        var task = new PrintTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task) {{setDaemon(true);}}.start();
    }

    private class PrintTask extends Task<Void> {
        private Text pageNoText;
        private final Font normal = Font.font(9);
        private final double dateWidth = 65, amountWidth = 50;
        private double width;

        @Override
        protected Void call() throws Exception {
            updateMessage("setting up header and footers");
            Thread.sleep(250);

            press.getPrinterJob().getJobSettings().setJobName("Ledger");
            var layout = press.getPrinterJob().getJobSettings().getPageLayout();
            width = layout.getPrintableWidth();

            var header = getHeader(width);
            var footer = getFooter(width);
            double leftOver = layout.getPrintableHeight() - header.prefHeight(-1) - footer.prefHeight(-1);

            var contentGrid = new GridPane() {{
                setMinSize(width, leftOver);
                setPrefSize(width, leftOver);
                setMaxSize(width, leftOver);
            }};
            var pageGrid = new GridPane() {{
                addRow(0, header);
                addRow(1, contentGrid);
                addRow(2, footer);
            }};

            updateMessage("generating pages");
            Thread.sleep(250);

            int pageNo = 1;
            setPageNo(pageNo);

            var topRow = getRow(new ReportEntry(){{
                setDate(LocalDate.now());
                setParticulars("balance b/d");
                setReceivable(100);
                setReceipt(100);
                setBalance(100);
            }});
            var totalRow = getPageTotal(0,0);
            var topRowHeight = topRow.prefHeight(-1);
            var totalRowHeight = totalRow.prefHeight(-1);
            double accumulatedHeight = totalRowHeight;
            double requiredHeight;

            int totalReceipt = 0 , totalReceivable = 0;


            for (var e : reportable) {
                totalReceipt += e.getReceipt();
                totalReceivable += e.getReceivable();

                var row = getRow(e);
                requiredHeight = row.prefHeight(-1);
                accumulatedHeight += requiredHeight;

                if ((leftOver - accumulatedHeight) < 0) {
                    var adjustedReceivable = totalReceivable - e.getReceivable();
                    var adjustedReceipt = totalReceipt - e.getReceipt();
                    contentGrid.addRow(contentGrid.getRowCount(), getPageTotal(adjustedReceivable, adjustedReceipt));


                    updateMessage("printing page " + pageNo);
                    press.getPrinterJob().printPage(pageGrid);
                    contentGrid.getChildren().clear();
                    setPageNo(++pageNo);

                    var last = reportable.get(reportable.indexOf(e) - 1);
                    var beginning = new ReportEntry(){{
                       setDate(last.getDate());
                       setParticulars("balance b/d");
                       setReceivable(adjustedReceivable);
                       setReceipt(adjustedReceipt);
                       setBalance(last.getBalance());
                    }};
                    contentGrid.addRow(contentGrid.getRowCount(), getRow(beginning));
                    accumulatedHeight = requiredHeight + topRowHeight + totalRowHeight;
                }
                contentGrid.addRow(contentGrid.getRowCount(), row);
            }
            updateMessage("printing page " + pageNo);

            // need new Page, is there anything left?
            contentGrid.addRow(contentGrid.getRowCount(), getPageTotal(totalReceivable, totalReceipt));
            press.getPrinterJob().printPage(pageGrid);
            press.getPrinterJob().endJob();

            updateMessage("Finished printing " + pageNo + " page(s)");
            Thread.sleep(500);
            return null;
        }

        private GridPane getPageTotal(int totalReceivable, int totalReceipt){
            var total = new Text("Total"){{ setFont(normal);}};
            var receivable = new Text(AppData.formatNumber(totalReceivable)) {{setFont(normal);}};
            var payment = new Text(AppData.formatNumber(totalReceipt)) {{setFont(normal);}};

            return new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(width - 3 * amountWidth),
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(total, 0, 0);
                add(receivable, 1, 0);
                add(payment, 2, 0);

                setPadding(new Insets(1, 0, 1, 0));
                setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1,0,0,0))));
            }};
        }

        private GridPane getRow(ReportEntry e){
            var date = new Text(e.getDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy"))) {{
                setFont(normal);
            }};
            var particulars = new Text(e.getParticulars()) {{
                setWrappingWidth(width - dateWidth - 3 * amountWidth); setFont(normal);
            }};
            var receivable = new Text(AppData.formatNumber(e.getReceivable())) {{setFont(normal);}};
            var payment = new Text(AppData.formatNumber(e.getReceipt())) {{setFont(normal);}};
            var balance = new Text(AppData.formatNumber(e.getBalance())) {{setFont(normal);}};


            return new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(dateWidth),
                        new ColumnConstraints(width - dateWidth - 3 * amountWidth),
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(date, 0, 0);
                add(particulars, 1, 0);
                add(receivable, 2, 0);
                add(payment, 3, 0);
                add(balance, 4, 0);

                setPadding(new Insets(1, 0, 1, 0));
                setValignment(date, VPos.TOP);
            }};
        }

        private Node getHeader(double width) {
            String head1, head2, from, to;

            if (selectionList.get(0) instanceof Plot) {
                var plot = AppData.plots.stream().filter(x -> x.getId() == idProperty.get()).findFirst().get();
                head1 = plot.getName();
                head2 = plot.getDescription();
            }
            else if (selectionList.get(0) instanceof Space) {
                var space = AppData.spaces.stream().filter(x -> x.getId() == idProperty.get()).findFirst().get();
                head1 = space.getName();
                head2 = space.getDescription();
            }
            else {
                var tenant = AppData.tenants.stream().filter(x -> x.getId() == idProperty.get()).findFirst().get();
                head1 = tenant.getName();
                head2 = tenant.getAddress();
            }
            from = reportable.get(0).getDate().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));
            to = reportable.get(reportable.size() - 1).getDate().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));

            var row1 = new Text(head1) {{
                setTextAlignment(TextAlignment.CENTER);
                setFont(Font.font(12));
            }};
            var row2 = new Text(head2) {{
                setTextAlignment(TextAlignment.CENTER);
                setFont(Font.font(11));
            }};
            var row3 = new Text("for the period from " + from + " to " + to) {{
                setTextAlignment(TextAlignment.CENTER);
                setFont(Font.font(10));
            }};

            var tableHeader = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(dateWidth),
                        new ColumnConstraints(width - dateWidth - 3 * amountWidth),
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(new Text("Date") {{setFont(normal);}}, 0, 0);
                add(new Text("Particulars") {{setFont(normal);}}, 1, 0);
                add(new Text("Receivable") {{setFont(normal);}}, 2, 0);
                add(new Text("Payment") {{setFont(normal);}}, 3, 0);
                add(new Text("Balance") {{setFont(normal);}}, 4, 0);

                setPadding(new Insets(1, 0, 1, 0));
                setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 1, 0))));
            }};

            return new VBox(row1, row2, row3, tableHeader) {{
                setAlignment(Pos.TOP_CENTER);
                setPrefWidth(width);
                setMargin(tableHeader, new Insets(2.5, 0, 2.5, 0));
            }};
        }

        private Node getFooter(double width) {
            var date = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));
            var time = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a"));
            var left = new Text("Generated on " + date + " | " + time) {{setFont(normal);}};
            pageNoText = new Text() {{setFont(normal);}};
            return new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints()
                );
                add(left, 0, 0);
                add(pageNoText, 1, 0);

                setPrefWidth(width);
                setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 0, 0))));
            }};
        }

        void setPageNo(int pageNo) {
            pageNoText.setText("Page No: " + pageNo);
        }
    }

    private class ResponseTask extends Task<List<ReportEntry>> {
        private int length;
        private LocalDate minDate, maxDate;
        @Override
        protected List<ReportEntry> call() {
            try {
                updateMessage("requesting data ...");
                Thread.sleep(500);

                var whereBytes = (getWhere() + '\0').getBytes(StandardCharsets.US_ASCII);
                var buffer = ByteBuffer.allocate(4 + whereBytes.length).order(ByteOrder.LITTLE_ENDIAN);
                buffer.putInt(idProperty.get());
                buffer.put(whereBytes);
                if (isCancelled()) return null;

                var request = new Request(Function.GetLedger.ordinal(), buffer);

                var response = Channels.getInstance().getResponse(request).get();
                if (!response.isSuccess()) {
                    updateMessage("service down ...");
                    Thread.sleep(500);
                    return null;
                }
                if (isCancelled()) return null;

                length = response.getPacket().length;
                if (length == 0) {
                    updateMessage("no data available");
                    Thread.sleep(500);
                    Platform.runLater(() ->{
                        entriesProperty.set(0);
                        receivableProperty.set(0);
                        receiptProperty.set(0);
                        balanceProperty.set(0);
                    });
                    return null;
                }
                if (isCancelled()) return null;

                updateMessage("received " + String.format("%,d", length) + " bytes");
                Thread.sleep(500);

                buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
                var list = getList(buffer, length);

                return filtefinalizeList(list);

            } catch (Exception e) {
                return null;
            }
        }

        @Override
        protected void succeeded() {
            reserved.clear();
            try {
                var result = get();
                if (result == null) return;

                reserved.addAll(get());

                minDateProperty.set(minDate);
                maxDateProperty.set(maxDate);

                var formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy");
                availablePeriodProperty.set("available from " +minDate.format(formatter) + " to " + maxDate.format(formatter));

                entriesProperty.set(entries);
                receivableProperty.set(receivable);
                receiptProperty.set(receipt);
                balanceProperty.set(balance);
                updateMessage("processed " + String.format("%,d", length) + " bytes");

            } catch (InterruptedException | ExecutionException e) {

            }
        }

        private List<ReportEntry> filtefinalizeList(List<ReportEntry> list) throws Exception{
            //check date comparisons and simplify
            minDate = list.get(0).getDate();
            maxDate = list.get(list.size() - 1).getDate();

            var startDate = startDateProperty.get() == null ? minDate : startDateProperty.get();
            var endDate = endDateProperty.get() == null ? maxDate : endDateProperty.get();

            if(startDateProperty.get() == null){
                Platform.runLater(() -> startDateProperty.set(minDate));
            }
            if(endDateProperty.get() == null){
                Platform.runLater(() -> endDateProperty.set(maxDate));
            }

            if(isLoaded) {
                var temp = new ArrayList<ReportEntry>();
                if (!startDate.isBefore(minDate)) {
                    var lastEntry = list.stream().filter(x -> x.getDate().isBefore(startDate)).reduce((x, y) -> y);
                    lastEntry.ifPresent(e -> temp.add(new ReportEntry() {{
                        setDate(startDate);
                        setParticulars("balance b/d");
                        setBalance(e.getBalance());
                    }}));
                    temp.addAll(list.stream().filter(x -> !x.getDate().isBefore(startDate)).toList());
                }
                if(isCancelled()) return null;


                if (!endDate.isAfter(maxDate)) {
                    var temp2 = temp.stream().filter(x -> !x.getDate().isAfter(endDate)).toList();
                    temp.clear();
                    temp.addAll(temp2);
                }
                if(isCancelled()) return null;

                if (temp.size() > 0) {
                    receivable = 0;
                    receipt = 0;
                    var newList = new ArrayList<ReportEntry>();
                    for (var e : temp) {
                        receivable += e.getReceivable();
                        receipt += e.getReceipt();
                        newList.add(e);
                    }
                    balance = newList.get(newList.size() - 1).getBalance();

                    if(maxDate.isBefore(endDate)){
                        Platform.runLater(() -> endDateProperty.set(maxDate));
                    }
                    if(minDate.isAfter(startDate)){
                        Platform.runLater(() -> startDateProperty.set(minDate));
                    }
                    return newList;
                }
                else {
                    updateMessage("no data in that range");
                    Thread.sleep(3000);
                    Platform.runLater(() ->{
                        startDateProperty.set(minDate);
                        endDateProperty.set(maxDate);
                    });
                    return list;
                }
            }
            else {
                isLoaded = true;
                Platform.runLater(() ->{
                    startDateProperty.set(minDate);
                    endDateProperty.set(maxDate);
                });
                return list;
            }
        }

        private List<ReportEntry> getList(ByteBuffer span, int length) {
            var list = new ArrayList<ReportEntry>();
            int read = 0;
            int start = 0;
            entries = receivable = receipt = balance = 0;

            var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            while (read < length) {
                if (isCancelled()) break;

                while (span.get(read) != 0) read++;
                var date = new String(span.array(), start, read - start, StandardCharsets.US_ASCII);
                start = ++read;

                while (span.get(read) != 0) read++;
                var particulars = new String(span.array(), start, read - start, StandardCharsets.US_ASCII);
                read++;
                int amount = span.getInt(read);
                int control = span.getInt(read + 4);
                read += 8;
                start = read;

                var entry = new ReportEntry() {{
                    setDate(LocalDate.parse(date, formatter));
                    setParticulars(particulars);
                }};
                if (control == AppData.controlIdOfReceivable || control == AppData.controlIdOfPayment) {
                    receivable += amount;
                    balance -= amount;
                    entry.setReceivable(amount);
                }
                else {
                    receipt += amount;
                    balance += amount;
                    entry.setReceipt(amount);
                }
                entry.setBalance(balance);
                list.add(entry);
                entries++;
            }

            return list;
        }
    }
}
