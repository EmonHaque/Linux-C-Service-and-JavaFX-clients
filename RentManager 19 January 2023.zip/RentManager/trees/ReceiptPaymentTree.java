package trees;

import Models.ReceiptPayment;
import abstracts.WrapTreeCellBase;
import controls.texts.HiText;
import helpers.Constants;
import javafx.beans.property.*;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.HPos;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

import java.util.Comparator;
import java.util.function.Function;

public class ReceiptPaymentTree extends ExtendedTreeView<ReceiptPayment> {
    private final FilteredList<ReceiptPayment> list;
    public BooleanProperty isExpandedProperty;

    public ReceiptPaymentTree(FilteredList<ReceiptPayment> list, StringProperty query) {
        this.list = list;
        isExpandedProperty = new SimpleBooleanProperty();
        setRoot(new TreeItem<>());
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new ReceiptPaymentCell(query));

        list.addListener(this::onItemsChanged);

        isExpandedProperty.addListener(o -> {
            var value = isExpandedProperty.get();
            for (var level1 : getRoot().getChildren())
                for (var level2 : level1.getChildren())
                    resetExpandState(level2, value);
        });

        query.addListener((o, ov, nv) ->{
            if(nv == null || nv.isBlank() || nv.isEmpty()) return;
            for(var node : getRoot().getChildren())
                resetExpandState(node, true);
        });
    }

    private void onItemsChanged(ListChangeListener.Change<? extends ReceiptPayment> change) {
        // the most efficient way that works in all situation
        getRoot().getChildren().clear();
        for (var e : list) addItem(getRoot(), e);
        removeSingleLeaf();
        for (var node : getRoot().getChildren()) sort(node);
        for (var level1 : getRoot().getChildren()){
            level1.setExpanded(true);
            for (var level2 : level1.getChildren())
                resetExpandState(level2, isExpandedProperty.get());
        }
    }

    private void resetExpandState(TreeItem<ReceiptPayment> node, boolean value) {
        node.setExpanded(value);
        for (var item : node.getChildren()) {
            if (item.isLeaf()) continue;
            resetExpandState(item, value);
        }
    }

    @SuppressWarnings("unchecked")
    private void sort(TreeItem<ReceiptPayment> node) {
        node.getChildren().sort(
                Comparator.comparing(x -> ((TreeItem<ReceiptPayment>) x).getChildren().size()).reversed()
                        .thenComparing(x -> ((TreeItem<ReceiptPayment>) x).getValue().getHead())
                        .thenComparing(x -> ((TreeItem<ReceiptPayment>) x).getValue().getPlot())
                        .thenComparing(x -> ((TreeItem<ReceiptPayment>) x).getValue().getTenant())
        );
        for (var item : node.getChildren()) sort(item);
    }

    private void addItem(TreeItem<ReceiptPayment> node, ReceiptPayment entry) {
        var level = getTreeItemLevel(node);
        var hasIt = false;
        TreeItem<ReceiptPayment> item = null;
        Function<ReceiptPayment, Boolean> condition = x -> true;

        switch (level) {
            case 0 -> condition = e -> e.getControl().equals(entry.getControl());
            case 1 -> condition = e -> e.getHead().equals(entry.getHead());
            case 2 -> condition = e -> e.getPlot().equals(entry.getPlot());
            case 3 -> condition = e -> e.getTenant().equals(entry.getTenant());
        }

        for (var branch : node.getChildren()) {
            if (!condition.apply(branch.getValue())) continue;
            var value = branch.getValue();
            value.setCash(value.getCash() + entry.getCash());
            value.setKind(value.getKind() + entry.getKind());
            value.setMobile(value.getMobile() + entry.getMobile());
            value.setTotal(value.getTotal() + entry.getTotal());
            hasIt = true;
            item = branch;
            break;
        }
        if (!hasIt) {
            var newEntry = new ReceiptPayment() {{
                setCash(entry.getCash());
                setKind(entry.getKind());
                setMobile(entry.getMobile());
                setTotal(entry.getTotal());
                setHead("");
                setPlot("");
                setTenant("");
                setSpace("");
            }};
            switch (level) {
                case 0 -> newEntry.setControl(entry.getControl());
                case 1 -> newEntry.setHead(entry.getHead());
                case 2 -> newEntry.setPlot(entry.getPlot());
                case 3 -> newEntry.setTenant(entry.getTenant());
            }
            item = new TreeItem<>(newEntry);
            node.getChildren().add(item);
        }

        if (level == 3) item.getChildren().add(new TreeItem<>(entry));
        else addItem(item, entry);
    }

    private void removeSingleLeaf() {
        for (var control : getRoot().getChildren()) {
            for (var head : control.getChildren()) {
                for (var plot : head.getChildren()) {
                    for (var tenant : plot.getChildren()) {
                        if (tenant.getChildren().size() > 1) continue;
                        var item = tenant.getChildren().get(0).getValue();
                        tenant.getChildren().clear();
                        tenant.getValue().setSpace(item.getSpace());
                    }
                }
            }
        }
    }

    private class ReceiptPaymentCell extends WrapTreeCellBase<ReceiptPayment>{
        private Font normal, bold;
        private Border topBorder;
        private Text cash, kind, mobile, total;
        private HiText particulars;
        private final StringProperty query;

        public ReceiptPaymentCell(StringProperty query) {
            // super();
            this.query = query;
        }

        @Override
        protected void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);
            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0)));

            particulars = new HiText();
            cash = new Text() {{setFill(Color.WHITE);}};
            kind = new Text() {{setFill(Color.WHITE);}};
            mobile = new Text() {{setFill(Color.WHITE);}};
            total = new Text() {{setFill(Color.WHITE);}};

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}}
                );
                add(particulars, 0, 0);
                add(cash, 1, 0);
                add(kind, 2, 0);
                add(mobile, 3, 0);
                add(total, 4, 0);
            }};
            makeFontBold();
        }

        @Override
        protected void resetValues(ReceiptPayment oldValue) {
            makeFontBold();
            root.setBorder(null);
            particulars.setText(null);
            particulars.queryProperty().unbind();
            particulars.queryProperty().set("");
            cash.setText(null);
            kind.setText(null);
            mobile.setText(null);
            total.setText(null);
        }

        @Override
        protected void setValues(ReceiptPayment newValue) {
                String text = "";
                switch (level) {
                    case 1 -> text = newValue.getControl() + " (" + item.getChildren().size() + ")";
                    case 2 -> text = newValue.getHead() + " (" + item.getChildren().size() + ")";
                    case 3 -> text = newValue.getPlot() + " (" + item.getChildren().size() + ")";
                    case 4 -> {
                        text = !newValue.getSpace().isEmpty() ?
                                newValue.getTenant() + " - " + newValue.getSpace() :
                                newValue.getTenant() + " (" + item.getChildren().size() + ")";
                        makeBorder(item);
                        makeFontNormal();
                    }
                    case 5 -> {
                        text = newValue.getSpace();
                        makeBorder(item);
                        makeFontNormal();
                    }
                }
                particulars.setText(text);
                particulars.queryProperty().bind(query);
                cash.setText(AppData.formatNumber(newValue.getCash()));
                kind.setText(AppData.formatNumber(newValue.getKind()));
                mobile.setText(AppData.formatNumber(newValue.getMobile()));
                total.setText(AppData.formatNumber(newValue.getTotal()));
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 4 * 80;
            particulars.setPrefWidth(remainder);
            return particulars.prefHeight(remainder);
        }

        private void makeFontNormal() {
            particulars.setFont(normal);
            cash.setFont(normal);
            kind.setFont(normal);
            mobile.setFont(normal);
            total.setFont(normal);
        }

        private void makeFontBold() {
            particulars.setFont(bold);
            cash.setFont(bold);
            kind.setFont(bold);
            mobile.setFont(bold);
            total.setFont(bold);
        }

        private void makeBorder(TreeItem<ReceiptPayment> item) {
            var siblings = item.getParent().getChildren();
            int index = siblings.indexOf(item);
            if (index == 0) {
                root.setBorder(topBorder);
            }
            else if (index == siblings.size() - 1) {
                root.setBorder(Constants.BottomLine);
            }
        }
    }
}
