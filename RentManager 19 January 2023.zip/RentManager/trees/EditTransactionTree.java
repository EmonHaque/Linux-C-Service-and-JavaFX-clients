package trees;

import Models.TransactionEditable;
import abstracts.WrapTreeCellBase;
import controls.texts.HiTexts;
import controls.SVGIconRegion;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import skinned.ExtendedTreeView;

import java.util.List;

public class EditTransactionTree extends ExtendedTreeView<TransactionEditable> {
    //private final TreeItem<TransactionEditable> plots;

    public EditTransactionTree(ObservableList<TransactionEditable> list, StringProperty query) {
        setRoot(new TreeItem<>());
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new TransactionCell(query));
        list.addListener(this::onItemsChanged);
    }

    private void onItemsChanged(ListChangeListener.Change<? extends TransactionEditable> change) {
        // why while?
        getSelectionModel().clearSelection();
        while (change.next()) {
            if (change.getRemovedSize() > 0) {
                removeItems((List<TransactionEditable>) change.getRemoved());
            }
            if (change.getAddedSize() > 0) {
                addItems((List<TransactionEditable>) change.getAddedSubList());
            }
        }
    }

    private void removeItems(List<TransactionEditable> list) {
        for (var transaction : list) {
            TreeItem<TransactionEditable> plot = null;
            for (var tree : getRoot().getChildren()) {
                if (tree.getValue().getPlotName().equals(transaction.getPlotName())) {
                    plot = tree;
                    plot.getValue().setAmount(plot.getValue().getAmount() - transaction.getAmount());
                    break;
                }
            }
            TreeItem<TransactionEditable> leaf = null;
            for (var item : plot.getChildren()) {
                if (item.getValue().getId() == transaction.getId()) {
                    leaf = item;
                    break;
                }
            }
            plot.getChildren().remove(leaf);
            if (plot.getChildren().size() == 0) {
                getRoot().getChildren().remove(plot);
            }
        }
    }

    private void addItems(List<TransactionEditable> list) {
        for (var transaction : list) {
            var hasIt = false;
            TreeItem<TransactionEditable> item = null;
            for (var tree : getRoot().getChildren()) {
                if (tree.getValue().getPlotName().equals(transaction.getPlotName())) {
                    item = tree;
                    item.getValue().setAmount(item.getValue().getAmount() + transaction.getAmount());
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                item = new TreeItem<>(new TransactionEditable() {{
                    setPlotName(transaction.getPlotName());
                    setAmount(transaction.getAmount());
                }});
                item.setExpanded(true);
                getRoot().getChildren().add(item);
            }
            var leaf = new TreeItem<>(transaction);
            item.getChildren().add(leaf);
        }
    }

    private class TransactionCell extends WrapTreeCellBase<TransactionEditable> {
        private HiTexts flow;
        private Text space, tenant, control, amount;
        private SVGIconRegion icon;
        private Font normal, bold;
        private final StringProperty query;

        public TransactionCell(StringProperty query) {
//            super();
            this.query = query;
        }

        @Override
        protected void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            space = new Text() {{setFill(Color.WHITE);}};
            tenant = new Text() {{setFill(Color.WHITE);}};
            control = new Text() {{
                setFill(Color.GRAY);
                setFont(Font.font(null, FontPosture.ITALIC, -1));
            }};
            amount = new Text() {{setFill(Color.WHITE);}};

            flow = new HiTexts(space, tenant, control);
            icon = new SVGIconRegion(Icons.Cash);

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.SOMETIMES); setWrapText(true);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(16) {{setHalignment(HPos.CENTER);}}
                );
                add(flow, 0, 0);
                add(amount, 1, 0);
                add(icon, 2, 0);
            }};
        }

        @Override
        protected void resetValues(TransactionEditable oldValue) {
            var item = getTreeItem();
            var level = getTreeItemLevel(item);
            if (level == 2) {
                oldValue.isCashProperty().removeListener(this::onIsCashChanged);
            }
            flow.queryProperty().unbind();
            flow.queryProperty().set("");
        }

        @Override
        protected void setValues(TransactionEditable newValue) {
            if (level == 1) {
                GridPane.setColumnSpan(amount, 2);
                control.textProperty().unbind();
                control.setText("");

                space.textProperty().bind(newValue.plotNameProperty().concat(" ("));
                tenant.textProperty().bind(Bindings.size(item.getChildren()).asString().concat(")"));

                space.setFont(bold);
                amount.setFont(bold);
                icon.setVisible(false);
            }
            else {
                GridPane.setColumnSpan(amount, 1);
                space.textProperty().bind(newValue.spaceNameProperty().concat(" - "));
                tenant.textProperty().bind(newValue.tenantNameProperty().concat(" "));
                control.textProperty().bind(newValue.controlNameProperty());
                flow.queryProperty().bind(query);

                space.setFont(normal);
                amount.setFont(normal);
                icon.setVisible(true);
                setIcon(newValue.getIsCash());
                newValue.isCashProperty().addListener(this::onIsCashChanged);
            }
            amount.textProperty().bind(newValue.amountProperty().asString("%,d"));
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 80 - 16;
            flow.setPrefWidth(remainder);
            return flow.prefHeight(remainder);
        }

//        @Override
//        protected void updateItem(TransactionEditable item, boolean empty) {
//            super.updateItem(item, empty);
//            if(empty) return;
//            setDisable(level == 1);
//        }

        private void setIcon(int value) {
            switch (value) {
                case 0 -> {
                    icon.setContent(Icons.Cash);
                    icon.setFill(Color.LIGHTGREEN);
                }
                case 1 -> {
                    icon.setContent(Icons.NonCash);
                    icon.setFill(Color.LIGHTCORAL);
                }
                case 2 -> {
                    icon.setContent(Icons.Mobile);
                    icon.setFill(Color.CORNFLOWERBLUE);
                }
            }
        }

        private void onIsCashChanged(ObservableValue<?> o, Number ov, Number nv) {
            setIcon(nv.intValue());
        }
    }
}
