package trees;

import Models.Entry;
import controls.SVGIcon;
import controls.SVGRegion;
import controls.buttons.ActionButtonArg;
import helpers.Constants;
import helpers.Icons;
import interfaces.IExecuteArg;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

public class TransactionEntryTree extends ExtendedTreeView<Entry> {
    private final ObservableList<Entry> entries;
    private final TreeItem<Entry> root, receipt, payment, receivable;

    public TransactionEntryTree(ObservableList<Entry> entries, IExecuteArg<Entry> executor) {
        this.entries = entries;
        receipt = new TreeItem<>(new Entry() {{setNarration("Receipt");}}) {{setExpanded(true);}};
        payment = new TreeItem<>(new Entry() {{setNarration("Payment");}}) {{setExpanded(true);}};
        receivable = new TreeItem<>(new Entry() {{setNarration("Receivable");}}) {{setExpanded(true);}};
        root = new TreeItem<>();
        setRoot(root);
        setShowRoot(false);
        setCellFactory(v -> new EntryCell(executor));
        entries.addListener(this::onEntriesChanged);
    }

    private void onEntriesChanged(ListChangeListener.Change<? extends Entry> change) {
        while (change.next()) {
            if (change.wasAdded()) {
                var item = change.getAddedSubList().get(0);
                var node = item.getControlId() == AppData.controlIdOfReceivable ? receivable
                        : item.getControlId() == AppData.controlIdOfPayment ? payment
                        : receipt;
                if (!root.getChildren().contains(node)) {
                    root.getChildren().add(node);
                }
                addItem(node, item);
                node.getValue().setAmount(node.getValue().getAmount() + item.getAmount());
            }
            else if (change.wasRemoved()) {
                if (entries.size() == 0) {
                    clearItems();
                    return;
                }
                var item = change.getRemoved().get(0);
                var node = item.getControlId() == AppData.controlIdOfReceivable ? receivable
                        : item.getControlId() == AppData.controlIdOfPayment ? payment
                        : receipt;
                if (!root.getChildren().contains(node)) {
                    root.getChildren().add(node);
                }
                removeItem(node, item);
                node.getValue().setAmount(node.getValue().getAmount() - item.getAmount());
            }
        }
    }

    private void clearItems() {
        receivable.getChildren().clear();
        receipt.getChildren().clear();
        payment.getChildren().clear();
        receivable.getValue().setAmount(0);
        receipt.getValue().setAmount(0);
        payment.getValue().setAmount(0);
        root.getChildren().clear();
    }

    private void addItem(TreeItem<Entry> node, Entry e) {
        TreeItem<Entry> plot = null;
        var hasIt = false;
        for (var item : node.getChildren()) {
            if (item.getValue().getPlotId() == e.getPlotId()) {
                plot = item;
                plot.getValue().setAmount(plot.getValue().getAmount() + e.getAmount());
                hasIt = true;
                break;
            }
        }
        if (!hasIt) {
            plot = new TreeItem<>(new Entry() {{
                setPlotId(e.getPlotId());
                setAmount(e.getAmount());
            }}) {{setExpanded(true);}};
            node.getChildren().add(plot);
        }
        plot.getChildren().add(new TreeItem<>(e));
    }

    private void removeItem(TreeItem<Entry> node, Entry e) {
        TreeItem<Entry> plot = null;
        TreeItem<Entry> leaf = null;
        for (var item : node.getChildren()) {
            if (item.getValue().getPlotId() == e.getPlotId()) {
                plot = item;
                for (var l : plot.getChildren()) {
                    if (l.getValue().equals(e)) {
                        leaf = l;
                        break;
                    }
                }
                plot.getValue().setAmount(plot.getValue().getAmount() - e.getAmount());
                break;
            }
        }
        plot.getChildren().remove(leaf);
        if (plot.getChildren().size() == 0) {
            node.getChildren().remove(plot);
        }
        if (node.getChildren().size() == 0) {
            root.getChildren().remove(node);
        }
    }

    public BooleanBinding isEmpty() {return Bindings.isEmpty(entries);}

    private class EntryCell extends TreeCell<Entry> {
        private final IExecuteArg<Entry> executor;
        private Font normal, bold;
        private GridPane root, breakup;
        private Text particulars, date, amount, totalCash, totalKind, totalMobile, grandTotal;
        private SVGIcon isCashIcon, cashIcon, kindIcon, mobileIcon, totalIcon;
        private SVGRegion disclosureIcon;
        private Border topBorder, bottomBorder;
        private ActionButtonArg<Entry> button;

        public EntryCell(IExecuteArg<Entry> executor) {
            this.executor = executor;
            setPrefWidth(0);
            setPadding(new Insets(2.5, 0, 2.5, 0));
            setBackground(null);

            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            initializeUI();
            itemProperty().addListener(this::onItemChanged);
        }

        private void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25,0,0,0)));
            bottomBorder = Constants.BottomLine;

            particulars = new Text() {{setFill(Color.WHITE);}};
            date = new Text() {{setFill(Color.WHITE);}};
            amount = new Text() {{setFill(Color.WHITE);}};
            isCashIcon = new SVGIcon(Icons.Cash);
            button = new ActionButtonArg<>(Icons.MinusCircle, 16, "remove");

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.SOMETIMES);}},
                        new ColumnConstraints() ,
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(20) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(20) {{setHalignment(HPos.RIGHT);}}
                );
                add(particulars, 0, 0);
                add(date, 1, 0);
                add(amount, 2, 0);
                add(isCashIcon, 3, 0);
                add(button, 4, 0);
            }};

            initializeBreakup();
        }

        private void initializeBreakup() {
            totalCash = new Text() {{setFill(Color.WHITE);}};
            totalKind = new Text() {{setFill(Color.WHITE);}};
            totalMobile = new Text() {{setFill(Color.WHITE);}};
            grandTotal = new Text() {{setFill(Color.WHITE);}};

            cashIcon = new SVGIcon(Icons.Cash) {{setFill(Color.LIGHTGREEN);}};
            kindIcon = new SVGIcon(Icons.NonCash) {{setFill(Color.LIGHTCORAL);}};
            mobileIcon = new SVGIcon(Icons.Mobile) {{setFill(Color.CORNFLOWERBLUE);}};
            totalIcon = new SVGIcon(Icons.Sum) {{setFill(Color.WHITE);}};

            breakup = new GridPane() {{
                add(cashIcon, 0, 0);
                add(totalCash, 1, 0);
                add(kindIcon, 2, 0);
                add(totalKind, 3, 0);
                add(mobileIcon, 4, 0);
                add(totalMobile, 5, 0);
                add(totalIcon, 6, 0);
                add(grandTotal, 7, 0);

                setHgap(5);
            }};
            GridPane.setColumnSpan(breakup, 4);
            GridPane.setHalignment(breakup, HPos.RIGHT);
            GridPane.setValignment(breakup, VPos.CENTER);
            GridPane.setHgrow(breakup, Priority.ALWAYS);
        }

        private void onItemChanged(ObservableValue<?> o, Entry ov, Entry nv) {
            if (ov != null) {
                particulars.setText(null);
                date.setText(null);
                amount.setText(null);
                button.setAction(null, null);

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);

                root.setBorder(null);
                root.getChildren().remove(breakup);
            }
            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                if (level == 1) {
                    particulars.setText(nv.getNarration());
                    particulars.setFont(bold);
                    amount.setVisible(false);
                    date.setVisible(false);
                    isCashIcon.setVisible(false);
                    button.setVisible(false);

                    int cash, kind, mobile;
                    cash = kind = mobile = 0;

                    for (var plot : item.getChildren()) {
                        for (var entry : plot.getChildren()) {
                            var e = entry.getValue();
                            switch (e.getIsCash()) {
                                case 0 -> cash += e.getAmount();
                                case 1 -> kind += e.getAmount();
                                case 2 -> mobile += e.getAmount();
                            }
                        }
                    }
                    totalCash.setText(String.format("%,d", cash));
                    totalKind.setText(String.format("%,d", kind));
                    totalMobile.setText(String.format("%,d", mobile));
                    grandTotal.setText(String.format("%,d", nv.getAmount()));
                    root.add(breakup, 1, 0);
                }
                else if (level == 2) {
                    particulars.setText(AppData.plots.stream().filter(x -> x.getId() == nv.getPlotId()).findFirst().get().getName());
                    particulars.setFont(bold);
                    amount.setVisible(false);
                    date.setVisible(false);
                    isCashIcon.setVisible(false);
                    button.setVisible(false);
                    root.setBorder(topBorder);

                    int cash, kind, mobile;
                    cash = kind = mobile = 0;

                    for (var entry : item.getChildren()) {
                        var e = entry.getValue();
                        switch (e.getIsCash()) {
                            case 0 -> cash += e.getAmount();
                            case 1 -> kind += e.getAmount();
                            case 2 -> mobile += e.getAmount();
                        }
                    }
                    totalCash.setText(String.format("%,d", cash));
                    totalKind.setText(String.format("%,d", kind));
                    totalMobile.setText(String.format("%,d", mobile));
                    grandTotal.setText(String.format("%,d", nv.getAmount()));
                    root.add(breakup, 1, 0);
                }
                else if (level == 3) {
                    int index = 0;
                    for(var e : item.getParent().getChildren()){
                        if(e.getValue().equals(nv)) break;
                        index++;
                    }
                    if(index == 0){
                        root.setBorder(topBorder);
                    }
                    else if (index == item.getParent().getChildren().size() - 1) {
                        root.setBorder(bottomBorder);
                    }
                    var space = AppData.spaces.stream().filter(x -> x.getId() == nv.getSpaceId()).findFirst().get().getName();
                    var tenant = AppData.tenants.stream().filter(x -> x.getId() == nv.getTenantId()).findFirst().get().getName();

                    particulars.setText(space + " - " + tenant);
                    date.setText(nv.getDate().toString());
                    amount.setText(String.format("%,d", nv.getAmount()));
                    particulars.setFont(normal);
                    amount.setFont(normal);

                    date.setVisible(true);
                    isCashIcon.setVisible(true);
                    amount.setVisible(true);
                    button.setVisible(true);
                    button.setAction(executor, nv);
                    switch (nv.getIsCash()) {
                        case 0 -> {
                            isCashIcon.setContent(Icons.Cash);
                            isCashIcon.setFill(Color.LIGHTGREEN);
                        }
                        case 1 -> {
                            isCashIcon.setContent(Icons.NonCash);
                            isCashIcon.setFill(Color.LIGHTCORAL);
                        }
                        case 2 -> {
                            isCashIcon.setContent(Icons.Mobile);
                            isCashIcon.setFill(Color.CORNFLOWERBLUE);
                        }
                    }
                }
            }
        }

        @Override
        protected void updateItem(Entry item, boolean empty) {
            super.updateItem(item, empty);
            setGraphic(empty ? null : root);
        }
    }
}
