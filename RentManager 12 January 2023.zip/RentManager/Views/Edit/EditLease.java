package Views.Edit;

import CellTemplates.ListView.EditLeaseTemplate;
import CellTemplates.ListView.ReceivableTemplate;
import Converters.IntToStringConverter;
import Models.*;
import ViewModels.Edit.EditBaseVM;
import ViewModels.Edit.EditLeaseVM;
import controls.SelectionBox;
import controls.buttons.CommandButton;
import controls.states.BiState;
import controls.states.MultiState;
import controls.texts.IntegerBox;
import editables.EditDate;
import editables.EditPane;
import editables.EditSelection;
import editables.EditTextMultiline;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ListCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import skinned.ExtendedListView;
import skinned.ExtendedSeparator;

public class EditLease extends EditBase<Lease> {
    private EditLeaseVM vm;
    private SelectionBox<Plot> plots;
    private MultiState state;

    private EditSelection<Plot> editPlot;
    private EditSelection<Space> editSpace;
    private EditSelection<Tenant> editTenant;
    private EditTextMultiline business;
    private BiState isExpired;
    private EditDate dateStart, dateEnd;
    private VBox amountBox;
    private SelectionBox<Head> heads;
    private IntegerBox amount;
    private CommandButton addReceivable;
    private ExtendedListView<Receivable> receivables;


    @Override
    protected String getHeader() {
        return "Lease";
    }

    @Override
    protected String getIcon() {
        return Icons.Lease;
    }

    @Override
    protected String getTip() {
        return "Lease";
    }

    @Override
    protected EditBaseVM<Lease> getViewModel() {
        vm = new EditLeaseVM();
        return vm;
    }

    @Override
    protected boolean isEditableList() {
        return true;
    }

    @Override
    protected ListCell<Lease> getListCellTemplate() {
        return new EditLeaseTemplate(query.textProperty(), state.stateProperty);
    }

    @Override
    protected void onSelectionChanged(Lease item) {
        editPlot.valueProperty().unbindBidirectional(vm.edited.plotIdProperty());
        editSpace.valueProperty().unbindBidirectional(vm.edited.spaceIdProperty());
        editTenant.valueProperty().unbindBidirectional(vm.edited.tenantIdProperty());
        dateStart.dateProperty().unbindBidirectional(vm.edited.dateStartProperty());
        business.textProperty().unbindBidirectional(vm.edited.businessProperty());

        isExpired.isCheckedProperty.unbindBidirectional(vm.edited.isExpiredProperty());
        isExpired.disableProperty().unbind();
        isExpired.setDisable(true);
        dateEnd.visibleProperty().unbind();
        dateEnd.setVisible(false);

        if(item == null) return;
        vm.selectionChangedTrigger.set(!vm.selectionChangedTrigger.get()); // highly inefficient

        editPlot.valueProperty().bind(vm.selected.plotIdProperty());
        editSpace.valueProperty().bind(vm.selected.spaceIdProperty());

        editTenant.valueProperty().bind(vm.selected.tenantIdProperty());
        dateStart.dateProperty().bind(vm.selected.dateStartProperty());
        business.textProperty().bind(vm.selected.businessProperty());
        receivables.itemsProperty().bind(vm.selected.fixedReceivablesProperty());
        isExpired.isCheckedProperty.bind(vm.selected.isExpiredProperty());
    }

    @Override
    protected void onIsOnEditChanged() {
        editPlot.valueProperty().unbind();
        editSpace.valueProperty().unbind();
        editTenant.valueProperty().unbind();
        dateStart.dateProperty().unbind();
        business.textProperty().unbind();
        isExpired.isCheckedProperty.unbind();

        editPlot.valueProperty().bindBidirectional(vm.edited.plotIdProperty());
        editSpace.valueProperty().bindBidirectional(vm.edited.spaceIdProperty());

        editTenant.valueProperty().bindBidirectional(vm.edited.tenantIdProperty());
        dateStart.dateProperty().bindBidirectional(vm.edited.dateStartProperty());
        business.textProperty().bindBidirectional(vm.edited.businessProperty());
        receivables.itemsProperty().bind(vm.edited.fixedReceivablesProperty());

        isExpired.isCheckedProperty.bindBidirectional(vm.edited.isExpiredProperty());
        isExpired.disableProperty().bind(getIsExpiredDisabilityBinding());
        dateEnd.visibleProperty().bind(getDateVisibilityBinding());
        vm.edited.dateEndProperty().bind(dateEnd.dateProperty());
    }

    @Override
    protected void initializeUI() {
        var icons = new String[]{Icons.Existing, Icons.LeftOrExpired, Icons.All};
        var texts = new String[]{"Active", "Expired", "All"};
        state = new MultiState(icons, texts, false) {{setAlignment(Pos.BOTTOM_CENTER);}};

        super.initializeUI();

        plots = new SelectionBox<>("Plot", Icons.Plot, vm.plots, false);
        leftBox.getChildren().add(0, plots);
        queryBox.getChildren().add(1, state);
    }

    @Override
    protected void bind() {
        super.bind();
        vm.stateProperty.bind(state.stateProperty);
        vm.selectedPlotIdProperty.bind(plots.selectedValueProperty());
        vm.isOnEditProperty.bind(pane.isOnEditProperty());
        receivables.setCellFactory(v -> new ReceivableTemplate(vm::removeReceivable, pane.isOnEditProperty()));

        vm.receivable.headIdProperty().bind(heads.selectedValueProperty());
        Bindings.bindBidirectional(amount.textProperty(), vm.receivable.amountProperty(), new IntToStringConverter());

        amountBox.visibleProperty().bind(pane.isOnEditProperty());
        amountBox.managedProperty().bind(pane.isOnEditProperty());
        addReceivable.disableProperty().bind(amount.isEmpty().or(heads.isEmpty()));
        addReceivable.setAction(vm::addReceivable);
    }

    @Override
    protected void initializeEditPane(EditPane pane) {
        editPlot = new EditSelection<>("Plot", Icons.Plot, vm.editPlot, true, pane);
        editSpace = new EditSelection<>("Space", Icons.Space, vm.editSpace, true, pane);
        editTenant = new EditSelection<>("Tenant", Icons.Tenant, vm.editTenant, true, pane);
        dateStart = new EditDate("from", Icons.Month, true, pane);
        business = new EditTextMultiline("Business", Icons.Description, true, pane) {{setMinHeight(75);}};

        isExpired = new BiState(true, "is expired") {{setAlignment(Pos.BOTTOM_LEFT);}};
        dateEnd = new EditDate("to", Icons.Month, true, pane);
        receivables = new ExtendedListView<>();

        heads = new SelectionBox<>("Head", Icons.Head, vm.heads, true) {{setSelectAddedItem(true);}};
        amount = new IntegerBox("Amount", Icons.Amount, true);
        addReceivable = new CommandButton(Icons.PlusCircle, 16, "add");
        var box = new HBox(amount, addReceivable) {{
            setSpacing(5);
            setHgrow(amount, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_RIGHT);
            setPadding(new Insets(0, 0, 10, 0));
        }};
        amountBox = new VBox(heads, box) {{setSpacing(5);}};

        var hBox = new HBox(isExpired, dateEnd) {{
            setSpacing(10);
            setHgrow(dateEnd, Priority.ALWAYS);
        }};
        var text = new Text("Receivables") {{
            setFill(Color.GRAY);
            setFont(Font.font(null, FontWeight.BOLD, -1));
        }};
        var rightBox = new VBox(editPlot, editSpace, editTenant, dateStart, business, text, new ExtendedSeparator(), amountBox, receivables, hBox) {{
            setSpacing(5);
            setPadding(new Insets(10));
        }};
        pane.setCenter(rightBox);
    }

    private BooleanBinding getIsExpiredDisabilityBinding() {
        return Bindings.createBooleanBinding(() -> {
            if (!pane.onEdit()) return true;
            return vm.selected.isIsExpired();

        }, pane.isOnEditProperty(), vm.selected.isExpiredProperty());
    }

    private BooleanBinding getDateVisibilityBinding() {
        return Bindings.createBooleanBinding(() ->
                        !vm.selected.isIsExpired() && vm.edited.isIsExpired()
                , vm.edited.isExpiredProperty());
    }
}
