package Views.Transaction;

import CellTemplates.SelectionBox.TenantTemplate;
import CellTemplates.Visual.TenantVisual;
import Converters.IntToStringConverter;
import Models.*;
import ViewModels.Transaction.TransactionBaseVM;
import abstracts.View;
import controls.SelectionBox;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.daymonth.DayPicker;
import controls.states.MultiState;
import controls.texts.IntegerBox;
import controls.texts.TextBoxMultiLine;
import dialogs.ConfirmDialog;
import helpers.Icons;
import interfaces.IReturnNameAndId;
import interfaces.ISetSelectionBoxContent;
import javafx.beans.binding.Bindings;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import trees.TransactionEntryTree;

public abstract class TransactionBase<P extends IReturnNameAndId<P>, S extends IReturnNameAndId<S>> extends View {
    TransactionBaseVM<P, S> vm;
    private SelectionBox<Tenant> tenant;
    private SelectionBox<P> plot;
    private SelectionBox<S> space;
    private SelectionBox<ControlHead> control;
    private SelectionBox<Head> head;
    private DayPicker date;
    private IntegerBox amount;
    private MultiState isCash;
    private TextBoxMultiLine narration;
    private TransactionEntryTree tree;
    private CommandButton addEntry, add;

    private SpinningArc spinner;
    private Text status;

    public abstract TransactionBaseVM<P, S> getViewModel();

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = getViewModel();
        initializeUI();
        bind();
    }

    protected ISetSelectionBoxContent<S> getVisual() {return null;}

    protected String getTemplate() {return null;}

    private void initializeUI() {
        tenant = new SelectionBox<>("Tenant", Icons.Tenant, vm.tenants, new TenantVisual(), TenantTemplate.class.getName(), true);
        plot = new SelectionBox<>("Plot", Icons.Plot, vm.plots, true);

        space = getVisual() == null ?
                new SelectionBox<>("Space", Icons.Space, vm.spaces, true) :
                new SelectionBox<>("Space", Icons.Space, vm.spaces, getVisual(), getTemplate(), true);

        control = new SelectionBox<>("Control", Icons.ControlHead, vm.controls, true);
        head = new SelectionBox<>("Head", Icons.Head, vm.heads, true);
        date = new DayPicker("Date", Icons.Month, true);

        amount = new IntegerBox("Amount", Icons.Amount, true);
        isCash = new MultiState(new String[]{Icons.Cash, Icons.NonCash, Icons.Mobile}, new String[]{"Cash", "Non cash", "Mobile"}, true) {{
            setAlignment(Pos.BOTTOM_LEFT);
        }};
        narration = new TextBoxMultiLine("Narration", Icons.Description, true) {{
            setMinHeight(75);
            setMaxHeight(100);
        }};

        tree = new TransactionEntryTree(vm.entries, vm::removeEntry);

        addEntry = new CommandButton(Icons.PlusCircle, 16, "add");
        add = new CommandButton(Icons.Add, 16, "add");

        var amountBox = new HBox(amount, isCash, addEntry) {{
            setSpacing(10);
            setHgrow(amount, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_RIGHT);
        }};

        var grid = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(50);}},
                    new ColumnConstraints() {{setPercentWidth(50);}}
            );
            add(tenant, 0, 0, 2, 1);
            add(plot, 0, 1);
            add(space, 1, 1);
            add(control, 0, 2);
            add(head, 1, 2);
            add(date, 0, 3);
            add(amountBox, 1, 3);
            add(narration, 0, 4, 2, 1);
            add(tree, 0, 5, 2, 1);
            add(add, 1, 6);

            setHalignment(add, HPos.RIGHT);
            setHgap(10);
            setVgap(10);
            setPadding(new Insets(5, 0, 0, 0));
            setVgrow(tree, Priority.ALWAYS);
        }};
        setCenter(grid);

        status = new Text(){{ setFill(Color.WHITE);}};
        spinner = new SpinningArc();
        addAction(spinner);
        addAction(status);
    }

    private void bind() {
        vm.entry.tenantIdProperty().bind(tenant.selectedValueProperty());
        vm.entry.plotIdProperty().bind(plot.selectedValueProperty());
        vm.entry.spaceIdProperty().bind(space.selectedValueProperty());
        vm.entry.controlIdProperty().bind(control.selectedValueProperty());
        vm.entry.headIdProperty().bind(head.selectedValueProperty());
        vm.entry.dateProperty().bind(date.selectedDateProperty());
        vm.entry.isCashProperty().bind(isCash.stateProperty);
        Bindings.bindBidirectional(amount.textProperty(), vm.entry.amountProperty(), new IntToStringConverter());
        Bindings.bindBidirectional(narration.textProperty(), vm.entry.narrationProperty());

        addEntry.setAction(vm::addEntry);
        add.setAction(vm::add);

        addEntry.disableProperty().bind(tenant.isEmpty()
                .or(plot.isEmpty())
                .or(space.isEmpty())
                .or(control.isEmpty())
                .or(head.isEmpty())
                .or(date.isEmpty())
                .or(amount.isEmpty())
                .or(narration.isEmpty())
        );
        add.disableProperty().bind(tree.isEmpty().or(vm.isRunningProperty));

        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);

        vm.dialogTrigger.addListener((o, ov, nv) ->{
            if(nv){
                var dialog = new ConfirmDialog("Transaction", vm.dialogMessage);
                var bound = localToScreen(getBoundsInLocal());
                dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
                vm.dialogResult = dialog.dialogResult;
                vm.dialogTrigger.set(false);
            }
        });
    }
}
