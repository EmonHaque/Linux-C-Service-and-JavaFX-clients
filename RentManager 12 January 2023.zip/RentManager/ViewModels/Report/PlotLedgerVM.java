package ViewModels.Report;

import Models.Plot;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;
import ridiculous.Jar;

public class PlotLedgerVM extends BaseLedgerVM<Plot> {
    @Override
    protected String getWhere() {
        return "PlotId";
    }

    @Override
    public String getHeader() {
        return "Plot";
    }


    @Override
    protected FilteredList<Plot> getSelectionList() {
        return new FilteredList<>(new Jar<>(AppData.plots));
    }
}
