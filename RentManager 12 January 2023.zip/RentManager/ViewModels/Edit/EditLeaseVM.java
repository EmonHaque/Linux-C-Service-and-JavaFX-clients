package ViewModels.Edit;

import Enums.Function;
import Models.*;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;
import ridiculous.Jar;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class EditLeaseVM extends EditBaseVM<Lease> {
    private final Jar<Head> headSource;
    private final List<Head> removedHead;
    private final IntegerProperty editedPlotIdProperty, selectedEditPlotIdProperty;

    public FilteredList<Plot> plots, editPlot;
    public FilteredList<Head> heads;
    public FilteredList<Space> editSpace;
    public FilteredList<Tenant> editTenant;
    public Receivable receivable;
    public IntegerProperty selectedPlotIdProperty, stateProperty;
    public BooleanProperty isOnEditProperty, selectionChangedTrigger;

    public EditLeaseVM() {
        selected = new Lease();
        edited = new Lease();
        receivable = new Receivable();

        stateProperty = new SimpleIntegerProperty();
        selectedPlotIdProperty = new SimpleIntegerProperty();
        selectedEditPlotIdProperty = new SimpleIntegerProperty();
        editedPlotIdProperty = new SimpleIntegerProperty();
        isOnEditProperty = new SimpleBooleanProperty();
        selectionChangedTrigger = new SimpleBooleanProperty();

        headSource = new Jar<>(AppData.heads, x -> new Observable[]{x.controlIdProperty()});
        heads = new FilteredList<>(
                headSource.sorted(Comparator.comparingInt(Head::getId)),
                c -> c.getControlId() == AppData.controlIdOfReceivable
        );
        removedHead = new ArrayList<>();

        plots = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.plots));
        editPlot = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.plots));

        var editSpaceSource = new Jar<>(AppData.spaces, o -> new Observable[]{
                selectedEditPlotIdProperty,
                editedPlotIdProperty
        });
        editSpace = new FilteredList<>(editSpaceSource, x -> isOnEditProperty.get() ?
                x.getPlotId() == editedPlotIdProperty.get() :
                x.getPlotId() == selectedEditPlotIdProperty.get()
        );
        editTenant = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.tenants));

        var source = new Jar<>(AppData.leases, o -> new Observable[]{
                o.isExpiredProperty(),
                o.plotIdProperty(),
                stateProperty,
                queryProperty,
                selectedPlotIdProperty
        });
        editableList = new FilteredList<>(source.sorted(Comparator.comparing(Lease::getSpaceName)), this::filter);

        isOnEditProperty.addListener(this::onIsOnEditChanged);
        selectionChangedTrigger.addListener(this::onSelectionChanged);
    }

    private void onSelectionChanged(Observable o) {
        selectedEditPlotIdProperty.set(selected.getPlotId());
    }

    private boolean filter(Lease lease) {
        var isMatch = lease.getPlotId() == selectedPlotIdProperty.get();
        if (!isMatch) return false;
        if (!isQueryEmpty) {
            isMatch = lease.getSpaceName().toLowerCase().contains(trimmedQuery)
                    || lease.getTenantName().toLowerCase().contains(trimmedQuery);
        }
        switch (stateProperty.get()) {
            case 0 -> isMatch = isMatch && !lease.isIsExpired();
            case 1 -> isMatch = isMatch && lease.isIsExpired();
        }
        return isMatch;
    }

    @Override
    protected int function() {
        return Function.EditLease.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        byte isExpired;
        var expireDate = "";
        if (!selected.isIsExpired() && edited.isIsExpired()) {
            expireDate = edited.getDateEnd().toString();
            isExpired = 1;
        }
        else {
            isExpired = selected.isIsExpired() ? (byte) 1 : 0;
        }
        var startDateBytes = (edited.getDateStart().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
        var endDateBytes = (expireDate + '\0').getBytes(StandardCharsets.US_ASCII);
        var businessBytes = (edited.getBusiness() + '\0').getBytes(StandardCharsets.US_ASCII);

        var buffer = ByteBuffer.allocate(17 + edited.getFixedReceivables().size() * 12
                        + startDateBytes.length + endDateBytes.length + businessBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(edited.getId())
                .putInt(edited.getPlotId())
                .putInt(edited.getSpaceId())
                .putInt(edited.getTenantId())
                .put(startDateBytes)
                .put(endDateBytes)
                .put(businessBytes)
                .put(isExpired);

        for (var receivable : edited.getFixedReceivables()) {
            buffer.putInt(receivable.getLeaseId())
                    .putInt(receivable.getHeadId())
                    .putInt(receivable.getAmount());
        }
        return buffer;
    }

    @Override
    public void cloneSelected() {
        edited = new Lease() {{
            setId(selected.getId());
            setPlotId(selected.getPlotId());
            setSpaceId(selected.getSpaceId());
            setTenantId(selected.getTenantId());
            setBusiness(selected.getBusiness());
            setDateStart(selected.getDateStart());
            setDateEnd(selected.getDateEnd());
            setIsExpired(selected.isIsExpired());
        }};

        edited.setFixedReceivables(FXCollections.observableArrayList());
        for (var rec : selected.getFixedReceivables()) {
            edited.getFixedReceivables().add(new Receivable(
                    rec.getLeaseId(),
                    rec.getHeadId(),
                    rec.getAmount()
            ));

            var head = AppData.heads.stream().filter(x -> x.getId() == rec.getHeadId()).findFirst().get();
            headSource.remove(head);
            removedHead.add(head);
        }
        edited.plotIdProperty().addListener(this::onEditedPlotIdChanged);
    }

    private void onIsOnEditChanged(ObservableValue<?> o, boolean ov, boolean nv) {
        if (nv) return;
        editedPlotIdProperty.set(selected.getPlotId());
        edited.plotIdProperty().removeListener(this::onEditedPlotIdChanged);
    }

    private void onEditedPlotIdChanged(ObservableValue<?> o, Number ov, Number nv) {
        editedPlotIdProperty.set(nv.intValue());
    }

    public void removeReceivable(Receivable r) {
        edited.getFixedReceivables().remove(r);

        var head = removedHead.stream().filter(x -> x.getId() == r.getHeadId()).findFirst().get();
        headSource.add(head);
        removedHead.remove(head);
    }

    public void addReceivable() {
        var newRec = new Receivable(edited.getId(), receivable.getHeadId(), receivable.getAmount());
        edited.getFixedReceivables().add(newRec);

        var head = AppData.heads.stream().filter(x -> x.getId() == receivable.getHeadId()).findFirst().get();
        headSource.remove(head);
        removedHead.add(head);

        receivable.setAmount(0);
    }
}
