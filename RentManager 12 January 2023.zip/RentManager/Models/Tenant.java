package Models;

import interfaces.IReturnNameAndId;
import javafx.beans.property.*;

public class Tenant extends IReturnNameAndId<Tenant> {
    private final IntegerProperty id;
    private final StringProperty name, father, mother, husband, address, nid, contactNo;
    private final BooleanProperty hasLeft;

    public Tenant() {
        id = new SimpleIntegerProperty();
        name = new SimpleStringProperty("");
        father = new SimpleStringProperty("");
        mother = new SimpleStringProperty("");
        husband = new SimpleStringProperty("");
        address = new SimpleStringProperty("");
        nid = new SimpleStringProperty("");
        contactNo = new SimpleStringProperty("");
        hasLeft = new SimpleBooleanProperty();
    }
    @Override
    public int getId() {
        return id.get();
    }

    @Override
    public String getName(){
        return name.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public StringProperty nameProperty() {
        return name;
    }

    public String getFather() {
        return father.get();
    }

    public StringProperty fatherProperty() {
        return father;
    }

    public String getMother() {
        return mother.get();
    }

    public StringProperty motherProperty() {
        return mother;
    }

    public String getHusband() {
        return husband.get();
    }

    public StringProperty husbandProperty() {
        return husband;
    }

    public String getAddress() {
        return address.get();
    }

    public StringProperty addressProperty() {
        return address;
    }

    public String getNid() {
        return nid.get();
    }

    public StringProperty nidProperty() {
        return nid;
    }

    public String getContactNo() {
        return contactNo.get();
    }

    public StringProperty contactNoProperty() {
        return contactNo;
    }

    public boolean isHasLeft() {
        return hasLeft.get();
    }

    public BooleanProperty hasLeftProperty() {
        return hasLeft;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public void setFather(String father) {
        this.father.set(father);
    }

    public void setMother(String mother) {
        this.mother.set(mother);
    }

    public void setHusband(String husband) {
        this.husband.set(husband);
    }

    public void setAddress(String address) {
        this.address.set(address);
    }

    public void setNid(String nid) {
        this.nid.set(nid);
    }

    public void setContactNo(String contactNo) {
        this.contactNo.set(contactNo);
    }

    public void setHasLeft(boolean hasLeft) {
        this.hasLeft.set(hasLeft);
    }
}
