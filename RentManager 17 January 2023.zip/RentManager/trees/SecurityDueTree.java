package trees;

import Models.LastDue;
import controls.SVGRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.Observable;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

public class SecurityDueTree extends ExtendedTreeView<LastDue> {
    private final ObservableList<LastDue> list;

    public SecurityDueTree(ObservableList<LastDue> list) {
        this.list = list;
        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new Cell());
        list.addListener(this::onItemsChanged);
        setBorder(Constants.BottomLine);
    }

    private void onItemsChanged(ListChangeListener.Change<? extends LastDue> change){
        getRoot().getChildren().clear();
        addItems();
    }

    private void addItems(){
        TreeItem<LastDue> node = null;
        boolean hasIt = false;

        for(var item : list){
            for(var branch : getRoot().getChildren()){
                if(branch.getValue().getPlot().equals(item.getPlot())){
                    var value = branch.getValue();
                    value.setSecurity(value.getSecurity() + item.getSecurity());
                    value.setDue(value.getDue() + item.getDue());
                    node = branch;
                    hasIt = true;
                    break;
                }
            }
            if(!hasIt){
                var newItem = new LastDue(){{
                    setPlot(item.getPlot());
                    setSecurity(item.getSecurity());
                    setDue(item.getDue());
                }};
                node = new TreeItem<>(newItem){{ setExpanded(true);}};
                getRoot().getChildren().add(node);
            }
            node.getChildren().add(new TreeItem<>(item));
            hasIt = false;
        }
    }

    private class Cell extends TreeCell<LastDue>{
        private final GridPane root;
        private final Text name, security, due;
        private final SVGRegion disclosureIcon;
        private final Border topBorder, doubleBorder;

        public Cell() {
            setPrefWidth(0);
            setBackground(null);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setPadding(new Insets(2.5, 0, 2.5, 0));

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0)));
            doubleBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0.25, 0)));


            name = new Text(){{ setFill(Color.WHITE);}};
            security = new Text(){{ setFill(Color.WHITE);}};
            due = new Text(){{ setFill(Color.WHITE);}};
            root = new GridPane(){{
               getColumnConstraints().addAll(
                       new ColumnConstraints(){{ setHgrow(Priority.SOMETIMES);}},
                       new ColumnConstraints(65){{ setHalignment(HPos.RIGHT);}},
                       new ColumnConstraints(65){{ setHalignment(HPos.RIGHT);}}
               );
               add(name, 0, 0);
               add(security, 1, 0);
               add(due, 2, 0);
            }};
            name.wrappingWidthProperty().bind(root.widthProperty().subtract(65 * 2));
            itemProperty().addListener(this::onItemChanged);
        }

        private void onItemChanged(Observable o, LastDue ov, LastDue nv){
            if(ov != null){
                name.setText(null);
                security.setText(null);
                due.setText(null);
                root.setBorder(null);

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if(nv != null){
                var item = getTreeItem();
                var level = getTreeItemLevel(item);
                var size = item.getParent().getChildren().size();

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                name.setText(level == 1 ? nv.getPlot() : nv.getSpace());
                security.setText(AppData.formatNumber(nv.getSecurity()));
                due.setText(AppData.formatNumber(nv.getDue()));

                if(level == 2){
                    if(size == 1) root.setBorder(doubleBorder);
                    else {
                        var index = item.getParent().getChildren().indexOf(item);
                        if(index == 0) root.setBorder(topBorder);
                        else if(index == item.getParent().getChildren().size() -1) root.setBorder(Constants.BottomLine);
                    }
                }
            }
        }

        @Override
        protected void updateItem(LastDue item, boolean empty) {
            super.updateItem(item, empty);
            if(empty){
                setBackground(null);
                setGraphic(null);
            }
            else {
                setGraphic(root);
                setBackground(isSelected()? Background.fill(Constants.BackgroundColorLight) : null);
            }
        }
    }
}
