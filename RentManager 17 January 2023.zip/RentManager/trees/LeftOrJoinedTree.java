package trees;

import Models.LeftOrJoined;
import controls.SVGRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

import java.util.function.Function;

public class LeftOrJoinedTree extends ExtendedTreeView<LeftOrJoined> {
    public ListProperty<LeftOrJoined> itemsProperty;
    public BooleanProperty isExpandedProperty;

    public LeftOrJoinedTree() {
        setRoot(new TreeItem<>());
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new LeftOrJoinedCell());
        itemsProperty = new SimpleListProperty<>();
        isExpandedProperty = new SimpleBooleanProperty();
        itemsProperty.addListener(this::onItemsChanged);

        isExpandedProperty.addListener(o -> {
            var value = isExpandedProperty.get();
            for (var item : getRoot().getChildren()) {
                resetExpandState(item, value);
            }
        });
    }

    private void resetExpandState(TreeItem<LeftOrJoined> node, boolean value) {
        node.setExpanded(value);
        for (var item : node.getChildren()) {
            if (item.isLeaf()) continue;
            resetExpandState(item, value);
        }
    }

    private void onItemsChanged(ObservableValue<?> o, ObservableList<LeftOrJoined> ov, ObservableList<LeftOrJoined> nv) {
        getRoot().getChildren().clear();
        for (var item : nv) addItem(getRoot(), item);
        removeSingleLeaf();
    }

    private void addItem(TreeItem<LeftOrJoined> node, LeftOrJoined entry) {
        var level = getTreeItemLevel(node);
        var hasIt = false;
        TreeItem<LeftOrJoined> item = null;
        Function<LeftOrJoined, Boolean> condition = x -> true;
        switch (level) {
            case 0 -> condition = e -> e.getStatus().equals(entry.getStatus());
            case 1 -> condition = e -> e.getPlot().equals(entry.getPlot());
            case 2 -> condition = e -> e.getTenant().equals(entry.getTenant());
        }
        for (var branch : node.getChildren()) {
            if (!condition.apply(branch.getValue())) continue;
            var value = branch.getValue();
            value.setReceivable(value.getReceivable() + entry.getReceivable());
            hasIt = true;
            item = branch;
            break;
        }
        if (!hasIt) {
            var newEntry = new LeftOrJoined() {{
                setStatus(entry.getStatus());
                setPlot(entry.getPlot());
                setTenant(entry.getTenant());
                setReceivable(entry.getReceivable());
            }};
            item = new TreeItem<>(newEntry);
            node.getChildren().add(item);
        }
        if (level == 2) item.getChildren().add(new TreeItem<>(entry));
        else addItem(item, entry);
    }

    private void removeSingleLeaf() {
        for (var leftOrJoined : getRoot().getChildren()) {
            for (var plot : leftOrJoined.getChildren()) {
                for (var tenant : plot.getChildren()) {
                    if (tenant.getChildren().size() > 1) continue;
                    var item = tenant.getChildren().get(0).getValue();
                    tenant.getChildren().clear();
                    tenant.getValue().setSpace(item.getSpace());
                    tenant.getValue().setDateStart(item.getDateStart());
                    tenant.getValue().setDateEnd(item.getDateEnd());
                }
            }
        }
    }

    private class LeftOrJoinedCell extends TreeCell<LeftOrJoined> {
        private SVGRegion disclosureIcon;
        private GridPane root;
        private Font normal, bold;
        private Border topBorder, doubleBorder;
        private Text particulars, from, to, amount;
        private TextFlow particularsFlow;

        public LeftOrJoinedCell() {
            setBackground(null);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setPadding(new Insets(2.5, 0, 2.5, 0));
            setPrefWidth(0);

            initializeUI();
            itemProperty().addListener(this::onItemChanged);

//            prefHeightProperty().bind(particularsFlow.heightProperty().add(5));
//            minHeightProperty().bind(particularsFlow.heightProperty().add(5));
//            maxHeightProperty().bind(particularsFlow.heightProperty().add(5));
        }

        private void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0)));
            doubleBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0.25, 0)));

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            particulars = new Text() {{setFill(Color.WHITE);}};
            from = new Text() {{setFill(Color.WHITE);}};
            to = new Text() {{setFill(Color.WHITE);}};
            amount = new Text() {{setFill(Color.WHITE);}};
            particularsFlow = new TextFlow(particulars);

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.SOMETIMES);}},
                        new ColumnConstraints(90) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(90) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}}
                );
                add(particularsFlow, 0, 0);
                add(from, 1, 0);
                add(to, 2, 0);
                add(amount, 3, 0);
            }};
        }

        private void onItemChanged(ObservableValue<?> o, LeftOrJoined ov, LeftOrJoined nv) {
            if (ov != null) {
                root.setBorder(null);
                particulars.setText(null);
                from.setText(null);
                to.setText(null);
                amount.setText(null);
                particulars.setFont(normal);
                amount.setFont(normal);

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                if (level == 1) {
                    int size = 0;
                    for (var c : item.getChildren()) {
                        size += c.getChildren().size();
                    }
                    particulars.setFont(bold);
                    amount.setFont(bold);
                    particulars.setText(nv.getStatus() + " (" + item.getChildren().size() + " - " + size + ")");
                }
                else if (level == 2) {
                    particulars.setFont(bold);
                    amount.setFont(bold);
                    particulars.setText(nv.getPlot() + " (" + item.getChildren().size() + ")");
                }
                else if (level == 3) {
                    int size = item.getParent().getChildren().size();
                    int index = item.getParent().getChildren().indexOf(item);

                    if(size == 1) root.setBorder(doubleBorder);
                    else{
                        if(index == 0) root.setBorder(topBorder);
                        if(index == size - 1) root.setBorder(Constants.BottomLine);
                    }
                    if (item.getChildren().size() > 0) {
                        particulars.setText(nv.getTenant());
                    }
                    else {
                        particulars.setText(nv.getSpace() + " - " + nv.getTenant());
                        from.setText(nv.getDateStart());
                        to.setText(nv.getDateEnd());
                    }
                }
                else {
                    int size = item.getParent().getChildren().size();
                    int index = item.getParent().getChildren().indexOf(item);

                    if(index == 0) root.setBorder(topBorder);
                    if(index == size - 1) root.setBorder(Constants.BottomLine);

                    particulars.setText(nv.getSpace());
                    from.setText(nv.getDateStart());
                    to.setText(nv.getDateEnd());
                }
                amount.setText(AppData.formatNumber(nv.getReceivable()));
            }
        }

        @Override
        protected void updateItem(LeftOrJoined item, boolean empty) {
            super.updateItem(item, empty);
            if (isEmpty()) {
                setBackground(null);
                setGraphic(null);
            }
            else {
                setGraphic(root);
                setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
            }

        }
    }
}
