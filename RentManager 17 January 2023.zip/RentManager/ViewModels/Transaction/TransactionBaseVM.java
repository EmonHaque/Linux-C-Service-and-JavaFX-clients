package ViewModels.Transaction;

import Enums.Function;
import Models.*;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import ridiculous.AppData;
import ridiculous.Jar;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public abstract class TransactionBaseVM<P, S> {
    public FilteredList<Tenant> tenants;
    public FilteredList<P> plots;
    public FilteredList<S> spaces;
    public FilteredList<ControlHead> controls;
    public FilteredList<Head> heads;
    public ObservableList<Entry> entries;
    public ObservableList<LastDue> dues;
    public ObservableList<LastPayment> payments;

    public StringProperty statusProperty, paymentDateProperty;
    public BooleanProperty isRunningProperty;

    public BooleanProperty dialogTrigger;
    public boolean dialogResult;
    public String dialogMessage;

    public Entry entry;

    private InformationTask task;

    public TransactionBaseVM() {
        entry = new Entry();

        tenants = new FilteredList<>(AppData.tenants);
        controls = new FilteredList<>(AppData.controlHeads);

        var headSource = new Jar<>(AppData.heads, o -> new Observable[]{
                o.controlIdProperty(),
                entry.controlIdProperty()
        });
        heads = new FilteredList<>(headSource, x -> x.getControlId() == entry.getControlId());
        entries = FXCollections.observableArrayList();
        dues = FXCollections.observableArrayList();
        payments = FXCollections.observableArrayList();

        statusProperty = new SimpleStringProperty("");
        paymentDateProperty = new SimpleStringProperty("");
        isRunningProperty = new SimpleBooleanProperty();
        dialogTrigger = new SimpleBooleanProperty();

        entry.tenantIdProperty().addListener(this::onTenantChanged);
    }

    public void addEntry(){
        entries.add(new Entry(){{
            setTenantId(entry.getTenantId());
            setPlotId(entry.getPlotId());
            setSpaceId(entry.getSpaceId());
            setControlId(entry.getControlId());
            setHeadId(entry.getHeadId());
            setDate(entry.getDate());
            setIsCash(entry.getIsCash());
            setAmount(entry.getAmount());
            setNarration(entry.getNarration());
        }});
        entry.setAmount(0);
    }

    public void removeEntry(Entry e){
        entries.remove(e);
    }

    public void add(){
        dialogMessage = entries.size()  + " entries will be recorded \n\n Are you Sure? ";
        dialogTrigger.set(true);
        if(!dialogResult) return;

        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    protected abstract int function();

    private void onTenantChanged(Observable o, Number ov, Number nv){
        if(nv.intValue() <= 0) return;
        if(task != null && task.isRunning()){
            task.setOnCancelled(e ->{
                task.setOnCancelled(null);
                updateInformation();
            });
            task.cancel();
        }
        else updateInformation();
    }

    private void updateInformation(){
        task = new InformationTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private class InformationTask extends Task<Void>{
        private int length;
        private String date;
        private List<LastDue> dueList;
        private List<LastPayment> paymentList;

        @Override
        protected Void call()  {
            try {
                updateMessage("requesting data ...");
                Thread.sleep(500);
                if(isCancelled()) return null;

                var buffer = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(entry.getTenantId());
                var request = new Request(Function.GetLastDueAndPayment.ordinal(), buffer);
                var response = Channels.getInstance().getResponse(request).get();
                if (!response.isSuccess()) {
                    updateMessage("service down ...");
                    Thread.sleep(500);
                    return null;
                }
                if(isCancelled()) return null;
                length = response.getPacket().length;
                buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
                updateMessage("received " + String.format("%,d", length) + " bytes");
                Thread.sleep(500);

                updateMessage("processing " + String.format("%,d", length) + " bytes");
                Thread.sleep(500);
                if(isCancelled()) return null;
                makeList(buffer);
            }
            catch (Exception e){}
            return null;
        }

        private void makeList(ByteBuffer buffer){
            dueList = new ArrayList<>();
            paymentList = new ArrayList<>();

            int read = 0;
            int start = 0;
            while (read < length){
                if(isCancelled()) break;

                while (buffer.get(read) != 0) read++;
                var date = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                start = ++read;

                int plotId = buffer.getInt(start);
                int spaceId = buffer.getInt(start + 4);
                var plot = AppData.plots.stream().filter(x -> x.getId() == plotId).findFirst().get().getName();
                var space = AppData.spaces.stream().filter(x -> x.getId() == spaceId).findFirst().get().getName();

                if(date.isEmpty()){
                    var entry = new LastDue();
                    entry.setPlot(plot);
                    entry.setSpace(space);
                    entry.setSecurity(buffer.getInt(start + 8));
                    entry.setDue(buffer.getInt(start + 12));
                    dueList.add(entry);
                }
                else {
                    var entry = new LastPayment();
                    entry.setPlot(plot);
                    entry.setSpace(space);
                    entry.setAmount(buffer.getInt(start + 8));
                    entry.setIsCash(buffer.getInt(start + 12));
                    paymentList.add(entry);
                    if(this.date == null) {
                        this.date = LocalDate.parse(date).format(DateTimeFormatter.ofPattern("dd MMMM, yyyy"));
                    }
                }
                read += 16;
                start = read;
            }
        }

        @Override
        protected void succeeded() {
            dues.clear();
            payments.clear();
            dues.addAll(dueList);
            payments.addAll(paymentList);
            paymentDateProperty.set(date);
            updateMessage("processed " + String.format("%,d", length) + " bytes");
        }
    }

    private class ResponseTask extends Task<Boolean>{
        @Override
        protected Boolean call() throws Exception {
            updateMessage("processing entries ...");
            Thread.sleep(500);

            var bytes = getBytes();
            var request = new Request(function(), bytes);

            updateMessage("requesting ...");
            Thread.sleep(500);
            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return false;
            }
            var isSuccess = response.getPacket()[0] != 0;
            updateMessage(isSuccess ? "successfully added " + entries.size() + " entries" : "failed to add entries");
            Thread.sleep(500);
            return isSuccess;
        }

        @Override
        protected void succeeded() {
            try {
                if(get()) entries.clear();
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        private ByteBuffer getBytes(){
            int size = 0;
            var arrays = new ArrayList<ByteBuffer>();
            for (var e : entries) {
                var dateBytes = (e.getDate().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
                var narrationBytes = (e.getNarration() + '\0').getBytes(StandardCharsets.US_ASCII);
                var total = 29 + dateBytes.length + narrationBytes.length;
                size += total;
                arrays.add(ByteBuffer.allocate(total)
                        .order(ByteOrder.LITTLE_ENDIAN)
                        .putInt(0)
                        .putInt(e.getPlotId())
                        .putInt(e.getSpaceId())
                        .putInt(e.getTenantId())
                        .putInt(e.getControlId())
                        .putInt(e.getHeadId())
                        .putInt(e.getAmount())
                        .put((byte) e.getIsCash())
                        .put(dateBytes)
                        .put(narrationBytes));
            }
            var bytes = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
            for (var array : arrays) bytes.put(array.array());
            return bytes;
        }
    }
}
