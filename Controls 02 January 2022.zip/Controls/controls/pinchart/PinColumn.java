package controls.pinchart;

import controls.columnstackchart.Column;
import javafx.animation.*;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Scale;
import javafx.stage.Popup;
import javafx.util.Duration;

public class PinColumn extends StackPane {
    private boolean isLoaded, isPinned;
    private double width, height, columnHeight, midPoint, y1Min, y1Max, y2Min, y2Max, ballY, radius = 3;
    private Column column;
    private PinSegment pin;
    private Circle ball;

    private Timeline anim;
    private TranslateTransition ballAnim;
    private final DoubleProperty pinHeight;

    private Popup popup;

    private final double pinValue, columnValue;

    public PinColumn(double pinValue, double columnValue) {
        this.pinValue = pinValue;
        this.columnValue = columnValue;

        getTransforms().add(new Scale(1, -1));

        column = new Column(Color.GREEN, Color.CORAL, true, columnValue < 0) {{
            setManaged(false);
            setMouseTransparent(true);
        }};
        pin = new PinSegment(Color.CORAL, Color.WHITE) {{
            setManaged(false);
            setMouseTransparent(true);
        }};
        ball = new Circle() {{
            setFill(Color.CORNFLOWERBLUE);
            setRadius(radius);
            setManaged(false);
            setMouseTransparent(true);
        }};
        getChildren().addAll(column, pin, ball);

        pinHeight = new SimpleDoubleProperty(0);
        var clip = new Rectangle();
        layoutBoundsProperty().addListener((observable, oldValue, newValue) -> {
            clip.setWidth(newValue.getWidth());
            clip.setHeight(newValue.getHeight());
        });
        setClip(clip);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseClicked(this::onClicked);
        setOnMouseExited(this::onMouseExited);
    }

    public double getColumnValue() {return columnValue;}

    public double getPinValue() {return pinValue;}

    public void makePin(double width, double height, double y1Min, double y2Min, double y1Max, double y2Max) {
        this.width = width;
        this.height = height;
        this.y1Min = y1Min;
        this.y2Min = y2Min;
        this.y1Max = y1Max;
        this.y2Max = y2Max;

        midPoint = width / 2;
        if (!isLoaded) {
            isLoaded = true;

            pinHeight.addListener((o, ov, nv) -> {
                setHeight(nv.doubleValue());
            });

            var key = new KeyValue(pinHeight, height, Interpolator.EASE_IN);
            var frame = new KeyFrame(Duration.millis(500), key);
            anim = new Timeline(frame);
            anim.setDelay(Duration.millis(500));
            anim.play();

            ball.setOpacity(0);
            anim.setOnFinished(e -> {
                setClip(null);
                ball.setOpacity(1);
                ball.setTranslateY(height - ballY);
                ballAnim.play();
                anim.setOnFinished(null);
            });

            ballAnim = new TranslateTransition(Duration.millis(500), ball);
            ballAnim.setToY(0);
        }
    }

    @Override
    protected void layoutChildren() {
        if (pinHeight.get() == 0)
            return;

        double negativeHeight = 0;
        if (y1Min < 0) {
            var absMin = Math.abs(y1Min);
            var spread = y1Max - y1Min;
            negativeHeight = height / spread * absMin;
        }

        double y1Factor = height / (y1Max - y1Min);
        double y2Factor = height / y2Max;
        var pinHeight = y2Factor * pinValue;
        columnHeight = y1Factor * columnValue;

        ball.setCenterX(midPoint);
        ball.setCenterY(pinHeight);
        ballY = pinHeight;

        pin.setValue(midPoint, 0, pinHeight - radius / 2);
        column.setValue(0, negativeHeight, width, columnHeight);
    }

    private void onMouseEntered(MouseEvent e) {
        if (isPinned) return;
        column.highlightColor();
        pin.highlightColor();

        if (popup == null) return;
        var point = localToScreen(0, columnHeight);
        popup.show(this, point.getX() + 20, point.getY());
    }

    private void onClicked(MouseEvent e) {isPinned = !isPinned;}

    private void onMouseExited(MouseEvent e) {
        if (isPinned) return;
        column.normalColor();
        pin.normalColor();

        if (popup == null) return;
        popup.hide();
    }

    public void setToolTip(Popup popup) {
        this.popup = popup;
    }
}
