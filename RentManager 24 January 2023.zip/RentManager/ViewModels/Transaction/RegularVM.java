package ViewModels.Transaction;

import Enums.Function;
import Models.PlotTransaction;
import Models.SpaceTransaction;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;

import java.nio.ByteBuffer;

public class RegularVM extends TransactionBaseVM<PlotTransaction, SpaceTransaction> {
    private ObservableList<PlotTransaction> plotSource;
    private ObservableList<SpaceTransaction> spaceSource;

    public RegularVM() {
        super();
        plotSource = FXCollections.observableArrayList();
        spaceSource = FXCollections.observableArrayList(o -> new Observable[]{ entry.plotIdProperty() });
        plots = new FilteredList<>(plotSource);
        spaces = new FilteredList<>(spaceSource, x -> x.getPlotId() == entry.getPlotId());

        entry.tenantIdProperty().addListener(this::onTenantChanged);
    }

    @Override
    protected int function() {
        return Function.AddTransactionsRegular.ordinal();
    }

    private void onTenantChanged(Observable o) {
        if(entry.getTenantId() == -1) return;
        plotSource.clear();
        spaceSource.clear();
        for (int i = 0; i < AppData.leases.size(); i++) {
            if (AppData.leases.get(i).getTenantId() == entry.getTenantId()) {
                var lease = AppData.leases.get(i);
                var containedInPlots = false;
                for (int j = 0; j < plotSource.size(); j++) {
                    if (plotSource.get(j).getId() == lease.getPlotId()) {
                        containedInPlots = true;
                        break;
                    }
                }
                if(!containedInPlots){
                    plotSource.add(new PlotTransaction(lease.getPlotId(), lease.getPlotName()));
                }
                spaceSource.add(new SpaceTransaction(lease.getId(), lease.getPlotId(), lease.getSpaceId(), lease.getSpaceName(), lease.getDateStart().toString(), lease.isIsExpired()));
            }
        }
    }
}
