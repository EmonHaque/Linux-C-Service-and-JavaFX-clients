package ViewModels.Add;

import Enums.Function;
import Models.*;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;
import ridiculous.Jar;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AddLeaseVM extends AddBaseVM {
    private Jar<Head> headSource;
    private List<Head> removedHead;

    public FilteredList<Plot> plots;
    public FilteredList<Space> spaces;
    public FilteredList<Tenant> tenants;
    public FilteredList<Head> heads;
    public ObservableList<Receivable> receivables;

    public StringProperty headQuery;
    public Receivable receivable;
    public Lease lease;

    public AddLeaseVM() {
        lease = new Lease();
        receivable = new Receivable();
        headQuery = new SimpleStringProperty();
        initializeCollections();
    }

    private void initializeCollections() {
        removedHead = new ArrayList<>();
        var spaceSource = new Jar<>(AppData.spaces, o -> new Observable[]{lease.plotIdProperty(), o.isVacantProperty()});
        var tenantSource = new Jar<>(AppData.tenants, o -> new Observable[]{o.hasLeftProperty()});

        headSource = new Jar<>(AppData.heads, x -> new Observable[]{ x.controlIdProperty() });
        plots = new FilteredList<>(AppData.plots, x -> true);
        spaces = new FilteredList<>(spaceSource, s -> s.getPlotId() == lease.getPlotId() && s.getIsVacant());
        tenants = new FilteredList<>(tenantSource, t -> !t.isHasLeft());
        heads = new FilteredList<>(headSource.sorted(Comparator.comparingInt(Head::getId)), c -> c.getControlId() == AppData.controlIdOfReceivable);
        receivables = FXCollections.observableArrayList();
    }

    @Override
    protected int function() {
        return Function.AddLease.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var startDateBytes = (lease.getDateStart().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
        var endDateBytes = ("\0").getBytes(StandardCharsets.US_ASCII);
        var businessBytes = (lease.getBusiness() + '\0').getBytes(StandardCharsets.US_ASCII);
        var buffer = ByteBuffer.allocate(17 + startDateBytes.length + endDateBytes.length
                        + businessBytes.length + receivables.size() * 12)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(lease.getId())
                .putInt(lease.getPlotId())
                .putInt(lease.getSpaceId())
                .putInt(lease.getTenantId())
                .put(startDateBytes)
                .put(endDateBytes)
                .put(businessBytes)
                .put((byte) 0);

        for (var rec : receivables)
            buffer.putInt(rec.getLeaseId())
                    .putInt(rec.getHeadId())
                    .putInt(rec.getAmount());

        return buffer;
    }

    @Override
    protected void resetObject() {
        lease.setBusiness("");
        receivables.clear();
        headSource.addAll(removedHead);
        removedHead.clear();
    }

    public void addReceivable() {
        var newRec = new Receivable(receivable.getLeaseId(), receivable.getHeadId(), receivable.getAmount());
        receivables.add(newRec);

        var head = AppData.heads.stream().filter(x -> x.getId() == receivable.getHeadId()).findFirst().get();
        headSource.remove(head);
        removedHead.add(head);

        receivable.setAmount(0);
    }

    public void removeReceivable(Receivable receivable) {
        receivables.remove(receivable);
        var head = removedHead.stream().filter(x -> x.getId() == receivable.getHeadId()).findFirst().get();
        headSource.add(head);
        removedHead.remove(head);
    }
}
