package ViewModels;

import Models.Notification;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import ridiculous.AppData;

public class NotificationVM {
    public ObservableList<Notification> list;
    public IntegerProperty countProperty;

    public NotificationVM() {
        countProperty = new SimpleIntegerProperty();
        list = FXCollections.synchronizedObservableList(AppData.notifications);
        list.addListener(this::onListChanged);
    }

    private void onListChanged(ListChangeListener.Change<? extends Notification> change) {
        while (change.next()){
            if(change.wasAdded()){
                countProperty.set(countProperty.get() + change.getAddedSize());
            }
        }
    }
}
