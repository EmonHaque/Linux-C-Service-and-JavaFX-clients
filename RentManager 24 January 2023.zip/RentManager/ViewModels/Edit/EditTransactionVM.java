package ViewModels.Edit;

import Enums.Function;
import Models.*;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import ridiculous.AppData;
import ridiculous.Jar;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class EditTransactionVM extends EditBaseVM<TransactionEditable> {
    public ObjectProperty<LocalDate> dateProperty;
    public BooleanProperty isOnEditProperty;

    public FilteredList<Tenant> tenants;
    public FilteredList<PlotTransaction> plots;
    public FilteredList<SpaceTransaction> spaces;
    public FilteredList<ControlHead> controls;
    public FilteredList<Head> heads;

    private final ObservableList<PlotTransaction> plotSource;
    private final ObservableList<SpaceTransaction> spaceSource;
    private final ObservableList<TransactionEditable> list;
    private final IntegerProperty selectedPlot, selectedTenant, selectedControl;
    public final BooleanProperty selectionTriggerProperty;

    public final BooleanProperty dialogTrigger;
    public boolean dialogResult;
    public String dialogMessage;

    public EditTransactionVM() {
        selected = new TransactionEditable();
        edited = new TransactionEditable();

        dateProperty = new SimpleObjectProperty<>();
        selectedTenant = new SimpleIntegerProperty();
        selectedPlot = new SimpleIntegerProperty();
        selectedControl = new SimpleIntegerProperty();
        selectionTriggerProperty = new SimpleBooleanProperty();
        isOnEditProperty = new SimpleBooleanProperty();
        dialogTrigger = new SimpleBooleanProperty();

        plotSource = FXCollections.observableArrayList();
        spaceSource = FXCollections.observableArrayList(o -> new Observable[]{selectedPlot});
        plots = new FilteredList<>(plotSource);
        spaces = new FilteredList<>(spaceSource, x -> x.getPlotId() == selectedPlot.get());

        var headSource = new Jar<>(AppData.heads, o -> new Observable[]{
                selectedControl
        });
        tenants = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.tenants));
        controls = new FilteredList<>(AppData.controlHeads);
        heads = new FilteredList<>(headSource, x -> x.getControlId() == selectedControl.get());

        list = FXCollections.observableArrayList(o -> new Observable[]{
                queryProperty,
                o.dateProperty()
        });
        editableList = new FilteredList<>(list, this::filter);

        dateProperty.addListener(this::onDateChanged);

        selectionTriggerProperty.addListener(this::onSelectionChanged);
        selectedTenant.addListener(this::onTenantChanged);
        isOnEditProperty.addListener(this::onIsOnEditChanged);

        AppData.onEditTransaction.addListener(this::onTransactionEdited);
        AppData.onDeleteTransaction.addListener(this::onTransactionDeleted);
    }

    private void onTransactionEdited(ObservableValue<?> o, Transaction ov, Transaction nv) {
        var match = list.stream().filter(x -> x.getId() == nv.getId()).findFirst();
        if (match.isEmpty()) return;
        var transaction = match.get();

        transaction.setDate(nv.getDate());
        transaction.setPlotId(nv.getPlotId());
        transaction.setSpaceId(nv.getSpaceId());
        transaction.setTenantId(nv.getTenantId());
        transaction.setControlId(nv.getControlId());
        transaction.setHeadId(nv.getHeadId());
        transaction.setIsCash(nv.getIsCash());
        transaction.setAmount(nv.getAmount());
        transaction.setNarration(nv.getNarration());

        transaction.setPlotName(AppData.plots.stream().filter(x -> x.getId() == nv.getPlotId()).findFirst().get().getName());
        transaction.setSpaceName(AppData.spaces.stream().filter(x -> x.getId() == nv.getSpaceId()).findFirst().get().getName());
        transaction.setTenantName(AppData.tenants.stream().filter(x -> x.getId() == nv.getTenantId()).findFirst().get().getName());
        transaction.setControlName(AppData.controlHeads.stream().filter(x -> x.getId() == nv.getControlId()).findFirst().get().getName());
    }

    private void onTransactionDeleted(ObservableValue<?> o, Transaction ov, Transaction nv){
        TransactionEditable deleted = null;
        for(var transaction : list){
            if(transaction.getId() == nv.getId()){
                deleted = transaction;
                break;
            }
        }
        list.remove(deleted);
    }

    private void onSelectionChanged(Observable o) {
        selectedTenant.set(selected.getTenantId());
        selectedPlot.set(selected.getPlotId());
        selectedControl.set(selected.getControlId());
    }

    private boolean filter(TransactionEditable tr) {
        var isMatch = tr.getDate().isEqual(dateProperty.get());
        if (isQueryEmpty) return isMatch;
        return isMatch &&
                (tr.getSpaceName().toLowerCase().contains(trimmedQuery)
                        || tr.getTenantName().toLowerCase().contains(trimmedQuery)
                        || tr.getControlName().toLowerCase().contains(trimmedQuery));
    }

    @Override
    protected int function() {
        return Function.EditTransaction.ordinal();
    }

    @Override
    protected ByteBuffer buffer() { return getBytes(edited); }

    private ByteBuffer getBytes(TransactionEditable transaction){
        var dateBytes = (transaction.getDate().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
        var narrationBytes = (transaction.getNarration() + '\0').getBytes(StandardCharsets.US_ASCII);

        return ByteBuffer.allocate(29 + dateBytes.length + narrationBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(transaction.getId())
                .putInt(transaction.getPlotId())
                .putInt(transaction.getSpaceId())
                .putInt(transaction.getTenantId())
                .putInt(transaction.getControlId())
                .putInt(transaction.getHeadId())
                .putInt(transaction.getAmount())
                .put((byte) transaction.getIsCash())
                .put(dateBytes)
                .put(narrationBytes);
    }

    @Override
    public void cloneSelected() {
        edited = new TransactionEditable() {{
            setId(selected.getId());
            setPlotId(selected.getPlotId());
            setSpaceId(selected.getSpaceId());
            setTenantId(selected.getTenantId());
            setControlId(selected.getControlId());
            setHeadId(selected.getHeadId());
            setDate(selected.getDate());
            setAmount(selected.getAmount());
            setIsCash(selected.getIsCash());
            setNarration(selected.getNarration());
        }};
        edited.plotIdProperty().addListener(this::onPlotIdChanged);
        edited.controlIdProperty().addListener(this::onControlIdChanged);
        edited.tenantIdProperty().addListener(this::onTenantIdChanged);
    }

    private void onIsOnEditChanged(ObservableValue<?> o, boolean ov, boolean nv) {
        if (nv) return;
        edited.plotIdProperty().removeListener(this::onPlotIdChanged);
        edited.controlIdProperty().removeListener(this::onControlIdChanged);
        edited.tenantIdProperty().removeListener(this::onTenantIdChanged);
    }

    private void onTenantIdChanged(ObservableValue<?> o, Number ov, Number nv) {
        selectedTenant.set(edited.getTenantId());
        selectedPlot.set(edited.getPlotId());
        selectedControl.set(edited.getControlId());
    }

    private void onPlotIdChanged(ObservableValue<?> o, Number ov, Number nv) {
        selectedPlot.set(nv.intValue());
    }

    private void onControlIdChanged(ObservableValue<?> o, Number ov, Number nv) {
        selectedControl.set(nv.intValue());
    }

    private void onTenantChanged(ObservableValue<?> o, Number ov, Number nv) {
        if (nv.intValue() == -1) return;
        plotSource.clear();
        spaceSource.clear();
        for (int i = 0; i < AppData.leases.size(); i++) {
            if (AppData.leases.get(i).getTenantId() == nv.intValue()) {
                var lease = AppData.leases.get(i);
                var containedInPlots = false;
                for (var plot : plotSource) {
                    if (plot.getId() == lease.getPlotId()) {
                        containedInPlots = true;
                        break;
                    }
                }
                if (!containedInPlots) {
                    plotSource.add(new PlotTransaction(lease.getPlotId(), lease.getPlotName()));
                }
                spaceSource.add(new SpaceTransaction(lease.getId(), lease.getPlotId(), lease.getSpaceId(), lease.getSpaceName(), lease.getDateStart().toString(), lease.isIsExpired()));
            }
        }
    }

    private void onDateChanged(Observable o) {
        if (dateProperty.get() == null) return;

        var task = new FetchTransactionTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    public void refresh() {onDateChanged(null);}

    public void delete(){
        dialogMessage = "Entry will be deleted \n\n Are you Sure?";
        dialogTrigger.set(true);
        if(!dialogResult) return;

        var task = new DeleteTransactionTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private class DeleteTransactionTask extends Task<Void>{

        @Override
        protected Void call() throws Exception {
            updateMessage("requesting ...");
            Thread.sleep(500);

            var request = new Request(Function.DeleteTransaction.ordinal(), getBytes(selected));
            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return null;
            }
            var isOk = response.getPacket()[0] != 0;
            updateMessage(isOk ? "successfully deleted" : new String(response.getPacket(), 1, response.getPacket().length - 1));
            Thread.sleep(500);
            return null;
        }
    }

    private class FetchTransactionTask extends Task<List<TransactionEditable>> {

        @Override
        protected List<TransactionEditable> call() throws Exception {
            updateMessage("requesting data ...");
            Thread.sleep(500);

            var bytes = (dateProperty.get().toString() + '\0').getBytes();
            var request = new Request(Function.GetTransactions.ordinal(), ByteBuffer.wrap(bytes));

            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                return null;
            }
            int length = response.getPacket().length;
            if (length == 0) {
                updateMessage("no data available");
                Thread.sleep(500);
                return null;
            }
            updateMessage("received " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);

            var buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
            var list = getList(buffer, length);

            updateMessage("processed " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);
            return list;

        }

        private List<TransactionEditable> getList(ByteBuffer span, int length) {
            var list = new ArrayList<TransactionEditable>();
            int read = 0;
            int start = 0;
            var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            while (read < length) {
                var transaction = new TransactionEditable();
                transaction.setId(span.getInt(start));
                transaction.setPlotId(span.getInt(start + 4));
                transaction.setSpaceId(span.getInt(start + 8));
                transaction.setTenantId(span.getInt(start + 12));
                transaction.setControlId(span.getInt(start + 16));
                transaction.setHeadId(span.getInt(start + 20));
                transaction.setAmount(span.getInt(start + 24));
                transaction.setIsCash(span.get(start + 28));

                transaction.setPlotName(AppData.plots.stream().filter(x -> x.getId() == transaction.getPlotId()).findFirst().get().getName());
                transaction.setSpaceName(AppData.spaces.stream().filter(x -> x.getId() == transaction.getSpaceId()).findFirst().get().getName());
                transaction.setTenantName(AppData.tenants.stream().filter(x -> x.getId() == transaction.getTenantId()).findFirst().get().getName());
                transaction.setControlName(AppData.controlHeads.stream().filter(x -> x.getId() == transaction.getControlId()).findFirst().get().getName());

                read += 29;
                start += 29;
                while (span.get(read) != 0) read++;
                var date = new String(span.array(), start, read - start, StandardCharsets.US_ASCII);
                transaction.setDate(LocalDate.parse(date, formatter));

                start = ++read;
                while (span.get(read) != 0) read++;
                transaction.setNarration(new String(span.array(), start, read - start, StandardCharsets.US_ASCII));

                list.add(transaction);
                start = ++read;
            }
            return list;
        }

        @Override
        protected void succeeded() {
            list.clear();
            try {
                var result = get();
                if (result == null) return;
                list.addAll(result);
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
