package Models;

import javafx.beans.property.*;
import javafx.collections.ObservableList;

import java.time.LocalDate;

public class Lease {
    private final IntegerProperty id, plotId, spaceId, tenantId;
    private final StringProperty plotName, spaceName, tenantName;
    private final ObjectProperty<LocalDate> dateStart, dateEnd;
    private final StringProperty business;
    private final BooleanProperty isExpired;
    private final ObjectProperty<ObservableList<Receivable>> fixedReceivables;

    public Lease() {
        id = new SimpleIntegerProperty();
        plotId = new SimpleIntegerProperty();
        spaceId = new SimpleIntegerProperty();
        tenantId = new SimpleIntegerProperty();
        plotName = new SimpleStringProperty();
        spaceName = new SimpleStringProperty();
        tenantName = new SimpleStringProperty();
        dateStart = new SimpleObjectProperty<>();
        dateEnd = new SimpleObjectProperty<>();
        business = new SimpleStringProperty("");
        isExpired = new SimpleBooleanProperty();
        fixedReceivables = new SimpleObjectProperty<>();
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public int getPlotId() {
        return plotId.get();
    }

    public IntegerProperty plotIdProperty() {
        return plotId;
    }

    public void setPlotId(int plotId) {
        this.plotId.set(plotId);
    }

    public int getSpaceId() {
        return spaceId.get();
    }

    public IntegerProperty spaceIdProperty() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId.set(spaceId);
    }

    public int getTenantId() {
        return tenantId.get();
    }

    public IntegerProperty tenantIdProperty() {
        return tenantId;
    }

    public void setTenantId(int tenantId) {
        this.tenantId.set(tenantId);
    }

    public String getPlotName() {
        return plotName.get();
    }

    public StringProperty plotNameProperty() {
        return plotName;
    }

    public void setPlotName(String plotName) {
        this.plotName.set(plotName);
    }

    public String getSpaceName() {
        return spaceName.get();
    }

    public StringProperty spaceNameProperty() {
        return spaceName;
    }

    public void setSpaceName(String spaceName) {
        this.spaceName.set(spaceName);
    }

    public String getTenantName() {
        return tenantName.get();
    }

    public StringProperty tenantNameProperty() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName.set(tenantName);
    }

    public LocalDate getDateStart() {
        return dateStart.get();
    }

    public ObjectProperty<LocalDate> dateStartProperty() {
        return dateStart;
    }

    public void setDateStart(LocalDate dateStart) {
        this.dateStart.set(dateStart);
    }

    public LocalDate getDateEnd() { return dateEnd.get(); }

    public ObjectProperty<LocalDate> dateEndProperty() {
        return dateEnd;
    }

    public void setDateEnd(LocalDate dateEnd) {
        this.dateEnd.set(dateEnd);
    }

    public String getBusiness() {
        return business.get();
    }

    public StringProperty businessProperty() {
        return business;
    }

    public void setBusiness(String business) {
        this.business.set(business);
    }

    public boolean isIsExpired() {
        return isExpired.get();
    }

    public BooleanProperty isExpiredProperty() {
        return isExpired;
    }

    public void setIsExpired(boolean isExpired) {
        this.isExpired.set(isExpired);
    }

    public ObservableList<Receivable> getFixedReceivables() {
        return fixedReceivables.get();
    }

    public ObjectProperty<ObservableList<Receivable>> fixedReceivablesProperty() {
        return fixedReceivables;
    }

    public void setFixedReceivables(ObservableList<Receivable> fixedReceivables) {
        this.fixedReceivables.set(fixedReceivables);
    }
}
