package Views.Transaction;

import CellTemplates.SelectionBox.TransactionSpaceTemplate;
import CellTemplates.Visual.TransactionSpaceVisual;
import Models.PlotTransaction;
import Models.SpaceTransaction;
import ViewModels.Transaction.RegularVM;
import ViewModels.Transaction.TransactionBaseVM;
import helpers.Icons;
import interfaces.ISetSelectionBoxContent;

public class Regular extends TransactionBase<PlotTransaction, SpaceTransaction> {
    @Override
    protected String getHeader() {
        return "Regular";
    }

    @Override
    protected String getIcon() {
        return Icons.RegularTransaction;
    }

    @Override
    public TransactionBaseVM<PlotTransaction, SpaceTransaction> getViewModel() {
        return new RegularVM();
    }

    @Override
    protected ISetSelectionBoxContent<SpaceTransaction> getVisual() {
        return new TransactionSpaceVisual();
    }

    @Override
    protected String getTemplate() {
        return TransactionSpaceTemplate.class.getName();
    }
}
