package CellTemplates.Visual;

import Models.Space;
import interfaces.ISetSelectionBoxContent;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import ridiculous.AppData;

public class SpaceVisual extends BorderPane implements ISetSelectionBoxContent<Space> {
    private final Text plot, space;
    private Space item;

    public SpaceVisual() {
        plot = new Text(){{ setFill(Color.WHITE);}};
        space = new Text(){{ setFill(Color.WHITE);}};
        setCenter(space);
        setRight(plot);
        setAlignment(space, Pos.CENTER_LEFT);
        setAlignment(plot, Pos.CENTER_RIGHT);
    }

    @Override
    public void setContent(Space item) {
        space.textProperty().unbind();
        plot.textProperty().unbind();

        this.item = item;
        var selectedPlot = AppData.plots.stream().filter(x -> x.getId() == item.getPlotId()).findFirst().get();

        space.textProperty().bind(item.nameProperty());
        plot.textProperty().bind(selectedPlot.nameProperty());
    }

    @Override
    public Space getContent() {
        return item;
    }

    @Override
    public Node getVisual() {
        return this;
    }
}
