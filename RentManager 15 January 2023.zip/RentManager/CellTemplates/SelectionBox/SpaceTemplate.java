package CellTemplates.SelectionBox;

import Models.Space;
import abstracts.ListCellBase;
import controls.texts.HiText;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import ridiculous.AppData;

public class SpaceTemplate extends ListCellBase<Space> {
    private BorderPane root;
    private HiText space;
    private Text plot;
    private final StringProperty query;

    public SpaceTemplate(StringProperty query) {
        this.query = query;
        setPadding(new Insets(5));
    }

    @Override
    protected void initializeUI() {
        space = new HiText();
        plot = new Text() {{setFill(Color.WHITE);}};
        root = new BorderPane() {{
            setCenter(space);
            setRight(plot);
            setAlignment(space, Pos.CENTER_LEFT);
            setAlignment(plot, Pos.CENTER_RIGHT);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Space ov, Space nv) {
        if (ov != null) {
            plot.textProperty().unbind();
            space.textProperty().unbind();
            space.queryProperty().unbind();
            plot.setText(null);
            space.setText(null);
            space.queryProperty().set("");
        }
        if (nv != null) {
            var selectedPlot = AppData.plots.stream().filter(x -> x.getId() == nv.getPlotId()).findFirst().get();
            plot.textProperty().bind(selectedPlot.nameProperty());
            space.textProperty().bind(nv.nameProperty());
            space.queryProperty().bind(query);
        }
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
