package Views.Transaction;

import Models.Plot;
import Models.Space;
import ViewModels.Transaction.IrregularVM;
import ViewModels.Transaction.TransactionBaseVM;
import helpers.Icons;

public class Irregular extends TransactionBase<Plot, Space> {
    @Override
    protected String getHeader() {
        return "Irregular";
    }

    @Override
    protected String getIcon() {
        return Icons.IrregularTransaction;
    }

    @Override
    public TransactionBaseVM<Plot, Space> getViewModel() {
        return new IrregularVM();
    }
}
