package ViewModels.Add;

import Enums.Function;
import Models.Plot;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import ridiculous.AppData;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class AddPlotVM extends AddBaseVM {
    public Plot plot;
    public BooleanBinding nameExists;
    public StringProperty nameErrorProperty;

    public AddPlotVM() {
        plot = new Plot();
        nameErrorProperty = new SimpleStringProperty("");
        nameExists = new BooleanBinding() {
            {bind(plot.nameProperty());}

            @Override
            protected boolean computeValue() {
                if (plot.getName().isEmpty()) {
                    nameErrorProperty.set("is required");
                    return true;
                }
                var matched = AppData.plots.stream().anyMatch(x -> x.getName().equalsIgnoreCase(plot.getName()));
                nameErrorProperty.set(matched ? "exists" : "");
                return matched;
            }
        };
    }

    @Override
    protected int function() {
        return Function.AddPlot.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var nameBytes = (plot.getName() + '\0').getBytes(StandardCharsets.US_ASCII);
        var descBytes = (plot.getDescription() + '\0').getBytes(StandardCharsets.US_ASCII);
        var total = 4 + nameBytes.length + descBytes.length;
        return ByteBuffer
                .allocate(total)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(plot.getId())
                .put(nameBytes)
                .put(descBytes);
    }

    @Override
    protected void resetObject() {
        plot.setName("");
        plot.setDescription("");
    }
}
