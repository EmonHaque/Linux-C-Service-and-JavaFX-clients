package ViewModels.Add;

import Enums.Function;
import Models.Tenant;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import ridiculous.AppData;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class AddTenantVM extends AddBaseVM {
    public Tenant tenant;
    public BooleanBinding nameExists;
    public StringProperty nameErrorProperty;

    public AddTenantVM() {
        tenant = new Tenant();
        nameErrorProperty = new SimpleStringProperty("");
        nameExists = new BooleanBinding() {
            {bind(tenant.nameProperty());}

            @Override
            protected boolean computeValue() {
                if (tenant.getName().isEmpty()) {
                    nameErrorProperty.set("is required");
                    return true;
                }
                var matched = AppData.tenants.stream().anyMatch(x -> x.getName().equalsIgnoreCase(tenant.getName()));
                nameErrorProperty.set(matched ? "exists" : "");
                return matched;
            }
        };
    }

    @Override
    protected int function() {
        return Function.AddTenant.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var nameBytes = (tenant.getName() + '\0').getBytes(StandardCharsets.US_ASCII);
        var fatherBytes = (tenant.getFather() + '\0').getBytes(StandardCharsets.US_ASCII);
        var motherBytes = (tenant.getMother() + '\0').getBytes(StandardCharsets.US_ASCII);
        var husbandBytes = (tenant.getHusband() + '\0').getBytes(StandardCharsets.US_ASCII);
        var addressBytes = (tenant.getAddress() + '\0').getBytes(StandardCharsets.US_ASCII);
        var nidBytes = (tenant.getNid() + '\0').getBytes(StandardCharsets.US_ASCII);
        var phoneBytes = (tenant.getContactNo() + '\0').getBytes(StandardCharsets.US_ASCII);

        return ByteBuffer.allocate(5 + nameBytes.length + fatherBytes.length + motherBytes.length
                        + husbandBytes.length + addressBytes.length + nidBytes.length + phoneBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(tenant.getId())
                .put(nameBytes)
                .put(fatherBytes)
                .put(motherBytes)
                .put(husbandBytes)
                .put(addressBytes)
                .put(nidBytes)
                .put(phoneBytes)
                .put((byte) 0);
    }

    @Override
    protected void resetObject() {
        tenant.setName("");
        tenant.setFather("");
        tenant.setMother("");
        tenant.setHusband("");
        tenant.setAddress("");
        tenant.setNid("");
        tenant.setContactNo("");
    }
}
