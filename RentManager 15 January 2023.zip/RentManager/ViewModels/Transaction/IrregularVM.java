package ViewModels.Transaction;

import Enums.Function;
import Models.Plot;
import Models.Space;
import javafx.beans.Observable;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;
import ridiculous.Jar;

import java.nio.ByteBuffer;

public class IrregularVM extends TransactionBaseVM<Plot, Space>{

    public IrregularVM() {
        var spaceSource = new Jar<>(AppData.spaces, o -> new Observable[]{ entry.plotIdProperty() });
        plots = new FilteredList<>(AppData.plots);
        spaces = new FilteredList<>(spaceSource, x -> x.getPlotId() == entry.getPlotId());
    }

    @Override
    protected int function() {
        return Function.AddTransactionsIrregular.ordinal();
    }
}
