package Controls;

import Helpers.Constants;
import Helpers.Icons;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.scene.control.Skin;
import javafx.scene.control.TextArea;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Popup;
import Skins.ExtendedTextAreaSkin;

import java.io.*;
import java.net.URLConnection;
import java.nio.file.Files;


public class TextBoxMultiLineClean extends TextArea {
    private double fontSize;
    private Popup contextMenu;

    public TextBoxMultiLineClean() {
        setContextMenu(null);
        fontSize = getFont().getSize();

        addContextMenu();
        addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
            if (e.getButton() == MouseButton.SECONDARY) {
                contextMenu.show(this, e.getScreenX() + 15, e.getScreenY() + 15);
            }
            else contextMenu.hide();
        });

        addEventFilter(ContextMenuEvent.CONTEXT_MENU_REQUESTED, Event::consume);
        addEventFilter(ScrollEvent.SCROLL, this::onScroll);

        setOnDragEntered(e -> {
            var db = e.getDragboard();
            if(db.hasFiles()){
                setBackground(Background.fill(Constants.BackgroundColorLight));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25))));
            }
            e.consume();
        });
        setOnDragExited(e -> {
            setBackground(null);
            setBorder(null);
            e.consume();
        });
        setOnDragOver(e -> {
            if (e.getDragboard().hasFiles()) {
                var db = e.getDragboard();
                if (db.getFiles().size() == 1) {
                    var name = db.getFiles().get(0).getName().toLowerCase();
                    if (name.endsWith(".sql")) {
                        e.acceptTransferModes(TransferMode.COPY_OR_MOVE);
                    }
                    else e.acceptTransferModes(TransferMode.NONE);
                }
                else e.acceptTransferModes(TransferMode.NONE);
            }
            e.consume();
        });
        setOnDragDropped(e -> {
            var db = e.getDragboard();
            boolean result = false;
            if (db.hasFiles()) {
                try (var reader = new BufferedReader(new FileReader(db.getFiles().get(0).getAbsolutePath()))) {
                    String line;
                    while ((line = reader.readLine()) != null){
                        appendText(line + '\n');
                    }
                    result = true;
                } catch (IOException exp) {
                    result = false;
                    exp.printStackTrace();
                }
            }
            e.setDropCompleted(result);
            e.consume();
        });
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedTextAreaSkin(this);
    }

    private void onScroll(ScrollEvent e) {
        if (!e.isControlDown()) return;
        // this function is called twice on every scroll, first with 0
        if (e.getDeltaY() == 0) return;

        if (e.getDeltaY() > 0) {
            fontSize++;
            setFont(Font.font(fontSize));
        }
        else {
            if (fontSize == 13) return;
            fontSize--;
            setFont(Font.font(fontSize));
        }
        e.consume();
    }

    private void addContextMenu() {
        contextMenu = new Popup() {{setAutoHide(true);}};
        contextMenu.getContent().add(new VBox() {{
            setPadding(new Insets(5, 15, 5, 5));
            setSpacing(5);
            setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, new CornerRadii(5), new Insets(0))));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
            getChildren().addAll(
                    new ContextItem(Icons.Cut, "Cut", () -> {
                        cut();
                        contextMenu.hide();
                    }),
                    new ContextItem(Icons.Copy, "Copy", () -> {
                        copy();
                        contextMenu.hide();
                    }),
                    new ContextItem(Icons.Paste, "Paste", () -> {
                        paste();
                        contextMenu.hide();
                    })
            );
        }});
    }

    public void setReadOnly(boolean value) {setEditable(!value);}
}
