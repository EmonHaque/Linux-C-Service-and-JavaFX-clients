package Controls;

import Helpers.Constants;
import Helpers.Icons;
import Skins.ExtendedSplitPaneSkin;
import com.sun.jna.ptr.PointerByReference;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import ridiculous.SQLiteWrapper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class QueryPage extends BorderPane {
    private ResultTask task;
    private String query = "";
    private final TabHeader header;
    private final ActionButton execute, cancel, comment, save, open;
    private final TextBoxMultiLineClean queryBox;
    private final Text status;
    private final SpinningArc spinner;
    private final ExtendedTableView<String[]> table;
    private final ObservableList<String[]> result;
    private final IntegerProperty fontSize;

    public QueryPage(String header) {
        this.header = new TabHeader(header) {{setManaged(false);}};
        fontSize = new SimpleIntegerProperty(12);
        result = FXCollections.observableArrayList();
        table = new ExtendedTableView<>();
        table.setItems(result);
        table.setPlaceholder(new Text(""));
        queryBox = new TextBoxMultiLineClean() {{setText("");}};
        queryBox.setOnKeyReleased(this::onKeyPressOnQueryBox);

        var split = new SplitPane();
        split.setSkin(new ExtendedSplitPaneSkin(split));

        open = new ActionButton(Icons.FileAdd, 16, "choose .sql file"){{ setAction(QueryPage.this::openFile);}};
        save = new ActionButton(Icons.Save, 16, "save"){{ setAction(QueryPage.this::saveQuery);}};
        comment = new ActionButton(Icons.Comment, 16, "(Ctrl+/) comment/uncomment") {{
            setAction(QueryPage.this::startCommentUnComment);
        }};
        execute = new ActionButton(Icons.Play, 16, "(F5) execute") {{setAction(QueryPage.this::executeQuery);}};
        cancel = new ActionButton(Icons.Cancel, 16, "(Esc) cancel") {{
            setVisible(false);
            setAction(QueryPage.this::cancelExecution);
        }};

        status = new Text();
        spinner = new SpinningArc();
        var statusBox = new HBox(spinner, status) {{
            setSpacing(5);
            setPadding(new Insets(5));
            setAlignment(Pos.CENTER_RIGHT);
        }};

        var executeCancel = new StackPane(cancel, execute) {{setAlignment(Pos.CENTER_RIGHT);}};
        var buttonBox = new HBox(executeCancel, comment, save, open) {{
            setAlignment(Pos.CENTER_RIGHT);
            setSpacing(2.5);
            setPadding(new Insets(5));
        }};
        var queryArea = new VBox(buttonBox, queryBox) {{
            //setAlignment(Pos.CENTER_RIGHT);
            setVgrow(queryBox, Priority.ALWAYS);
            setPadding(new Insets(0, 5, 0, 0));
        }};
        var resultArea = new VBox(statusBox, table) {{
            setVgrow(table, Priority.ALWAYS);
            setPadding(new Insets(0, 0, 0, 5));
        }};

        split.getItems().addAll(queryArea, resultArea);
        split.setDividerPositions(0.45);
        setCenter(split);
        setBorder(Constants.TopBorder);
        setManaged(false);

        table.addEventFilter(ScrollEvent.SCROLL, this::onControlWheel);
    }

    public void focusQueryArea(){ queryBox.requestFocus();}

    public TabHeader getHeader() {return header;}

    private void onControlWheel(ScrollEvent e) {
        if (!e.isControlDown()) return;
        // this function is called twice on every scroll, first with 0
        if (e.getDeltaY() == 0) return;

        e.consume();
        if (e.getDeltaY() > 0) {
            fontSize.set(fontSize.get() + 1);
        }
        else {
            var current = fontSize.get();
            if (current > 12) fontSize.set(current - 1);
        }
    }

    private void executeQuery() {
        query = queryBox.getSelectedText();
        if (query.isEmpty() || query.isBlank()) {
            query = queryBox.getText().trim();
        }
        if (query.isEmpty()) return;

        table.getColumns().clear();
        result.clear();
        status.setFill(Color.WHITE);

        if (task != null && task.isRunning()) {
            SQLiteWrapper.cancel();
            task.setOnCancelled(c -> {
                task.setOnCancelled(null);
                startTask();
            });
            task.cancel();
        }
        else startTask();
    }

    private void cancelExecution() {
        if (task != null && task.isRunning()) {
            task.setOnCancelled(e -> {
                task.setOnCancelled(null);
                status.textProperty().unbind();
                status.setText("cancelled");
            });
            task.cancel();
            SQLiteWrapper.cancel();
        }
    }

    private void onKeyPressOnQueryBox(KeyEvent e) {
        if (e.getCode() == KeyCode.ESCAPE) cancelExecution();
        else if (e.getCode() == KeyCode.F5) executeQuery();
        else if (e.getCode() == KeyCode.SLASH && e.isControlDown()) startCommentUnComment();
    }

    public void startCommentUnComment() {
        if (queryBox.getSelectedText().startsWith("--")) unComment();
        else comment();
    }

    private void comment() {
        var start = queryBox.getSelection().getStart();
        var lines = queryBox.getSelectedText().split("\n");
        var newLine = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            newLine.append("--").append(lines[i]);
            if (i < lines.length - 1) {
                newLine.append('\n');
            }
        }
        queryBox.replaceSelection(newLine.toString());
        queryBox.selectRange(start, start + newLine.length());
    }

    private void unComment() {
        var start = queryBox.getSelection().getStart();
        var newLine = queryBox.getSelectedText().replace("--", "");
        queryBox.replaceSelection(newLine);
        queryBox.selectRange(start, start + newLine.length());
    }

    private void saveQuery() {
        var chooser = new FileChooser();
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("SQL file", "*.sql"));
        var file = chooser.showSaveDialog(null);
        if (file == null) return;

        status.textProperty().unbind();
        try (var writer = new FileWriter(file)) {
            writer.write(queryBox.getText());
            status.setFill(Color.WHITE);
            status.setText("saved successfully");
        } catch (IOException e) {
            status.setFill(Color.LIGHTCORAL);
            status.setText("couldn't save");
        }

    }

    private void openFile(){
        var chooser = new FileChooser();
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("SQL file", "*.sql"));
        var file = chooser.showOpenDialog(null);
        if(file == null) return;

        queryBox.clear();
        try (var reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null){
                queryBox.appendText(line + '\n');
            }
        } catch (IOException exp) {
            exp.printStackTrace();
        }
    }

    private void startTask() {
        task = new ResultTask();
        execute.visibleProperty().bind(task.runningProperty().not());
        cancel.visibleProperty().bind(task.runningProperty());
        spinner.visibleProperty().bind(task.runningProperty());
        status.textProperty().bind(task.messageProperty());
        new Thread(task) {{setDaemon(true);}}.start();
    }

    private class ResultTask extends Task<Void> {
        private List<String[]> result;
        private String[] columns;
        private String error;
        private long time;
        private int pointerLength, numRow, numColumn, numChange;

        private void getColumnNames(int count, PointerByReference values, int length) {
            updateMessage(count + " columns found");
            numColumn = count;
            pointerLength = length;
            var pointers = values.getPointer().getPointerArray(0, length);
            columns = new String[count];
            for (int i = 0; i < count; i++) {
                columns[i] = pointers[i].getString(0);
            }
            updateMessage("adding rows");
        }

        private void getRows(PointerByReference values) {
            var pointers = values.getPointer().getPointerArray(0, pointerLength);
            var array = new String[numColumn];
            for (int i = 0; i < numColumn; i++) {
                array[i] = pointers[i] == null ? "NULL" : pointers[i].getString(0);
            }
            result.add(array);
            numRow++;
            if (numRow % 1000 == 0) {
                updateMessage("got " + String.format("%,d", numRow) + " rows");
            }
            if (isCancelled()) {
                updateMessage("cancelled");
            }
        }

        private void getChange(int count) {
            numChange = count;
        }

        private void getError(String error) {
            this.error = error;
        }

        @Override
        protected Void call() {
            updateMessage("waiting for key");
            synchronized (SQLiteWrapper.key) {
                var start = System.currentTimeMillis();
                updateMessage("submitting task");
                result = new ArrayList<>();

                SQLiteWrapper.setColumnCallback(this::getColumnNames);
                SQLiteWrapper.setRowCallback(this::getRows);
                SQLiteWrapper.setChangeCallback(this::getChange);
                SQLiteWrapper.setCErrorCallback(this::getError);

                SQLiteWrapper.execute(query);
                time = System.currentTimeMillis() - start;
            }
            return null;
        }

        private void addColumns() {
            for (int i = 0; i < numColumn; i++) {
                final int index = i;
                var column = new TableColumn<String[], String>(columns[i]) {{
                    setSortable(false);
                    setCellFactory(v -> new TableCell<>() {
                        private String content;
                        {
                            setBackground(null);
                            setBorder(null);
                            setContentDisplay(ContentDisplay.TEXT_ONLY);
                            fontSize.addListener(o -> {
                                if (isEmpty()) return;
                                var posture = content.equals("NULL") ? FontPosture.ITALIC : FontPosture.REGULAR;
                                setFont(Font.font(null, posture, fontSize.get()));
                            });
                        }

                        @Override
                        protected void updateItem(String item, boolean empty) {
                            super.updateItem(item, empty);
                            if (empty) {
                                setTextFill(null);
                                setText(null);
                            }
                            else {
                                content = result.get(getIndex())[index];
                                if (content.equals("NULL")) {
                                    setTextFill(Color.GRAY);
                                    setFont(Font.font(null, FontPosture.ITALIC, fontSize.get()));
                                }
                                else {
                                    setTextFill(Color.WHITE);
                                    setFont(Font.font(null, FontPosture.REGULAR, fontSize.get()));
                                }
                                setText(content);
                            }
                        }
                    });
                }};
                table.getColumns().add(column);
            }
        }

        @Override
        protected void succeeded() {
            // Why do you get: JNA: callback object has been garbage collected
            // It's to be when it's in a task

            if (error != null) {
                status.setFill(Color.LIGHTCORAL);
                updateMessage(error);
            }
            else {
                status.setFill(Color.WHITE);
                String timeText;
                if (time > 1000) {
                    double seconds = time / (double) 1000;
                    timeText = String.format("%.2f", seconds) + " seconds";
                }
                else timeText = String.format("%,d", time) + " milliseconds";

                if (numChange > 0) updateMessage(String.format("%,d", numChange) + " rows affected in " + timeText);
                else if (numColumn > 0) {
                    updateMessage(String.format("%,d", numColumn) + " columns, " + String.format("%,d", numRow) + " rows returned in " + timeText);
                    addColumns();
                    QueryPage.this.result.addAll(result);
                }
                else updateMessage("successfully executed in " + timeText);
            }
        }
    }
}
