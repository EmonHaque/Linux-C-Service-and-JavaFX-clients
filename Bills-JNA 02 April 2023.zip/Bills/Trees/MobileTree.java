package Trees;

import Model.MobileEntry;
import Model.PeriodicEntry;
import abstracts.WrapTreeCellBase;
import controls.texts.HiText;
import helpers.Constants;
import helpers.Helper;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import skinned.ExtendedTreeView;

import java.text.DateFormatSymbols;
import java.util.function.Function;

public class MobileTree extends ExtendedTreeView<MobileEntry> {
    private final FilteredList<MobileEntry> list;
    public ObjectProperty<MobileEntry> selectedItem;
    private boolean isSorted;

    public MobileTree(FilteredList<MobileEntry> list) {
        this.list = list;
        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new Cell());

        selectedItem = new SimpleObjectProperty<>();
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        getSelectionModel().selectedItemProperty().addListener(this::onSelectionChange);
        list.addListener(this::onListChange);
    }

    private void onSelectionChange(Observable o, TreeItem<MobileEntry> ov, TreeItem<MobileEntry> nv){
        if(nv == null) selectedItem.set(null);
        if(getTreeItemLevel(nv) != 4) {
            selectedItem.set(null);
            return;
        }
        selectedItem.set(nv.getValue());
    }

    private void onListChange(ListChangeListener.Change<? extends MobileEntry> change){
        while (change.next()){
            if(change.wasAdded()){
                if(change.getRemovedSize() > 0){
                    for(var e : change.getRemoved()) removeItem(getRoot(), e);
                }
                for (var e : change.getAddedSubList()) addItem(getRoot(), e);
            }
            else if(change.wasRemoved()){
                for(var e : change.getRemoved()) removeItem(getRoot(), e);
            }
        }
        sortItems();
    }

    private void addItem(TreeItem<MobileEntry> node, MobileEntry entry){
        var level = getTreeItemLevel(node);
        var hasIt = false;
        TreeItem<MobileEntry> item = null;
        Function<MobileEntry, Boolean> condition = x -> true;

        switch (level) {
            case 0 -> condition = e -> e.getMonth().equals(entry.getMonth());
            case 1 -> condition = e -> e.getDate().equals(entry.getDate());
            case 2 -> condition = e -> e.getDepartment().equals(entry.getDepartment());
        }
        for (var branch : node.getChildren()) {
            if (!condition.apply(branch.getValue())) continue;
            var value = branch.getValue();
            value.setPayment(value.getPayment() + entry.getPayment());
            hasIt = true;
            item = branch;
            break;
        }
        if (!hasIt) {
            var newEntry = new MobileEntry() {{
                setPayment(entry.getPayment());
            }};
            switch (level) {
                case 0 -> newEntry.setMonth(entry.getMonth());
                case 1 -> newEntry.setDate(entry.getDate());
                case 2 -> newEntry.setDepartment(entry.getDepartment());
            }
            item = new TreeItem<>(newEntry);
            node.getChildren().add(item);
        }

        if (level == 2) item.getChildren().add(new TreeItem<>(entry));
        else addItem(item, entry);
    }

    private void removeItem(TreeItem<MobileEntry> node, MobileEntry entry){
        var level = getTreeItemLevel(node);
        TreeItem<MobileEntry> item = null;
        Function<MobileEntry, Boolean> condition = x -> true;

        switch (level) {
            case 0 -> condition = e -> e.getMonth().equals(entry.getMonth());
            case 1 -> condition = e -> e.getDate().equals(entry.getDate());
            case 2 -> condition = e -> e.getDepartment().equals(entry.getDepartment());
        }
        for (var branch : node.getChildren()) {
            if (!condition.apply(branch.getValue())) continue;
            var value = branch.getValue();
            value.setPayment(value.getPayment() - entry.getPayment());
            item = branch;
            break;
        }

        if(level == 2) {
            TreeItem<MobileEntry> match = null;
            for(var leaf : item.getChildren()){
                if(leaf.getValue().equals(entry)){
                    match = leaf;
                    break;
                }
            }
            item.getChildren().remove(match);
        }
        else removeItem(item, entry);

        if(item.getChildren().size() == 0){
            item.getParent().getChildren().remove(item);
        }
    }

    public void sort(){
        isSorted = !isSorted;
        sortItems();
    }

    private void sortItems(){
        if(isSorted){
            getRoot().getChildren().sort((o1, o2) -> {
                var item1 = o1.getValue().getMonth().split(", ");
                var item2 = o2.getValue().getMonth().split(", ");
                var num1 = Integer.parseInt(item1[1] + item1[0]);
                var num2 = Integer.parseInt(item2[1] + item2[0]);
                return num2 - num1;
            });
        }
        else{
            getRoot().getChildren().sort((o1, o2) -> {
                var item1 = o1.getValue().getMonth().split(", ");
                var item2 = o2.getValue().getMonth().split(", ");
                var num1 = Integer.parseInt(item1[1] + item1[0]);
                var num2 = Integer.parseInt(item2[1] + item2[0]);
                return num1 - num2;
            });
        }
    }

    private class Cell extends WrapTreeCellBase<MobileEntry>{
        private HiText particulars;
        private Text amount;
        private ColumnConstraints firstColumn;
        private Popup toolTip;
        private Text popText;
        private final String[] months;
        private EventHandler<MouseEvent> enterEvent, exitEvent;

        public Cell() {
            months = new DateFormatSymbols().getMonths();
        }

        @Override
        protected void initializeUI() {
            popText = new Text(){{ setFill(Color.WHITE);}};
            toolTip = new Popup() {{
                getContent().add(
                        new StackPane(popText){{
                            setPadding(new Insets(5));
                            setBackground(Background.fill(Constants.BackgroundColor));
                            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
                        }}
                );
            }};
            particulars = new HiText();
            amount = new Text() {{setFill(Color.WHITE);}};
            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(90) {{setHalignment(HPos.RIGHT);}}
                );
                add(particulars, 0, 0);
                add(amount, 1, 0);
            }};
        }

        @Override
        protected void resetValues(MobileEntry oldValue) {
            if(enterEvent != null)
                root.removeEventHandler(MouseEvent.MOUSE_ENTERED, enterEvent);
            if(exitEvent != null)
                root.removeEventHandler(MouseEvent.MOUSE_EXITED, exitEvent);

            root.setBorder(null);
            particulars.setText(null);
            particulars.queryProperty().unbind();
            particulars.queryProperty().set("");
            amount.setText(null);
        }

        @Override
        protected void setValues(MobileEntry newValue) {
            String text = "";
            switch (level) {
                case 1 -> {
                    var splits = newValue.getMonth().split(",");
                    var monthName = months[Integer.parseInt(splits[0]) - 1] + "," + splits[1];
                    text = monthName + " (" + item.getChildren().size() + ")";
                }
                case 2 ->  text = newValue.getDate().split("-")[2] + " (" + item.getChildren().size() + ")";
                case 3 -> text = newValue.getDepartment() + " (" + item.getChildren().size() + ")";
                case 4 -> {
                    text = newValue.getAccountId() + " | " + newValue.getAccountHolder();
                    popText.setText(newValue.getAddress());

                    enterEvent = this::onMouseEnter;
                    exitEvent = this::onMouseExit;
                    root.addEventHandler(MouseEvent.MOUSE_ENTERED, enterEvent);
                    root.addEventHandler(MouseEvent.MOUSE_EXITED, exitEvent);
                }
            }
            particulars.setText(text);
            //particulars.queryProperty().bind(query);
            amount.setText(Helper.formatNumber(newValue.getPayment()));
            if(level > 1) makeBorder(item);
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() -90;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            particulars.setPrefWidth(remainder);
            return particulars.prefHeight(remainder);
        }

        private void onMouseEnter(MouseEvent e){
            if(level != 4) return;
            toolTip.show(root, e.getScreenX() + 20, e.getScreenY() + 10);
        }

        private void onMouseExit(MouseEvent e){
            toolTip.hide();
        }

        private void makeBorder(TreeItem<MobileEntry> item){
            var siblings = item.getParent().getChildren();
            if(siblings.size() == 1) root.setBorder(Constants.DoubleBorder);
            else{
                var index = siblings.indexOf(item);
                if(index == 0) root.setBorder(Constants.TopBorder);
                else if (index == siblings.size() - 1) {
                    root.setBorder(Constants.BottomBorder);
                }
            }
        }
    }
}
