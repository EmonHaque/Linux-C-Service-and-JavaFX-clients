package Trees;

import Model.RawInfo;
import abstracts.WrapTreeCellBase;
import controls.SVGIcon;
import helpers.Constants;
import helpers.Helper;
import helpers.Icons;
import interfaces.IExecuteArg;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeItem;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import skinned.ExtendedTreeView;

import java.util.List;

public class LoadTree extends ExtendedTreeView<RawInfo> {
    public ObjectProperty<RawInfo> selectedItem;
    private final IExecuteArg<RawInfo> removeAction;

    public LoadTree(FilteredList<RawInfo> list, IExecuteArg<RawInfo> removeAction) {
        this.removeAction = removeAction;
        selectedItem = new SimpleObjectProperty<>();
        setRoot(new TreeItem<>());
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new Cell());
        getSelectionModel().selectedItemProperty().addListener(this::onSelectionChange);
        list.addListener(this::onItemsChanged);
    }

    private void onSelectionChange(Observable o, TreeItem<RawInfo> ov, TreeItem<RawInfo> nv) {
        if (nv == null) {
            selectedItem.set(null);
            return;
        }
        if (getTreeItemLevel(nv) == 1) return;
        selectedItem.set(nv.getValue());
    }

    private void onItemsChanged(ListChangeListener.Change<? extends RawInfo> change) {
        while (change.next()) {
            if (change.wasAdded()) {
                if (change.getRemovedSize() > 0) {
                    removeItems((List<RawInfo>) change.getRemoved());
                }
                addItems((List<RawInfo>) change.getAddedSubList());
            }
            else if (change.wasRemoved()) {
                removeItems((List<RawInfo>) change.getRemoved());
            }
        }
    }

    private void addItems(List<RawInfo> list) {
        TreeItem<RawInfo> branch = null;
        boolean hasIt = false;
        for (var item : list) {
            if (item.getDeptName().isEmpty()) {
                for (var node : getRoot().getChildren()) {
                    if (node.getValue().getDeptName().equals("Uncategorized")) {
                        hasIt = true;
                        branch = node;
                        branch.getValue().setTotalPayment(branch.getValue().getTotalPayment() + item.getTotalPayment());
                        break;
                    }
                }
                if (!hasIt) {
                    var newInfo = new RawInfo() {{
                        setDeptName("Uncategorized");
                        setTotalPayment(item.getTotalPayment());
                    }};
                    branch = new TreeItem<>(newInfo) {{setExpanded(true);}};
                    getRoot().getChildren().add(branch);
                }
                branch.getChildren().add(new TreeItem<>(item));
            }
            else {
                for (var node : getRoot().getChildren()) {
                    if (node.getValue().getDeptName().equals(item.getDeptName())) {
                        hasIt = true;
                        branch = node;
                        branch.getValue().setTotalPayment(branch.getValue().getTotalPayment() + item.getTotalPayment());
                        break;
                    }
                }
                if (!hasIt) {
                    var newInfo = new RawInfo() {{
                        setDeptName(item.getDeptName());
                        setTotalPayment(item.getTotalPayment());
                    }};
                    branch = new TreeItem<>(newInfo) {{setExpanded(true);}};
                    getRoot().getChildren().add(branch);
                }
                branch.getChildren().add(new TreeItem<>(item));
            }
            hasIt = false;
        }
    }

    private void removeItems(List<RawInfo> list) {
        for(var info : list){
            TreeItem<RawInfo> branch = null;
            TreeItem<RawInfo> leaf = null;
            var found = false;

            for (var group : getRoot().getChildren()){
                for (var item : group.getChildren()){
                    if(item.getValue().equals(info)){
                        found = true;
                        leaf = item;
                        branch = group;
                        break;
                    }
                }
                if(found) break;
            }
            branch.getValue().setTotalPayment(branch.getValue().getTotalPayment() - info.getTotalPayment());
            branch.getChildren().remove(leaf);
            if(branch.getChildren().size() == 0){
                getRoot().getChildren().remove(branch);
            }
        }
    }

    private class Cell extends WrapTreeCellBase<RawInfo> {
        private Text name, total;
        private SVGIcon icon;
        private ColumnConstraints firstColumn;
        private Popup contextMenu;
        private EventHandler<MouseEvent> popupEvent;

        @Override
        protected void initializeUI() {
            name = new Text() {{setFill(Color.WHITE);}};
            total = new Text() {{setFill(Color.WHITE);}};
            icon = new SVGIcon(Icons.CheckCircle) {{setVisible(false);}};

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(16) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(100) {{setHalignment(HPos.RIGHT);}}

                );
                add(name, 0, 0);
                add(icon, 1, 0);
                add(total, 2, 0);
            }};


            var icon = new SVGIcon(Icons.CloseCircle);
            var text = new Text("remove"){{ setFill(Color.WHITE);}};
            var hBox = new HBox(icon, text){{
                setSpacing(5);
                setAlignment(Pos.CENTER_LEFT);
                setPadding(new Insets(5));
                setBackground(Background.fill(Constants.BackgroundColor));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(1))));
            }};
            contextMenu = new Popup();
            contextMenu.getContent().add(hBox);
            contextMenu.setAutoHide(true);

            hBox.setOnMouseClicked(e ->{
                removeAction.execute(getItem());
                contextMenu.hide();
            });
        }

        @Override
        protected void resetValues(RawInfo oldValue) {
            if(popupEvent != null)
                root.removeEventHandler(MouseEvent.MOUSE_CLICKED, popupEvent);

            root.setBorder(null);

            total.textProperty().unbind();
            icon.visibleProperty().unbind();
            name.fillProperty().unbind();
            total.fillProperty().unbind();

            name.setFont(Constants.Normal);
            total.setFont(Constants.Normal);
            name.setFill(Color.WHITE);
            total.setFill(Color.WHITE);

            icon.setVisible(false);
            name.setText(null);
            total.setText(null);
        }

        @Override
        protected void setValues(RawInfo newValue) {
            if (level == 1) {
                //var dept = AppData.departments.stream().filter(x -> x.getId() == newValue.getDeptId()).findFirst().get().getName();
                name.setFont(Constants.Bold);
                total.setFont(Constants.Bold);
                name.setText(newValue.getDeptName() + " (" + item.getChildren().size() + ")");
                total.textProperty().bind(Bindings.createStringBinding(() -> {
                    double total = 0;
                    for (var branch : item.getChildren()) {
                        total += branch.getValue().getTotalPayment();
                    }
                    return Helper.formatNumber(total);
                }, item.getChildren().stream().map(x -> x.getValue().totalPaymentProperty()).toArray(Observable[]::new)));
            }
            else {
                int size = item.getParent().getChildren().size();
                var index = item.getParent().getChildren().indexOf(item);
                if (size == 1) root.setBorder(Constants.DoubleBorder);
                else {
                    if (index == 0) root.setBorder(Constants.TopBorder);
                    else if (index == size - 1) root.setBorder(Constants.BottomBorder);
                }
                name.setText(newValue.getFileName());
                total.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(newValue.getTotalPayment()), newValue.totalPaymentProperty()));
                icon.visibleProperty().bind(newValue.isOkProperty());

                name.fillProperty().bind(getBinding());
                total.fillProperty().bind(getBinding());

                popupEvent = this::showPopup;
                root.addEventHandler(MouseEvent.MOUSE_CLICKED, popupEvent);
            }
        }

        private ObjectBinding<Paint> getBinding() {
            return Bindings.createObjectBinding(() ->
                            getItem().isIsDuplicate() ? Color.LIGHTCORAL : Color.WHITE,
                    getItem().isDuplicateProperty()
            );
        }

        private void showPopup(MouseEvent e){
            if(level == 1) return;
            if(e.getButton() != MouseButton.SECONDARY) {
                contextMenu.hide();
                return;
            }
            contextMenu.show(root, e.getScreenX() + 10, e.getScreenY());
        }


        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 100 - 16;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            firstColumn.setMinWidth(remainder);
            name.setWrappingWidth(remainder);
            return name.prefHeight(remainder);
        }
    }
}
