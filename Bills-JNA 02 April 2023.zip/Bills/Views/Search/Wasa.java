package Views.Search;

import ViewModels.Search.DepartmentSearchVM;
import ViewModels.Search.WasaVM;
import helpers.Icons;

public class Wasa extends DepartmentSearch{
    @Override
    protected String getIcon() {
        return Icons.Water;
    }

    @Override
    protected DepartmentSearchVM getViewModel() {
        return  new WasaVM();
    }
}
