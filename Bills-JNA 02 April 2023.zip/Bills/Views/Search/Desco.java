package Views.Search;

import ViewModels.Search.DescoVM;
import ViewModels.Search.DepartmentSearchVM;
import helpers.Icons;

public class Desco extends DepartmentSearch{
    @Override
    protected String getIcon() {
        return Icons.Electricity;
    }

    @Override
    protected DepartmentSearchVM getViewModel() {
        return new DescoVM();
    }
}
