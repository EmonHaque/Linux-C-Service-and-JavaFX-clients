package Model;

import Interfaces.IBillEntry;
import javafx.beans.property.*;

public class MobileEntry extends IBillEntry {
    private final StringProperty month, department, accountId, accountHolder, address;

    public MobileEntry() {
        month = new SimpleStringProperty("");
        department = new SimpleStringProperty("");
        accountId = new SimpleStringProperty("");
        accountHolder = new SimpleStringProperty("");
        address = new SimpleStringProperty("");
    }

    public String getMonth() {
        return month.get();
    }

    public StringProperty monthProperty() {
        return month;
    }

    public void setMonth(String month) {
        this.month.set(month);
    }

    public String getDepartment() {
        return department.get();
    }

    public StringProperty departmentProperty() {
        return department;
    }

    public void setDepartment(String department) {
        this.department.set(department);
    }

    public String getAccountId() {
        return accountId.get();
    }

    public StringProperty accountIdProperty() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId.set(accountId);
    }

    public String getAccountHolder() {
        return accountHolder.get();
    }

    public StringProperty accountHolderProperty() {
        return accountHolder;
    }

    public void setAccountHolder(String accountHolder) {
        this.accountHolder.set(accountHolder);
    }

    public String getAddress() {
        return address.get();
    }

    public StringProperty addressProperty() {
        return address;
    }

    public void setAddress(String address) {
        this.address.set(address);
    }
}
