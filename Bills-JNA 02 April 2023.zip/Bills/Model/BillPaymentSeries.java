package Model;

public class BillPaymentSeries {
    private String date;
    private double bill, payment;

    public BillPaymentSeries(String date, double bill, double payment) {
        this.date = date;
        this.bill = bill;
        this.payment = payment;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getBill() {
        return bill;
    }

    public void setBill(double bill) {
        this.bill = bill;
    }

    public double getPayment() {
        return payment;
    }

    public void setPayment(double payment) {
        this.payment = payment;
    }
}
