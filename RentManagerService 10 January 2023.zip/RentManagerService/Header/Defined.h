#pragma once

#define POINTER_SIZE sizeof(void*)
#define SENDER_SIZE sizeof(Sender)
#define REQUEST_SIZE sizeof(Request)
#define RESPONSE_PERSONAL_SIZE sizeof(ResponsePersonal)
#define RESPONSE_PUBLIC_SIZE sizeof(ResponsePublic)
#define PLOT_SIZE sizeof(Plot)
#define SPACE_SIZE sizeof(Space)
#define EDITED_SPACE_SIZE sizeof(EditedSpace)
#define EDITED_TENANT_SIZE sizeof(EditedTenant)
#define TENANT_SIZE sizeof(Tenant)
#define LEASE_SIZE sizeof(Lease)
#define RECEIVABLE_SIZE sizeof(Receivable)
#define NEW_LEASE_SIZE sizeof(NewLease)
#define CONTROL_HEAD_SIZE sizeof(ControlHead)
#define HEAD_SIZE sizeof(Head)
#define PLOTWISE_DUE_SIZE sizeof(PlotwiseDue)
#define PLOTWISE_RENT_SIZE sizeof(PlotwiseRent)
#define TENANT_DETAIL_SIZE sizeof(TenantDetail)
#define RENT_PAYMENT_SIZE sizeof(RentPayment)
#define DEPOSIT_DUE_RENT_SIZE sizeof(DepositDueRent)
#define BALANCE_SIZE sizeof(Balance)
#define REPORT_ENTRY_SIZE sizeof(ReportEntry)
#define MONTHY_BALANCE_SIZE sizeof(MonthlyBalance)
#define RECEIPT_PAYMENT_SIZE sizeof(ReceiptPayment)
#define TRANSACTION_SIZE sizeof(Transaction)
#define SHORT_MESSAGE_SIZE sizeof(ShortMessage)

typedef unsigned char byte;
typedef unsigned int uint;
typedef unsigned long ulong;

typedef void Action();