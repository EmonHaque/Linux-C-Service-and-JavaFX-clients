#include "Messenger.h"
#include <stdio.h>

int sendString(int s, char* str) {
	int length = strlen(str) + 1;
	int sent = 0, offset = 0;
	do {
		sent = send(s, &str[offset], length, 0);
		if (sent <= 0) return -1;
		length -= sent;
		offset += sent;
	} while (length > 0);
	return 0;
}
int sendFile(int s, char *buffer, long length){
	int sent = 0, offset = 0;
	do {
		sent = send(s, &buffer[offset], length, 0);
		if (sent <= 0) return -1;
		length -= sent;
		offset += sent;
	} while (length > 0);
	return 0;
}
int sendByte(int s, byte val) {
	int sent = send(s, &val, 1, 0);
	if (sent <= 0) return -1;
	return 0;
}
int sendInt(int s, int val) {
	char* ptr = &val;
	int length = 4;
	int sent = 0, offset = 0;
	do {
		sent = send(s, &ptr[offset], length, 0);
		if (sent <= 0) return -1;
		length -= sent;
		offset += sent;
	} while (length > 0);
	return 0;
}
int sendDouble(int s, double val){
	char* ptr = &val;
	int length = 8;
	int sent = 0, offset = 0;
	do {
		sent = send(s, &ptr[offset], length, 0);
		if (sent <= 0) return -1;
		length -= sent;
		offset += sent;
	} while (length > 0);
	return 0;
}