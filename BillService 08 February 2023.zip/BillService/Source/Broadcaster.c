#include "BlockingQueue.h"
#include "CommonStructures.h"
#include "List.h"
#include "Messenger.h"
#include "Structures.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern byte isRunning;
extern List receivers;
extern BlockingQueue publicResponses;
extern pthread_mutex_t criticalReceiver;

static pthread_t broadcastThread;

static void sendDepartment(ResponsePublic *r) {
    int **list = receivers.data;
    Department *dept = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver *client = list[i];
        sendInt(client->socket, r->size);
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, dept->id);
        sendString(client->socket, dept->name);
    }
}

static void sendAccount(ResponsePublic *r) {
    int **list = receivers.data;
    Account *acc = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver *client = list[i];
        sendInt(client->socket, r->size);
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, acc->id);
        sendInt(client->socket, acc->departmentId);
        sendString(client->socket, acc->accoutId);
        sendString(client->socket, acc->name);
        sendString(client->socket, acc->address);
        sendByte(client->socket, acc->isWrong);
    }
}

static void sendMobile(ResponsePublic *r) {
    int **list = receivers.data;
    Mobile *mob = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver *client = list[i];
        sendInt(client->socket, r->size);
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, mob->id);
        sendString(client->socket, mob->number);
        sendString(client->socket, mob->name);
    }
}

static void sendHeads(ResponsePublic *r) {
    int **list = receivers.data;
    Head **hea = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver *client = list[i];
        sendInt(client->socket, r->size);
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        for (int j = 0; j < r->count; j++) {
            sendInt(client->socket, hea[j]->id);
            sendString(client->socket, hea[j]->name);
        }
    }
    free(r->data);
}

static void sendEditedBillInfo(ResponsePublic *r) {
    int **list = receivers.data;
    EditedBillInfo *info = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver *client = list[i];
        sendInt(client->socket, r->size);
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, info->billId);
        sendInt(client->socket, info->mobileId);
        sendByte(client->socket, info->fileRenamed);

        sendString(client->socket, info->date);
        sendString(client->socket, info->billNo);
        sendString(client->socket, info->transactionId);
        sendString(client->socket, info->period);
        sendString(client->socket, info->fileName);
    }
    // another thread to free ?
    free(info->date);
    free(info->billNo);
    free(info->transactionId);
    free(info->period);
    free(info->fileName);
    free(info);
}

static void sendEditedEntry(ResponsePublic *r) {
    int **list = receivers.data;
    EditedEntry **entries = r->data;
    for (int i = 0; i < receivers.count; i++) {
        Receiver *client = list[i];
        sendInt(client->socket, r->size);
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        for (int j = 0; j < r->count; j++) {
            sendInt(client->socket, entries[j]->billId);
            sendInt(client->socket, entries[j]->headId);
            sendDouble(client->socket, entries[j]->payment);
            sendDouble(client->socket, entries[j]->bill);
        }
    }
    for (int j = 0; j < r->count; j++) {
        free(entries[j]);
    }
    free(r->data);
}

static void sendEditedAccount(ResponsePublic *r) {
    int **list = receivers.data;
    Account *account = r->data;
    for (int i = 0; i < receivers.count; i++) {
        Receiver *client = list[i];
        sendInt(client->socket, r->size);
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, account->id);
        sendByte(client->socket, account->isWrong);
        sendString(client->socket, account->accoutId);
        sendString(client->socket, account->name);
        sendString(client->socket, account->address);
    }
}

static void sendEditedHead(ResponsePublic *r) {
    int **list = receivers.data;
    Head *head = r->data;
    for (int i = 0; i < receivers.count; i++) {
        Receiver *client = list[i];
        sendInt(client->socket, r->size);
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, head->id);
        sendString(client->socket, head->name);
    }
}

static void sendEditedDepartment(ResponsePublic *r) {
    int **list = receivers.data;
    Department *department = r->data;
    for (int i = 0; i < receivers.count; i++) {
        Receiver *client = list[i];
        sendInt(client->socket, r->size);
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, department->id);
        sendString(client->socket, department->name);
    }
}

static void sendEditedMobile(ResponsePublic *r) {
    int **list = receivers.data;
    Mobile *mobile = r->data;
    for (int i = 0; i < receivers.count; i++) {
        Receiver *client = list[i];
        sendInt(client->socket, r->size);
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, mobile->id);
        sendString(client->socket, mobile->number);
        sendString(client->socket, mobile->name);
    }
}

static void *BroadcastResponse(void *p) {
    pthread_detach(pthread_self());

    while (isRunning) {
        ResponsePublic *r = takeOutFrom(&publicResponses);
        if (!r) break;

        pthread_mutex_lock(&criticalReceiver);
        switch (r->function) {
            case AddDepartment: sendDepartment(r); break;
            case AddAccount: sendAccount(r); break;
            case AddMobile: sendMobile(r); break;
            case AddHead: sendHeads(r); break;
            case EditBillInfo: sendEditedBillInfo(r); break;
            case EditBillEntry: sendEditedEntry(r); break;
            case EditAccount: sendEditedAccount(r); break;
            case EditHead: sendEditedHead(r); break;
            case EditDepartment: sendEditedDepartment(r); break;
            case EditMobile: sendEditedMobile(r); break;
        }
        pthread_mutex_unlock(&criticalReceiver);
        free(r);
    }
    pthread_exit(0);
}

void InitializeBroadcaster() {
    pthread_create(&broadcastThread, 0, BroadcastResponse, 0);
}

void ShutdownBroadcaster() {
}