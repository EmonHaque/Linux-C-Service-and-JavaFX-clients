#include "BlockingQueue.h"
#include "CommonStructures.h"
#include "Messenger.h"
#include "Structures.h"
#include <malloc.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>

extern byte isRunning;
extern BlockingQueue personalResponses;

static BlockingQueue garbagePersonalResponses;
static pthread_t dispatcherThread, freePersonalResponseThread;

int messageCount = 0;

static void sendShortMessage(ResponsePersonal *r) {
    ShortMessage *message = r->data;
    sendInt(r->sender, r->size);
    sendByte(r->sender, message->isSuccess);
    sendString(r->sender, message->text);
    putInto(&garbagePersonalResponses, r);
}

static void sendHeads(ResponsePersonal *r) {
    Head **list = r->data;
    sendInt(r->sender, r->size);

    for (int i = 0; i < r->count; i++) {
        sendInt(r->sender, list[i]->id);
        sendString(r->sender, list[i]->name);
    }
    putInto(&garbagePersonalResponses, r);
}

static void sendDuplicate(ResponsePersonal *r) {
    char **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        sendString(r->sender, list[i]);
        free(list[i]);
    }
    putInto(&garbagePersonalResponses, r);
}

static void sendEntriesByAccountOrDate(ResponsePersonal *r) {
    ReportEntry **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        sendInt(r->sender, list[i]->id);
        sendInt(r->sender, list[i]->deptId);
        sendInt(r->sender, list[i]->accountId);
        sendInt(r->sender, list[i]->mobileId);

        sendString(r->sender, list[i]->billNo);
        sendString(r->sender, list[i]->period);
        sendString(r->sender, list[i]->transactionId);
        sendString(r->sender, list[i]->date);
        sendString(r->sender, list[i]->fileName);
        sendString(r->sender, list[i]->accountNo);

        sendDouble(r->sender, list[i]->billl);
        sendDouble(r->sender, list[i]->payment);
    }
    putInto(&garbagePersonalResponses, r);
}

static void sendEntriesByMobile(ResponsePersonal *r) {
    MobileEntry **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        sendInt(r->sender, list[i]->billId);
        sendDouble(r->sender, list[i]->amount);

        sendString(r->sender, list[i]->month);
        sendString(r->sender, list[i]->department);
        sendString(r->sender, list[i]->date);
        sendString(r->sender, list[i]->fileName);
        sendString(r->sender, list[i]->accountId);
        sendString(r->sender, list[i]->accountHolder);
        sendString(r->sender, list[i]->address);
        sendString(r->sender, list[i]->billNo);
        sendString(r->sender, list[i]->period);
        sendString(r->sender, list[i]->transactionId);
    }
    putInto(&garbagePersonalResponses, r);
}

static void sendPeriodicEntries(ResponsePersonal *r){
    PeriodicEntry **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++){
        sendInt(r->sender, list[i]->accountId);
        sendInt(r->sender, list[i]->mobileId);

        sendDouble(r->sender, list[i]->bill);
        sendDouble(r->sender, list[i]->payment);

        sendString(r->sender, list[i]->department);
        sendString(r->sender, list[i]->account);
        sendString(r->sender, list[i]->holder);
        sendString(r->sender, list[i]->address);
        sendString(r->sender, list[i]->head);
        sendString(r->sender, list[i]->date);
        sendString(r->sender, list[i]->month);
    }
    putInto(&garbagePersonalResponses, r);
}

static void sendDatePaymentSummary(ResponsePersonal *r){
    DatePaymentSummary **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++){
        sendDouble(r->sender, list[i]->bill);
        sendDouble(r->sender, list[i]->payment);

        sendString(r->sender, list[i]->department);
        sendString(r->sender, list[i]->head);
    }
    putInto(&garbagePersonalResponses, r);
}

static void sendImageFile(ResponsePersonal *r) {
    sendInt(r->sender, r->size);
    sendFile(r->sender, r->data, r->size);
    putInto(&garbagePersonalResponses, r);
}

static void sendBreakup(ResponsePersonal *r) {
    Breakup **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        sendString(r->sender, list[i]->head);

        sendInt(r->sender, list[i]->billId);
        sendInt(r->sender, list[i]->paymentId);

        sendDouble(r->sender, list[i]->billAmount);
        sendDouble(r->sender, list[i]->paymentAmount);
    }
    putInto(&garbagePersonalResponses, r);
}

static void *DispatchPersonalResponse(void *p) {
    pthread_detach(pthread_self());

    while (isRunning) {
        ResponsePersonal *r = takeOutFrom(&personalResponses);
        if (!r) break;

        switch (r->function) {
            case AddDepartment:
            case AddAccount:
            case AddMobile:
            case CheckFileExistence: 
            case EditBillInfo: 
            case EditBillEntry: 
            case EditAccount: 
            case EditHead:
            case EditDepartment:
            case EditMobile: sendShortMessage(r); break;
            case AddHead: {
                if (messageCount == 0) {
                    sendShortMessage(r);
                    messageCount++;
                } else {
                    messageCount--;
                    sendHeads(r);
                }
            } break;
            case AddEntries: {
                ShortMessage *message = r->data;
                if (strcmp(message->text, "duplicate") == 0) {
                    sendShortMessage(r);
                    messageCount++;
                } else {
                    if (messageCount == 0)
                        sendShortMessage(r);
                    else {
                        messageCount--;
                        sendDuplicate(r);
                    }
                }
            } break;
            case GetEntriesByAccount: 
            case GetEntriesByDate: sendEntriesByAccountOrDate(r); break;
            case GetEntriesByMobile: sendEntriesByMobile(r); break;
            case GetPeriodicEntries: sendPeriodicEntries(r); break;
            case GetDatePaymentSummary: sendDatePaymentSummary(r); break;
            case GetImage: sendImageFile(r); break;
            case GetBreakup: sendBreakup(r); break;
        }
    }
    pthread_exit(0);
}
static void *FreePersonalResponse(void *p) {
    pthread_detach(pthread_self());

    while (isRunning) {
        ResponsePersonal *r = takeOutFrom(&garbagePersonalResponses);
        if (!r) break;

        switch (r->function) {
            case GetEntriesByAccount:
            case GetEntriesByDate: {
                ReportEntry **list = r->data;
                for (size_t i = 0; i < r->count; i++) {
                    free(list[i]->billNo);
                    free(list[i]->period);
                    free(list[i]->transactionId);
                    free(list[i]->date);
                    free(list[i]->fileName);
                    free(list[i]->accountNo);
                    free(list[i]);
                }
            } break;
            case GetEntriesByMobile: {
                MobileEntry **list = r->data;
                for (size_t i = 0; i < r->count; i++) {
                    free(list[i]->month);
                    free(list[i]->department);
                    free(list[i]->date);
                    free(list[i]->fileName);
                    free(list[i]->accountId);
                    free(list[i]->accountHolder);
                    free(list[i]->address);
                    free(list[i]->billNo);
                    free(list[i]->period);
                    free(list[i]->transactionId);
                    free(list[i]);
                }
            } break;
            case GetPeriodicEntries:{
                PeriodicEntry **list = r->data;
                for (size_t i = 0; i < r->count; i++){
                    free(list[i]->department);
                    free(list[i]->account);
                    free(list[i]->holder);
                    free(list[i]->address);
                    free(list[i]->head);
                    free(list[i]->date);
                    free(list[i]->month);
                    free(list[i]);
                }
            } break;
            case GetDatePaymentSummary:{
                DatePaymentSummary **list = r->data;
                for (size_t i = 0; i < r->count; i++){
                     free(list[i]->department);
                     free(list[i]->head);
                     free(list[i]);
                }
            } break;
            case GetBreakup: {
                Breakup **list = r->data;
                for (size_t i = 0; i < r->count; i++) {
                    free(list[i]->head);
                    free(list[i]);
                }
            } break;
        };
        free(r->data);
        free(r);
    }
    pthread_exit(0);
}

void InitializeDispatcher() {
    initializeBlockingQueue(&garbagePersonalResponses, 10);

    pthread_create(&dispatcherThread, 0, DispatchPersonalResponse, 0);
    pthread_create(&freePersonalResponseThread, 0, FreePersonalResponse, 0);
}

void ShutdownDispatcher() {
    if (garbagePersonalResponses.isWaiting) {
        pthread_cond_signal(&garbagePersonalResponses.condition);
    }
    // free resources if required
}