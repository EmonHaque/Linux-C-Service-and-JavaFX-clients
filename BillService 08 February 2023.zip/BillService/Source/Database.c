#include "BlockingQueue.h"
#include "CommonDefined.h"
#include "CommonFunctions.h"
#include "CommonStructures.h"
#include "Defined.h"
#include "List.h"
#include "Messenger.h"
#include "Structures.h"

#include <pthread.h>
#include <sqlite3.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

extern byte isRunning;
extern BlockingQueue requests;

BlockingQueue personalResponses, publicResponses;

static sqlite3 *db;
static sqlite3_stmt *command;
static BlockingQueue garbageRequests;
static pthread_t requestProcessThread, freeRequestThread;

static Totals total;
static List accounts, mobiles, heads, departments;
static int maxBillId;
static char *imageDirectory = "/mnt/HDD/images/";

static void initializeListAndQueues() {
    int size = 10;

    initializeList(&accounts, size);
    initializeList(&mobiles, size);
    initializeList(&heads, size);
    initializeList(&departments, size);

    initializeBlockingQueue(&garbageRequests, size);
    initializeBlockingQueue(&personalResponses, size);
    initializeBlockingQueue(&publicResponses, size);
}
static void initializeQueue() {
}

static void sendStartupPackets(int socket) {
    sendInt(socket, total.account);
    Account **ap = accounts.data;
    for (uint i = 0; i < accounts.count; i++) {
        if (sendInt(socket, ap[i]->id) < 0) break;
        sendInt(socket, ap[i]->departmentId);
        sendString(socket, ap[i]->accoutId);
        sendString(socket, ap[i]->name);
        sendString(socket, ap[i]->address);
        sendByte(socket, ap[i]->isWrong);
    }

    Mobile **mp = mobiles.data;
    sendInt(socket, total.mobile);
    for (uint i = 0; i < mobiles.count; i++) {
        if (sendInt(socket, mp[i]->id) < 0) break;
        sendString(socket, mp[i]->number);
        sendString(socket, mp[i]->name);
    }

    Head **hp = heads.data;
    sendInt(socket, total.head);
    for (uint i = 0; i < heads.count; i++) {
        if (sendInt(socket, hp[i]->id) < 0) break;
        sendString(socket, hp[i]->name);
    }

    Department **dp = departments.data;
    sendInt(socket, total.department);
    for (uint i = 0; i < departments.count; i++) {
        if (sendInt(socket, dp[i]->id) < 0) break;
        sendString(socket, dp[i]->name);
    }
}

static void addDepartment(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;
    byte isFound = 0;
    int size = 0;
    char *name = &r->packet[8], *sql;

    Department **dd = departments.data;
    for (uint i = 0; i < departments.count; i++) {
        if (strcasecmp(dd[i]->name, name) == 0) {
            isFound = 1;
            size = sprintf(message->text, "%d", dd[i]->id);
            break;
        }
    }
    if (!isFound) {
        sql = "INSERT INTO Department (Name) VALUES(?)";
        sqlite3_prepare_v2(db, sql, -1, &command, 0);
        sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
        int result = sqlite3_step(command);
        sqlite3_finalize(command);
        if (result != SQLITE_DONE) {
            message->isSuccess = 0;
            size = sprintf(message->text, "Failed to insert Department");
        } else {
            Department *d = malloc(DEPARTMENT_SIZE);
            d->id = departments.count ? dd[departments.count - 1]->id + 1 : 1;
            int len = mallocate(name, &d->name);
            total.department += 4 + len;
            addToList(&departments, d);
            addShortPublicResponse(r, d, 4 + 8 + len); // 4 id, 8 userId + function

            size = sprintf(message->text, "%d", d->id);
        }
    }
    addShortPersonalResponse(r, message, size);
}

static void addAccount(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;
    byte isFound = 0;
    int size = 0;

    char *cursor, *account, *name, *address, *sql;
    int deptId;
    byte isWrong;

    account = strtok_r(&r->packet[8], "", &cursor), cursor++;
    name = strtok_r(0, "", &cursor), cursor++;
    address = strtok_r(0, "", &cursor), cursor++;
    memcpy(&deptId, cursor, 4);
    cursor += 4;
    memcpy(&isWrong, cursor, 1);

    Account **ad = accounts.data;
    for (uint i = 0; i < accounts.count; i++) {
        if (ad[i]->departmentId == deptId && strcasecmp(ad[i]->accoutId, account) == 0) {
            isFound = 1;
            size = sprintf(message->text, "%d", ad[i]->id);
            break;
        }
    }
    if (!isFound) {
        sql = "INSERT INTO Account (DeptId, AccountNo, Name, Address, IsWrong) VALUES(?, ?, ?, ?, ?)";
        sqlite3_prepare_v2(db, sql, -1, &command, 0);
        sqlite3_bind_int(command, 1, deptId);
        sqlite3_bind_text(command, 2, account, -1, SQLITE_STATIC);
        sqlite3_bind_text(command, 3, name, -1, SQLITE_STATIC);
        sqlite3_bind_text(command, 4, address, -1, SQLITE_STATIC);
        sqlite3_bind_int(command, 5, isWrong);
        int result = sqlite3_step(command);
        sqlite3_finalize(command);
        if (result != SQLITE_DONE) {
            message->isSuccess = 0;
            size = sprintf(message->text, "Failed to insert Account");
        } else {
            Account *a = malloc(ACCOUNT_SIZE);
            a->id = accounts.count ? ad[accounts.count - 1]->id + 1 : 1;
            a->departmentId = deptId;
            a->isWrong = isWrong;
            int len = 9;
            len += mallocate(account, &a->accoutId);
            len += mallocate(name, &a->name);
            len += mallocate(address, &a->address);
            total.account += len;
            addToList(&accounts, a);
            addShortPublicResponse(r, a, 8 + len); // 8 userId + function

            size = sprintf(message->text, "%d", a->id);
        }
    }
    addShortPersonalResponse(r, message, size);
}

static void addMobile(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;
    byte isFound = 0;
    int size = 0;

    char *number, *name, *sql;
    number = strtok_r(&r->packet[8], "", &name), name++;

    Mobile **md = mobiles.data;
    for (uint i = 0; i < mobiles.count; i++) {
        if (strcmp(number, md[i]->number) == 0) {
            isFound = 1;
            size = sprintf(message->text, "%d", md[i]->id);
            break;
        }
    }
    if (!isFound) {
        sql = "INSERT INTO Mobile (MobileNo, Name) VALUES(?, ?)";
        sqlite3_prepare_v2(db, sql, -1, &command, 0);
        sqlite3_bind_text(command, 1, number, -1, SQLITE_STATIC);
        sqlite3_bind_text(command, 2, name, -1, SQLITE_STATIC);
        int result = sqlite3_step(command);
        sqlite3_finalize(command);
        if (result != SQLITE_DONE) {
            message->isSuccess = 0;
            size = sprintf(message->text, "Failed to insert Mobile");
        } else {
            Mobile *m = malloc(MOBILE_SIZE);
            m->id = mobiles.count ? ((Mobile **)mobiles.data)[mobiles.count - 1]->id : 1;
            int len = 4;
            len += mallocate(number, &m->number);
            len += mallocate(name, &m->name);
            total.mobile += len;
            addToList(&mobiles, m);
            addShortPublicResponse(r, m, 8 + len);

            size = sprintf(message->text, "%d", m->id);
        }
    }
    addShortPersonalResponse(r, message, size);
}

static void addHead(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;
    int size = 0;

    int length;
    memcpy(&length, &r->packet[8], 4);

    Head **hd = heads.data;
    int lastId = heads.count ? hd[heads.count - 1]->id : 0;

    List requestedheads = {0, length, malloc(requestedheads.capacity * POINTER_SIZE)};
    char *cursor, *head, *sql;

    for (uint i = 0; i < length; i++) {
        NewHead *nh = malloc(sizeof(NewHead));
        if (i == 0)
            head = strtok_r(&r->packet[12], "", &cursor), cursor++;
        else
            head = strtok_r(0, "", &cursor), cursor++;

        nh->length = mallocate(head, &nh->name);
        nh->doesExist = 0;
        for (uint j = 0; j < heads.count; j++) {
            if (strcasecmp(head, hd[i]->name) == 0) {
                nh->doesExist = 1;
                nh->id = hd[i]->id;
                break;
            }
        }
        addToList(&requestedheads, nh);
    }

    int result = SQLITE_DONE;
    sql = "INSERT INTO Heads (Name) VALUES(?)";
    sqlite3_exec(db, "BEGIN", 0, 0, 0);

    NewHead **nh = requestedheads.data;
    int addedNumber = 0;
    for (uint i = 0; i < length; i++) {
        if (nh[i]->doesExist) continue;

        addedNumber++;
        sqlite3_prepare_v2(db, sql, -1, &command, 0);
        sqlite3_bind_text(command, 1, nh[i]->name, -1, SQLITE_STATIC);
        result = sqlite3_step(command);
        sqlite3_finalize(command);

        if (result == SQLITE_DONE) {
            ++lastId;
            nh[i]->id = lastId;
        } else {
            message->isSuccess = 0;
            size = sprintf(message->text, "Failed to insert Head");
            break;
        }
    }

    if (result == SQLITE_DONE) {
        size = sprintf(message->text, "Successfully added Head");
        addShortPersonalResponse(r, message, size);

        sqlite3_exec(db, "COMMIT", 0, 0, 0);
        List personalList = {0, addedNumber, malloc(personalList.capacity * POINTER_SIZE)};
        List publicList = {0, addedNumber, malloc(publicList.capacity * POINTER_SIZE)};
        int newLength = 0;

        for (uint i = 0; i < length; i++) {
            if (nh[i]->doesExist) continue;

            int len = 4;
            Head *h = malloc(HEAD_SIZE);
            h->id = nh[i]->id;
            len += mallocate(nh[i]->name, &h->name);
            addToList(&heads, h);
            addToList(&personalList, h);
            addToList(&publicList, h);

            newLength += len;
            total.head += len;
        }
        addLongPersonalResponse(r, personalList, newLength);
        addLongPublicResponse(r, publicList, newLength);

    } else {
        sqlite3_exec(db, "ROLLBACK", 0, 0, 0);
    }

    for (uint i = 0; i < length; i++) {
        free(nh[i]->name);
    }
    free(requestedheads.data);
}

static void checkFileExistence(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;

    int size = 0;
    char *name = &r->packet[8];
    char fullPath[500];

    int length = sprintf(fullPath, "%s", imageDirectory);
    sprintf(fullPath + length, "%s", name);

    if (access(fullPath, F_OK) == 0) {
        message->isSuccess = 0;
        size = sprintf(message->text, "file with same name exists");
    } else {
        size = sprintf(message->text, "valid");
    }
    addShortPersonalResponse(r, message, size);
}

static void addEntries(Request *r) {
    int numberOfBill;
    memcpy(&numberOfBill, &r->packet[8], 4);
    EntryInsert entries[numberOfBill];
    int index = 12;

    for (uint i = 0; i < numberOfBill; i++) {
        int *ptr = &r->packet[index];
        EntryInsert e;
        e.billCount = *ptr++;
        e.paymentCount = *ptr++;
        e.imageLength = *ptr++;
        e.deptId = *ptr++;
        e.customerId = *ptr++;
        e.mobileId = *ptr;

        index += 24;
        char *begin = &r->packet[index], *end;

        e.billNo = strtok_r(begin, "", &end), end++;
        e.period = strtok_r(0, "", &end), end++;
        e.date = strtok_r(0, "", &end), end++;
        e.transactionId = strtok_r(0, "", &end), end++;
        e.fileName = strtok_r(0, "", &end), end++;

        e.image = malloc(e.imageLength * sizeof(char));
        memcpy(e.image, end, e.imageLength);

        end += e.imageLength;
        index += (end - begin);

        e.bills = malloc(e.billCount * sizeof(void *));
        for (uint j = 0; j < e.billCount; j++) {
            EntryAmount *ea = malloc(sizeof(EntryAmount));
            memcpy(&ea->headId, &r->packet[index], 4);
            memcpy(&ea->amount, &r->packet[index + 4], 8);
            e.bills[j] = ea;
            index += 12;
        }

        e.payments = malloc(e.paymentCount * sizeof(void *));
        for (uint j = 0; j < e.paymentCount; j++) {
            EntryAmount *ea = malloc(sizeof(EntryAmount));
            memcpy(&ea->headId, &r->packet[index], 4);
            memcpy(&ea->amount, &r->packet[index + 4], 8);
            e.payments[j] = ea;
            index += 12;
        }
        entries[i] = e;
    }

    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;
    int size = 0;
    List duplicates = {0, 5, malloc(duplicates.capacity * POINTER_SIZE)};
    int duplicateLength = 0;

    for (int i = 0; i < numberOfBill; i++) {
        EntryInsert e = entries[i];
        char fullPath[200];
        int length = sprintf(fullPath, "%s", imageDirectory);
        sprintf(fullPath + length, "%s", e.fileName);

        if (access(fullPath, F_OK) == 0) {
            if (message->isSuccess) {
                message->isSuccess = 0;
                size = sprintf(message->text, "duplicate");
            }
            char *name;
            duplicateLength += mallocate(e.fileName, &name);
            addToList(&duplicates, name);
        }
    }

    if (message->isSuccess) {
        char *btSql =
            "INSERT INTO Bills(DeptId, AccountId, BillNo, FileName, Period, PaymentDate, MobileId, TransactionId) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        char *beSql = "INSERT INTO BillEntries(BillId, HeadId, Amount) VALUES(?, ?, ?)";
        char *peSql = "INSERT INTO PaymentEntries(BillId, HeadId, Amount) VALUES(?, ?, ?)";

        int result = SQLITE_DONE;
        sqlite3_exec(db, "BEGIN", 0, 0, 0);
        int id = maxBillId;

        for (int i = 0; i < numberOfBill; i++) {
            EntryInsert e = entries[i];

            char fullPath[200];
            int length = sprintf(fullPath, "%s", imageDirectory);
            sprintf(fullPath + length, "%s", e.fileName);

            FILE *imageFile = fopen(fullPath, "w");
            for (uint j = 0; j < e.imageLength; j++) {
                fputc(e.image[j], imageFile);
            }
            fclose(imageFile);

            int billId = ++id;

            sqlite3_prepare_v2(db, btSql, -1, &command, 0);
            sqlite3_bind_int(command, 1, e.deptId);
            sqlite3_bind_int(command, 2, e.customerId);
            if (e.billNo)
                sqlite3_bind_text(command, 3, e.billNo, -1, SQLITE_STATIC);
            else
                sqlite3_bind_null(command, 3);
            sqlite3_bind_text(command, 4, e.fileName, -1, SQLITE_STATIC);
            sqlite3_bind_text(command, 5, e.period, -1, SQLITE_STATIC);
            sqlite3_bind_text(command, 6, e.date, -1, SQLITE_STATIC);
            sqlite3_bind_int(command, 7, e.mobileId);
            sqlite3_bind_text(command, 8, e.transactionId, -1, SQLITE_STATIC);

            result = sqlite3_step(command);
            sqlite3_finalize(command);

            if (result != SQLITE_DONE) {
                message->isSuccess = 0;
                size = sprintf(message->text, "failed to insert in Bills");
                break;
            }

            for (int j = 0; j < e.billCount; j++) {
                EntryAmount ea = *e.bills[j];
                sqlite3_prepare_v2(db, beSql, -1, &command, 0);
                sqlite3_bind_int(command, 1, billId);
                sqlite3_bind_int(command, 2, ea.headId);
                sqlite3_bind_double(command, 3, ea.amount);

                result = sqlite3_step(command);
                sqlite3_finalize(command);

                if (result != SQLITE_DONE) {
                    message->isSuccess = 0;
                    size = sprintf(message->text, "failed to insert in BillEntries");
                    break;
                }
            }
            if (result != SQLITE_DONE) break;

            for (int j = 0; j < e.paymentCount; j++) {
                EntryAmount ea = *e.payments[j];
                sqlite3_prepare_v2(db, peSql, -1, &command, 0);
                sqlite3_bind_int(command, 1, billId);
                sqlite3_bind_int(command, 2, ea.headId);
                sqlite3_bind_double(command, 3, ea.amount);

                result = sqlite3_step(command);
                sqlite3_finalize(command);

                if (result != SQLITE_DONE) {
                    message->isSuccess = 0;
                    size = sprintf(message->text, "failed to insert in PaymentEntries");
                    break;
                }
            }
            if (result != SQLITE_DONE) break;
        }
        if (result == SQLITE_DONE) {
            sqlite3_exec(db, "COMMIT", 0, 0, 0);
            maxBillId = id;
            size = sprintf(message->text, "successfully added entries");
        } else {
            sqlite3_exec(db, "ROLLBACK", 0, 0, 0);

            for (int i = 0; i < numberOfBill; i++) {
                EntryInsert e = entries[i];
                char fullPath[200];
                int length = sprintf(fullPath, "%s", imageDirectory);
                sprintf(fullPath + length, "%s", e.fileName);

                if (access(fullPath, F_OK) == 0) {
                    remove(fullPath);
                }
            }
        }
        addShortPersonalResponse(r, message, size);
    } else {
        addShortPersonalResponse(r, message, size);
        addLongPersonalResponse(r, duplicates, duplicateLength);
    }

    for (uint i = 0; i < numberOfBill; i++) {
        EntryInsert e = entries[i];
        free(e.image);
        for (uint j = 0; j < e.billCount; j++) {
            free(e.bills[j]);
        }
        for (uint j = 0; j < e.paymentCount; j++) {
            free(e.payments[j]);
        }
        free(e.bills);
        free(e.payments);
    }
}

static void getEntriesByAccount(Request *r) {
    int accountId;
    memcpy(&accountId, &r->packet[8], 4);
    char sql[1000];
    sprintf(sql,
            "SELECT b.Id, b.DeptId, AccountId, MobileId, coalesce(BillNo, ''), Period, TransactionId, PaymentDate, FileName, "
            "(SELECT sum(Amount) FROM BillEntries WHERE BillId = b.Id), "
            "(SELECT sum(Amount) FROM PaymentEntries WHERE BillId = b.Id), "
            "a.AccountNo "
            "FROM Bills b "
            "LEFT JOIN Account a ON a.Id = b.AccountId "
            "WHERE AccountId = %d "
            "ORDER BY PaymentDate",
            accountId);
    int size = 0;
    List list = {0, 50, malloc(list.capacity * POINTER_SIZE)};
    sqlite3_prepare_v2(db, sql, -1, &command, 0);
    while (sqlite3_step(command) == SQLITE_ROW) {
        ReportEntry *e = malloc(REPORT_ENTRY_SIZE);
        e->id = sqlite3_column_int(command, 0);
        e->deptId = sqlite3_column_int(command, 1);
        e->accountId = sqlite3_column_int(command, 2);
        e->mobileId = sqlite3_column_int(command, 3);
        e->billl = sqlite3_column_double(command, 9);
        e->payment = sqlite3_column_double(command, 10);
        // clang-format off
        size += (4 * 4 + 2 * 8 
            + mallocate(sqlite3_column_text(command, 4), &e->billNo) 
            + mallocate(sqlite3_column_text(command, 5), &e->period) 
            + mallocate(sqlite3_column_text(command, 6), &e->transactionId) 
            + mallocate(sqlite3_column_text(command, 7), &e->date) 
            + mallocate(sqlite3_column_text(command, 8), &e->fileName) 
            + mallocate(sqlite3_column_text(command, 11), &e->accountNo)
        );
        // clang-format on
        addToList(&list, e);
    }
    sqlite3_finalize(command);
    addLongPersonalResponse(r, list, size);
}

static void getEntriesByMobile(Request *r) {
    int mobileId;
    memcpy(&mobileId, &r->packet[8], 4);
    char sql[1000];
    char *monthYearFormat = "%m, %Y";

    sprintf(sql, "WITH t1 AS( "
                 "SELECT Bills.Id, Department.Name Dept, Account.AccountNo Account, PaymentDate, FileName, "
                 "strftime('%s', PaymentDate) Month, "
                 "Account.Name, Account.Address, BillNo, Period, TransactionId FROM Bills "
                 "LEFT JOIN Account ON Account.Id = Bills.AccountId "
                 "LEFT JOIN Department ON Department.Id = Bills.DeptId "
                 "WHERE MobileId = %d "
                 "), "
                 "t2 AS( "
                 "SELECT BillId, SUM(Amount) Amount FROM PaymentEntries WHERE BillId IN(SELECT Id FROM t1) "
                 "GROUP BY BillId "
                 ") "
                 "SELECT Month, Dept, PaymentDate, t2.Amount, FileName, Account, Name, Address, Id, BillNo, Period, TransactionId FROM t1 "
                 "LEFT JOIN t2 ON t2.BillId = t1.Id "
                 "ORDER BY PaymentDate",
            monthYearFormat, mobileId);
    int size = 0;
    List list = {0, 50, malloc(list.capacity * POINTER_SIZE)};
    sqlite3_prepare_v2(db, sql, -1, &command, 0);
    while (sqlite3_step(command) == SQLITE_ROW) {
        MobileEntry *e = malloc(sizeof(MobileEntry));
        e->amount = sqlite3_column_double(command, 3);
        e->billId = sqlite3_column_int(command, 8);
        // clang-format off
        size += (8 + 4
            + mallocate(sqlite3_column_text(command, 0), &e->month)
            + mallocate(sqlite3_column_text(command, 1), &e->department)
            + mallocate(sqlite3_column_text(command, 2), &e->date)
            + mallocate(sqlite3_column_text(command, 4), &e->fileName)
            + mallocate(sqlite3_column_text(command, 5), &e->accountId)
            + mallocate(sqlite3_column_text(command, 6), &e->accountHolder)
            + mallocate(sqlite3_column_text(command, 7), &e->address)
            + mallocate(sqlite3_column_text(command, 9), &e->billNo)
            + mallocate(sqlite3_column_text(command, 10), &e->period)
            + mallocate(sqlite3_column_text(command, 11), &e->transactionId)
        );
        // clang-format on
        addToList(&list, e);
    }
    sqlite3_finalize(command);
    addLongPersonalResponse(r, list, size);
}

// same as getEntriesByAccount, only change is in WHERE clause
static void getEntriesByDate(Request *r) {
    char *date = &r->packet[8];
    char sql[1000];
    sprintf(sql,
            "SELECT b.Id, b.DeptId, AccountId, MobileId, coalesce(BillNo, ''), Period, TransactionId, PaymentDate, FileName, "
            "(SELECT sum(Amount) FROM BillEntries WHERE BillId = b.Id), "
            "(SELECT sum(Amount) FROM PaymentEntries WHERE BillId = b.Id), "
            "a.AccountNo "
            "FROM Bills b "
            "LEFT JOIN Account a ON a.Id = b.AccountId "
            "WHERE PaymentDate = '%s' "
            "ORDER BY PaymentDate",
            date);
    int size = 0;
    List list = {0, 50, malloc(list.capacity * POINTER_SIZE)};
    sqlite3_prepare_v2(db, sql, -1, &command, 0);
    while (sqlite3_step(command) == SQLITE_ROW) {
        ReportEntry *e = malloc(REPORT_ENTRY_SIZE);
        e->id = sqlite3_column_int(command, 0);
        e->deptId = sqlite3_column_int(command, 1);
        e->accountId = sqlite3_column_int(command, 2);
        e->mobileId = sqlite3_column_int(command, 3);
        e->billl = sqlite3_column_double(command, 9);
        e->payment = sqlite3_column_double(command, 10);
        // clang-format off
        size += (4 * 4 + 2 * 8 
            + mallocate(sqlite3_column_text(command, 4), &e->billNo) 
            + mallocate(sqlite3_column_text(command, 5), &e->period) 
            + mallocate(sqlite3_column_text(command, 6), &e->transactionId) 
            + mallocate(sqlite3_column_text(command, 7), &e->date) 
            + mallocate(sqlite3_column_text(command, 8), &e->fileName) 
            + mallocate(sqlite3_column_text(command, 11), &e->accountNo)
        );
        // clang-format on
        addToList(&list, e);
    }
    sqlite3_finalize(command);
    addLongPersonalResponse(r, list, size);
}

static void getPaymentSummaryByDate(Request *r) {
    char *date = &r->packet[8];
    char sql[1500];
    sprintf(sql, "WITH t0 AS( "
                 "SELECT Id, DeptId FROM Bills WHERE PaymentDate = '%s' "
                 "), "
                 "t1 (DeptId, BillId, HeadId, Amount) AS( "
                 "SELECT t.DeptId, e.BillId, e.HeadId, e.Amount FROM BillEntries e "
                 "LEFT JOIN t0 t ON t.id = e.BillId "
                 "WHERE BillId IN (SELECT Id FROM t0) "
                 "), "
                 "t2 (DeptId, BillId, HeadId, Amount) AS( "
                 "SELECT t.DeptId, e.BillId, e.HeadId, e.Amount FROM PaymentEntries e "
                 "LEFT JOIN t0 t ON t.id = e.BillId "
                 "WHERE BillId IN (SELECT Id FROM t0) "
                 "), "
                 "t3 (DeptId, HeadId, Payment, Bill) AS( "
                 "SELECT t1.DeptId, t1.HeadId, t2.Amount, t1.Amount "
                 "FROM t1 LEFT JOIN t2 ON  "
                 "t1.DeptId = t2.DeptId AND  t1.BillId = t2.BillId AND t1.HeadId = t2.HeadId "
                 "UNION ALL "
                 "SELECT t2.DeptId, t2.HeadId, t2.Amount, t1.Amount "
                 "FROM t2 LEFT JOIN t1 ON "
                 "t2.DeptId = t1.DeptId AND t2.BillId = t1.BillId AND t2.HeadId = t1.HeadId "
                 "WHERE t1.HeadId IS NULL "
                 ") "
                 "SELECT d.name, h.name, coalesce(SUM(t.Payment), 0), coalesce(SUM(t.Bill), 0) FROM t3 t "
                 "LEFT JOIN Department d ON d.Id = t.DeptId "
                 "LEFT JOIN Heads h ON h.Id = t.HeadId "
                 "GROUP BY d.Name, h.Name "
                 "ORDER BY d.Name",
            date);

    int size = 0;
    List list = {0, 10, malloc(list.capacity * POINTER_SIZE)};
    sqlite3_prepare_v2(db, sql, -1, &command, 0);
    while (sqlite3_step(command) == SQLITE_ROW) {
        DatePaymentSummary *e = malloc(sizeof(DatePaymentSummary));
        e->payment = sqlite3_column_double(command, 2);
        e->bill = sqlite3_column_double(command, 3);
        // clang-format off
        size += ( 8 * 2
            + mallocate(sqlite3_column_text(command, 0), &e->department) 
            + mallocate(sqlite3_column_text(command, 1), &e->head) 
        );
        // clang-format on
        addToList(&list, e);
    }
    sqlite3_finalize(command);
    addLongPersonalResponse(r, list, size);
}

static void getPeriodicEntries(Request *r) {
    char *start, *end;
    start = strtok_r(&r->packet[8], "", &end), end++;
    char *monthFormat = "%Y-%m";
    char sql[2000];
    sprintf(sql, "WITH T1 AS( "
                 "SELECT Id FROM Bills "
                 "WHERE PaymentDate BETWEEN "
                 "'%s' AND '%s' "
                 "), "
                 "T2(Date, DeptId, AccountId, Head, Bill, Payment, UID, MobileId) AS( "
                 "SELECT bi.PaymentDate, bi.DeptId, bi.AccountId, h.Name, be.Amount, null, bi.Id, bi.MobileId "
                 "FROM BillEntries be "
                 "LEFT JOIN Bills bi ON bi.Id = be.BillId "
                 "LEFT JOIN Heads h ON h.Id = be.HeadId "
                 "WHERE be.BillId IN (SELECT * FROM T1) "
                 "), "
                 "T3(Date, DeptId, AccountId, Head, Bill, Payment, UID, MobileId) AS( "
                 "SELECT bi.PaymentDate, bi.DeptId, bi.AccountId, h.Name, null, pe.Amount, bi.Id, bi.MobileId "
                 "FROM PaymentEntries pe "
                 "LEFT JOIN Bills bi ON bi.Id = pe.BillId "
                 "LEFT JOIN Heads h ON h.Id = pe.HeadId "
                 "WHERE pe.BillId IN (SELECT * FROM T1) "
                 "), "
                 "T4 (Date, DeptId, AccountId, Head, Bill, Payment, MobileId) AS ( "
                 "SELECT t2.Date, t2.DeptId, t2.AccountId, t2.Head, coalesce(t2.Bill, 0), coalesce(t3.Payment, 0), t2.MobileId "
                 "FROM T2 t2 "
                 "LEFT JOIN T3 t3 USING(AccountId, Head, UID) "
                 "UNION  ALL "
                 "SELECT t3.Date, t3.DeptId, t3.AccountId, t3.Head, coalesce(t2.Bill, 0), coalesce(t3.Payment, 0), t3.MobileId "
                 "FROM T3 t3 "
                 "LEFT JOIN T2 t2 USING(AccountId, Head, UID) "
                 "WHERE t2.Head IS NULL "
                 ") "
                 "SELECT d.Name, a.AccountNo, a.Name, a.Address, t.Head, t.Bill, t.Payment, t.Date, t.AccountId, "
                 "MobileId, strftime('%s', t.Date) Month FROM T4 t "
                 "LEFT JOIN Department d ON d.Id = t.DeptId "
                 "LEFT JOIN Account a ON a.Id = t.AccountId",
            start, end, monthFormat);

    int size = 0;
    List list = {0, 50, malloc(list.capacity * POINTER_SIZE)};
    sqlite3_prepare_v2(db, sql, -1, &command, 0);
    while (sqlite3_step(command) == SQLITE_ROW) {
        PeriodicEntry *e = malloc(sizeof(PeriodicEntry));
        e->bill = sqlite3_column_double(command, 5);
        e->payment = sqlite3_column_double(command, 6);
        e->accountId = sqlite3_column_int(command, 8);
        e->mobileId = sqlite3_column_int(command, 9);
        // clang-format off
        size += (
            8 * 2 + 4 * 2 
            + mallocate(sqlite3_column_text(command, 0), &e->department) 
            + mallocate(sqlite3_column_text(command, 1), &e->account) 
            + mallocate(sqlite3_column_text(command, 2), &e->holder) 
            + mallocate(sqlite3_column_text(command, 3), &e->address) 
            + mallocate(sqlite3_column_text(command, 4), &e->head) 
            + mallocate(sqlite3_column_text(command, 7), &e->date) 
            + mallocate(sqlite3_column_text(command, 10), &e->month)
        );
        // clang-format on
        addToList(&list, e);
    }
    sqlite3_finalize(command);
    addLongPersonalResponse(r, list, size);
}

static void getImage(Request *r) {
    char *fileName = &r->packet[8];
    char fullPath[200];
    int length = sprintf(fullPath, "%s", imageDirectory);
    sprintf(fullPath + length, "%s", fileName);

    FILE *file = fopen(fullPath, "r"); // mode rb?
    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    char *buffer = malloc(fileSize);

    fseek(file, 0, SEEK_SET); /* same as rewind(file); */
    fread(buffer, fileSize, 1, file);
    fclose(file);

    addFilePersonalResponse(r, buffer, fileSize);
}

static void getBreakup(Request *r) {
    int billId;
    memcpy(&billId, &r->packet[8], 4);
    char sql[1500];

    // BillId, PaymentId used in client side?

    // T3 FULL OUTER JOIN
    sprintf(sql, "WITH T1(Head, Bill, Payment, BillId, PaymentId) AS( "
                 "SELECT HeadId, Amount , null, Id, null FROM BillEntries "
                 "WHERE BillId = %d "
                 "), "
                 "T2(Head, Bill, Payment, BillId, PaymentId) AS( "
                 "SELECT HeadId, null, Amount, BillId, Id FROM PaymentEntries "
                 "WHERE BillId = %d "
                 "), "
                 "T3(Head, Bill, Payment, BillId, PaymentId) AS ( "
                 "SELECT t1.Head, t1.Bill, t2.Payment, t1.BillId, t2.PaymentId FROM T1 t1 LEFT JOIN T2 t2 ON t1.Head = t2.Head "
                 "UNION  ALL "
                 "SELECT t2.Head, t1.Bill, t2.Payment, t1.BillId, t2.PaymentId FROM T2 t2 LEFT JOIN T1 t1 ON t2.Head = t1.Head "
                 "WHERE t1.Head IS NULL "
                 ") "
                 "SELECT h.Name, coalesce(Bill, 0), coalesce(Payment, 0), coalesce(BillId, 0), coalesce(PaymentId, 0) "
                 "FROM T3 LEFT JOIN Heads h ON h.Id = Head "
                 "ORDER BY h.Id",
            billId, billId);

    int size = 0;
    List list = {0, 5, malloc(list.capacity * POINTER_SIZE)};
    sqlite3_prepare_v2(db, sql, -1, &command, 0);
    while (sqlite3_step(command) == SQLITE_ROW) {
        Breakup *e = malloc(sizeof(Breakup));
        e->billAmount = sqlite3_column_double(command, 1);
        e->paymentAmount = sqlite3_column_double(command, 2);
        e->billId = sqlite3_column_int(command, 3);
        e->paymentId = sqlite3_column_int(command, 4);
        size += 8 * 2 + 4 * 2 + mallocate(sqlite3_column_text(command, 0), &e->head);
        addToList(&list, e);
    }
    sqlite3_finalize(command);
    addLongPersonalResponse(r, list, size);
}

static void editBillInfo(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;

    int billId, mobileId, size = 0;
    byte needFileRename;
    char *date, *billNo, *transactionId, *period, *newFile, *oldFile, *cursor;
    memcpy(&billId, &r->packet[8], 4);
    memcpy(&mobileId, &r->packet[12], 4);
    memcpy(&needFileRename, &r->packet[16], 1);

    date = strtok_r(&r->packet[17], "", &cursor), cursor++;
    billNo = strtok_r(0, "", &cursor), cursor++;
    transactionId = strtok_r(0, "", &cursor), cursor++;
    period = strtok_r(0, "", &cursor), cursor++;
    newFile = strtok_r(0, "", &cursor), cursor++;
    oldFile = cursor;

    char newPath[500], oldPath[500];
    if (needFileRename) {
        int length = sprintf(newPath, "%s", imageDirectory);
        sprintf(newPath + length, "%s", newFile);
        if (access(newPath, F_OK) == 0) {
            message->isSuccess = 0;
            size = sprintf(message->text, "file name %s exists", newFile);
        } else {
            length = sprintf(oldPath, "%s", imageDirectory);
            sprintf(oldPath + length, "%s", oldFile);
            rename(oldPath, newPath);
        }
    }
    if (message->isSuccess) {
        if (needFileRename) {
            char *sql = "UPDATE Bills SET BillNo = ?, Period = ?, MobileId = ?, PaymentDate = ?, "
                        "TransactionId = ?, FileName = ? WHERE Id = ?";
            sqlite3_prepare_v2(db, sql, -1, &command, 0);
            sqlite3_bind_text(command, 4, date, -1, SQLITE_STATIC);
            sqlite3_bind_text(command, 5, transactionId, -1, SQLITE_STATIC);
            sqlite3_bind_text(command, 6, newFile, -1, SQLITE_STATIC);
            sqlite3_bind_int(command, 7, billId);
        } else {
            char *sql = "UPDATE Bills SET BillNo = ?, Period = ?, MobileId = ? WHERE Id = ?";
            sqlite3_prepare_v2(db, sql, -1, &command, 0);
            sqlite3_bind_int(command, 4, billId);
        }
        if (billNo)
            sqlite3_bind_text(command, 1, billNo, -1, SQLITE_STATIC);
        else
            sqlite3_bind_null(command, 1);

        sqlite3_bind_text(command, 2, period, -1, SQLITE_STATIC);
        sqlite3_bind_int(command, 3, mobileId);

        int result = sqlite3_step(command);
        sqlite3_finalize(command);
        if (result == SQLITE_DONE) {
            size = sprintf(message->text, "Successfully updated bill info");

            EditedBillInfo *info = malloc(sizeof(EditedBillInfo));
            info->billId = billId;
            info->mobileId = mobileId;
            info->fileRenamed = needFileRename;
            int infoSize = 4 * 2 + 1;
            infoSize += mallocate(date, &info->date);
            infoSize += mallocate(billNo, &info->billNo);
            infoSize += mallocate(transactionId, &info->transactionId);
            infoSize += mallocate(period, &info->period);
            infoSize += mallocate(newFile, &info->fileName);
            addShortPublicResponse(r, info, 8 + infoSize);
        } else {
            if (needFileRename) {
                rename(newPath, oldPath);
            }
            message->isSuccess = 0;
            size = sprintf(message->text, "Failed to update Bill info");
        }
    }
    addShortPersonalResponse(r, message, size);
}

static void editBillEntry(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;
    int size = 0;
    int offset = 8;
    int billId = 0;

    int numberOfElements = (r->length - offset) / sizeof(EditedEntry);
    EditedEntry entries[numberOfElements];

    for (uint i = 0; i < numberOfElements; i++) {
        memcpy(&entries[i].billId, &r->packet[offset], 4);
        memcpy(&entries[i].headId, &r->packet[offset + 4], 4);
        memcpy(&entries[i].payment, &r->packet[offset + 8], 8);
        memcpy(&entries[i].bill, &r->packet[offset + 16], 8);
        offset += 24;

        if (!billId) billId = entries[i].billId;
    }

    char *deleteBill = "DELETE FROM BillEntries WHERE BillId = ?";
    char *deletePayment = "DELETE FROM PaymentEntries WHERE BillId = ?";
    char *insertBill = "INSERT INTO BillEntries(BillId, HeadId, Amount) VALUES(?, ?, ?)";
    char *insertPayment = "INSERT INTO PaymentEntries(BillId, HeadId, Amount) VALUES(?, ?, ?)";

    sqlite3_exec(db, "BEGIN", 0, 0, 0);
    sqlite3_prepare_v2(db, deleteBill, -1, &command, 0);
    sqlite3_bind_int(command, 1, billId);
    int result = sqlite3_step(command);
    sqlite3_finalize(command);

    if (result != SQLITE_DONE) {
        message->isSuccess = 0;
        size = sprintf(&message->text, "Failed to delete bills");
    }
    if (message->isSuccess) {
        sqlite3_prepare_v2(db, deletePayment, -1, &command, 0);
        sqlite3_bind_int(command, 1, billId);
        result = sqlite3_step(command);
        sqlite3_finalize(command);

        if (result != SQLITE_DONE) {
            message->isSuccess = 0;
            size = sprintf(&message->text, "Failed to delete payments");
        }
    }
    if (message->isSuccess) {
        for (int i = 0; i < numberOfElements; i++) {
            EditedEntry e = entries[i];
            if (e.bill <= 0) continue;

            sqlite3_prepare_v2(db, insertBill, -1, &command, 0);
            sqlite3_bind_int(command, 1, e.billId);
            sqlite3_bind_int(command, 2, e.headId);
            sqlite3_bind_double(command, 3, e.bill);
            result = sqlite3_step(command);
            sqlite3_finalize(command);

            if (result != SQLITE_DONE) {
                message->isSuccess = 0;
                size = sprintf(&message->text, "Failed to insert bills");
                break;
            }
        }
        if (message->isSuccess) {
            for (int i = 0; i < numberOfElements; i++) {
                EditedEntry e = entries[i];
                if (e.payment <= 0) continue;

                sqlite3_prepare_v2(db, insertPayment, -1, &command, 0);
                sqlite3_bind_int(command, 1, e.billId);
                sqlite3_bind_int(command, 2, e.headId);
                sqlite3_bind_double(command, 3, e.payment);
                result = sqlite3_step(command);
                sqlite3_finalize(command);

                if (result != SQLITE_DONE) {
                    message->isSuccess = 0;
                    size = sprintf(&message->text, "Failed to insert payments");
                    break;
                }
            }
        }
    }
    if (message->isSuccess) {
        sqlite3_exec(db, "COMMIT", 0, 0, 0);
        size = sprintf(&message->text, "Successfully edited entries");

        List list = {0, numberOfElements, malloc(list.capacity * POINTER_SIZE)};
        for (int i = 0; i < numberOfElements; i++) {
            EditedEntry *e = malloc(sizeof(EditedEntry));
            e->billId = entries[i].billId;
            e->headId = entries[i].headId;
            e->payment = entries[i].payment;
            e->bill = entries[i].bill;
            addToList(&list, e);
        }
        addLongPublicResponse(r, list, numberOfElements * sizeof(EditedEntry));

    } else {
        sqlite3_exec(db, "ROLLBACK", 0, 0, 0);
    }
    addShortPersonalResponse(r, message, size);
}

static void editAccount(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;
    int size = 0;

    int id, deptId;
    byte isWrong;
    char *accountId, *holder, *address, *sql;

    memcpy(&id, &r->packet[8], 4);
    memcpy(&deptId, &r->packet[12], 4);
    memcpy(&isWrong, &r->packet[16], 1);

    accountId = strtok_r(&r->packet[17], "", &address), address++;
    holder = strtok_r(0, "", &address), address++;

    Account **ap = accounts.data;
    Account *a;
    for (int i = 0; i < accounts.count; i++) {
        if (ap[i]->id == id) {
            a = ap[i];
            for (int j = 0; j < accounts.count; j++) {
                if (ap[j]->departmentId != deptId) continue;
                if (strcasecmp(accountId, ap[j]->accoutId) == 0) {
                    message->isSuccess = 0;
                    size = sprintf(&message->text, "account exists");
                    break;
                }
            }
            break;
        }
    }

    if (message->isSuccess) {
        sql = "UPDATE Account SET AccountNo = ?, Name = ?, Address = ?, IsWrong = ? WHERE Id = ?";
        sqlite3_prepare_v2(db, sql, -1, &command, 0);
        sqlite3_bind_text(command, 1, accountId, -1, SQLITE_STATIC);
        sqlite3_bind_text(command, 2, holder, -1, SQLITE_STATIC);
        sqlite3_bind_text(command, 3, address, -1, SQLITE_STATIC);
        sqlite3_bind_int(command, 4, isWrong);
        sqlite3_bind_int(command, 5, id);

        int result = sqlite3_step(command);
        sqlite3_finalize(command);

        if (result != SQLITE_DONE) {
            message->isSuccess = 0;
            size = sprintf(&message->text, "Failed to update account");
        } else {
            size = sprintf(&message->text, "Successfully edited");
            a->isWrong = isWrong;

            int len = strlen(a->accoutId);
            len += strlen(a->name);
            len += strlen(a->address);

            total.account -= (len + 3);

            free(a->accoutId);
            free(a->name);
            free(a->address);

            len = 0;
            len += mallocate(accountId, &a->accoutId);
            len += mallocate(holder, &a->name);
            len += mallocate(address, &a->address);

            total.account += len;

            addShortPublicResponse(r, a, 8 + 4 + 1 + len); // 8 = userId + function, 4 id, 1 isWrong
        }
    }
    addShortPersonalResponse(r, message, size);
}

static void editHead(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;
    int size = 0;

    int id;
    memcpy(&id, &r->packet[8], 4);
    char *name = &r->packet[12];

    Head **hp = heads.data;
    Head *h;
    for (int i = 0; i < heads.count; i++) {
        if (hp[i]->id == id) h = hp[i];
        if (strcasecmp(name, hp[i]->name) == 0) {
            message->isSuccess = 0;
            size = sprintf(&message->text, "name exists");
            break;
        }
    }
    if(message->isSuccess){
        char *sql = "UPDATE Heads SET Name = ? WHERE Id = ?";
        sqlite3_prepare_v2(db, sql, -1, &command, 0);
        sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
        sqlite3_bind_int(command, 2, id);

        int result = sqlite3_step(command);
        sqlite3_finalize(command);

        if (result != SQLITE_DONE) {
            message->isSuccess = 0;
            size = sprintf(&message->text, "Failed to update Head");
        }
        else{
            size = sprintf(&message->text, "Successfully edited");

            int len = strlen(h->name);
            total.head -= (len + 1);
            free(h->name);
            len = mallocate(name, &h->name);
            total.head += len;
            addShortPublicResponse(r, h, 8 + 4 + len); // 8 = userId + function, 4 id
        }
    }
    addShortPersonalResponse(r, message, size);
}

static void editDepartment(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;
    int size = 0;

    int id;
    memcpy(&id, &r->packet[8], 4);
    char *name = &r->packet[12];

    Department **dp = departments.data;
    Department *d;
    for (int i = 0; i < departments.count; i++) {
        if (dp[i]->id == id) d = dp[i];
        if (strcasecmp(name, dp[i]->name) == 0) {
            message->isSuccess = 0;
            size = sprintf(&message->text, "name exists");
            break;
        }
    }
    if(message->isSuccess){
        char *sql = "UPDATE Department SET Name = ? WHERE Id = ?";
        sqlite3_prepare_v2(db, sql, -1, &command, 0);
        sqlite3_bind_text(command, 1, name, -1, SQLITE_STATIC);
        sqlite3_bind_int(command, 2, id);

        int result = sqlite3_step(command);
        sqlite3_finalize(command);

        if (result != SQLITE_DONE) {
            message->isSuccess = 0;
            size = sprintf(&message->text, "Failed to update Department");
        }
        else{
            size = sprintf(&message->text, "Successfully edited");

            int len = strlen(d->name);
            total.department -= (len + 1);
            free(d->name);
            len = mallocate(name, &d->name);
            total.department += len;
            addShortPublicResponse(r, d, 8 + 4 + len); // 8 = userId + function, 4 id
        }
    }
    addShortPersonalResponse(r, message, size);
}

static void editMobile(Request *r) {
    ShortMessage *message = malloc(SHORT_MESSAGE_SIZE);
    message->isSuccess = 1;
    int size = 0;

    int id;
    memcpy(&id, &r->packet[8], 4);
    char *number, *name;
    number = strtok_r(&r->packet[12], "", &name), name++;

    Mobile **mp = mobiles.data;
    Mobile *m;
    for (int i = 0; i < mobiles.count; i++) {
        if (mp[i]->id == id) m = mp[i];
        if (strcasecmp(number, mp[i]->number) == 0) {
            message->isSuccess = 0;
            size = sprintf(&message->text, "number exists");
            break;
        }
    }
    if(message->isSuccess){
        char *sql = "UPDATE Mobile SET MobileNo = ?, Name = ? WHERE Id = ?";
        sqlite3_prepare_v2(db, sql, -1, &command, 0);
        sqlite3_bind_text(command, 1, number, -1, SQLITE_STATIC);
        sqlite3_bind_text(command, 2, name, -1, SQLITE_STATIC);
        sqlite3_bind_int(command, 3, id);

        int result = sqlite3_step(command);
        sqlite3_finalize(command);

        if (result != SQLITE_DONE) {
            message->isSuccess = 0;
            size = sprintf(&message->text, "Failed to update Mobile");
        }
        else{
            size = sprintf(&message->text, "Successfully edited");

            int len = strlen(m->name);
            len += strlen(m->number);
            total.mobile -= (len + 2);
            free(m->name);
            free(m->number);
            len = mallocate(name, &m->name);
            len += mallocate(number, &m->number);
            total.mobile += len;
            addShortPublicResponse(r, m, 8 + 4 + len); // 8 = userId + function, 4 id
        }
    }
    addShortPersonalResponse(r, message, size);
}

static void *ProcessRequest(void *p) {
    pthread_detach(pthread_self());

    while (isRunning) {
        Request *r = takeOutFrom(&requests);
        if (!r) break;

        switch (r->function) {
            case GetInitialData: sendStartupPackets(r->sender); break;
            case AddDepartment: addDepartment(r); break;
            case AddAccount: addAccount(r); break;
            case AddMobile: addMobile(r); break;
            case AddHead: addHead(r); break;
            case CheckFileExistence: checkFileExistence(r); break;
            case AddEntries: addEntries(r); break;
            case GetEntriesByAccount: getEntriesByAccount(r); break;
            case GetEntriesByMobile: getEntriesByMobile(r); break;
            case GetEntriesByDate: getEntriesByDate(r); break;
            case GetPeriodicEntries: getPeriodicEntries(r); break;
            case GetDatePaymentSummary: getPaymentSummaryByDate(r); break;
            case GetImage: getImage(r); break;
            case GetBreakup: getBreakup(r); break;
            case EditBillInfo: editBillInfo(r); break;
            case EditBillEntry: editBillEntry(r); break;
            case EditAccount: editAccount(r); break;
            case EditHead: editHead(r); break;
            case EditDepartment: editDepartment(r); break;
            case EditMobile: editMobile(r); break;
        }
        putInto(&garbageRequests, r);
    }
    pthread_exit(0);
}
static void *FreeRequest(void *p) {
    pthread_detach(pthread_self());

    while (isRunning) {
        Request *r = takeOutFrom(&garbageRequests);
        if (!r) break;

        free(r->packet);
        free(r);
    }
    pthread_exit(0);
}

void InitializeDatabase() {
    pthread_create(&freeRequestThread, 0, FreeRequest, 0);
    pthread_create(&requestProcessThread, 0, ProcessRequest, 0);

    initializeListAndQueues();
    // initializeQueue();

    char *database = "/mnt/HDD/bills.db";
    sqlite3_config(SQLITE_CONFIG_SINGLETHREAD); // since requests are processed one by one on ProcessRequest thread
    sqlite3_open(database, &db);

    char *query =
        "SELECT * FROM Account; "
        "SELECT * FROM Department; "
        "SELECT * FROM Mobile; "
        "SELECT* FROM Heads; "
        "SELECT MAX(Id) FROM Bills";

    char *pzTail;
    sqlite3_prepare_v2(db, query, -1, &command, &pzTail);
    while (sqlite3_step(command) == SQLITE_ROW) {
        Account *account = malloc(ACCOUNT_SIZE);
        account->id = sqlite3_column_int(command, 0);
        account->departmentId = sqlite3_column_int(command, 1);
        account->isWrong = sqlite3_column_int(command, 5);
        // clang-format off
        total.account += (
            4 + 4 + 1 
            + mallocate(sqlite3_column_text(command, 2), &account->accoutId) 
            + mallocate(sqlite3_column_text(command, 3), &account->name) 
            + mallocate(sqlite3_column_text(command, 4), &account->address)
        );
        // clang-format on
        addToList(&accounts, account);
    }

    sqlite3_finalize(command);
    sqlite3_prepare_v2(db, pzTail, -1, &command, &pzTail);
    while (sqlite3_step(command) == SQLITE_ROW) {
        Department *department = malloc(DEPARTMENT_SIZE);
        department->id = sqlite3_column_int(command, 0);
        // clang-format off
        total.department += (
            4 
            + mallocate(sqlite3_column_text(command, 1), &department->name)
        );
        // clang-format on
        addToList(&departments, department);
    }

    sqlite3_finalize(command);
    sqlite3_prepare_v2(db, pzTail, -1, &command, &pzTail);
    while (sqlite3_step(command) == SQLITE_ROW) {
        Mobile *mobile = malloc(MOBILE_SIZE);
        mobile->id = sqlite3_column_int(command, 0);
        // clang-format off
        total.mobile += (
            4 
            + mallocate(sqlite3_column_text(command, 1), &mobile->number) 
            + mallocate(sqlite3_column_text(command, 2), &mobile->name)
        );
        // clang-format on
        addToList(&mobiles, mobile);
    }

    sqlite3_finalize(command);
    sqlite3_prepare_v2(db, pzTail, -1, &command, &pzTail);
    while (sqlite3_step(command) == SQLITE_ROW) {
        Head *head = malloc(HEAD_SIZE);
        head->id = sqlite3_column_int(command, 0);
        // clang-format off
        total.head += (
            4 
            + mallocate(sqlite3_column_text(command, 1), &head->name)
        );
        // clang-format on
        addToList(&heads, head);
    }
    sqlite3_finalize(command);

    sqlite3_prepare_v2(db, pzTail, -1, &command, &pzTail);
    sqlite3_step(command);
    maxBillId = sqlite3_column_int(command, 0);
    sqlite3_finalize(command);
}

void ShutdownDatabase() {
    if (personalResponses.isWaiting) {
        pthread_cond_signal(&personalResponses.condition);
    }
    if (publicResponses.isWaiting) {
        pthread_cond_signal(&publicResponses.condition);
    }
    if (garbageRequests.isWaiting) {
        pthread_cond_signal(&garbageRequests.condition);
    }
    // free resources if required
    sqlite3_close(db);
}