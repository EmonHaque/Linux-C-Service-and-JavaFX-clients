#pragma once
#include "List.h"
#include "BlockingQueue.h"
#include "CommonStructures.h"
#include "Structures.h"

extern BlockingQueue personalResponses, publicResponses;

void addShortPersonalResponse(Request *r, ShortMessage *s, int size);
void addLongPersonalResponse(Request *r, List l, int size);
void addFilePersonalResponse(Request *r, char *buffer, int length);
void addShortPublicResponse(Request *r, void *d, int size);
void addLongPublicResponse(Request *r, List l, int size);
int mallocate(char *src, char **dst);