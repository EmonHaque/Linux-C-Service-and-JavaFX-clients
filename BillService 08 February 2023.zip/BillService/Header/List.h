#pragma once
#include <malloc.h>

typedef struct {
	unsigned int count;
	unsigned int capacity;
	void* data;
} List;

void initializeList(List*, int);
void addToList(List*, void*);
void removeFromList(List*, void*);