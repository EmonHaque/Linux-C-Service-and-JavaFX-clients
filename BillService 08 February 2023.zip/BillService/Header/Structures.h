#pragma once
#include "CommonDefined.h"

typedef struct  {
	int department;
	int account;
    int mobile;
	int head;
} Totals;

typedef struct{
    int id;
    char* name;
} Department;

typedef struct{
    int id;
    char* name;
} Head;

typedef struct{
    int id;
    int length;
    char* name;
    byte doesExist;
} NewHead;

typedef struct{
    int id;
    char *number;
    char* name;
} Mobile;

typedef struct{
    int id;
    int departmentId;
    char *accoutId;
    char *name;
    char* address;
    byte isWrong;
} Account;

typedef struct{
    int billId;
    int headId;
    double amount;
} EntryAmount;

typedef struct{
    int billCount;
    int paymentCount;
    int imageLength;
    int deptId;
    int customerId;
    int mobileId;

    char *billNo;
    char *period;
    char *date;
    char *transactionId;
    char *fileName;
    char *image;

    EntryAmount **bills;
    EntryAmount **payments;
} EntryInsert;

typedef struct{
    int id;
    int deptId;
    int accountId;
    int mobileId;
    char *billNo;
    char *period;
    char *transactionId;
    char *date;
    char *fileName;
    double billl;
    double payment;
    char *accountNo;
}ReportEntry;

typedef struct{
    int billId;
    char *month;
    char *department;
    char *date;
    char *fileName;
    char *accountId;
    char *accountHolder;
    char *address;
    char *billNo;
    char *period;
    char *transactionId;
    double amount;
} MobileEntry;

typedef struct{
    int accountId;
    int mobileId;
    double bill;
    double payment;
    char *department;
    char *account;
    char *holder;
    char *address;
    char *head;
    char *date;
    char *month;
} PeriodicEntry;

typedef struct{
    double payment;
    double bill;
    char *department;
    char *head;
} DatePaymentSummary;

typedef struct{
    char *head;
    double billAmount;
    double paymentAmount;
    int billId;
    int paymentId;
} Breakup;

typedef struct{
    int billId;
    int mobileId;
    byte fileRenamed;
    char *date;
    char *billNo;
    char *transactionId;
    char *period;
    char *fileName;
} EditedBillInfo;

typedef struct{
    int billId;
    int headId;
    double bill;
    double payment;
} EditedEntry;

typedef enum {
    GetInitialData,
    AddDepartment,
    AddAccount,
    AddMobile,
    AddHead,
    CheckFileExistence,
    AddEntries,
    GetEntriesByAccount,
    GetEntriesByMobile,
    GetEntriesByDate,
    GetPeriodicEntries,
    GetDatePaymentSummary,
    GetImage,
    GetBreakup,
    EditBillInfo,
    EditBillEntry,
    EditAccount,
    EditHead,
    EditDepartment,
    EditMobile
} Function;