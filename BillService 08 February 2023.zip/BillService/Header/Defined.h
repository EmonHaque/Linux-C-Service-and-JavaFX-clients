#pragma once

#include "CommonDefined.h"

#define ACCOUNT_SIZE sizeof(Account)
#define MOBILE_SIZE sizeof(Mobile)
#define DEPARTMENT_SIZE sizeof(Department)
#define HEAD_SIZE sizeof(Head)
#define REPORT_ENTRY_SIZE sizeof(ReportEntry)