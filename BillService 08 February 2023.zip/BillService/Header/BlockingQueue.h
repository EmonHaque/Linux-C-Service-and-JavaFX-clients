#pragma once
#include <pthread.h>

typedef struct{
    int capacity, count;
    void *data;
    pthread_mutex_t lock;
    pthread_cond_t condition;
    unsigned char isWaiting;
} BlockingQueue;

void initializeBlockingQueue(BlockingQueue *, int);
void putInto(BlockingQueue *, void *);
void *takeOutFrom(BlockingQueue *);