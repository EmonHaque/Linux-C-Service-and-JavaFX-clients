#pragma once
#include <string.h>
#include <sys/socket.h>
#include "Defined.h"

int sendString(int, char*);
int sendFile(int s, char*, long);
int sendByte(int, byte);
int sendInt(int, int);
int sendDouble(int, double);
