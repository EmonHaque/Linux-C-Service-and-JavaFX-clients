package ViewModels.Report;

import Enums.Function;
import Models.LeftOrJoined;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class ReportLeftJoinedVM {
    private final ObservableList<LeftOrJoined> list;
    public ListProperty<LeftOrJoined> listProperty;
    public ObjectProperty<LocalDate> startDateProperty, endDateProperty;
    public StringProperty statusProperty;
    public BooleanProperty isRunningProperty;

    private ResponseTask task;

    public ReportLeftJoinedVM() {
        statusProperty = new SimpleStringProperty();
        isRunningProperty = new SimpleBooleanProperty();

        var now = LocalDate.now();
        startDateProperty = new SimpleObjectProperty<>(now.minusMonths(1));
        endDateProperty = new SimpleObjectProperty<>(now);

        list = FXCollections.observableArrayList();
        listProperty = new SimpleListProperty<>(list);
    }

    public void updateReportable() { update(); }

    private void update(){
        statusProperty.unbind();
        isRunningProperty.unbind();
        statusProperty.set("");
        isRunningProperty.set(false);

        if (task != null && task.isRunning()){
            task.setOnCancelled(e -> {
                task.setOnCancelled(null);
                startTask();
            });
            task.cancel();
        }
        else startTask();
    }

    private void startTask(){
        task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private class ResponseTask extends Task<List<LeftOrJoined>> {
        private int length;

        @Override
        protected List<LeftOrJoined> call() {
            try {
                updateMessage("requesting data ...");
                Thread.sleep(500);

                var start = (startDateProperty.get().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
                var end = (endDateProperty.get().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
                var buffer = ByteBuffer.allocate(start.length + end.length).order(ByteOrder.LITTLE_ENDIAN);
                buffer.put(start);
                buffer.put(end);
                var request = new Request(Function.GetLeftOrJoined.ordinal(), buffer);

                if(isCancelled()) return null;

                var response = Channels.getInstance().getResponse(request).get();
                if (!response.isSuccess()) {
                    updateMessage("service down ...");
                    Thread.sleep(500);
                    return null;
                }
                if(isCancelled()) return null;

                int length = response.getPacket().length;
                if (length == 0) {
                    updateMessage("no data available");
                    Thread.sleep(500);
                    return null;
                }
                updateMessage("received " + String.format("%,d", length) + " bytes");
                Thread.sleep(500);
                if(isCancelled()) return null;

                buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
                return isCancelled() ? null : getList(buffer, length);
            }
            catch (Exception e){
                return null;
            }
        }

        @Override
        protected void succeeded() {
            list.clear();
            try {
                var result = get();
                if (result == null) return;
                list.addAll(result);
                updateMessage("processed " + String.format("%,d", length) + " bytes");
            } catch (InterruptedException | ExecutionException e) {

            }
        }

        private List<LeftOrJoined> getList(ByteBuffer buffer, int length) {
            var list = new ArrayList<LeftOrJoined>();
            var span = buffer.array();
            int read = 0;
            while (read < length) {
                if(isCancelled()) break;

                var status = buffer.get(read) != 0 ? "Left" : "Joined";
                int plotId = buffer.getInt(read + 1);
                int spaceId = buffer.getInt(read + 5);
                int tenantId = buffer.getInt(read + 9);
                int receivable = buffer.getInt(read + 13);

                read += 17;
                var start = read;
                while (span[read] != 0) read++;
                var dateStart = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);

                read++;
                start = read;
                while (span[read] != 0) read++;
                var dateEnd = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                list.add(new LeftOrJoined() {{
                    setStatus(status);
                    setPlot(AppData.plots.stream().filter(x -> x.getId() == plotId).findFirst().get().getName());
                    setSpace(AppData.spaces.stream().filter(x -> x.getId() == spaceId).findFirst().get().getName());
                    setTenant(AppData.tenants.stream().filter(x -> x.getId() == tenantId).findFirst().get().getName());
                    setReceivable(receivable);
                    setDateStart(dateStart);
                    setDateEnd(dateEnd);
                }});
                read++;
            }
            return list;
        }
    }
}
