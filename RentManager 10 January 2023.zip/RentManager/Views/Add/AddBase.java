package Views.Add;

import ViewModels.Add.AddBaseVM;
import abstracts.View;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public abstract class AddBase extends View {
    private Text status;
    private SpinningArc spinner;

    protected CommandButton add;
    protected AddBaseVM viewModel;
    protected abstract Node getUI();
    protected abstract void bind();

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        setCenter(getUI());
        add = new CommandButton(Icons.Add, 16, "add"){{ setAction(viewModel::add);}};
        setBottom(add);
        BorderPane.setAlignment(add, Pos.BOTTOM_RIGHT);
        BorderPane.setMargin(add, new Insets(5,0,0,0));
        bind();

        spinner = new SpinningArc();
        status = new Text(){{ setFill(Color.WHITE);}};
        addAction(spinner);
        addAction(status);

        spinner.visibleProperty().bind(viewModel.isRunningProperty);
        status.textProperty().bind(viewModel.statusProperty);
    }
}
