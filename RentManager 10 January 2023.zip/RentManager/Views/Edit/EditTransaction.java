package Views.Edit;

import Converters.IntToStringConverter;
import Models.*;
import ViewModels.Edit.EditBaseVM;
import ViewModels.Edit.EditTransactionVM;
import controls.buttons.CommandButton;
import controls.daymonth.DayPicker;
import controls.states.MultiState;
import dialogs.ConfirmDialog;
import editables.*;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import trees.EditTransactionTree;

public class EditTransaction extends EditBase<TransactionEditable> {
    private EditTransactionVM vm;
    private DayPicker date;
    private CommandButton refresh, delete;
    private Text status;

    private EditSelection<Tenant> tenant;
    private EditSelection<PlotTransaction> plot;
    private EditSelection<SpaceTransaction> space;
    private EditSelection<ControlHead> control;
    private EditSelection<Head> head;
    private EditDate editDate;
    private EditInteger amount;
    private MultiState isCash;
    private EditTextMultiline narration;

    @Override
    protected String getHeader() {
        return "Transaction";
    }

    @Override
    protected String getIcon() {
        return Icons.Transact;
    }

    @Override
    protected String getTip() {
        return "Transaction";
    }

    @Override
    protected EditBaseVM<TransactionEditable> getViewModel() {
        vm = new EditTransactionVM();
        return vm;
    }

    @Override
    protected boolean isEditableList() {
        return false;
    }

    @Override
    public EditTransactionTree getTree() {
        return new EditTransactionTree(vm.editableList, query.textProperty());
    }

    @Override
    protected void onSelectionChanged(TransactionEditable item) {
        tenant.valueProperty().unbindBidirectional(vm.edited.tenantIdProperty());
        plot.valueProperty().unbindBidirectional(vm.edited.plotIdProperty());
        space.valueProperty().unbindBidirectional(vm.edited.spaceIdProperty());
        control.valueProperty().unbindBidirectional(vm.edited.controlIdProperty());
        head.valueProperty().unbindBidirectional(vm.edited.headIdProperty());
        editDate.dateProperty().unbindBidirectional(vm.edited.dateProperty());
        Bindings.unbindBidirectional(amount.textProperty(), vm.edited.amountProperty());
        isCash.stateProperty.unbindBidirectional(vm.edited.isCashProperty());
        narration.textProperty().unbindBidirectional(vm.edited.narrationProperty());

        if(item == null) return;
        vm.selectionTriggerProperty.set(!vm.selectionTriggerProperty.get());

        tenant.valueProperty().bind(vm.selected.tenantIdProperty());
        plot.valueProperty().bind(vm.selected.plotIdProperty());
        space.valueProperty().bind(vm.selected.spaceIdProperty());
        control.valueProperty().bind(vm.selected.controlIdProperty());
        head.valueProperty().bind(vm.selected.headIdProperty());
        editDate.dateProperty().bind(vm.selected.dateProperty());
        amount.textProperty().bind(Bindings.createStringBinding(() -> String.format("%,d", vm.selected.getAmount()), vm.selected.amountProperty()));
        isCash.stateProperty.bind(vm.selected.isCashProperty());
        narration.textProperty().bind(vm.selected.narrationProperty());
    }

    @Override
    protected void onIsOnEditChanged() {
        tenant.valueProperty().unbind();
        plot.valueProperty().unbind();
        space.valueProperty().unbind();
        control.valueProperty().unbind();
        head.valueProperty().unbind();
        editDate.dateProperty().unbind();
        amount.textProperty().unbind();
        isCash.stateProperty.unbind();
        narration.textProperty().unbind();

        tenant.valueProperty().bindBidirectional(vm.edited.tenantIdProperty());
        plot.valueProperty().bindBidirectional(vm.edited.plotIdProperty());
        space.valueProperty().bindBidirectional(vm.edited.spaceIdProperty());
        control.valueProperty().bindBidirectional(vm.edited.controlIdProperty());
        head.valueProperty().bindBidirectional(vm.edited.headIdProperty());
        editDate.dateProperty().bindBidirectional(vm.edited.dateProperty());
        Bindings.bindBidirectional(amount.textProperty(), vm.edited.amountProperty(), new IntToStringConverter());
        isCash.stateProperty.bindBidirectional(vm.edited.isCashProperty());
        narration.textProperty().bindBidirectional(vm.edited.narrationProperty());
    }

    @Override
    protected void initializeUI() {
        super.initializeUI();
        date = new DayPicker("Date", Icons.Month, false);
        refresh = new CommandButton(Icons.Reload, 16, "refresh");
        var box = new HBox(date, refresh){{
            setSpacing(5);
            setHgrow(date, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_RIGHT);
            setMargin(refresh, new Insets(0, 0, 4, 0));
        }};
        leftBox.getChildren().add(0, box);

        status = new Text() {{setFill(Color.WHITE);}};
        addAction(status);
    }

    @Override
    protected void bind() {
        super.bind();
        vm.dateProperty.bind(date.selectedDateProperty());

        refresh.setAction(vm::refresh);
        delete.setAction(vm::delete);
        refresh.disableProperty().bind(date.isEmpty());

        isCash.disableProperty().bind(pane.isOnEditProperty().not());

        vm.dialogTrigger.addListener((o, ov, nv) ->{
            if(nv){
                var dialog = new ConfirmDialog("Edit", vm.dialogMessage);
                var bound = pane.localToScreen(pane.getBoundsInLocal());
                // see on a different screen resolution whether these 7.5, 17.5 and 10 works
                dialog.showDialog(bound.getMinX() - 7.5, bound.getMinY(), bound.getWidth() + 17.5, bound.getHeight() + 10);
                vm.dialogResult = dialog.dialogResult;
                vm.dialogTrigger.set(false);
            }
        });
    }

    @Override
    protected void initializeEditPane(EditPane pane) {
        delete = new CommandButton(Icons.Delete, 16, "delete");

        tenant = new EditSelection<>("Tenant", Icons.Tenant, vm.tenants, true, pane);
        plot = new EditSelection<>("Plot", Icons.Plot, vm.plots, true, pane);
        space = new EditSelection<>("Space", Icons.Space, vm.spaces, true, pane);
        control = new EditSelection<>("Control", Icons.ControlHead, vm.controls, true, pane);
        head = new EditSelection<>("Head", Icons.Head, vm.heads, true, pane);
        editDate = new EditDate("Date", Icons.Month, true, pane);
        amount = new EditInteger("Amount", Icons.Amount, true, pane);
        narration = new EditTextMultiline("Narration", Icons.Description, true, pane);
        isCash = new MultiState(new String[]{Icons.Cash, Icons.NonCash, Icons.Mobile}, new String[]{"Cash", "Non cash", "Mobile"}, true) {{
            setAlignment(Pos.BOTTOM_LEFT);
        }};

        var amountBox = new HBox(amount, isCash) {{
            setSpacing(10);
            setHgrow(amount, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_RIGHT);
        }};

        pane.setTop(delete);
        BorderPane.setAlignment(delete, Pos.CENTER_RIGHT);
        BorderPane.setMargin(delete, new Insets(5,0,0,0));
        pane.setCenter(new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(50);}},
                    new ColumnConstraints() {{setPercentWidth(50);}}
            );
            add(tenant, 0, 0, 2, 1);
            add(plot, 0, 1);
            add(space, 1, 1);
            add(control, 0, 2);
            add(head, 1, 2);
            add(editDate, 0, 3);
            add(amountBox, 1, 3);
            add(narration, 0, 4, 2, 1);

            setHgap(10);
            setVgap(10);
            setPadding(new Insets(5, 0, 0, 0));
        }});
    }
}
