package Models;

import interfaces.IReturnNameAndId;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class PlotTransaction extends IReturnNameAndId<PlotTransaction> {
    private IntegerProperty id;
    private StringProperty name;

    public PlotTransaction(int id, String name) {
        this.id = new SimpleIntegerProperty(id);
        this.name = new SimpleStringProperty(name);
    }

    @Override
    public String getName() {
        return name.get();
    }

    @Override
    public StringProperty nameProperty() {
        return name;
    }

    @Override
    public int getId() {
        return id.get();
    }
}
