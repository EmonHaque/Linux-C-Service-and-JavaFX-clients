package trees;

import Models.LeftOrJoined;
import controls.SVGRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

public class LeftOrJoinedTree extends ExtendedTreeView<LeftOrJoined> {
    private final TreeItem<LeftOrJoined> root, left, joined;
    public ListProperty<LeftOrJoined> itemsProperty;
    public BooleanProperty isExpandedProperty;

    public LeftOrJoinedTree() {
        left = new TreeItem<>(new LeftOrJoined() {{setPlot("Left");}});
        joined = new TreeItem<>(new LeftOrJoined() {{setPlot("Joined");}});
        root = new TreeItem<>();
        root.getChildren().addAll(left, joined);

        left.setExpanded(true);
        joined.setExpanded(true);

        itemsProperty = new SimpleListProperty<>();
        isExpandedProperty = new SimpleBooleanProperty();
        itemsProperty.addListener(this::onItemsChanged);
        setRoot(root);
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new LeftOrJoinedCell());

        isExpandedProperty.addListener(o ->{
            var value = isExpandedProperty.get();
            resetExpandState(left, value);
            resetExpandState(joined, value);
        });
    }

    private void resetExpandState(TreeItem<LeftOrJoined> node, boolean value){
        node.setExpanded(value);
        for(var item : node.getChildren()){
            if(item.isLeaf()) continue;
            resetExpandState(item, value);
        }
    }

    private void onItemsChanged(ObservableValue<?> o, ObservableList<LeftOrJoined> ov, ObservableList<LeftOrJoined> nv) {
        root.getChildren().clear();
        left.getChildren().clear();
        joined.getChildren().clear();
        left.getValue().setReceivable(0);
        joined.getValue().setReceivable(0);

        if (nv == null) return;

        for (var lj : nv) {
            boolean hasIt = false;
            var node = lj.getStatus().equals("Left") ? left : joined;
            node.getValue().setReceivable(node.getValue().getReceivable() + lj.getReceivable());

            TreeItem<LeftOrJoined> item = null;
            for (var tree : node.getChildren()) {
                if (tree.getValue().getPlot().equals(lj.getPlot())) {
                    item = tree;
                    var value = item.getValue();
                    value.setReceivable(lj.getReceivable() + value.getReceivable());
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                var newItem = new LeftOrJoined() {{
                    setPlot(lj.getPlot());
                    setReceivable(lj.getReceivable());
                }};
                item = new TreeItem<>(newItem);
                node.getChildren().add(item);
            }
            var leaf = new TreeItem<>(lj);
            item.getChildren().add(leaf);
        }
        if(left.getChildren().size() > 0) root.getChildren().add(left);
        if(joined.getChildren().size() > 0) root.getChildren().add(joined);
    }

    private class LeftOrJoinedCell extends TreeCell<LeftOrJoined> {
        private SVGRegion disclosureIcon;
        private GridPane root;
        private Font normal, bold;
        private Border topBorder;
        private Text particulars, from, to, amount;
        private TextFlow particularsFlow;

        public LeftOrJoinedCell() {
            setBackground(null);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setPadding(new Insets(2.5, 0, 2.5, 0));
            setPrefWidth(0);

            initializeUI();
            itemProperty().addListener(this::onItemChanged);

//            prefHeightProperty().bind(particularsFlow.heightProperty().add(5));
//            minHeightProperty().bind(particularsFlow.heightProperty().add(5));
//            maxHeightProperty().bind(particularsFlow.heightProperty().add(5));
        }

        private void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0), new Insets(0, 0, 0, -15)));

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            particulars = new Text() {{setFill(Color.WHITE); }};
            from = new Text() {{setFill(Color.WHITE); }};
            to = new Text() {{setFill(Color.WHITE);}};
            amount = new Text() {{setFill(Color.WHITE);}};
            particularsFlow = new TextFlow(particulars);

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{ setHgrow(Priority.SOMETIMES);}},
                        new ColumnConstraints(90){{ setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(90){{ setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}}
                );
                add(particularsFlow, 0, 0);
                add(from, 1, 0);
                add(to, 2, 0);
                add(amount, 3, 0);
            }};
        }

        private void onItemChanged(ObservableValue<?> o, LeftOrJoined ov, LeftOrJoined nv) {
            if (ov != null) {
                particulars.setText(null);
                from.setText(null);
                to.setText(null);
                amount.setText(null);

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);
                root.setBorder(null);
                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                if (level == 1) {
                    int size = 0;
                    for(var c : item.getChildren()){
                        size += c.getChildren().size();
                    }
                    particulars.setFont(bold);
                    amount.setFont(bold);
                    particulars.setText(nv.getPlot() + " (" + item.getChildren().size() + " - " + size + ")");
                }
                else if (level == 2) {
                    particulars.setFont(bold);
                    amount.setFont(bold);
                    particulars.setText(nv.getPlot() + " (" + item.getChildren().size() + ")");
                    root.setBorder(Constants.BottomLine);
                }
                else {
                    particulars.setFont(normal);
                    amount.setFont(normal);
                    particulars.setText(nv.getSpace() + " - " + nv.getTenant());
                    from.setText(nv.getDateStart());
                    to.setText(nv.getDateEnd());
                }
                amount.setText(AppData.formatNumber(nv.getReceivable()));
            }
        }

        @Override
        protected void updateItem(LeftOrJoined item, boolean empty) {
            super.updateItem(item, empty);
            if (isEmpty()) {
                setBackground(null);
                setGraphic(null);
            }
            else{
                setGraphic(root);
                setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
            }

        }
    }
}
