package Views.Accounts;

import Model.Department;
import ViewModels.Accounts.EditBaseVM;
import ViewModels.Accounts.EditDepartmentVM;
import abstracts.ListCellBase;
import controls.buttons.ActionButton;
import controls.texts.TextBoxClean;
import helpers.Icons;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import ridiculous.AppData;
import skinned.ExtendedListView;

public class Departments extends EditBase<Department> {
    private EditDepartmentVM vm;

    @Override
    protected String getHeader() {
        return "Departments";
    }

    @Override
    protected EditBaseVM<Department> getViewModel() {
        vm = new EditDepartmentVM();
        return vm;
    }

    @Override
    protected Node getCentralNode() {
        return new ExtendedListView<>(AppData.departments){{
            setEditable(true);
            setPadding(new Insets(5,0,0,0));
            setCellFactory(v -> new ListCellBase<>() {
                private Text name;
                private TextBoxClean editName;
                private ActionButton edit, cancel, save;
                private BorderPane root;
                private HBox buttons;

                @Override
                protected void initializeUI() {
                    name = new Text(){{ setFill(Color.WHITE);}};
                    editName = new TextBoxClean();

                    edit = new ActionButton(Icons.Pencil, 16, "edit"){{ setAction(() -> startEdit());}};
                    cancel = new ActionButton(Icons.CloseCircle, 16, "edit"){{ setAction(() -> cancelEdit());}};
                    save = new ActionButton(Icons.CheckCircle, 16, "edit"){{
                        setAction(() ->{
                            vm.edited = new Department(getItem().getId(), editName.getText().trim());
                            vm.startTask();
                            cancelEdit();
                        });
                    }};
                    buttons = new HBox(save, cancel){{ setSpacing(2.5);}};

                    root = new BorderPane(){{
                        setCenter(name);
                        setRight(edit);
                        setAlignment(name, Pos.CENTER_LEFT);
                    }};
                }

                @Override
                protected void onItemChanged(ObservableValue<?> o, Department ov, Department nv) {
                    if(ov != null){
                        name.textProperty().unbind();
                        name.setText(null);
                        edit.visibleProperty().unbind();
                        edit.setVisible(false);
                    }
                    if(nv != null){
                        name.textProperty().bind(nv.nameProperty());
                        edit.visibleProperty().bind(hoverProperty());
                    }
                }

                @Override
                protected Node getRootNode() {
                    return root;
                }

                @Override
                public void startEdit() {
                    root.getChildren().clear();
                    editName.setText(name.getText());
                    root.setCenter(editName);
                    root.setRight(buttons);
                    save.disableProperty().bind(editName.isEmpty());
                    BorderPane.setAlignment(name, Pos.CENTER_LEFT);
                    editName.requestFocus();
                }

                @Override
                public void cancelEdit() {
                    root.getChildren().clear();
                    root.setCenter(name);
                    root.setRight(edit);
                    BorderPane.setAlignment(name, Pos.CENTER_LEFT);
                }
            });
        }};
    }
}
