package Views.Process;

import abstracts.View;
import controls.texts.TextBoxMultiLineClean;
import javafx.geometry.Insets;

public class Extracted extends View {
    public static TextBoxMultiLineClean text;
    @Override
    protected String getHeader() {
        return "Extracted";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        text = new TextBoxMultiLineClean(){{
            setPadding(new Insets(5,0,0,0));
        }};
        setCenter(text);
    }
}
