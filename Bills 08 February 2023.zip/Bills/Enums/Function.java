package Enums;

public enum Function {
    GetInitialData,
    AddDepartment,
    AddAccount,
    AddMobile,
    AddHead,
    CheckFileExistence,
    AddEntries,
    GetEntriesByAccount,
    GetEntriesByMobile,
    GetEntriesByDate,
    GetPeriodicEntries,
    GetDatePaymentSummary,
    GetImage,
    GetBreakup,
    EditBillInfo,
    EditBillEntry,
    EditAccount,
    EditHead,
    EditDepartment,
    EditMobile
}
