package controls;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ScrollEvent;
import skinned.ExtendedScrollPane;

public class ImageZoomer extends ExtendedScrollPane {
    private double zoomLevel;
    private ImageView view;
    private Image image;
    public ObjectProperty<Image> imageProperty;
    public DoubleProperty zoomLevelProperty;

    public ImageZoomer() {
        view = new ImageView();
        view.setPreserveRatio(true);
        setContent(view);
        setPannable(true);

        // setFitToHeight(true);
        // setFitToWidth(true);

        zoomLevel = 1;
        zoomLevelProperty = new SimpleDoubleProperty(zoomLevel);
        imageProperty = view.imageProperty();
        imageProperty.addListener(this::onImageChanged);
        addEventFilter(ScrollEvent.SCROLL, this::onScroll);
    }

    public void zoomIn() {
        if (image == null)
            return;

        zoomLevel *= 1.05;
        set();
    }

    public void zoomOut() {
        if (image == null)
            return;

        zoomLevel *= 0.95;
        set();
    }

    public void restore() {
        zoomLevel = 1;
        if (image == null)
            return;

        set();
    }

    private void onImageChanged(ObservableValue<?> o, Image ov, Image nv) {
        image = nv;
        restore();
    }

    private void set() {
        view.setFitWidth(image.getWidth() * zoomLevel);
        view.setFitHeight(image.getHeight() * zoomLevel);
        zoomLevelProperty.set(zoomLevel);
    }

    private void onScroll(ScrollEvent e) {
        if(image == null)
            return;

        if (!e.isControlDown())
            return;

        System.out.println("DeltaY: " + e.getDeltaY());
        if (e.getDeltaY() == 0)
            return;

        e.consume();
        zoomLevel *= e.getDeltaY() > 0 ? 1.05 : 0.95;

        // var x = getHvalue();
        // var y = getVvalue();

        set();

        // setHvalue(x);
        // setVvalue(y);
    }
}
