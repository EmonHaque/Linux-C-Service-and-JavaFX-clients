package controls;

import helpers.Constants;
import helpers.Icons;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class LoadingWindow extends Stage {
    private double radius = 200;
    private double strokeWidth = 5;
    private Timeline anim;
    public StringProperty messageProperty;
    public BooleanProperty isSuccessProperty;

    public LoadingWindow(String title, Image icon) {
        initStyle(StageStyle.TRANSPARENT);
        getIcons().add(icon);
        double halfStroke = strokeWidth / 2;
        var arc = new Arc(radius, radius, radius - halfStroke, radius - halfStroke, 0, 0);
        arc.setStrokeWidth(strokeWidth);
        arc.setType(ArcType.OPEN);
        arc.setStroke(Color.DODGERBLUE);
        arc.setFill(null);
        arc.setManaged(false);

        var circle = new Circle(radius, Constants.BackgroundColor);

        var image = new ImageView(icon);
        var titleText = new Text(title);
        titleText.setFill(Color.DODGERBLUE);
        titleText.setFont(Font.font(null, FontWeight.BOLD,  32));
        var messageText = new Text();
        messageText.setFill(Color.WHITE);
        messageText.setFont(Font.font(null, 18));
        messageProperty = messageText.textProperty();
        isSuccessProperty = new SimpleBooleanProperty();

        var box = new VBox(image, titleText, messageText);
        box.setSpacing(5);
        box.setAlignment(Pos.CENTER);
        
        var stack = new StackPane(circle, box, arc);
        var scene = new Scene(stack);
        stack.setBackground(null);
        scene.setFill(null);
        setScene(scene);
        centerOnScreen();

        var kv = new KeyValue(arc.lengthProperty(), -360, Interpolator.EASE_BOTH);
        var kf = new KeyFrame(Duration.seconds(2.5), kv);

        anim = new Timeline();
        anim.setCycleCount(Timeline.INDEFINITE);
        anim.getKeyFrames().add(kf);
        anim.play();

        setOnShown(e -> anim.play());
    }

}
