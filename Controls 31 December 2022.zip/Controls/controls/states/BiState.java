package controls.states;

import controls.SVGIcon;
import helpers.Icons;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class BiState extends GridPane {
    private SVGIcon icon;
    private Text textLabel;
    public BooleanProperty isCheckedProperty;

    public BiState(boolean isChecked) {
        if (isChecked) {
            icon = new SVGIcon(Icons.CheckCircle);
            icon.setFill(Color.LIGHTGREEN);
        }
        else {
            icon = new SVGIcon(Icons.CloseCircle);
            icon.setFill(Color.LIGHTCORAL);
        }
        icon.setMouseTransparent(true);
        addColumn(0, icon);
        setHgap(5);
        isCheckedProperty = new SimpleBooleanProperty();
        isCheckedProperty.addListener(this::onCheckedChanged);
        isCheckedProperty.set(isChecked);
        // bound property cannot be modified!
        setOnMouseClicked(e -> isCheckedProperty.set(!isCheckedProperty.get()));

        // setFocusTraversable(true);
        // focusVisibleProperty().addListener((o,ov,nv) ->{
        //     System.out.println("old " + ov + " new " + nv);
        // });
    }

    public BiState(boolean isChecked, String text) {
        this(isChecked);
        textLabel = new Text(text);
        textLabel.setFill(Color.WHITE);
        textLabel.setMouseTransparent(true);
        addColumn(1, textLabel);
    }

    private void onCheckedChanged(ObservableValue<?> obs, boolean oldValue, boolean newValue) {
        if (newValue) {
            icon.setContent(Icons.CheckCircle);
            icon.setFill(Color.LIGHTGREEN);
        }
        else {
            icon.setContent(Icons.CloseCircle);
            icon.setFill(Color.LIGHTCORAL);
        }
    }

    public void setChecked(boolean value) {
        isCheckedProperty.set(value);
    }

    public StringProperty textProperty() {
        // null if you don't give it text in constructor
        return textLabel.textProperty();
    }
}
