package controls.columnstackchart;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.util.Duration;
import model.ColumnSeries;

import java.util.ArrayList;
import java.util.List;

public class Columns extends Region {
    private int numLines;
    private double labelWidth, min, max, gap = 15;
    private Group lines, labels;
    private FadeTransition labelAnim;
    private ScaleTransition lineAnim;
    private List<ColumnStack> columns;

    public ObjectProperty<List<ColumnSeries>> seriesProperty;

    public Columns() {
        lines = new Group();
        labels = new Group();
        columns = new ArrayList<>();
        lines.setManaged(false);
        labels.setManaged(false);
        getChildren().addAll(lines, labels);

        numLines = 5;
        for (int i = 0; i < numLines + 1; i++) {
            var line = new Line();
            var label = new Text();
            line.setStroke(Color.GRAY);
            line.getStrokeDashArray().addAll(5d, 2d);
            label.setFill(Color.WHITE);

            lines.getChildren().add(line);
            labels.getChildren().add(label);

            label.setMouseTransparent(true);
            line.setMouseTransparent(true);
            line.setManaged(false);
            label.setManaged(false);
        }
        labelAnim = new FadeTransition(Duration.millis(500), labels);
        lineAnim = new ScaleTransition(Duration.millis(500), lines);

        labelAnim.setDelay(Duration.millis(500));
        labelAnim.setFromValue(0);
        labelAnim.setToValue(1);
        lineAnim.setFromY(0);
        lineAnim.setToY(1);

        seriesProperty = new SimpleObjectProperty<>();
        seriesProperty.addListener(this::onSeriesChanged);
    }

    private void onSeriesChanged(ObservableValue<?> obs, List<ColumnSeries> ov, List<ColumnSeries> nv) {
        for (var n : columns) {
            getChildren().remove(n);
        }
        columns.clear();
        if (nv == null) {
            labels.setVisible(false);
            lines.setVisible(false);
        }
        else {
            labels.setVisible(true);
            lines.setVisible(true);
            min = max = 0;
            for (int i = 0; i < nv.size(); i++) {
                var total = nv.get(i).getValues().stream().mapToDouble(x -> x).sum();
                if (max < total)
                    max = total;

                var column = new ColumnStack(nv.get(i));
                columns.add(column);
                getChildren().add(column);
                column.setManaged(false);
            }

            double step = max / numLines;
            double current = min;
            for (var t : labels.getChildren()) {
                var label = (Text) t;
                label.setText(String.format("%.1f", current));
                current += step;
                labelWidth = label.prefWidth(-1);
            }
            lines.setScaleY(0);
            labels.setOpacity(0);
            lineAnim.play();
            labelAnim.play();
        }
    }

    @Override
    protected void layoutChildren() {
        if (!lines.isVisible()) {
            return;
        }
        var height = getHeight();
        var width = getWidth();
        var vSpace = height / (numLines + 1);
        var colWidth = (width - labelWidth - columns.size() * gap) / columns.size();

        double lineY = height;
        double labelY = lineY - 5;
        double x = labelWidth + gap;

        for (var l : lines.getChildren()) {
            var line = (Line) l;
            line.setStartY(lineY);
            line.setEndY(lineY);
            line.setEndX(width);
            lineY -= vSpace;
        }
        for (var t : labels.getChildren()) {
            var text = (Text) t;
            text.setY(labelY);
            labelY -= vSpace;
        }
        for (var column : columns) {
            var colHeight = column.getTotal() * (height - vSpace) / max;
            column.makeColumn(colWidth, colHeight);
            column.resizeRelocate(x, height, colWidth, colHeight); // y is flipped
            x += colWidth + gap;
            // double y = height - colHeight;
            // column.resizeRelocate(x, y, colWidth, colHeight);
        }
    }
}
