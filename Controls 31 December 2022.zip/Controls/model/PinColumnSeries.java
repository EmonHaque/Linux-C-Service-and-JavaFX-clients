package model;

public class PinColumnSeries {
    private double pin, column;
    private String label;

    public PinColumnSeries(String label, double pin, double column) {
        this.label = label;
        this.pin = pin;
        this.column = column;
    }

    public double getPin() {
        return pin;
    }

    public double getColumn() {
        return column;
    }

    public void setPin(double pin) {
        this.pin = pin;
    }

    public void setColumn(double column) {
        this.column = column;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
