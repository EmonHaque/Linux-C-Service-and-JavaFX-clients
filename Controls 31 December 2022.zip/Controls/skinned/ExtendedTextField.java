package skinned;

import javafx.event.Event;
import javafx.scene.control.Skin;
import javafx.scene.control.TextField;
import javafx.scene.input.ContextMenuEvent;
import skins.ExtendedTextFieldSkin;

public class ExtendedTextField extends TextField {

    public ExtendedTextField() {
        super();
        setBackground(null);
        addEventFilter(ContextMenuEvent.CONTEXT_MENU_REQUESTED, Event::consume);
    }
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedTextFieldSkin(this);
    }
}