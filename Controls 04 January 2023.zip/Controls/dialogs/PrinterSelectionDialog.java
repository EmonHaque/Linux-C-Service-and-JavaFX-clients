package dialogs;

import controls.buttons.ActionButton;
import helpers.Constants;
import helpers.Icons;
import javafx.animation.Interpolator;
import javafx.animation.ScaleTransition;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.print.Printer;
import javafx.scene.Scene;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import skinned.ExtendedListView;

public class PrinterSelectionDialog extends Stage {
    private final BorderPane root;
    private final ExtendedListView<Printer> listView;
    private Printer selected;

    public PrinterSelectionDialog(ObservableList<Printer> printers) {
        initStyle(StageStyle.TRANSPARENT);
        initModality(Modality.APPLICATION_MODAL);

        var okButton = new ActionButton(Icons.CheckCircle, 16, "ok");
        okButton.setAction(this::closeDialog);
        var radius = Constants.CardRadius;
        var titlePane = new StackPane() {{
            getChildren().add(
                    new Text("Select a printer") {{
                        setFill(Color.WHITE);
                        setFont(Font.font(null, FontWeight.BOLD, 18));
                    }}
            );
            setPadding(new Insets(5));
            setBorder(Constants.BottomLine);
            setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 1), new CornerRadii(radius, radius, 0, 0, false), null)));
        }};
        var buttonPane = new GridPane() {{
            getColumnConstraints().add(new ColumnConstraints() {{
                setPercentWidth(100);
                setHalignment(HPos.RIGHT);
            }});
            add(okButton, 0, 0);
            setPadding(new Insets(5));
            setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 1), new CornerRadii(0, 0, radius, radius, false), null)));
        }};
        listView = new ExtendedListView<>(printers) {{
            setBackground(Background.fill(Color.BLACK));
            setCellFactory(v -> new Cell());
            getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            getSelectionModel().selectedItemProperty().addListener(o -> selected = getSelectionModel().getSelectedItem());
        }};
        root = new BorderPane(){{
            setTop(titlePane);
            setCenter(listView);
            setBottom(buttonPane);
            setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 0, 0.5), new CornerRadii(radius, false), null)));
        }};
        setOnShown(this::animateShow);
    }

    public Printer getSelected() {return selected;}

    public void showDialog(double left, double top, double width, double height) {
        listView.setMaxHeight(height / 3);
        listView.setMinHeight(height / 3);
        listView.setPrefHeight(height / 3);

        listView.setLayoutX(width / 3);
        listView.setLayoutY(height / 3);

        var scene = new Scene(root, width, height);
        scene.setFill(Color.TRANSPARENT);
        setScene(scene);
        setX(left);
        setY(top);
        showAndWait();
    }

    public void closeDialog() {
        var animation = new ScaleTransition(Duration.millis(500), root);
        animation.setInterpolator(Interpolator.EASE_IN);
        animation.setFromX(1);
        animation.setFromY(1);
        animation.setToX(0);
        animation.setToY(0);
        animation.play();
        animation.setOnFinished(e -> close());
    }

    private void animateShow(WindowEvent e) {
        var animation = new ScaleTransition(Duration.millis(500), root);
        animation.setInterpolator(Interpolator.EASE_IN);
        animation.setFromX(0);
        animation.setFromY(0);
        animation.setToX(1);
        animation.setToY(1);
        animation.play();
    }

    private class Cell extends ListCell<Printer> {
        public Cell() {
            setContentDisplay(ContentDisplay.TEXT_ONLY);
            setAlignment(Pos.CENTER);
            setTextFill(Color.WHITE);
        }

        @Override
        protected void updateItem(Printer item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setText(null);
                setBackground(null);
            }
            else {
                setPrefWidth(0);
                setText(item.getName());
                setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
                if (isHover()) {
                    if (isSelected()) return;
                    setBackground(isHover() ? Background.fill(Constants.BackgroundColorLight) : null);
                }
            }
        }
    }
}
