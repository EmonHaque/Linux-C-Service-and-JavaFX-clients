package interfaces;

public interface IExecuteArg<T> {
    void execute(T arg);
}
