package Views.Home;

import ChartControls.PlotDueChart.PinColumnChart;
import ViewModels.Home.PlotDueVM;
import abstracts.View;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.states.BiState;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.*;

public class PlotDue extends View {
    private PlotDueVM vm;
    private TextFlow plotFlow;
    private Text status, plot;
    private BiState state;
    private SpinningArc spinner;
    private CommandButton refresh;
    private PinColumnChart chart;

    @Override
    protected String getHeader() {
        return  "Due & Tenants";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new PlotDueVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        status = new Text(){{setFill(Color.WHITE);}};
        refresh = new CommandButton(Icons.Reload, 16, "refresh");
        state = new BiState(false, "All");
        spinner = new SpinningArc();

        addAction(spinner);
        addAction(status);
        addAction(state);
        addAction(refresh);

        plot = new Text(){{ setFill(Color.WHITE); setFont(Font.font(null, FontWeight.BOLD, -1));}};
        plotFlow = new TextFlow(){{
            setTextAlignment(TextAlignment.RIGHT);
            getChildren().addAll(
                    new Text("in "){{ setFill(Color.WHITE);}},
                    plot
            );
        }};
        chart = new PinColumnChart("Due", "Tenant");
        var box = new VBox(plotFlow, chart){{
            setPadding(new Insets(5));
            setMargin(chart, new Insets(20, 0, 0, 0));
            setVgrow(chart, Priority.ALWAYS);
        }};
        setCenter(box);
        //BorderPane.setMargin(chart, new Insets(25,0,0,0));
    }

    private void bind(){
        refresh.setAction(vm::refresh);
        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);
        vm.stateProperty.bind(state.isCheckedProperty);
        chart.seriesProperty.bind(vm.seriesProperty);
        plot.textProperty().bind(vm.plotProperty);
        plotFlow.visibleProperty().bind(plot.textProperty().isNotNull());
    }
}
