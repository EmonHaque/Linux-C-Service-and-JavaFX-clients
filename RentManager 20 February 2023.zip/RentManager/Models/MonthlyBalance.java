package Models;

public class MonthlyBalance {
    private String plot, tenant, date;
    private int due, lastMonthDue, payment, shortOrLong;

    public String getPlot() {
        return plot;
    }

    public void setPlot(String plot) {
        this.plot = plot;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getDue() {
        return due;
    }

    public void setDue(int due) {
        this.due = due;
    }

    public int getLastMonthDue() {
        return lastMonthDue;
    }

    public void setLastMonthDue(int lastMonthDue) {
        this.lastMonthDue = lastMonthDue;
    }

    public int getPayment() {
        return payment;
    }

    public void setPayment(int payment) {
        this.payment = payment;
    }

    public int getShortOrLong() {
        return shortOrLong;
    }

    public void setShortOrLong(int shortOrLong) {
        this.shortOrLong = shortOrLong;
    }
}
