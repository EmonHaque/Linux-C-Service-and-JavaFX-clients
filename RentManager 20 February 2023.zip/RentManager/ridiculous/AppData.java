package ridiculous;

import Models.*;
import controls.LoadingWindow;
import Enums.Function;
import dialogs.InfoDialog;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.stage.Stage;
import ridiculuous.Channels;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AppData extends BaseData {
    public static int controlIdOfReceivable, controlIdOfPayment;
    public static ObservableList<Plot> plots;
    public static ObservableList<Space> spaces;
    public static ObservableList<Tenant> tenants;
    public static ObservableList<Lease> leases;
    public static ObservableList<ControlHead> controlHeads;
    public static ObservableList<Head> heads;
    public static ObservableList<Notification> notifications;

    public static ObjectProperty<Transaction> onEditTransaction, onDeleteTransaction;

    public AppData(LoadingWindow window, Stage stage) {
        super(window, stage);
        onEditTransaction = new SimpleObjectProperty<>();
        onDeleteTransaction = new SimpleObjectProperty<>();
    }

    @Override
    protected int getInitialMethod() {
        return Function.GetInitialData.ordinal();
    }

    @Override
    protected void initializeCollections() {
        plots = FXCollections.observableArrayList();
        spaces = FXCollections.observableArrayList();
        tenants = FXCollections.observableArrayList();
        leases = FXCollections.observableArrayList();
        controlHeads = FXCollections.observableArrayList();
        heads = FXCollections.observableArrayList();
        notifications = FXCollections.observableArrayList();
    }

    @Override
    protected void populateCollections() {
        var task = new InitialLoadTask();
        window.messageProperty.bind(task.messageProperty());
        new Thread(task).start();
    }

    @Override
    protected void processMessage() {
        while (isConnected) {
            try {
                var packet = ByteBuffer.wrap(messages.take()).order(ByteOrder.LITTLE_ENDIAN);
                var message = Function.values()[packet.getInt()];
                switch (message) {
                    case AddPlot -> plotAdd(packet);
                    case EditPlot -> plotEdit(packet);
                    case AddSpace -> spaceAdd(packet);
                    case EditSpace -> spaceEdit(packet);
                    case AddTenant -> tenantAdd(packet);
                    case EditTenant -> tenantEdit(packet);
                    case AddHead -> headAdd(packet);
                    case EditHead -> headEdit(packet);
                    case AddLease -> leaseAdd(packet);
                    case EditLease -> leaseEdit(packet);
                    case AddTransactionsRegular -> regularAdd(packet);
                    case AddTransactionsIrregular -> irregularAdd(packet);
                    case EditTransaction -> transactionEdit(packet);
                    case DeleteTransaction -> transactionDelete(packet);
                }
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void plotAdd(ByteBuffer array) {
        var userId = array.getInt(4);
        int start = 8;
        int read = 8;
        int id = array.getInt(start);
        read += 4;
        start = read;

        while (array.get(read) != 0) read++;
        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        start = ++read;
        while (array.get(read) != 0) read++;
        var description = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);


        Platform.runLater(() -> {
            var plot = new Plot(id, name, description);
            plots.add(plot);
            if (userId != Channels.getInstance().userId) {
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Plot");
                    setMessage(plot.getName() + " added by " + userId);
                }});
            }
        });
    }

    private void plotEdit(ByteBuffer array) {
        var userId = array.getInt(4);
        int start = 8;
        int read = 8;
        int id = array.getInt(start);
        read += 4;
        start = read;

        while (array.get(read) != 0) read++;
        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        start = ++read;
        while (array.get(read) != 0) read++;
        var description = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        var original = plots.stream().filter(x -> x.getId() == id).findFirst().get();

        Platform.runLater(() -> {
            if (userId != Channels.getInstance().userId) {
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Plot");
                    setMessage(original.getName() + " edited, see " + name);
                }});
            }

            if(!original.getDescription().equals(description)){
                original.setDescription(description);
            }
            if(!original.getName().equals(name)){
                original.setName(name);
                for(var lease : leases){
                    if(lease.getPlotId() != id) continue;
                    lease.setPlotName(name);
                }
            }

        });
    }

    private void spaceAdd(ByteBuffer array) {
        var userId = array.getInt(4);
        int start = 8;
        int read = 8;

        int id = array.getInt(start);
        int plotId = array.getInt(start + 4);
        read += 8;
        start = read;

        while (array.get(read) != 0) read++;
        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        start = ++read;
        while (array.get(read) != 0) read++;
        var description = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        Platform.runLater(() -> AppData.spaces.add(new Space(id, plotId, name, description, true)));
    }

    private void spaceEdit(ByteBuffer array) {
        var userId = array.getInt(4);
        var leaseId = array.getInt(8);
        int start = 12;
        int read = 12;
        int length = array.array().length;

        final String message;
        final LocalDate vacationDate;
        final Lease lease;
        final boolean isExpired;

        if(leaseId > 0){
            isExpired = true;
            while (read < length) {
                if (array.get(read) != 0) {
                    read++;
                    continue;
                }
                break;
            }
            var vacatedOn = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
            lease = leases.stream().filter(x -> x.getId() == leaseId).findFirst().get();
            vacationDate = LocalDate.parse(vacatedOn, DateTimeFormatter.ofPattern("yyyy-MM-dd"));

            var tenantName = tenants.stream().filter(x -> x.getId() == lease.getTenantId()).findFirst().get().getName();
            var spaceName = spaces.stream().filter(x -> x.getId() == lease.getSpaceId()).findFirst().get().getName();
            message = spaceName + " was let out to " + tenantName + "\nNow is vacant and available to let out";
        }
        else{
            message = "";
            vacationDate = null;
            lease = null;
            isExpired = false;
        }
        read++;

        int id = array.getInt(read);
        int plotId = array.getInt(read + 4);
        read += 8;
        start = read;
        int index = 0;
        var segments = new String[2];
        while (read < length) {
            if (array.get(read) != 0) {
                read++;
                continue;
            }
            segments[index++] = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
            start = ++read;
            if (index == segments.length) break;
        }
        var isVacant = array.get(read) != 0;

        var original = spaces.stream().filter(x -> x.getId() == id).findFirst().get();

        Platform.runLater(() ->{
            if(!original.getName().equals(segments[0])){
                original.setName(segments[0]);
                for(var l : leases){
                    if(l.getSpaceId() != id) continue;
                    l.setSpaceName(segments[0]);
                }
            }
            original.setPlotId(plotId);
            original.setDescription(segments[1]);
            original.setIsVacant(isVacant);

            if(isExpired){
                lease.setDateEnd(vacationDate);
                lease.setIsExpired(true);

                var dialog = new InfoDialog("Lease", message);
                dialog.showDialog(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight());
            }
        });
    }

    private void tenantAdd(ByteBuffer array) {
        var userId = array.getInt(4);
        int length = array.array().length;
        int index = 0;
        int start = 8;
        int read = 8;

        int id = array.getInt(start);
        read += 4;
        start = read;

        var segments = new String[7];
        while (read < length) {
            if (array.get(read) != 0) {
                read++;
                continue;
            }
            segments[index++] = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
            start = ++read;
            if (index == segments.length) break;
        }

        Platform.runLater(() -> AppData.tenants.add(new Tenant(){{
            setId(id);
            setName(segments[0]);
            setFather(segments[1]);
            setMother(segments[2]);
            setHusband(segments[3]);
            setAddress(segments[4]);
            setNid(segments[5]);
            setContactNo(segments[6]);
            setHasLeft(false);
        }}));
    }

    private void tenantEdit(ByteBuffer array) {
        var userId = array.getInt(4);
        int length = array.array().length;
        int index = 0;
        int start = 8;
        int read = 8;

        while (read < length) {
            if (array.get(read) != 0) {
                read++;
                continue;
            }
            break;
        }
        final var leftOn = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        read++;
        int id = array.getInt(read);
        read += 4;
        start = read;

        var segments = new String[7];
        while (read < length) {
            if (array.get(read) != 0) {
                read++;
                continue;
            }
            segments[index++] = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
            start = ++read;
            if (index == segments.length) break;
        }
        var hasLeft = array.get(read) != 0;

        final String message;
        final List<Lease> expiredLeases;
        final List<Space> vacatedSpaces;
        final LocalDate leftOnDate;

        if(!leftOn.isEmpty()){
            leftOnDate = LocalDate.parse(leftOn, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            expiredLeases = leases.stream().filter(x -> !x.isIsExpired() && x.getTenantId() == id).toList();

            if(expiredLeases.size() > 0){
                vacatedSpaces = new ArrayList<>();
                String text = "Space(S) occupied:";
                for(var lease : expiredLeases){
                    var space = spaces.stream().filter(x -> x.getId() == lease.getSpaceId()).findFirst().get();
                    var plot = plots.stream().filter(x -> x.getId() == space.getPlotId()).findFirst().get();
                    text += "\n\n" + space.getName() + " of " + plot.getName();
                    vacatedSpaces.add(space);
                }
                text += "\n\nby " + segments[0] + " now available to let out";
                message = text;
            }
            else {
                message = null;
                vacatedSpaces = null;
            }
        }
        else {
            message = null;
            expiredLeases = null;
            vacatedSpaces = null;
            leftOnDate = null;
        }
        var original = tenants.stream().filter(x -> x.getId() == id).findFirst().get();
        Platform.runLater(() -> {
            if(!original.getName().equals(segments[0])){
                for(var lease : leases){
                    if(lease.getTenantId() == id){
                        lease.setTenantName(segments[0]);
                    }
                }
            }
            original.setName(segments[0]);
            original.setFather(segments[1]);
            original.setMother(segments[2]);
            original.setHusband(segments[3]);
            original.setAddress(segments[4]);
            original.setNid(segments[5]);
            original.setContactNo(segments[6]);
            original.setHasLeft(hasLeft);

            if(!leftOn.isEmpty() && vacatedSpaces != null){
                for(var space : vacatedSpaces){
                    space.setIsVacant(true);
                }
                for(var lease : expiredLeases){
                    lease.setDateEnd(leftOnDate);
                    lease.setIsExpired(true);
                }

                var dialog = new InfoDialog("Tenant", message);
                dialog.showDialog(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight());
            }
        });
    }

    private void headAdd(ByteBuffer array) {
        var userId = array.getInt(4);
        int start = 8;
        int read = 8;

        int id = array.getInt(start);
        int controlId = array.getInt(start + 4);
        read += 8;
        start = read;

        while (array.get(read) != 0) read++;
        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        start = ++read;
        while (array.get(read) != 0) read++;
        var description = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        Platform.runLater(() -> heads.add(new Head(id, controlId, name, description)));
    }

    private void headEdit(ByteBuffer array) {
        var userId = array.getInt(4);
        int start = 8;
        int read = 8;

        int id = array.getInt(start);
        int controlId = array.getInt(start + 4);
        read += 8;
        start = read;

        while (array.get(read) != 0) read++;
        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        start = ++read;
        while (array.get(read) != 0) read++;
        var description = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        Platform.runLater(() ->{
            var original = heads.stream().filter(x -> x.getId() == id).findFirst().get();
            original.setControlId(controlId);
            original.setName(name);
            original.setDescription(description);
        });
    }

    private void leaseAdd(ByteBuffer array) {
        var userId = array.getInt(4);
        int index = 0;
        int length = array.array().length;
        int start = 8;
        int read = 8;

        int id = array.getInt(start);
        int plotId = array.getInt(start + 4);
        int spaceId = array.getInt(start + 8);
        int tenantId = array.getInt(start + 12);
        read += 16;
        start = read;

        var segments = new String[3];
        while (read < length) {
            if (array.get(read) != 0) {
                read++;
                continue;
            }
            segments[index++] = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
            start = ++read;
            if (index == segments.length) break;
        }
        var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        var dateStart = LocalDate.parse(segments[0], formatter);
        LocalDate dateEnd = null;
        var business = segments[2];
        var isExpired = false;

        read++;

        var receivables = new ArrayList<Receivable>();
        for(int i = read; i < length; i += 12){
            var rec = new Receivable();
            rec.setLeaseId(array.getInt(i));
            rec.setHeadId(array.getInt(i + 4));
            rec.setAmount(array.getInt(i + 8));
            receivables.add(rec);
        }
        var space = AppData.spaces.stream().filter(x -> x.getId() == spaceId).findFirst().get();
        Platform.runLater(() -> {
            space.setIsVacant(false);
            AppData.leases.add(new Lease(){{
               setId(id);
               setPlotId(plotId);
               setSpaceId(spaceId);
               setTenantId(tenantId);
               setPlotName(AppData.plots.stream().filter(x -> x.getId() == plotId).findFirst().get().getName());
               setSpaceName(space.getName());
               setTenantName(AppData.tenants.stream().filter(x -> x.getId() == tenantId).findFirst().get().getName());
               setBusiness(business);
               setDateStart(dateStart);
               setDateEnd(dateEnd);
               setIsExpired(isExpired);
               setFixedReceivables(FXCollections.observableArrayList(receivables));
            }});
        });
    }

    private void leaseEdit(ByteBuffer array) {
        var userId = array.getInt(4);
        int index = 0;
        int length = array.array().length;
        int start = 8;
        int read = 8;

        int id = array.getInt(start);
        int plotId = array.getInt(start + 4);
        int spaceId = array.getInt(start + 8);
        int tenantId = array.getInt(start + 12);
        read += 16;
        start = read;

        var segments = new String[3];
        while (read < length) {
            if (array.get(read) != 0) {
                read++;
                continue;
            }
            segments[index++] = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
            start = ++read;
            if (index == segments.length) break;
        }
        var isExpired = array.get(read) != 0;

        var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        var dateStart = LocalDate.parse(segments[0], formatter);
        var business = segments[2];

        read++;

        var receivables = new ArrayList<Receivable>();
        for(int i = read; i < length; i += 12){
            var rec = new Receivable();
            rec.setLeaseId(array.getInt(i));
            rec.setHeadId(array.getInt(i + 4));
            rec.setAmount(array.getInt(i + 8));
            receivables.add(rec);
        }

        var original = leases.stream().filter(x -> x.getId() == id).findFirst().get();
        final String message;
        final LocalDate dateEnd;
        if(isExpired && !original.isIsExpired()){
            dateEnd = LocalDate.parse(segments[1], DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            var space = spaces.stream().filter(x -> x.getId() == spaceId).findFirst().get();
            var plot = plots.stream().filter(x -> x.getId() == plotId).findFirst().get();
            var tenant = tenants.stream().filter(x -> x.getId() == tenantId).findFirst().get();
            message = tenant.getName() + "'s lease " + space.getName() + " of " + plot.getName() + " is free";
            Platform.runLater(() -> space.setIsVacant(true));
        }
        else {
            message = null;
            dateEnd = null;
        }

        if(original.getSpaceId() != spaceId){
            var oldSpace = spaces.stream().filter(x -> x.getId() == original.getSpaceId()).findFirst().get();
            var newSpace =  spaces.stream().filter(x -> x.getId() == spaceId).findFirst().get();
            var isPlotChanged = oldSpace.getPlotId() != newSpace.getPlotId();
            var plot = isPlotChanged ? plots.stream().filter(x -> x.getId() == plotId).findFirst().get() : null;
            Platform.runLater(() -> {
                oldSpace.setIsVacant(true);
                newSpace.setIsVacant(false);
                original.setSpaceName(newSpace.getName());
                if(isPlotChanged) original.setPlotName(plot.getName());
            });
        }
        var tenant = original.getTenantId() != tenantId ? tenants.stream().filter(x -> x.getId() == tenantId).findFirst().get() : null;

        Platform.runLater(() -> {
            original.setPlotId(plotId);
            original.setSpaceId(spaceId);
            original.setTenantId(tenantId);
            original.setDateStart(dateStart);
            original.setDateEnd(dateEnd);
            original.setBusiness(business);
            original.setIsExpired(isExpired);
            original.getFixedReceivables().clear();
            original.getFixedReceivables().addAll(receivables);
            if(tenant != null) original.setTenantName(tenant.getName());

            if(message != null){
                var dialog = new InfoDialog("Lease", message);
                dialog.showDialog(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight());
            }
        });
    }

    private void regularAdd(ByteBuffer array) {}

    private void irregularAdd(ByteBuffer array) {}

    private void transactionEdit(ByteBuffer array) {
        var userId = array.getInt(4);
        int start, read = 8;

        var transaction = new Transaction();
        transaction.setId(array.getInt(read));
        transaction.setPlotId(array.getInt(read + 4));
        transaction.setSpaceId(array.getInt(read + 8));
        transaction.setTenantId(array.getInt(read + 12));
        transaction.setControlId(array.getInt(read + 16));
        transaction.setHeadId(array.getInt(read + 20));
        transaction.setAmount(array.getInt(read + 24));
        transaction.setIsCash(array.get(read + 28 ));

        read += 29;
        start = read;

        while (array.get(read) != 0) read++;
        var date = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
        transaction.setDate(LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd")));

        start = ++read;
        while (array.get(read) != 0) read++;
        transaction.setNarration(new String(array.array(), start, read - start, StandardCharsets.US_ASCII));

        Platform.runLater(() -> onEditTransaction.set(transaction));
    }

    private void transactionDelete(ByteBuffer array) {
        var userId = array.getInt(4);
        int start, read = 8;

        var transaction = new Transaction();
        transaction.setId(array.getInt(read));
        transaction.setPlotId(array.getInt(read + 4));
        transaction.setSpaceId(array.getInt(read + 8));
        transaction.setTenantId(array.getInt(read + 12));
        transaction.setControlId(array.getInt(read + 16));
        transaction.setHeadId(array.getInt(read + 20));
        transaction.setAmount(array.getInt(read + 24));
        transaction.setIsCash(array.get(read + 28 ));

        read += 29;
        start = read;

        while (array.get(read) != 0) read++;
        var date = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
        transaction.setDate(LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd")));

        start = ++read;
        while (array.get(read) != 0) read++;
        transaction.setNarration(new String(array.array(), start, read - start, StandardCharsets.US_ASCII));

        Platform.runLater(() -> onDeleteTransaction.set(transaction));
    }

    private class InitialLoadTask extends Task<Void> {
        private List<Plot> plots;
        private List<Space> spaces;
        private List<Tenant> tenants;
        private List<Lease> leases;
        private List<ControlHead> controlHeads;
        private List<Head> heads;

        @Override
        protected Void call() throws Exception {
            int count = 0;
            updateMessage("Initializing");
            Thread.sleep(250);

            var plotSpan = getPacket();
            count += plotSpan.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            var spaceSpan = getPacket();
            count += spaceSpan.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            var tenantSpan = getPacket();
            count += tenantSpan.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            var leaseSpan = getPacket();
            count += leaseSpan.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            var receivableSpan = getPacket();
            count += receivableSpan.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            var controlHeadSpan = getPacket();
            count += controlHeadSpan.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            var headSpan = getPacket();
            count += headSpan.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            updateMessage("listing plots");
            plots = getPlots(plotSpan);
            Thread.sleep(250);

            updateMessage("listing spaces");
            spaces = getSpaces(spaceSpan);
            Thread.sleep(250);

            updateMessage("listing tenants");
            tenants = getTenants(tenantSpan);
            Thread.sleep(250);

            updateMessage("listing leases");
            leases = getLeases(leaseSpan);
            Thread.sleep(250);

            updateMessage("listing receivables");
            List<Receivable> receivables = getReceivables(receivableSpan);
            Thread.sleep(250);

            updateMessage("listing control heads");
            controlHeads = getControlHeads(controlHeadSpan);
            Thread.sleep(250);

            updateMessage("listing heads");
            heads = getHeads(headSpan);
            Thread.sleep(250);

            for (int i = 0; i < leases.size(); i++) {
                var lease = leases.get(i);
                lease.setPlotName(plots.stream().filter(x -> x.getId() == lease.getPlotId()).findFirst().get().getName());
                lease.setSpaceName(spaces.stream().filter(x -> x.getId() == lease.getSpaceId()).findFirst().get().getName());
                lease.setTenantName(tenants.stream().filter(x -> x.getId() == lease.getTenantId()).findFirst().get().getName());

                var rec = receivables.stream().filter(x -> x.getLeaseId() == lease.getId()).collect(Collectors.toCollection(FXCollections::observableArrayList));
                lease.setFixedReceivables(rec);

            }
            for(var control : controlHeads){
                if(control.getName().equals("Receivable"))
                    controlIdOfReceivable = control.getId();
                else if(control.getName().equals("Payment"))
                    controlIdOfPayment = control.getId();
            }

            return null;
        }

        @Override
        protected void succeeded() {
            AppData.plots.addAll(plots);
            AppData.spaces.addAll(spaces);
            AppData.tenants.addAll(tenants);
            AppData.leases.addAll(leases);

            AppData.controlHeads.addAll(controlHeads);
            AppData.heads.addAll(heads);
            window.isSuccessProperty.set(true);
        }

        private List<Plot> getPlots(ByteBuffer array) {
            var list = new ArrayList<Plot>();
            int read = 0;
            int start = 0;
            int length = array.array().length;
            while (read < length){
                int id = array.getInt(start);

                read += 4;
                start = read;
                while (array.get(read) != 0) read++;
                var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                start = ++read;
                while (array.get(read) != 0) read++;
                var description = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                list.add(new Plot(id, name, description));
                start = ++read;
            }
            return list;
        }

        private List<Space> getSpaces(ByteBuffer array) {
            var list = new ArrayList<Space>();
            int read = 0;
            int start = 0;
            int length = array.array().length;
            while (read < length) {
                int id = array.getInt(start);
                int plotId = array.getInt(start + 4);
                read += 8;
                start = read;
                while (array.get(read) != 0) read++;
                var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                start = ++read;
                while (array.get(read) != 0) read++;
                var description = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
                read++;
                var isVacant = array.get(read) != 0;

                list.add(new Space(id, plotId, name, description, isVacant));
                start = ++read;
            }
            return list;
        }

        private List<Tenant> getTenants(ByteBuffer array) {
            var list = new ArrayList<Tenant>();
            int read = 0;
            int start = 0;
            int length = array.array().length;
            while (read < length) {
                int id = array.getInt(start);
                read += 4;
                start = read;
                int index = 0;
                var segments = new String[7];
                while (read < length) {
                    if (array.get(read) != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }
                var hasLeft = array.get(read) != 0;
                start = ++read;

                list.add(new Tenant(){{
                    setId(id);
                    setName(segments[0]);
                    setFather(segments[1]);
                    setMother(segments[2]);
                    setHusband(segments[3]);
                    setAddress(segments[4]);
                    setNid(segments[5]);
                    setContactNo(segments[6]);
                    setHasLeft(hasLeft);
                }});
            }
            return list;
        }

        private List<Lease> getLeases(ByteBuffer array) {
            var list = new ArrayList<Lease>();
            int read = 0;
            int start = 0;
            int length = array.array().length;
            var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            while (read < length) {
                int id = array.getInt(start);
                int plotId = array.getInt(start + 4);
                int spaceId = array.getInt(start + 8);
                int tenantId = array.getInt(start + 12);

                read += 16;
                start = read;
                while (array.get(read) != 0) read++;
                var startDate = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
                var dateStart = LocalDate.parse(startDate, formatter);

                start = ++read;
                while (array.get(read) != 0) read++;
                var endDate = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
                var dateEnd = endDate.isEmpty() ? null : LocalDate.parse(endDate, formatter);

                start = ++read;
                while (array.get(read) != 0) read++;
                var business = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                read++;
                var isExpired = array.get(read) != 0;

                list.add(new Lease(){{
                    setId(id);
                    setPlotId(plotId);
                    setSpaceId(spaceId);
                    setTenantId(tenantId);
                    setDateStart(dateStart);
                    setDateEnd(dateEnd);
                    setBusiness(business);
                    setIsExpired(isExpired);
                }});
                start = ++read;
            }

            return list;
        }

        private List<Receivable> getReceivables(ByteBuffer array) {
            var list = new ArrayList<Receivable>();
            int read = 0;
            int length = array.array().length;
            while (read < length) {
                var leaseId = array.getInt(read);
                var headId = array.getInt(read + 4);
                var amount = array.getInt(read + 8);

                list.add(new Receivable(leaseId, headId, amount));
                read += 12;
            }
            return list;
        }

        private List<ControlHead> getControlHeads(ByteBuffer array) {
            var list = new ArrayList<ControlHead>();
            int read = 0;
            int start = 0;
            int length = array.array().length;

            while (read < length) {
                int id = array.getInt(start);
                read += 4;
                start = read;
                while (array.get(read) != 0) read++;
                var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                list.add(new ControlHead(id, name));
                start = ++read;
            }
            return list;
        }

        private List<Head> getHeads(ByteBuffer array) {
            var list = new ArrayList<Head>();
            int read = 0;
            int start = 0;
            int length = array.array().length;

            while (read < length) {
                int id = array.getInt(start);
                int controlId = array.getInt(start +4);
                read += 8;
                start = read;
                while (array.get(read) != 0) read++;
                var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                start = ++read;
                while (array.get(read) != 0) read++;
                var description = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                list.add(new Head(id, controlId, name, description));
                start = ++read;
            }
            return list;
        }
    }
}
