package editables;

import controls.SVGIcon;
import controls.SelectionBox;
import interfaces.IReturnNameAndId;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.transformation.FilteredList;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class EditSelection<T extends IReturnNameAndId<T>> extends GridPane {
    private final FilteredList<T> list;
    private final Text content;
    private final SelectionBox<T> box;
    private final EditPane parent;
    private final IntegerProperty valueProperty;

    public EditSelection(String hint, String icon, FilteredList<T> list, boolean isRequired, EditPane parent) {
        this.parent = parent;
        this.list = list;
        valueProperty = new SimpleIntegerProperty(-1);

        box = new SelectionBox<>(hint, icon, list, isRequired) {{
            visibleProperty().bind(parent.isOnEditProperty());
        }};
        var svgIcon = new SVGIcon(icon) {{
            visibleProperty().bind(parent.isOnEditProperty().not());
        }};
        var label = new Text(hint) {{
            setFill(Color.GRAY);
            visibleProperty().bind(parent.isOnEditProperty().not());
        }};
        content = new Text() {{
            setFill(Color.WHITE);
            visibleProperty().bind(parent.isOnEditProperty().not());
            textProperty().bind(getBinding());
        }};

        add(box, 0, 0, 2, 2);
        add(svgIcon, 0, 0);
        add(label, 1, 0);
        add(content, 0, 1, 2, 1);

        getColumnConstraints().addAll(
                new ColumnConstraints(),
                new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}}
        );
        setVgap(5);
        setHgap(5);

        parent.isOnEditProperty().addListener(this::onIsOnEditChanged);
    }

    private void onIsOnEditChanged(Observable o) {
        if (parent.isOnEditProperty().get()) {
            content.textProperty().unbind();
            box.selectedValueProperty().bindBidirectional(valueProperty);
        }
        else {
            box.selectedValueProperty().unbindBidirectional(valueProperty);
            content.textProperty().bind(getBinding());
        }
    }

    private StringBinding getBinding() {
        return Bindings.createStringBinding(() -> {
            if (valueProperty.get() == -1) return "";
            return list.stream()
                    .filter(x -> x.getId() == valueProperty.get())
                    .findFirst().get().getName();
        }, valueProperty);
    }

    public IntegerProperty valueProperty() {return valueProperty;}
}
