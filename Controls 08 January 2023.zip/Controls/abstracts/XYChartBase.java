package abstracts;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.List;

public abstract class XYChartBase<T> extends Region {
    private final Group yMajors;
    private final FadeTransition yLabelAnim;
    private final ScaleTransition lineAnim;

    protected int numLines = 6;
    protected Group xLabels, yLabels;
    protected double startX, min, max, availableHeight, availableWidth, xLabelWidth, yLabelWidth;
    protected List<T> series;

    public ObjectProperty<List<T>> seriesProperty;

    public XYChartBase() {
        yMajors = new Group() {{setManaged(false);}};
        yLabels = new Group() {{setManaged(false);}};
        xLabels = new Group() {{setManaged(false);}};

        getChildren().addAll(yMajors, yLabels, xLabels);

        for (int i = 0; i < numLines; i++) {
            var line = new Line() {{
                setStroke(Color.GRAY);
                getStrokeDashArray().addAll(5d, 2d);
                setMouseTransparent(true);
                setManaged(false);
            }};
            var label = new Text() {{
                setFill(Color.WHITE);
                setMouseTransparent(true);
                setManaged(false);
            }};

            yMajors.getChildren().add(line);
            yLabels.getChildren().add(label);
        }
        yLabelAnim = new FadeTransition(Duration.millis(500), yLabels);
        lineAnim = new ScaleTransition(Duration.millis(500), yMajors);

        yLabelAnim.setDelay(Duration.millis(500));
        yLabelAnim.setFromValue(0);
        yLabelAnim.setToValue(1);
        lineAnim.setFromY(0);
        lineAnim.setToY(1);

        seriesProperty = new SimpleObjectProperty<>();
        seriesProperty.addListener(this::onSeriesChanged);
    }

    protected abstract void setMinMaxAndXLabels();
    protected abstract void reset();

    protected void onSeriesChanged(ObservableValue<?> obs, List<T> ov, List<T> nv) {
        xLabels.getChildren().clear();
        yMajors.setScaleY(0);
        yLabels.setOpacity(0);

        if (nv == null) {
            yMajors.setVisible(false);
            return;
        }

        yLabels.setVisible(true);
        yMajors.setVisible(true);
        series = nv;
        min = 0;
        max = 0;
        xLabelWidth = 0;

        reset();
        setMinMaxAndXLabels();

        Platform.runLater(() ->{
            lineAnim.play();
            yLabelAnim.play();
        });
    }

    @Override
    protected void layoutChildren() {
        startX = yLabelWidth + 10;
        availableHeight = getHeight() - xLabelWidth;
        availableWidth = getWidth() - startX;

        var vSpace = availableHeight / (numLines - 1);

        double lineY = availableHeight;
        double labelY = lineY - 5;
        for (int i = 0; i < yMajors.getChildren().size(); i++) {
            var text = (Text) yLabels.getChildren().get(i);
            text.setY(labelY);

            var line = (Line) yMajors.getChildren().get(i);
            line.setStartY(lineY);
            line.setEndY(lineY);
            line.setEndX(getWidth());

            lineY -= vSpace;
            labelY -= vSpace;
        }
    }
}
