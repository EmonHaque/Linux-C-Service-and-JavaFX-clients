package controls.columnstackchart;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Scale;
import javafx.stage.Popup;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;

public class DoubleBar extends Region {
    private boolean isPinned;
    private final List<Column> stack;
    private final Column bar;

    private double width, height, barHeight, min, max, midPoint;
    private final double barValue;
    private final List<Double> stackValues;

    private Popup popup;

    private Timeline anim;
    private final DoubleProperty columnHeight;

    public DoubleBar(double barValue, List<Double> stackValues) {
        this.barValue = barValue;
        this.stackValues = stackValues;
        getTransforms().add(new Scale(1, -1));

        bar = new Column(Color.LIGHTBLUE, Color.LIGHTGREEN, true, barValue < 0) {{
            setManaged(false);
            setMouseTransparent(true);
        }};
        getChildren().add(bar);
        stack = new ArrayList<>();
        for (int i = 0; i < stackValues.size(); i++) {
            Column rect = null;
            if (i == stackValues.size() - 1) {
                rect = new Column(Color.CORNFLOWERBLUE, Color.BLUE, true, false);
            }
            else {
                switch (i) {
                    case 0 -> rect = new Column(Color.LIGHTGRAY, Color.GRAY, false, false);
                    case 1 -> rect = new Column(Color.LIGHTCORAL, Color.CORAL, false, false);
                }
            }
            getChildren().add(rect);
            rect.setManaged(false);
            rect.setMouseTransparent(true);
            stack.add(rect);
        }

        var clip = new Rectangle();
        layoutBoundsProperty().addListener((observable, oldValue, newValue) -> {
            clip.setWidth(newValue.getWidth());
            clip.setHeight(newValue.getHeight());
        });
        setClip(clip);
        columnHeight = new SimpleDoubleProperty(0);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseClicked(this::onClicked);
        setOnMouseExited(this::onMouseExited);
    }

    public void makeColumn(double width, double height, double min, double max) {
        this.width = width;
        this.height = height;
        this.midPoint = width / 2;
        this.min = min;
        this.max = max;


        columnHeight.addListener((o, ov, nv) -> setHeight(nv.doubleValue()));
        var key = new KeyValue(columnHeight, height, Interpolator.EASE_IN);
        var frame = new KeyFrame(Duration.millis(500), key);
        anim = new Timeline(frame);
        anim.setDelay(Duration.millis(500));
        anim.play();
        anim.setOnFinished(e -> setClip(null));
    }

    @Override
    protected void layoutChildren() {
        if (columnHeight.get() == 0) return;

        double spread = max - min;
        double negativeHeight = 0;
        if (min < 0) {
            var absMin = Math.abs(min);
            negativeHeight = height / spread * absMin;
        }

        double y = negativeHeight;
        double halfWidth = width / 2;

        barHeight = height / spread * barValue;
        bar.setValue(0, y, halfWidth, barHeight);
        for (int i = 0; i < stackValues.size(); i++) {
            barHeight = height / spread * stackValues.get(i);
            var rect = stack.get(i);
            rect.setValue(midPoint, y, halfWidth, barHeight);
            y += barHeight;
        }
        barHeight = y;
    }

    @SuppressWarnings("unchecked")
    void onMouseEntered(MouseEvent e) {
        if (isPinned) return;
        for (var column : (List<Column>) (List<?>) getChildren()) {
            column.highlightColor();
        }
        if(popup != null)
            popup.show(this, e.getScreenX() + 20, e.getScreenY() + 20);
    }

    private void onClicked(MouseEvent e) {isPinned = !isPinned;}

    @SuppressWarnings("unchecked")
    private void onMouseExited(MouseEvent e) {
        if (isPinned) return;
        for (var column : (List<Column>) (List<?>) getChildren()) {
            column.normalColor();
        }
        if(popup != null)
            popup.hide();
    }

   public void setToolTip(Popup popup){
        this.popup = popup;
   }
}
