package controls.buttons;

import interfaces.IActivate;
import javafx.animation.Animation;
import javafx.animation.FillTransition;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class CounterButton extends StackPane implements IActivate {
    private final Rectangle rect;
    private boolean isActive;
    private final FillTransition anim;
    private final IntegerProperty number;
    private final Color normal, hover, active, pressed, highlight;

    public CounterButton() {
        normal = Color.DODGERBLUE;
        highlight = Color.LIGHTGREEN;
        pressed = Color.RED;
        active = Color.CORNFLOWERBLUE;
        hover = Color.CORAL;

        number = new SimpleIntegerProperty(0);
        var text = new Text() {{
            setFill(Color.WHITE);
            setRotate(-90);
            setFont(Font.font(9));
            textProperty().bind(number.asString("%,d"));
        }};
        double width = 15;
        rect = new Rectangle(){{
            setFill(Color.DODGERBLUE);
            setArcHeight(10);
            setArcWidth(10);
            setWidth(width);
        }};
        rect.heightProperty().bind(heightProperty());

        getChildren().addAll(rect, text);
        setMinHeight(20);
        setMinWidth(width);
        setMaxWidth(width);
        setPrefWidth(width);

        anim = new FillTransition(Duration.millis(300));
        anim.setShape(rect);
        addEventHandler(MouseEvent.ANY, this::handleState);

        number.addListener((o, ov, nv) ->{
            if (nv.intValue() <= ov.intValue()) return;

            anim.setAutoReverse(true);
            anim.setFromValue((Color) rect.getFill());
            anim.setToValue(highlight);
            anim.setCycleCount(6); // 3 times it'll be green and 3 times back

            anim.setOnFinished(e -> {
                anim.setOnFinished(null);
                anim.setCycleCount(0);
                anim.setAutoReverse(false);
            });
            animate(highlight);
        });
    }

    public IntegerProperty numberProperty(){ return number; }

    protected void animate(Color color){
        if(anim.getStatus() == Animation.Status.RUNNING) anim.stop();
        anim.setToValue(color);
        anim.play();
    }
    private void handleState(MouseEvent e){
        if(isActive) return;
        if(disabledProperty().get()) return;

        if(e.getEventType() == MouseEvent.MOUSE_ENTERED){
            animate(hover);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_PRESSED){
            animate(pressed);
        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED){
            animate(normal);
        }
    }

    @Override
    public void setActive(boolean value) {
        isActive = value;
        if(isActive) animate(active);
        else animate(normal);
    }
}
