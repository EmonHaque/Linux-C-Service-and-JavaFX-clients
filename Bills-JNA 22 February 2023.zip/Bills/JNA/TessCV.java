package JNA;
import com.sun.jna.Native;

public class TessCV {
    static {
        Native.register("resources/lib/tesscv.so");
    }
    public native void initialize(String dataPath, String language);
    public native void setWhiteList(String characters);
    public native String getText(String file);

    public native void setImageFile(String file);
    public native void setImageBuffer(int size, byte[] data);

    public native ImageCV getOriginalImage();
    public native ImageCV getInvertedGrayImage();
    public native ImageCV getInvertedBinaryImage();

    public native FXMat getOriginalMat();
    public native FXMat getInvertedGrayMat();
    public native FXMat getInvertedBinaryMat();

    public native void destroyTesseract();
    public native void destroyImage();
}