package CellTemplates.SelectionBox;

import Model.Account;
import abstracts.ListCellBase;
import controls.texts.HiText;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class AccountTemplate extends ListCellBase<Account> {
    private BorderPane root;
    private HiText name;
    private Text holder;
    private final StringProperty query;

    public AccountTemplate(StringProperty query) {
        this.query = query;
        setPadding(new Insets(5));
    }

    @Override
    protected void initializeUI() {
        name = new HiText();
        holder = new Text(){{ setFill(Color.WHITE);}};
        root = new BorderPane() {{
            setCenter(name);
            setRight(holder);
            setAlignment(holder, Pos.CENTER_LEFT);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Account ov, Account nv) {
        if (ov != null) {
            name.queryProperty().unbind();
            name.queryProperty().set("");
        }
        if (nv == null) return;
        name.textProperty().bind(nv.nameProperty());
        holder.textProperty().bind(nv.holderProperty());
        name.queryProperty().bind(query);
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
