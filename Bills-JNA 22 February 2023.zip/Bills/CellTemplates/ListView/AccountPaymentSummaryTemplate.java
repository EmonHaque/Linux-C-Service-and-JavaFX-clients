package CellTemplates.ListView;

import Model.AccountPaymentSummary;
import Model.MobileEntry;
import abstracts.ListCellBase;
import helpers.Constants;
import helpers.Helper;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.TreeItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Popup;

public class AccountPaymentSummaryTemplate extends ListCellBase<AccountPaymentSummary> {
    private GridPane root;
    private Text accountNo, payment, holder, address;
    private Popup toolTip;

    @Override
    protected void initializeUI() {
        holder = new Text(){{ setFill(Color.WHITE);}};
        address = new Text(){{ setFill(Color.WHITE);}};

        toolTip = new Popup() {{
            getContent().add(
                    new VBox(holder, address){{
                        setPadding(new Insets(5));
                        setBackground(Background.fill(Constants.BackgroundColor));
                        setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
                    }}
            );
        }};

        accountNo = new Text(){{ setFill(Color.WHITE);}};
        payment = new Text(){{ setFill(Color.WHITE);}};
        root = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(100){{ setHalignment(HPos.RIGHT);}}
            );
            add(accountNo, 0, 0);
            add(payment, 1, 0);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, AccountPaymentSummary ov, AccountPaymentSummary nv) {
        if(ov != null){
            root.removeEventHandler(MouseEvent.MOUSE_ENTERED, this::onMouseEnter);
            root.removeEventHandler(MouseEvent.MOUSE_EXITED, this::onMouseExit);
        }
        if(nv != null){
            holder.setText(nv.getAccountHolder());
            address.setText(nv.getAddress());
            accountNo.setText(nv.getAccountNo());
            payment.setText(Helper.formatNumber(nv.getPayment()));
            root.addEventHandler(MouseEvent.MOUSE_ENTERED, this::onMouseEnter);
            root.addEventHandler(MouseEvent.MOUSE_EXITED, this::onMouseExit);
        }
    }

    @Override
    protected Node getRootNode() {
        return root;
    }

    private void onMouseEnter(MouseEvent e){
        toolTip.show(root, e.getScreenX() + 20, e.getScreenY() + 10);
    }

    private void onMouseExit(MouseEvent e){
        toolTip.hide();
    }
}
