package ridiculous;

import Enums.Function;
import JNA.TessCV;
import Model.*;
import com.sun.jna.Native;
import controls.LoadingWindow;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.stage.Stage;
import ridiculuous.Channels;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class AppData extends BaseData {
    public static TessCV tessCV;
    public static ObservableList<Account> accounts;
    public static ObservableList<Department> departments;
    public static ObservableList<Mobile> mobiles;
    public static ObservableList<Head> heads;
    public static ObservableList<Notification> notifications;

    public static ObjectProperty<List<Head>> onHeadAdded;
    public static ObjectProperty<EditedBillInfo> onBillInfoEdited;
    public static ObjectProperty<List<EditedEntry>> onBillEntryEdited;

    public AppData(LoadingWindow window, Stage stage) {
        super(window, stage);
        onHeadAdded = new SimpleObjectProperty<>();
        onBillInfoEdited = new SimpleObjectProperty<>();
        onBillEntryEdited = new SimpleObjectProperty<>();
        tessCV = new TessCV();
        tessCV.initialize("/home/emon/Bills/tessData", "eng");
        tessCV.setWhiteList("01234567890.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ -:'\"`~@#$%^&*()-=+_/<>?\\;,:[]{}|");
    }

    @Override
    protected int getInitialMethod() {
        return Function.GetInitialData.ordinal();
    }

    @Override
    protected void initializeCollections() {
        accounts = FXCollections.observableArrayList();
        departments = FXCollections.observableArrayList();
        mobiles = FXCollections.observableArrayList();
        heads = FXCollections.observableArrayList();
        notifications = FXCollections.observableArrayList();
    }

    @Override
    protected void populateCollections() {
        var task = new InitialLoadTask();
        window.messageProperty.bind(task.messageProperty());
        new Thread(task).start();
    }

    @Override
    protected void processMessage() {
        while (isConnected) {
            try {
                var packet = ByteBuffer.wrap(messages.take()).order(ByteOrder.LITTLE_ENDIAN);
                var message = Function.values()[packet.getInt()];
                switch (message) {
                    case AddDepartment -> addDepartment(packet);
                    case AddAccount -> addAccount(packet);
                    case AddMobile -> addMobile(packet);
                    case AddHead -> addHead(packet);
                    case EditBillInfo -> editBillInfo(packet);
                    case EditBillEntry -> editEntryInfo(packet);
                    case EditAccount -> editAccount(packet);
                    case EditHead -> editHead(packet);
                    case EditDepartment -> editDepartment(packet);
                    case EditMobile -> editMobile(packet);
                }
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void addDepartment(ByteBuffer array) {
        var userId = array.getInt(4);
        int start = 8;
        int read = 8;

        int id = array.getInt(start);
        read += 4;
        start = read;
        while (array.get(read) != 0) read++;
        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        Platform.runLater(() -> {
            AppData.departments.add(new Department(id, name));
            if (userId != Channels.getInstance().userId) {
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Department");
                    setMessage(name + " added by " + userId);
                }});
            }
        });
    }

    private void addAccount(ByteBuffer array) {
        var userId = array.getInt(4);
        int start = 8;
        int read = 8;
        int length = array.array().length;

        int id = array.getInt(start);
        int deptId = array.getInt(start + 4);
        read += 8;
        start = read;

        int index = 0;
        var segments = new String[3];
        while (read < length) {
            if (array.get(read) != 0) {
                read++;
                continue;
            }
            segments[index++] = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
            start = ++read;
            if (index == segments.length) break;
        }
        var isWrong = array.get(read) == 1;
        var deptName = AppData.departments.stream().filter(x -> x.getId() == deptId).findFirst().get().getName();
        Platform.runLater(() -> {
            var account = new Account() {{
                setId(id);
                setDepartmentId(deptId);
                setName(segments[0]);
                setHolder(segments[1]);
                setAddress(segments[2]);
                setIsWrong(isWrong);
                setDepartmentName(deptName);
            }};
            AppData.accounts.add(account);
            if (userId != Channels.getInstance().userId) {
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Account");
                    setMessage(account.getName() + " in Department " + deptName + " added by " + userId);
                }});
            }
        });
    }

    private void addMobile(ByteBuffer array) {
        var userId = array.getInt(4);
        int start = 8;
        int read = 8;

        int id = array.getInt(start);
        read += 4;
        start = read;
        while (array.get(read) != 0) read++;
        var number = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        start = ++read;
        while (array.get(read) != 0) read++;
        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        Platform.runLater(() -> {
            AppData.mobiles.add(new Mobile(id, name, number));
            if (userId != Channels.getInstance().userId) {
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Mobile");
                    setMessage(number + " for " + name + " added by " + userId);
                }});
            }
        });
    }

    private void addHead(ByteBuffer array) {
        var userId = array.getInt(4);

        int start, read = 8;
        int remaining = array.array().length - 8;
        var heads = new ArrayList<Head>();

        while (read < remaining) {
            int id = array.getInt(read);
            read += 4;
            start = read;
            while (array.get(read) != 0) read++;
            var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
            heads.add(new Head(id, name));
            ++read;
        }
        Platform.runLater(() -> {
            for (var head : heads) {
                AppData.heads.add(new Head(head.getId(), head.getName()));
            }
            if (userId != Channels.getInstance().userId) {
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Head");
                    setMessage(heads.size() + " new head added by " + userId);
                }});
            }
            onHeadAdded.set(heads);
        });
    }

    private void editBillInfo(ByteBuffer array) {
        var userId = array.getInt(4);
        int length = array.array().length;
        int index = 0, read = 17, start = 17;

        var segments = new String[5];
        while (read < length) {
            if (array.get(read) != 0) {
                read++;
                continue;
            }
            segments[index++] = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
            start = ++read;
            if (index == segments.length) break;
        }

        var info = new EditedBillInfo() {{
            setBillId(array.getInt(8));
            setMobileId(array.getInt(12));
            setFileRenamed(array.get(16) == 1);
            setDate(segments[0]);
            setBillNo(segments[1]);
            setTransactionId(segments[2]);
            setPeriod(segments[3]);
            setNewFile(segments[4]);
        }};

        Platform.runLater(() -> {
            onBillInfoEdited.set(info);
            if (userId != Channels.getInstance().userId){
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Bill info");
                    setMessage("a bill information of " + info.getDate()  + " has been edited by " + userId);
                }});
            }
        });
    }

    private void editEntryInfo(ByteBuffer array){
        var userId = array.getInt(4);
        int length = array.array().length;
        int read = 8;
        int size = (length - 8) / 24;

        var list = new ArrayList<EditedEntry>();
        for(int i = 0; i < size; i++){
            int billId = array.getInt(read);
            int headId = array.getInt(read + 4);
            double payment = array.getDouble(read + 8);
            double bill = array.getDouble(read + 16);
            read += 24;

            list.add(new EditedEntry(billId, headId, payment, bill));
        }
        Platform.runLater(() -> {
            onBillEntryEdited.set(list);
            if (userId != Channels.getInstance().userId){
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Entry info");
                    setMessage("a bill entry has been edited by " + userId);
                }});
            }
        });
    }

    private void editAccount(ByteBuffer array){
        var userId = array.getInt(4);
        int length = array.array().length;

        int id = array.getInt(8);
        boolean isWrong = array.get(12) == 1;

        int index = 0, read = 13, start = 13;
        var segments = new String[3];
        while (read < length){
            if (array.get(read) != 0) {
                read++;
                continue;
            }
            segments[index++] = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
            start = ++read;
            if (index == segments.length) break;
        }
        var old = AppData.accounts.stream().filter(x -> x.getId() == id).findFirst().get();

        Platform.runLater(() ->{
            old.setIsWrong(isWrong);
            old.setName(segments[0]);
            old.setHolder(segments[1]);
            old.setAddress(segments[2]);
            if (userId != Channels.getInstance().userId){
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Account");
                    setMessage("an Account in " + old.getDepartmentName()  + " has been edited by " + userId);
                }});
            }
        });
    }

    private void editHead(ByteBuffer array){
        var userId = array.getInt(4);

        int id = array.getInt(8), read = 12, start = 12;
        while ((array.get(read) != 0)) read++;
        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        var old = AppData.heads.stream().filter(x -> x.getId() == id).findFirst().get();
        var oldName = old.getName();
        Platform.runLater(() ->{
            old.setName(name);
            if (userId != Channels.getInstance().userId){
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Head");
                    setMessage(oldName  + " has been replaced with " + name + " by " + userId);
                }});
            }
        });
    }

    private void editDepartment(ByteBuffer array){
        var userId = array.getInt(4);

        int id = array.getInt(8), read = 12, start = 12;
        while ((array.get(read) != 0)) read++;
        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        var old = AppData.departments.stream().filter(x -> x.getId() == id).findFirst().get();
        var oldName = old.getName();
        Platform.runLater(() ->{
            old.setName(name);
            if (userId != Channels.getInstance().userId){
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Department");
                    setMessage(oldName  + " has been replaced with " + name + " by " + userId);
                }});
            }
        });
    }

    private void editMobile(ByteBuffer array){
        var userId = array.getInt(4);

        int id = array.getInt(8), read = 12, start = 12;
        while ((array.get(read) != 0)) read++;
        var number = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        read++;
        start = read;
        while ((array.get(read) != 0)) read++;
        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

        var old = AppData.mobiles.stream().filter(x -> x.getId() == id).findFirst().get();
        var oldName = old.getName();
        var oldNumber = old.getNumber();
        Platform.runLater(() ->{
            old.setName(name);
            old.setNumber(number);
            if (userId != Channels.getInstance().userId){
                notifications.add(new Notification() {{
                    setIsRead(false);
                    setCategory("Mobile");
                    setMessage(oldName  + " : " + oldNumber + " has been replaced with " + name + " : " + number + " by " + userId);
                }});
            }
        });
    }

    private class InitialLoadTask extends Task<Void> {
        private List<Account> accounts;
        private List<Mobile> mobiles;
        private List<Department> departments;
        private List<Head> heads;

        @Override
        protected Void call() throws Exception {
            int count = 0;
            updateMessage("Initializing");
            Thread.sleep(250);

            var accountsBuffer = getPacket();
            count += accountsBuffer.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            var mobilesBuffer = getPacket();
            count += mobilesBuffer.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            var headsBuffer = getPacket();
            count += headsBuffer.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            var departmentsBuffer = getPacket();
            count += departmentsBuffer.array().length;
            updateMessage("received " + String.format("%,d", count) + " bytes");
            Thread.sleep(250);

            updateMessage("listing departments");
            departments = getDepartments(departmentsBuffer);
            Thread.sleep(250);

            updateMessage("listing heads");
            heads = getHeads(headsBuffer);
            Thread.sleep(250);

            updateMessage("listing accounts");
            accounts = getAccounts(accountsBuffer);
            Thread.sleep(250);

            updateMessage("listing mobiles");
            mobiles = getMobiles(mobilesBuffer);
            Thread.sleep(250);

            return null;
        }

        @Override
        protected void succeeded() {
            AppData.departments.addAll(departments);
            AppData.heads.addAll(heads);
            AppData.accounts.addAll(accounts);
            AppData.mobiles.addAll(mobiles);
            window.isSuccessProperty.set(true);
        }

        private List<Department> getDepartments(ByteBuffer array) {
            var list = new ArrayList<Department>();
            int read = 0;
            int start = 0;
            int length = array.array().length;
            while (read < length) {
                int id = array.getInt(start);
                read += 4;
                start = read;
                while (array.get(read) != 0) read++;
                var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
                list.add(new Department(id, name));
                start = ++read;
            }
            return list;
        }

        private List<Head> getHeads(ByteBuffer array) {
            var list = new ArrayList<Head>();
            int read = 0;
            int start = 0;
            int length = array.array().length;
            while (read < length) {
                int id = array.getInt(start);
                read += 4;
                start = read;
                while (array.get(read) != 0) read++;
                var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
                list.add(new Head(id, name));
                start = ++read;
            }
            return list;
        }

        private List<Account> getAccounts(ByteBuffer array) {
            var list = new ArrayList<Account>();
            int read = 0;
            int start = 0;
            int length = array.array().length;
            while (read < length) {
                int id = array.getInt(start);
                int deptId = array.getInt(start + 4);
                read += 8;
                start = read;

                while (array.get(read) != 0) read++;
                var accountId = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                start = ++read;
                while (array.get(read) != 0) read++;
                var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                start = ++read;
                while (array.get(read) != 0) read++;
                var address = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                var isWrong = array.get(++read);

                var deptName = departments.stream().filter(x -> x.getId() == deptId).findFirst().get().getName();

                list.add(new Account() {{
                    setId(id);
                    setDepartmentId(deptId);
                    setName(accountId);
                    setHolder(name);
                    setAddress(address);
                    setIsWrong(isWrong == 1);
                    setDepartmentName(deptName);
                }});
                start = ++read;
            }
            return list;
        }

        private List<Mobile> getMobiles(ByteBuffer array) {
            var list = new ArrayList<Mobile>();
            int read = 0;
            int start = 0;
            int length = array.array().length;
            while (read < length) {
                int id = array.getInt(start);
                read += 4;
                start = read;

                while (array.get(read) != 0) read++;
                var number = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);

                start = ++read;
                while (array.get(read) != 0) read++;
                var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);


                list.add(new Mobile(id, name, number));
                start = ++read;
            }
            return list;
        }
    }
}
