package Dialogs;

import Model.Mobile;
import abstracts.DialogBase;
import controls.buttons.ActionButton;
import controls.texts.TextBox;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class MobileCreateDialog extends DialogBase {
    private ActionButton okButton, closeButton;
    public boolean isOk;
    private final VBox box;
    private final Mobile mobile;

    public MobileCreateDialog(String title, Mobile mobile) {
        super();
        this.mobile = mobile;
        titlelabel.setText(title);

        box = new VBox() {{
            setBackground(Background.fill(Color.BLACK));
            setPadding(new Insets(10));
            setSpacing(10);
            getChildren().addAll(
                    new HBox() {{
                        getChildren().addAll(
                                new Text("Number: ") {{setFill(Color.WHITE); setFont(Constants.Bold);}},
                                new Text(mobile.getNumber()) {{setFill(Color.WHITE);}}
                        );
                        setSpacing(5);
                    }},
                    new TextBox("Name", Icons.Tenant, true) {{mobile.nameProperty().bind(textProperty());}}
            );
        }};

        root.setCenter(box);

        okButton = new ActionButton(Icons.CheckCircle, 16, "Yes");
        closeButton = new ActionButton(Icons.CloseCircle, 16, "No");
        okButton.setAction(this::confirm);
        closeButton.setAction(this::cancel);
        buttonsPane.getChildren().addAll(okButton, closeButton);
        GridPane.setHgrow(closeButton, Priority.ALWAYS);
        GridPane.setHalignment(closeButton, HPos.LEFT);
        GridPane.setHalignment(closeButton, HPos.RIGHT);
        GridPane.setMargin(okButton, new Insets(5, 0, 5, 5));
        GridPane.setMargin(closeButton, new Insets(5, 5, 5, 0));
    }

    @Override
    public void showDialog(double left, double top, double width, double height) {
        var h = height / 3;
        box.setMinHeight(h);
        box.setPrefHeight(h);
        box.setMaxHeight(h);

        super.showDialog(left, top, width, height);
        showAndWait();
    }

    public void cancel() {
        super.closeDialog();
        isOk = false;
    }

    public void confirm() {
        super.closeDialog();
        isOk = true;
    }

    public Mobile getMobile() {return mobile;}
}
