package Views.Search;

import ViewModels.Search.DepartmentSearchVM;
import ViewModels.Search.TgclVM;
import helpers.Icons;

public class Tgcl extends DepartmentSearch{
    @Override
    protected String getIcon() {
        return Icons.Gas;
    }

    @Override
    protected DepartmentSearchVM getViewModel() {
        return new TgclVM();
    }
}
