package Views.Search;

import CellTemplates.ListView.BreakupTemplate;
import Controls.ImageViewer;
import Model.Breakup;
import Model.Head;
import ViewModels.Search.SearchBaseVM;
import abstracts.View;
import controls.SpinningArc;
import controls.SumBoxDoubleColumn;
import controls.piechart.Pie;
import controls.texts.TextBox;
import dialogs.InfoKeyValueDialog;
import editables.EditPane;
import editables.EditSumBoxDoubleColumn;
import editables.EditText;
import helpers.Constants;
import helpers.Helper;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import ridiculous.AppData;
import skinned.ExtendedResizableListView;
import skinned.ExtendedSeparator;

public abstract class SearchBase extends View {
    protected TextBox query;
    private ExtendedResizableListView<Breakup> breakups;
    private Pie pie;
    private Text breakupBill, breakupPayment, status;

    private EditPane billInfoEditPane, billEntryEditPane;
    private EditText billNo, period, transactionId, date, mobile;
    private EditSumBoxDoubleColumn editEntries;
    private SumBoxDoubleColumn<String> sumBox;
    //private Text billNo, period, transactionId, date, mobile;

    private GridPane rightGrid;
    private SpinningArc spinner;
    private ImageViewer imageViewer;
    private VBox rightBox;
    protected SearchBaseVM viewModel;

    protected abstract SearchBaseVM getViewModel();
    protected abstract Node getLeftView();
    protected abstract Node getTopRightView();
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        viewModel = getViewModel();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        query = new TextBox("Search", Icons.Magnify, false);
        imageViewer = new ImageViewer(true);
        initializeRightBox();

        var grid = new GridPane(){{
            setPadding(new Insets(5,0,0,0));
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setPercentWidth(33);}},
                    new ColumnConstraints(){{ setPercentWidth(0.5);}},
                    new ColumnConstraints(){{ setPercentWidth(33);}},
                    new ColumnConstraints(){{ setPercentWidth(0.5);}},
                    new ColumnConstraints(){{ setPercentWidth(33);}}
            );
            getRowConstraints().add(new RowConstraints(){{ setPercentHeight(100);}});
            add(getLeftView(), 0, 0);
            add(new ExtendedSeparator(){{ setOrientation(Orientation.VERTICAL);}}, 1, 0);
            add(imageViewer, 2, 0);
            add(new ExtendedSeparator(){{ setOrientation(Orientation.VERTICAL);}}, 3, 0);
            add(rightGrid, 4, 0);
        }};
        setCenter(grid);

        spinner = new SpinningArc();
        status = new Text(){{ setFill(Color.WHITE);}};
        addAction(spinner);
        addAction(status);
    }

    private void initializeBreakup(){
        var header = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(90){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(90){{ setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Head"){{ setFill(Color.WHITE);}}, 0, 0);
            add(new Text("Payment"){{ setFill(Color.WHITE);}}, 1, 0);
            add(new Text("Bill"){{ setFill(Color.WHITE);}}, 2, 0);

            setBorder(Constants.BottomBorder);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};

        breakupBill = new Text(){{ setFill(Color.WHITE);}};
        breakupPayment = new Text(){{ setFill(Color.WHITE);}};
        var footer = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(90){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(90){{ setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Total"){{ setFill(Color.WHITE);}}, 0, 0);
            add(breakupPayment, 1, 0);
            add(breakupBill, 2, 0);

            setBorder(Constants.TopBorder);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};
        breakups = new ExtendedResizableListView<>(viewModel.breakups);
        breakups.setMaxHeight(200);
        breakups.setCellFactory(x -> new BreakupTemplate());

        var breakupBox = new VBox(header, breakups, footer);

        var suggestionList = FXCollections.observableArrayList(AppData.heads.stream().map(Head::getName).toList());
        sumBox = new SumBoxDoubleColumn<>(suggestionList, null, null){{ setHeader("Payments", "Payment", "Bill");}};

        billEntryEditPane = new EditPane(viewModel::saveEntries);
        billEntryEditPane.makeHoverEdit();
        if(this instanceof MobileSearch) billEntryEditPane.makeUneditable();

        editEntries = new EditSumBoxDoubleColumn(sumBox, breakupBox, billEntryEditPane);
        billEntryEditPane.setCenter(editEntries);
    }

    private void initializeRightBox(){
        rightBox = new VBox();
        initializeBreakup();

        billInfoEditPane = new EditPane(viewModel::saveBillInfo);
        date = new EditText("Date", Icons.Month, true, billInfoEditPane);
        period = new EditText("Period", Icons.Month, true, billInfoEditPane);
        billNo = new EditText("Bill no", Icons.Month, false, billInfoEditPane);
        transactionId = new EditText("Transaction No", Icons.Month, true, billInfoEditPane);
        mobile = new EditText("Mobile", Icons.Month, true, billInfoEditPane);

        var infoGrid = new GridPane(){{
           getColumnConstraints().addAll(
                   new ColumnConstraints(){{ setPercentWidth(50);}},
                   new ColumnConstraints(){{ setPercentWidth(50); setHalignment(HPos.RIGHT);}}
           );
           add(period, 0, 0, 2, 1);
           add(date, 0, 1);
           add(mobile, 1, 1);
           add(billNo, 0, 2);
           add(transactionId, 1, 2);
           setVgap(5);
           setHgap(5);
           setPadding(new Insets(0,0,5,0));
           setHalignment(period, HPos.CENTER);
        }};

        billInfoEditPane.setCenter(infoGrid);
        billInfoEditPane.makeHoverEdit();
        if(this instanceof MobileSearch) billInfoEditPane.makeUneditable();

        //rightBox.getChildren().addAll(billInfoEditPane, header, breakups, footer);
        rightBox.getChildren().addAll(billInfoEditPane, billEntryEditPane);

        pie = new Pie();

        rightGrid = new GridPane(){{
            getRowConstraints().addAll(
                    new RowConstraints(){{ setPercentHeight(30);}},
                    new RowConstraints(){{ setPercentHeight(40);}},
                    new RowConstraints(){{ setPercentHeight(30);}}
            );
            getColumnConstraints().add(new ColumnConstraints(){{ setPercentWidth(100);}});
            add(getTopRightView(), 0, 0);
            add(rightBox, 0, 1);
            add(pie, 0, 2);

            setPadding(new Insets(0,0,0,5));
        }};
    }

    protected void bind(){
        viewModel.query.bind(query.textProperty());
        viewModel.isInfoOnEdit.bind(billInfoEditPane.isOnEditProperty());
        viewModel.isEntryOnEdit.bind(billEntryEditPane.isOnEditProperty());
        spinner.visibleProperty().bind(viewModel.isRunning);
        status.textProperty().bind(viewModel.status);

        breakupBill.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(viewModel.breakupBillTotal.get()), viewModel.breakupBillTotal));
        breakupPayment.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(viewModel.breakupPaymentTotal.get()), viewModel.breakupPaymentTotal));

        pie.seriesProperty.bind(viewModel.breakupSeries);

        billInfoEditPane.canEditProperty().bind(viewModel.imageBuffer.isNotNull());
        billEntryEditPane.canEditProperty().bind(viewModel.imageBuffer.isNotNull());

        rightBox.visibleProperty().bind(viewModel.imageBuffer.isNotNull());
        imageViewer.bufferProperty.bind(viewModel.imageBuffer);

        viewModel.selectedEntry.addListener((o, ov, nv) ->{
            if(billInfoEditPane.onEdit()) billInfoEditPane.setIsOnEdit(false);
            if(ov != null){

            }
            if(nv != null){
                var e = viewModel.selectedEntry.get();
                var mobileId = this instanceof MobileSearch ? viewModel.selectedId.get() : e.getMobileId();
                var mob = AppData.mobiles.stream().filter(x -> x.getId() == mobileId).findFirst().get();
                date.textProperty().bind(e.dateProperty());
                period.textProperty().bind(e.periodProperty());
                transactionId.textProperty().bind(e.transactionIdProperty());
                billNo.textProperty().bind(e.billNoProperty());
                mobile.textProperty().bind(mob.numberProperty());
            }
        });

        viewModel.isEntryOnEdit.addListener((o, ov, nv) ->{
            if(nv){
                sumBox.setList(viewModel.entryList);
            }
        });

        viewModel.isInfoOnEdit.addListener((o, ov, nv) ->{
            if(nv){
                date.textProperty().unbind();
                period.textProperty().unbind();
                transactionId.textProperty().unbind();
                billNo.textProperty().unbind();
                mobile.textProperty().unbind();


                date.textProperty().bindBidirectional(viewModel.edited.dateProperty());
                period.textProperty().bindBidirectional(viewModel.edited.periodProperty());
                transactionId.textProperty().bindBidirectional(viewModel.edited.transactionIdProperty());
                billNo.textProperty().bindBidirectional(viewModel.edited.billNoProperty());
                mobile.textProperty().bindBidirectional(viewModel.edited.mobileNoProperty());
            }
            else{
                date.textProperty().unbindBidirectional(viewModel.edited.dateProperty());
                period.textProperty().unbindBidirectional(viewModel.edited.periodProperty());
                transactionId.textProperty().unbindBidirectional(viewModel.edited.transactionIdProperty());
                billNo.textProperty().unbindBidirectional(viewModel.edited.billNoProperty());
                mobile.textProperty().unbindBidirectional(viewModel.edited.mobileNoProperty());

                var e = viewModel.selectedEntry.get();
                var mobileId = this instanceof MobileSearch ? viewModel.selectedId.get() : e.getMobileId();
                var mob = AppData.mobiles.stream().filter(x -> x.getId() == mobileId).findFirst().get();
                date.textProperty().bind(e.dateProperty());
                period.textProperty().bind(e.periodProperty());
                transactionId.textProperty().bind(e.transactionIdProperty());
                billNo.textProperty().bind(e.billNoProperty());
                mobile.textProperty().bind(mob.numberProperty());
            }
        });

        viewModel.errorTrigger.addListener((o, ov, nv) ->{
            if(nv){
                var dialog = new InfoKeyValueDialog("Bill info", viewModel.errors);
                var bound = rightGrid.localToScreen(rightGrid.getBoundsInLocal());
                dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
                viewModel.errorTrigger.set(false);
            }
        });
    }
}
