package Controls;

import JNA.FXMat;
import controls.ImageZoomer;
import controls.buttons.CommandButton;
import helpers.Icons;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.geometry.Pos;
import javafx.scene.image.PixelFormat;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import ridiculous.AppData;

import java.nio.ByteBuffer;

public class ImageViewer extends BorderPane {
    private enum ImageType{
        BinaryInverted,
        GrayInverted,
        Color
    }
    public StringProperty fileProperty;
    public ObjectProperty<byte[]> bufferProperty;
    private final CommandButton blackWhite, grayScale, color;
    private final PixelFormat<ByteBuffer> rgb, gray;
    private final ImageZoomer zoomer;
    private WritableImage image;

    public ImageViewer(boolean isOfBuffer) {
        blackWhite = new CommandButton(Icons.ImageBW, 16, "Black & White");
        grayScale = new CommandButton(Icons.ImageGray, 16, "Gray Scale");
        color = new CommandButton(Icons.ImageColor, 16, "Original");

        var colors = new int[256];
        for (int i = 0; i < 256; i++) {
            // r = g = b = i, a = 255
            colors[i] = (255 << 24) | (i << 16) | (i << 8) | i;
        }
        rgb = PixelFormat.getByteRgbInstance();
        gray = PixelFormat.createByteIndexedInstance(colors);

        blackWhite.setAction(() -> makeImage(ImageType.BinaryInverted));
        grayScale.setAction(() -> makeImage(ImageType.GrayInverted));
        color.setAction(() -> makeImage(ImageType.Color));

        var button = new HBox(blackWhite, grayScale, color) {{
            setAlignment(Pos.CENTER_RIGHT);
        }};

        zoomer = new ImageZoomer();
        setTop(button);
        setCenter(zoomer);


        BooleanBinding disableBinding;
        if (isOfBuffer) {
            bufferProperty = new SimpleObjectProperty<>();
            bufferProperty.addListener((o, ov, nv) -> {
                if (nv == null) {
                    image = null;
                    zoomer.imageProperty.set(null);
                }
                else {
                    AppData.tessCV.setImageBuffer(nv.length, nv);
                    makeImage(ImageType.GrayInverted);
                }
            });
            disableBinding = bufferProperty.isNull();
        }
        else {
            fileProperty = new SimpleStringProperty("");
            fileProperty.addListener((o, ov, nv) -> {
                if (nv == null) {
                    image = null;
                    zoomer.imageProperty.set(null);
                }
                else {
                    AppData.tessCV.setImageFile(nv);
                    makeImage(ImageType.GrayInverted);
                }
            });
            disableBinding = fileProperty.isNull().or(fileProperty.isEmpty());
        }
        blackWhite.disableProperty().bind(disableBinding);
        grayScale.disableProperty().bind(disableBinding);
        color.disableProperty().bind(disableBinding);
    }

    private void makeImage(ImageType type){
        FXMat mat;
        if(type == ImageType.BinaryInverted){
            mat = AppData.tessCV.getInvertedBinaryMat();
        }
        else if(type == ImageType.GrayInverted){
            mat = AppData.tessCV.getInvertedGrayMat();
        }
        else{
            mat = AppData.tessCV.getOriginalMat();
        }
        var format = mat.channels == 1 ? gray : rgb;
        var array = mat.data.getByteArray(0, mat.size);
        image = new WritableImage(mat.width, mat.height);
        image.getPixelWriter().setPixels(0, 0, mat.width, mat.height, format, array, 0, mat.width * mat.channels);
        zoomer.imageProperty.set(image);
    }
}
