package ViewModels.Home;

import Enums.DepositDueRentState;
import Enums.Function;
import Models.DepositDueRent;
import Models.Receivable;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import model.PieSeries;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class RentVM {
    private ObservableList<PieSeries> summary;
    private ResponseTask task;
    public StringProperty status;
    public BooleanProperty isRunning;
    public IntegerProperty state, totalPlot, totalInPlot;
    public ObjectProperty<List<PieSeries>> seriesProperty;

    public static IntegerProperty selectedPlot;
    public static ObjectProperty<List<DepositDueRent>> depositDueRentList;

    public RentVM() {
        status = new SimpleStringProperty("");
        isRunning = new SimpleBooleanProperty();
        state = new SimpleIntegerProperty();
        seriesProperty = new SimpleObjectProperty<>();
        totalPlot = new SimpleIntegerProperty();
        totalInPlot = new SimpleIntegerProperty();

        selectedPlot = new SimpleIntegerProperty();
        depositDueRentList = new SimpleObjectProperty<>();

        state.addListener(this::onStateChanged);
    }

    public void refresh() {onStateChanged(null);}

    private void onStateChanged(Observable o) {
        status.unbind();
        isRunning.unbind();
        status.set("");
        isRunning.set(false);

        if (task != null && task.isRunning()) {
            task.setOnCancelled(e -> {
                task.setOnCancelled(null);
                makeSummary();
            });
            task.cancel();
        }
        else makeSummary();
    }

    private void makeSummary() {
        var list = new ArrayList<DepositDueRent>();
        summary = FXCollections.observableArrayList();
        int totalPlot = 0, totalInPlot = 0;
        if (state.get() == 0) {
            for (var plot : AppData.plots) {
                int grandTotal = 0;
                for (var item : AppData.leases) {
                    if (item.getPlotId() != plot.getId() || item.isIsExpired()) continue;
                    int total = item.getFixedReceivables().stream().mapToInt(Receivable::getAmount).sum();
                    list.add(new DepositDueRent() {{
                        setState(DepositDueRentState.Rent);
                        setPlotId(item.getPlotId());
                        setSpaceId(item.getSpaceId());
                        setTenantId(item.getTenantId());
                        setAmount(total);
                    }});
                    grandTotal += total;
                }
                depositDueRentList.set(list);
                summary.add(new PieSeries(plot.getId(), plot.getName(), grandTotal));
                totalPlot++;
                totalInPlot += grandTotal;
            }
            this.totalPlot.set(totalPlot);
            this.totalInPlot.set(totalInPlot);
            seriesProperty.set(summary);
        }
        else {
            task = new ResponseTask();
            status.bind(task.messageProperty());
            isRunning.bind(task.runningProperty());
            new Thread(task) {{setDaemon(true);}}.start();
        }
    }

    private class ResponseTask extends Task<List<DepositDueRent>> {
        private int length;

        @Override
        protected List<DepositDueRent> call() {
            try {
                updateMessage("requesting ...");
                Thread.sleep(500);
                if (isCancelled()) {
                    updateMessage("cancelled ...");
                    return null;
                }

                var request = new Request(Function.GetDepositDueRent.ordinal(), ByteBuffer.allocate(1).put((byte) state.get()));
                var response = Channels.getInstance().getResponse(request).get();
                if (!response.isSuccess()) {
                    updateMessage("service down ...");
                    Thread.sleep(500);
                    return null;
                }
                if (isCancelled()) {
                    updateMessage("cancelled ...");
                    return null;
                }

                length = response.getPacket().length;
                var buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
                updateMessage("received " + String.format("%,d", length) + " bytes");
                Thread.sleep(500);

                if (isCancelled()) {
                    updateMessage("cancelled ...");
                    return null;
                }
                updateMessage("processing " + String.format("%,d", length) + " bytes");
                Thread.sleep(500);
                var list = new ArrayList<DepositDueRent>();
                int read = 0;
                while (read < length) {
                    var ddr = new DepositDueRent();
                    ddr.setState(DepositDueRentState.values()[buffer.get(read)]);
                    ddr.setPlotId(buffer.getInt(read + 1));
                    ddr.setSpaceId(buffer.getInt(read + 5));
                    ddr.setTenantId(buffer.getInt(read + 9));
                    ddr.setAmount(buffer.getInt(read + 13));
                    list.add(ddr);
                    read += 17;
                    if (isCancelled()) {
                        updateMessage("cancelled ...");
                        break;
                    }
                }
                return isCancelled() ? null : list;
            } catch (InterruptedException | ExecutionException e) {
                updateMessage("cancelled ...");
                return null;
            }
        }

        @Override
        protected void succeeded() {
            try {
                var list = get();
                int totalInPlot = 0, totalPlot = 0;
                for (var plot : AppData.plots) {
                    var total = list.stream().filter(x -> x.getPlotId() == plot.getId()).mapToInt(DepositDueRent::getAmount).sum();
                    summary.add(new PieSeries(plot.getId(), plot.getName(), total));
                    totalPlot++;
                    totalInPlot += total;
                }
                RentVM.this.totalPlot.set(totalPlot);
                RentVM.this.totalInPlot.set(totalInPlot);
                depositDueRentList.set(list);
                seriesProperty.set(summary);
                updateMessage("processed " + String.format("%,d", length) + " bytes");

            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
