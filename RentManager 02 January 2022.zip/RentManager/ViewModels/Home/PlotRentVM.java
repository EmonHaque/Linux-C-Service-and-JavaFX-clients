package ViewModels.Home;

import Enums.Function;
import Models.PlotwiseRent;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class PlotRentVM {
    private int selectedPlotId, requestId;
    public StringProperty statusProperty;
    public BooleanProperty stateProperty, isRunningProperty;
    public ObjectProperty<List<PlotwiseRent>> seriesProperty;

    public PlotRentVM() {
        statusProperty = new SimpleStringProperty("");
        stateProperty = new SimpleBooleanProperty();
        isRunningProperty = new SimpleBooleanProperty();
        seriesProperty = new SimpleObjectProperty<>();
        stateProperty.addListener(this::onStateChanged);
        RentVM.selectedPlot.addListener(this::onPlotChanged);
    }

    private void onStateChanged(ObservableValue<?> o, boolean ov, boolean nv){
        requestId = nv ? 0 : selectedPlotId;
        refresh();
    }

    private void onPlotChanged(ObservableValue<?> o, Number ov, Number nv){
        if(selectedPlotId == nv.intValue()) return;
        selectedPlotId = nv.intValue();
        requestId = stateProperty.get() ? 0 : selectedPlotId;
        refresh();
    }

    public void refresh(){
        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private class ResponseTask extends Task<List<PlotwiseRent>>{
        private int length;
        @Override
        protected List<PlotwiseRent> call() throws Exception {
            updateMessage("requesting ...");
            Thread.sleep(500);

            var date = LocalDate.now().minusYears(2);
            date = LocalDate.of(date.getYear(), date.getMonthValue(), 1);
            var dateBytes = (date.toString() + '\0').getBytes(StandardCharsets.US_ASCII);
            var buffer = ByteBuffer.allocate(4 + dateBytes.length)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .putInt(requestId)
                    .put(dateBytes);

            var request = new Request(Function.GetPlotwiseRent.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return null;
            }
            length = response.getPacket().length;
            buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
            updateMessage("received " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);

            updateMessage("processing " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);
            var list = new ArrayList<PlotwiseRent>();
            int read, start, index;
            read = index = start = 0;

            while (read < length) {
                var segments = new String[3];
                while (read < length) {
                    if (buffer.get(read) != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }
                var pr = new PlotwiseRent();
                pr.setPlotName(segments[0]);
                pr.setTenantName(segments[1]);
                pr.setMonth(segments[2]);
                pr.setRent(buffer.getInt(start));
                pr.setCash(buffer.getInt(start + 4));
                pr.setMobile(buffer.getInt(start + 8));
                pr.setKind(buffer.getInt(start + 12));
                pr.setTotal(buffer.getInt(start + 16));
                pr.setPlotId(buffer.getInt(start + 20));
                list.add(pr);

                read += 24;
                start = read;
                index = 0;
            }
            return list;
        }

        @Override
        protected void succeeded() {
            try {
                seriesProperty.set(get());
                updateMessage("processed " + String.format("%,d", length) + " bytes");
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
