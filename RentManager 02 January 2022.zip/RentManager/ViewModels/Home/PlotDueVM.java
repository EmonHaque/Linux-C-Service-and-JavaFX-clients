package ViewModels.Home;

import Enums.Function;
import Models.PlotwiseDue;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class PlotDueVM {
    private int selectedPlotId, requestId;
    public StringProperty statusProperty;
    public BooleanProperty stateProperty, isRunningProperty;
    public ObjectProperty<List<PlotwiseDue>> seriesProperty;

    public PlotDueVM() {
        statusProperty = new SimpleStringProperty("");
        stateProperty = new SimpleBooleanProperty();
        isRunningProperty = new SimpleBooleanProperty();
        seriesProperty = new SimpleObjectProperty<>();

        stateProperty.addListener(this::onStateChanged);
        RentVM.selectedPlot.addListener(this::onPlotChanged);
    }

    public void refresh(){
        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private void onStateChanged(ObservableValue<?> o, boolean ov, boolean nv){
        requestId = nv ? 0 : selectedPlotId;
        refresh();
    }

    private void onPlotChanged(ObservableValue<?> o, Number ov, Number nv){
        if(selectedPlotId == nv.intValue()) return;
        selectedPlotId = nv.intValue();
        requestId = stateProperty.get() ? 0 : selectedPlotId;
        refresh();
    }

    private class ResponseTask extends Task<List<PlotwiseDue>>{
        private int length;
        @Override
        protected List<PlotwiseDue> call() throws Exception {
            updateMessage("requesting ...");
            Thread.sleep(500);

            var date = LocalDate.now().minusYears(2);
            date = LocalDate.of(date.getYear(), date.getMonthValue(), 1);
            var dateBytes = (date.toString() + '\0').getBytes(StandardCharsets.US_ASCII);
            var buffer = ByteBuffer.allocate(4 + dateBytes.length)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .putInt(requestId)
                    .put(dateBytes);

            var request = new Request(Function.GetPlotDueChart.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return null;
            }
            length = response.getPacket().length;
            buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
            updateMessage("received " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);

            updateMessage("processing " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);

            int read = 0;
            int start = 0;
            var list = new ArrayList<PlotwiseDue>();
            while (read < length) {
                while (buffer.get(read) != 0) read++;
                var month = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                start = ++read;
                while (buffer.get(read) != 0) read++;
                var tenant = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                read++;
                int due = buffer.getInt(read);
                list.add(new PlotwiseDue(month, tenant, due));

                read += 4;
                start = read;
            }

            return list;
        }

        @Override
        protected void succeeded() {
            try {
                seriesProperty.set(get());
                updateMessage("processed " + String.format("%,d", length) + " bytes");
                Thread.sleep(500);
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
