package ViewModels.Home;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import model.XYSeries;
import ridiculous.AppData;

import java.util.ArrayList;
import java.util.List;

public class RentDetailVM {
    public ObjectProperty<List<XYSeries>> dataProperty;

    public RentDetailVM() {
        dataProperty = new SimpleObjectProperty<>();
        RentVM.selectedPlot.addListener(this::onPlotChanged);
    }

    private void onPlotChanged(ObservableValue<?> o, Number ov, Number nv){
        var list = RentVM.depositDueRentList.get().stream().filter(x -> x.getPlotId() == nv.intValue()).toList();
        var series = new ArrayList<XYSeries>();
        for(var point : list){
            var space = AppData.spaces.stream().filter(x -> x.getId() == point.getSpaceId()).findFirst().get().getName();
            series.add(new XYSeries(space, point.getAmount()));
        }
        dataProperty.set(series);
    }
}
