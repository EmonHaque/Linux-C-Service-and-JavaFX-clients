package ViewModels.Report;

import Enums.Function;
import Models.ReceiptPayment;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class ReportReceiptPaymentVM {
    private final ObservableList<ReceiptPayment> list;
    public ListProperty<ReceiptPayment> listProperty;
    public ObjectProperty<LocalDate> startDateProperty, endDateProperty;
    public StringProperty statusProperty;
    public BooleanProperty isRunningProperty;

    public ReportReceiptPaymentVM() {
        statusProperty = new SimpleStringProperty();
        isRunningProperty = new SimpleBooleanProperty();

        var now = LocalDate.now();
        startDateProperty = new SimpleObjectProperty<>(now.minusMonths(1));
        endDateProperty = new SimpleObjectProperty<>(now);

        list = FXCollections.observableArrayList();
        listProperty = new SimpleListProperty<>(list);
    }

    public void updateReportable() {
        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private class ResponseTask extends Task<List<ReceiptPayment>> {
        @Override
        protected List<ReceiptPayment> call() throws Exception {
            updateMessage("requesting data ...");
            Thread.sleep(500);

            var start = (startDateProperty.get().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
            var end = (endDateProperty.get().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
            var buffer = ByteBuffer.allocate(start.length + end.length).order(ByteOrder.LITTLE_ENDIAN);
            buffer.put(start);
            buffer.put(end);
            var request = new Request(Function.GetReceiptPayment.ordinal(), buffer);

            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return null;
            }
            int length = response.getPacket().length;
            if (length == 0) {
                updateMessage("no data available");
                Thread.sleep(500);
                return null;
            }
            updateMessage("received " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);

            buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
            return getList(buffer, length);
        }

        @Override
        protected void succeeded() {
            list.clear();
            try {
                var result = get();
                if (result == null) return;
                list.addAll(result);
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        private List<ReceiptPayment> getList(ByteBuffer buffer, int length) {
            var list = new ArrayList<ReceiptPayment>();
            var span = buffer.array();
            int start, index, read;
            start = read = index = 0;
            var segments = new String[5];
            while (read < length) {
                while (read < length) {
                    if (span[read] != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }
                var rp = new ReceiptPayment() {{
                    setControl(segments[0]);
                    setHead(segments[1]);
                    setPlot(segments[2]);
                    setSpace(segments[3]);
                    setTenant(segments[4]);

                }};
                rp.setCash(buffer.getInt(read));
                rp.setMobile(buffer.getInt(read + 4));
                rp.setKind(buffer.getInt(read + 8));
                rp.setTotal(buffer.getInt(read + 12));
                list.add(rp);

                index = 0;
                read += 16;
                start = read;
            }
            return list;
        }
    }
}
