package ViewModels.Report;

import Enums.Function;
import Models.Balance;
import Models.Plot;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class ReportBalanceVM {
    public IntegerProperty selectedPlotProperty;
    public StringProperty statusProperty, queryProperty;
    public BooleanProperty hasLeftProperty;
    public FilteredList<Plot> plots;
    public FilteredList<Balance> balances;

    private final ObservableList<Balance> list;

    public ReportBalanceVM() {
        selectedPlotProperty = new SimpleIntegerProperty();
        statusProperty = new SimpleStringProperty();
        queryProperty = new SimpleStringProperty("");
        hasLeftProperty = new SimpleBooleanProperty();

        plots = new FilteredList<>(AppData.plots);
        list = FXCollections.observableArrayList(o -> new Observable[]{queryProperty});
        balances = new FilteredList<>(list, x -> {
            var lower = queryProperty.get().trim().toLowerCase();
            if (lower.isEmpty()) return true;
            return x.getSpace().toLowerCase().contains(lower)
                    || x.getTenant().toLowerCase().contains(lower);
        });
    }

    public void updateReportable() {
        var buffer = ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN);
        buffer.putInt(selectedPlotProperty.get());
        byte hasLeft = hasLeftProperty.get() ? (byte) 1 : 0;
        buffer.put(hasLeft);
        var request = new Request(Function.GetBalance.ordinal(), buffer);
        var task = new ResponseTask(request);
        statusProperty.bind(task.messageProperty());
        new Thread(task).start();
    }

    private class ResponseTask extends Task<List<Balance>> {
        private final Request request;

        public ResponseTask(Request request) {
            this.request = request;
        }

        @Override
        protected List<Balance> call() throws Exception {
            updateMessage("requesting data ...");
            Thread.sleep(500);

            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                return null;
            }
            int length = response.getPacket().length;
            if (length == 0) {
                updateMessage("no data available");
                Thread.sleep(500);
                return null;
            }
            updateMessage("received " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);

            var buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
            return getList(buffer, length);
        }

        @Override
        protected void succeeded() {
            list.clear();
            try {
                var result = get();
                if (result == null) return;
                list.addAll(result);
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        private List<Balance> getList(ByteBuffer buffer, int length) {
            var list = new ArrayList<Balance>();
            var span = buffer.array();
            int start, index, read;
            start = read = index = 0;
            var segments = new String[4];

            while (read < length) {
                while (read < length) {
                    if (span[read] != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(span, start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }
                var balance = new Balance() {{
                    setSpace(segments[0]);
                    setTenant(segments[1]);
                    setDateStart(segments[2]);
                    setDateEnd(segments[3]);
                }};
                balance.setSecurity(buffer.getInt(read));
                balance.setRent(buffer.getInt(read + 4));
                balance.setDue(buffer.getInt(read + 8));
                balance.setCount(buffer.getInt(read + 12));
                balance.setExpired(buffer.get(read + 16) != 0);
                list.add(balance);

                index = 0;
                read += 17;
                start = read;
            }
            return list;
        }
    }
}
