package ChartControls.RentDetailChart;

import abstracts.XYChartBase;
import controls.areachart.AreaFill;
import controls.areachart.AreaStroke;
import javafx.animation.*;
import javafx.scene.Group;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.util.Duration;
import model.XYSeries;

import java.util.ArrayList;

public class AreaChart extends XYChartBase<XYSeries> {
    private boolean isLoaded;
    private final AreaStroke stroke;
    private final AreaFill fill;
    private final Group circles;
    private final double minRadius = 3, maxRadius = 5;
    private final Timeline strokeAnim, fillAnim;
    private final FadeTransition circleAnim;
    private final Rectangle widthClip, heightClip;
    private final Line cursor;

    public AreaChart() {
        cursor = new Line();
        cursor.setStroke(Color.WHITE);
        cursor.getStrokeDashArray().addAll(5d, 2d);
        cursor.setManaged(false);
        cursor.setMouseTransparent(true);

        circles = new Group() {{setManaged(false);}};
        stroke = new AreaStroke() {{
            setManaged(false);
            setMouseTransparent(true);
            getTransforms().add(new Scale(1, -1));
        }};
        fill = new AreaFill() {{
            setManaged(false);
            setMouseTransparent(true);
            getTransforms().add(new Scale(1, -1));
        }};
        getChildren().addAll(fill, stroke, circles);

        widthClip = new Rectangle(0, 0, 0, 0);
        heightClip = new Rectangle(0, 0, 0, 0);
        stroke.setClip(widthClip);
        fill.setClip(heightClip);

        strokeAnim = new Timeline();
        fillAnim = new Timeline();
        circleAnim = new FadeTransition(Duration.millis(1000), circles);
        circleAnim.setDelay(Duration.seconds(1));
        circleAnim.setToValue(1);

        strokeAnim.setOnFinished(e -> stroke.setClip(null));
        fillAnim.setOnFinished(e -> fill.setClip(null));

        setOnMouseMoved(this::onMouseMove);
        getChildren().add(cursor);
    }

    @Override
    protected void setMinMaxAndXLabels() {
        double step = (max - min) / (numLines - 1);
        double current = min;
        for (var t : yLabels.getChildren()) {
            var label = (Text) t;
            label.setText(String.format("%,d", (int) current));
            current += step;
            yLabelWidth = label.prefWidth(-1);
        }
    }

    @Override
    protected void reset() {
        circles.getChildren().clear();
        stroke.clear();
        fill.clear();
        circles.setOpacity(0);
        var doubles = new ArrayList<Double>();
        for (var value : series) {
            var v = value.getValue();
            doubles.add(v);

            if (v < min) min = v;
            if (v > max) max = v;

            var xLabel = new Text(value.getLabel());
            xLabel.setFill(Color.WHITE);
            xLabel.setRotate(-90);
            xLabel.setManaged(false);
            xLabels.getChildren().add(xLabel);

            if (xLabelWidth < xLabel.prefWidth(-1))
                xLabelWidth = xLabel.prefWidth(-1);

            var circle = new Circle();
            circle.setRadius(minRadius);
            circle.setFill(Color.CORAL);
            circles.getChildren().add(circle);
            circle.setManaged(false);
        }

        stroke.setData(doubles);
        fill.setData(doubles);

        requestLayout();
        circleAnim.play();
        if (!isLoaded) return;

        resetAnim();
        fillAnim.play();
        strokeAnim.play();
    }

    private void onMouseMove(MouseEvent e) {
        if (series == null) return;
        double cursorX = e.getX();
        if (cursorX < startX || cursorX > (startX + availableWidth)) {
            cursor.setVisible(false);
            resetRadius();
            return;
        }

        if (!cursor.isVisible()) cursor.setVisible(true);

        cursor.setStartX(cursorX);
        cursor.setEndX(cursorX);
        cursor.setStartY(0);
        cursor.setEndY(availableHeight);

        for (var c : circles.getChildren()) {
            var circle = (Circle) c;
            var bounds = c.getBoundsInLocal();
            if (cursorX >= bounds.getMinX() && cursorX <= bounds.getMaxX()) {
                circle.setFill(Color.WHITE);
                circle.setRadius(maxRadius);
                cursor.setStroke(Color.CORAL);
            }
            else {
                if (circle.getRadius() == maxRadius) {
                    circle.setFill(Color.CORAL);
                    circle.setRadius(minRadius);
                    cursor.setStroke(Color.WHITE);
                }
            }
        }
    }

    private void resetRadius() {
        for (var c : circles.getChildren()) {
            var circle = (Circle) c;
            if (circle.getRadius() == maxRadius) {
                circle.setFill(Color.CORAL);
                circle.setRadius(minRadius);
                cursor.setStroke(Color.WHITE);
                break;
            }
        }
    }

    private void resetAnim() {
        var width = startX + availableWidth;
        var height = availableHeight + xLabelWidth;
        widthClip.setWidth(0);
        widthClip.setHeight(height);
        heightClip.setHeight(0);
        heightClip.setWidth(width);
        stroke.setClip(widthClip);
        fill.setClip(heightClip);

        strokeAnim.getKeyFrames().clear();
        fillAnim.getKeyFrames().clear();
        var widthKey = new KeyValue(widthClip.widthProperty(), width, Interpolator.EASE_IN);
        var heightKey = new KeyValue(heightClip.heightProperty(), height, Interpolator.EASE_IN);
        KeyFrame widthFrame = new KeyFrame(Duration.millis(1000), widthKey);
        KeyFrame heightFrame = new KeyFrame(Duration.millis(1000), heightKey);
        strokeAnim.getKeyFrames().add(widthFrame);
        fillAnim.getKeyFrames().add(heightFrame);
    }

    @Override
    protected void layoutChildren() {
        if (series == null) return;
        super.layoutChildren();

        if (!isLoaded) {
            isLoaded = true;
            resetAnim();
            fillAnim.play();
            strokeAnim.play();
        }

        double positiveHeight, negativeHeight;
        if (min < 0) {
            var absMin = Math.abs(min);
            var spread = max - min;
            negativeHeight = availableHeight / spread * absMin;
            positiveHeight = availableHeight - negativeHeight;
        }
        else {
            positiveHeight = availableHeight;
        }
        fill.setTranslateY(positiveHeight);
        stroke.setTranslateY(positiveHeight);
        fill.setTranslateX(startX);
        stroke.setTranslateX(startX);

        double size = series.size();

        fill.setValue(availableWidth, availableHeight, min, max); // same computation thrice
        stroke.setValue(availableWidth, availableHeight, min, max); // same computation thrice

        double xGap = availableWidth / (size - 1);
        double yFactor = availableHeight / (max - min);
        double x = startX, y;

        for (int i = 0; i < size; i++) {
            // same computation thrice
            y = positiveHeight - series.get(i).getValue() * yFactor;
            var circle = (Circle) circles.getChildren().get(i);

            circle.setCenterX(x);
            circle.setCenterY(y);

            var xLabel = (Text) xLabels.getChildren().get(i);
            xLabel.setX(x - xLabel.prefWidth(-1) / 2);
            xLabel.setY(availableHeight + xLabel.prefWidth(-1) / 2 + xLabel.prefHeight(-1) / 2);
            x += xGap;
        }
    }
}
