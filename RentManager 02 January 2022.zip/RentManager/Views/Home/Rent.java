package Views.Home;

import ViewModels.Home.RentVM;
import abstracts.View;
import controls.SpinningArc;
import controls.buttons.ActionButton;
import controls.piechart.Pie;
import controls.states.MultiState;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.TextFlow;

public class Rent extends View {
    private Pie pie;
    private MultiState state;
    private Text totalPlot, totalInPlot, status;
    private TextFlow totals;
    private SpinningArc spinner;
    private ActionButton refresh;
    private RentVM vm;

    @Override
    protected String getHeader() {
        return "Rent, Deposit & Dues";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new RentVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        var icons = new String[] { Icons.Rent, Icons.Deposit, Icons.Due };
        var texts = new String[] { "Rent", "Deposit", "Due" };
        state = new MultiState(icons, texts, true){{ setAlignment(Pos.CENTER_RIGHT);}};
        pie = new Pie();
        totalPlot = new Text() {{ setFill(Color.WHITE);}};
        totalInPlot = new Text() {{ setFill(Color.WHITE);}};
        totals = new TextFlow(){{
            getChildren().addAll(
                    new Text("Total "){{ setFill(Color.WHITE);}},
                    totalInPlot,
                    new Text(" in "){{ setFill(Color.WHITE);}},
                    totalPlot,
                    new Text(" plots"){{ setFill(Color.WHITE);}}
            );
            setTextAlignment(TextAlignment.CENTER);
        }};

        var grid = new GridPane(){{
            getRowConstraints().addAll(
                    new RowConstraints(),
                    new RowConstraints(){{ setVgrow(Priority.ALWAYS);}},
                    new RowConstraints()
            );
            getColumnConstraints().add(new ColumnConstraints(){{ setPercentWidth(100);}});
            add(state, 0, 0);
            add(pie, 0, 1);
            add(totals, 0, 2);

            setHalignment(totals, HPos.CENTER);
            setPadding(new Insets(5,0,0,0));
        }};

        setCenter(grid);

        status = new Text(){{ setFill(Color.WHITE);}};
        spinner = new SpinningArc();
        refresh = new ActionButton(Icons.Reload, 16, "refresh");

        addAction(spinner);
        addAction(status);
        addAction(refresh);
    }

    private void bind(){
        refresh.setAction(vm::refresh);
        vm.state.bind(state.stateProperty);
        pie.seriesProperty.bind(vm.seriesProperty);
        totalInPlot.textProperty().bind(vm.totalInPlot.asString("%,d"));
        totalPlot.textProperty().bind(vm.totalPlot.asString());

        spinner.visibleProperty().bind(vm.isRunning);
        status.textProperty().bind(vm.status);

        RentVM.selectedPlot.bindBidirectional(pie.selectedValueProperty);
    }
}
