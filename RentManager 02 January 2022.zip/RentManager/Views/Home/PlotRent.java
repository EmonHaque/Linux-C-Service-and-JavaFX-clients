package Views.Home;

import ChartControls.PlotRentChart.PinLineChart;
import ViewModels.Home.PlotRentVM;
import abstracts.View;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.states.BiState;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class PlotRent extends View {
    private PlotRentVM vm;
    private CommandButton refresh;
    private BiState state;
    private Text status;
    private SpinningArc spinner;
    private PinLineChart pinLine;

    @Override
    protected String getHeader() {
        return "Charge & Collections";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new PlotRentVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        pinLine = new PinLineChart("Charges", "Collections");
        setCenter(pinLine);
        BorderPane.setMargin(pinLine, new Insets(25,0,0,0));

        refresh = new CommandButton(Icons.Reload, 16, "refresh");
        state = new BiState(false, "All");
        status = new Text(){{ setFill(Color.WHITE);}};
        spinner = new SpinningArc();

        addAction(spinner);
        addAction(status);
        addAction(state);
        addAction(refresh);
    }

    private void bind(){
        pinLine.seriesProperty.bind(vm.seriesProperty);
        refresh.setAction(vm::refresh);
        vm.stateProperty.bind(state.isCheckedProperty);
        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);
    }
}
