package Views.Home;

import ChartControls.RentDetailChart.AreaChart;
import ViewModels.Home.RentDetailVM;
import abstracts.View;
import javafx.geometry.Insets;
import javafx.scene.layout.*;

public class RentDetail extends View {
    private RentDetailVM vm;
    private AreaChart area;
    @Override
    protected String getHeader() {
        return "Detail Rent Deposit & Dues";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new RentDetailVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        area = new AreaChart();
        BorderPane.setMargin(area, new Insets(25,10,0,0));
        setCenter(area);
    }

    private  void bind(){
        area.seriesProperty.bind(vm.dataProperty);
    }
}
