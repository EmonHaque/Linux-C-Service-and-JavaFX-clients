package controls;

import abstracts.SelectionControlBase;
import abstracts.StringVisual;
import abstracts.StringVisualCell;
import helpers.Constants;
import helpers.Icons;
import interfaces.IReturnNameAndId;
import interfaces.ISetSelectionBoxContent;
import javafx.animation.RotateTransition;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.scene.control.ListCell;
import javafx.scene.control.SelectionMode;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import skinned.ExtendedResizableListView;

import java.lang.reflect.InvocationTargetException;
import java.util.function.Predicate;

public class SelectionBox<T extends IReturnNameAndId<T>> extends SelectionControlBase {
    private FilteredList<T> list;
    private ExtendedResizableListView<T> listView;
    private final ISetSelectionBoxContent<T> visual;
    private RotateTransition rotationAnim;
    private boolean selectAddedItem, isLoaded, isInteractiveChange;
    private Predicate<T> predicate;

    private ObjectProperty<T> selectedItem;
    private IntegerProperty selectedValue;
    private BooleanProperty isFiltering;

    public SelectionBox(String hint, String leftIcon, FilteredList<T> list, ISetSelectionBoxContent<T> visual, String templateName, boolean isRequired) {
        super(hint, leftIcon, isRequired);
        this.visual = visual;
        initializeUI(list);

        try {
            var tor = Class.forName(templateName).getConstructor(StringProperty.class);
            listView.setCellFactory(v -> {
                try {
                    return (ListCell<T>) tor.newInstance(input.textProperty());
                } catch (InstantiationException | IllegalAccessException | IllegalArgumentException |
                         InvocationTargetException e) {
                    e.printStackTrace();
                }
                return null;
            });
        } catch (ClassNotFoundException | NoSuchMethodException | SecurityException e) {
            e.printStackTrace();
        }
    }

    public SelectionBox(String hint, String leftIcon, FilteredList<T> list, boolean isRequired) {
        super(hint, leftIcon, isRequired);
        visual = new StringVisual<>();
        initializeUI(list);
        listView.setCellFactory(v -> new StringVisualCell<>(textProperty(), false));
    }

    private void initializeUI(FilteredList<T> list) {
        super.setSelectedContent(visual.getVisual());
        this.list = list;
        predicate = (Predicate<T>) list.getPredicate();
        listView = new ExtendedResizableListView<>(list);
        listView.setBorder(Constants.BottomLine);
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setMaxHeight(200);
        listView.setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, null, null)));
        listView.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25))));

        popup.getContent().remove(0); // remove popupGrid
        popup.getContent().add(listView);
        input.setText("");

        selectedItem = new SimpleObjectProperty<>();
        selectedValue = new SimpleIntegerProperty();
        selectedItem.addListener(this::onSelectedItemChanged);
        selectedValue.addListener(this::onSelectedValueChanged);

        isFiltering = new SimpleBooleanProperty();

        rotationAnim = new RotateTransition(Duration.millis(500));
        rotationAnim.setNode(open);

        listView.setOnKeyReleased(this::onKeyReleasedOnListView);
        listView.setOnMouseClicked(this::onMouseClickedOnListView);

        list.addListener(this::onCollectionChanged);
    }

    private void onSelectedItemChanged(ObservableValue<?> o, T ov, T nv) {
        if (!isLoaded) return;
        if (isInteractiveChange) return;

        int id = -1;
        if (nv != null) {
            if (isDisabled()) setDisable(false);
            visual.setContent(nv);
            super.onSelected();
            id = nv.getId();
        }
        else {
            super.removeSelected();
            setDisable(true);
        }
        isInteractiveChange = true;
        selectedValue.set(id);
        isInteractiveChange = false;
    }

    private void onSelectedValueChanged(ObservableValue<?> o, Number ov, Number nv) {
        if (!isLoaded) return;
        if (isInteractiveChange) return;

        var item = list.stream().filter(x -> x.getId() == nv.intValue()).findFirst();
        if (item.isPresent()) {
            if (isDisabled()) setDisable(false);
            visual.setContent(item.get());
            super.onSelected();
        }
        else {
            super.removeSelected();
            setDisable(true);
        }
        isInteractiveChange = true;
        selectedItem.set(item.orElse(null));
        isInteractiveChange = false;
    }

    public void setSelectAddedItem(boolean value) {
        selectAddedItem = value;
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if (!isLoaded) {
            isLoaded = true;

            isInteractiveChange = true;
            if (list.size() > 0) selectFirst();
            else {
                nullify();
                setDisable(true);
            }
            isInteractiveChange = false;

            if (textProperty().isBound()) return;

            textProperty().addListener(o -> {
                var query = input.getText().trim().toLowerCase();
                var isEmpty = query.isEmpty();

                isFiltering.set(true);
                if (predicate != null) {
                    list.setPredicate(isEmpty ?
                            predicate :
                            predicate.and(x -> x.getName().toLowerCase().contains(query)));
                }
                else {
                    list.setPredicate(isEmpty ? x -> true : x -> x.getName().toLowerCase().contains(query));
                }
                if(list.size() > 0 && selectedValue.get() == -1) {
                    showPopup();
                }
                isFiltering.set(false);
            });
        }
    }

    private void onCollectionChanged(ListChangeListener.Change<? extends T> change) {
        // bind isFilteringProperty in VM, set true before filter and reset after, if you want to filter there

        if (!isLoaded) return;
        if (isFiltering.get()) return;

        isInteractiveChange = true;
        // highly inefficient
        // when the FilteredList is reset, it's called for every item, instead of a single shot
        while (change.next()) {
            if (change.wasAdded()) {
                if (selectedValue.get() == -1) {
                    setDisable(false);
                    selectFirst();
                }
                else if (selectAddedItem) {
                    listView.getSelectionModel().select(change.getAddedSubList().get(0));
                    setSelected();
                }
            }
            else if (change.wasRemoved()) {
                if (list.size() == 0) {
                    nullify();
                    setDisable(true);
                }
                else if (change.getRemoved().get(0).equals(visual.getContent())) {
                    if (list.size() == 0) {
                        nullify();
                        setDisable(true);
                    }
                    else selectFirst();
                }
            }
        }
        isInteractiveChange = false;
    }

    @Override
    protected String getRightIcon() {
        return Icons.DownArrow;
    }

    @Override
    protected void removeSelected() {
        isInteractiveChange = true;
        nullify();
        showPopup();
        isInteractiveChange = false;
        super.removeSelected();
    }

    private void setSelected() {
        var selected = listView.getSelectionModel().getSelectedItem();
        int value = -1;
        if (selected != null) {
            visual.setContent(selected);
            value = selected.getId();
        }
        selectedItem.set(selected);
        selectedValue.set(value);
        super.onSelected();
    }

    private void nullify() {
        super.removeSelected();
        selectedItem.set(null);
        selectedValue.set(-1);
    }

    private void selectFirst() {
        listView.getSelectionModel().selectFirst();
        setSelected();
    }

    @Override
    protected void onPopupShowing(WindowEvent e) {
        super.onPopupShowing(e);
        rotationAnim.setToAngle(180);
        rotationAnim.play();
        open.setTip("close");
    }

    @Override
    protected void onPopupHiding(WindowEvent e) {
        super.onPopupHiding(e);
        rotationAnim.setToAngle(0);
        rotationAnim.play();
        open.setTip("show");
    }

    private void onKeyReleasedOnListView(KeyEvent e) {
        if (e.getCode() == KeyCode.ENTER) {
            // when you enter on input ListView gets event and it can be null
            if(listView.getSelectionModel().getSelectedItem() == null) return;

            isInteractiveChange = true;
            setSelected();
            isInteractiveChange = false;
        }
    }

    private void onMouseClickedOnListView(MouseEvent e) {
        isInteractiveChange = true;
        setSelected();
        isInteractiveChange = false;
    }

    private void showPopup() {
        var point = input.localToScreen(0, 0);
        listView.setMinWidth(input.getWidth());
        popup.show(getScene().getWindow(), point.getX(), point.getY() + input.getHeight());
    }

    public ObjectProperty<T> selectedItemProperty() {return selectedItem;}

    public IntegerProperty selectedValueProperty() {return selectedValue;}

    public BooleanProperty isFilteringProperty() {return isFiltering;}
}
