package controls;

import java.util.ArrayList;
import java.util.List;

import helpers.Constants;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import model.HorizontalSeries;
import skinned.ExtendedListView;
import templates.HorizontalChartTemplate;

public class HorizontalListChart extends StackPane {
    private double topLabelHeight, bottomlabelHeight, rightPadding = 4.5, numLines = 5, percentOfChartArea = 0.7;
    private double topMax, bottomMax;
    private Text topTitle, bottomTitle;

    private List<Line> lines;
    private List<Text> topLabels, bottomLabels;

    private ExtendedListView<HorizontalSeries> list;
    private ObservableList<HorizontalSeries> series;
    public ObjectProperty<ObservableList<HorizontalSeries>> seriesProperty;
    public DoubleProperty topMaxProperty, bottomMaxProperty;
    public StringProperty queryProperty;
    
    public HorizontalListChart() {
        lines = new ArrayList<>();
        topLabels = new ArrayList<>();
        bottomLabels = new ArrayList<>();
        addLines();

        topMaxProperty = new SimpleDoubleProperty();
        bottomMaxProperty = new SimpleDoubleProperty();

        list = new ExtendedListView<>(series);
        list.setPadding(new Insets(0));

        list.setCellFactory(v -> new HorizontalChartTemplate(rightPadding, percentOfChartArea, topMaxProperty, bottomMaxProperty));
        list.setManaged(false);
        getChildren().add(list);

        seriesProperty = new SimpleObjectProperty<>();
        seriesProperty.addListener(this::onSeriesChanged);
        queryProperty = new SimpleStringProperty();
    }

    private void onSeriesChanged(ObservableValue<?> obs, ObservableList<HorizontalSeries> ov, ObservableList<HorizontalSeries> nv) {
        series = nv;
        setMinMax();
        topMaxProperty.set(topMax);
        bottomMaxProperty.set(bottomMax);
        list.setItems(series);
    }

    private void setMinMax() {
        topMax = bottomMax = 0;
        for (var s : series) {
            var total = s.getValue1() + s.getValue2();
            if (topMax < total)
                topMax = total;

            if (bottomMax < s.getValue3())
                bottomMax = s.getValue3();
        }
        double y1Step = topMax / (numLines - 1);
        double y2Step = bottomMax / (numLines - 1);
        double y1Current = 0;
        double y2Current = 0;
        for (int i = 0; i < numLines; i++) {
            var y1 = topLabels.get(i);
            var y2 = bottomLabels.get(i);

            y1.setText(String.format("%.1f", y1Current));
            y2.setText(String.format("%.1f", y2Current));

            topLabelHeight = y1.prefWidth(-1);
            bottomlabelHeight = y2.prefWidth(-1);

            y1Current += y1Step;
            y2Current += y2Step;
        }
    }

    private void addLines() {
        topLabelHeight = bottomlabelHeight = 0;
        for (int i = 0; i < numLines; i++) {
            var line = new Line();
            line.setStroke(Color.WHITE);
            line.setStrokeWidth(0.5);
            line.getStrokeDashArray().addAll(5d, 2d);

            // lines.getChildren().add(line);
            getChildren().add(line);
            lines.add(line);

            line.setManaged(false);
            line.setMouseTransparent(true);

            var topLabel = new Text();
            topLabel.setRotate(90);
            topLabel.setFill(Color.WHITE);

            // topLabels.getChildren().add(topLabel);
            getChildren().add(topLabel);
            topLabels.add(topLabel);

            topLabel.setManaged(false);
            topLabel.setMouseTransparent(true);

            if (topLabel.prefWidth(-1) > topLabelHeight)
                topLabelHeight = topLabel.prefWidth(-1);

            var bottomLabel = new Text();
            bottomLabel.setRotate(90);
            bottomLabel.setFill(Color.WHITE);

            // bottomLabels.getChildren().add(bottomLabel);
            getChildren().add(bottomLabel);
            bottomLabels.add(bottomLabel);

            bottomLabel.setManaged(false);
            bottomLabel.setMouseTransparent(true);

            if (bottomLabel.prefWidth(-1) > bottomlabelHeight)
                bottomlabelHeight = bottomLabel.prefWidth(-1);
        }
        topTitle = new Text("Top Title");
        topTitle.setFont(Font.font(null, FontWeight.BOLD, -1));
        topTitle.setFill(Color.WHITE);
        topTitle.setManaged(false);
        topTitle.setMouseTransparent(true);

        bottomTitle = new Text("Bottom Title");
        bottomTitle.setFont(Font.font(null, FontWeight.BOLD, -1));
        bottomTitle.setFill(Color.WHITE);
        bottomTitle.setManaged(false);
        bottomTitle.setMouseTransparent(true);

        getChildren().addAll(topTitle, bottomTitle);
    }

    @Override
    protected void layoutChildren() {
        double width = getWidth();
        double height = getHeight();

        double titleMargin = 10; 
        double rightMargin = Constants.ScrollBarSize + rightPadding;
        double titleHeight = topTitle.prefHeight(-1);
        double chartWidth = (width - rightMargin) * percentOfChartArea;

        double lineX = (width - rightMargin) * (1 - percentOfChartArea);
        double lineStartY = titleHeight + titleMargin;
        double lineEndY = height - titleHeight - titleMargin;

        topTitle.setX(lineX + chartWidth / 2 - topTitle.prefWidth(1) / 2);
        topTitle.setY(lineStartY - titleMargin);
        bottomTitle.setX(lineX + chartWidth / 2 - bottomTitle.prefWidth(1) / 2);
        bottomTitle.setY(height);

        double lineStep = chartWidth / (numLines - 1);
        for (int i = 0; i < numLines; i++) {
            var line = lines.get(i);
            var topLabel = topLabels.get(i);
            var bottomLabel = bottomLabels.get(i);

            line.setStartX(lineX);
            line.setEndX(lineX);
            line.setStartY(lineStartY);
            line.setEndY(lineEndY);

            var halfTopWidth = topLabel.prefWidth(-1) / 2;
            var halfTopHeight = topLabel.prefHeight(-1) / 2;
            var halfBottomWidth = bottomLabel.prefWidth(-1) / 2;
            var halfBottomHeight = bottomLabel.prefHeight(-1) / 2;

            var topX = lineX - halfTopWidth + halfTopHeight;
            var bottomX = lineX - halfBottomWidth + halfBottomHeight;

            if (i == numLines - 1) {
                topX += 2.5;
                bottomX += 2.5;
            }
            
            topLabel.setX(topX);
            bottomLabel.setX(bottomX);
            topLabel.setY(halfTopWidth + halfTopHeight + lineStartY);
            bottomLabel.setY(lineEndY - halfBottomWidth + halfBottomHeight);

            lineX += lineStep;
        }
        double listStartY = lineStartY + topLabelHeight + 10;
        double listEndY = lineEndY - bottomlabelHeight - 5;
        list.resizeRelocate(0, listStartY, width, listEndY - listStartY);
    }
}
