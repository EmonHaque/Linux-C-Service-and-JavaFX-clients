package abstracts;

import controls.SVGRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.Background;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

public abstract class WrapTreeCellBase<T> extends TreeCell<T> {
    private final double padding = 2.5;
    private final SVGRegion disclosureIcon;
    private double availableWidth, indent;
    private boolean isLoaded, isLaidOut;

    protected GridPane root;
    protected TreeItem<T> item;
    protected int level;

    public WrapTreeCellBase() {
        setBackground(null);
        setPrefWidth(0);
        setPadding(new Insets(padding, 0, padding, 0));
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

        disclosureIcon = new SVGRegion(Icons.PlusCircle);
        var disclosurePane = new StackPane(disclosureIcon);
        disclosurePane.setPadding(new Insets(1.5, 6, 0, 0));
        setDisclosureNode(disclosurePane);

        initializeUI();
        root.setManaged(false);
        itemProperty().addListener(this::onItemChanged);
    }

    protected abstract void initializeUI();
    protected abstract void resetValues(T oldValue);
    protected abstract void setValues(T newValue);
    protected abstract double setWrapWidthAndReturnDesiredHeight();

    protected double getAvailableWidth(){ return availableWidth; }

    private void onItemChanged(Observable o, T ov, T nv){
        if(ov != null){
            resetValues(ov);

            disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
            disclosureIcon.setOnMouseEntered(null);
            disclosureIcon.setOnMouseExited(null);
        }
        if(nv != null){
            item = getTreeItem();
            level = getTreeView().getTreeItemLevel(item);
            disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
            disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
            disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

            setValues(nv);

            indent = level * 17;
            isLaidOut = false;
        }
    }

    @Override
    protected void updateItem(T item, boolean empty) {
        super.updateItem(item, empty);
        if (isEmpty()) {
            setGraphic(null);
            setBackground(null);
        }
        else {
            setGraphic(root);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }

    @Override
    protected void layoutChildren() {
        if(!isLoaded){
            isLoaded = true;
            getTreeView().widthProperty().addListener(o -> isLaidOut = false);
        }
        super.layoutChildren();
        if (isEmpty()) return;

        availableWidth = getWidth() - indent;
        var desiredHeight = setWrapWidthAndReturnDesiredHeight();
        root.resizeRelocate(indent, padding, availableWidth, desiredHeight);

        Platform.runLater(() -> {
            setPrefHeight(desiredHeight + padding * 2);
            if(!isLaidOut){
                isLaidOut = true;
                requestLayout();
            }
        });
    }
}
