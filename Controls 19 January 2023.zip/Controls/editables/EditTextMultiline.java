package editables;

import controls.SVGIcon;
import controls.texts.TextBoxMultiLine;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.geometry.VPos;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class EditTextMultiline extends GridPane {
    private final Text content;
    private final TextBoxMultiLine box;
    private final EditPane parent;

    private final StringProperty textProperty;

    public EditTextMultiline(String hint, String icon, boolean isRequired, EditPane parent) {
        this.parent = parent;
        textProperty = new SimpleStringProperty("");
        box = new TextBoxMultiLine(hint, icon, isRequired){{
            visibleProperty().bind(parent.isOnEditProperty());
        }};
        var svgIcon = new SVGIcon(icon);
        var label = new Text(hint) {{
            setFill(Color.GRAY);
            visibleProperty().bind(parent.isOnEditProperty().not());
        }};
        content = new Text() {{
            setFill(Color.WHITE);
            visibleProperty().bind(parent.isOnEditProperty().not());
            textProperty().bind(textProperty);

        }};

        add(box, 0, 0, 2, 2);
        add(svgIcon, 0, 0);
        add(label, 1, 0);
        add(content, 0, 1, 2, 1);

        getColumnConstraints().addAll(
                new ColumnConstraints(),
                new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}}
        );
        setVgap(5);
        setHgap(5);
        setValignment(content, VPos.TOP);

        parent.isOnEditProperty().addListener(this::onIsOnEditChanged);
    }

    private void onIsOnEditChanged(Observable o) {
        if (parent.isOnEditProperty().get()) {
            content.textProperty().unbind();
            box.textProperty().bindBidirectional(textProperty);
        }
        else {
            box.textProperty().unbindBidirectional(textProperty);
            content.textProperty().bind(textProperty);
        }
    }

    public StringProperty textProperty() {return textProperty;}
}
