package Views.Home;

import ChartControls.PlotRentChart.PinLineChart;
import ViewModels.Home.PlotRentVM;
import abstracts.View;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.states.BiState;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.StringBinding;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.*;

public class PlotRent extends View {
    private PlotRentVM vm;
    private CommandButton refresh;
    private BiState state;
    private TextFlow rentFlow, collectionFlow, plotFlow;
    private Text status, cash, kind, mobile, rent, total, plot;
    private SpinningArc spinner;
    private PinLineChart pinLine;

    @Override
    protected String getHeader() {
        return "Charge & Collections";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new PlotRentVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        var bold = Font.font(null, FontWeight.BOLD, -1);
        cash = new Text() {{setFill(Color.WHITE);}};
        kind = new Text() {{setFill(Color.WHITE);}};
        mobile = new Text() {{setFill(Color.WHITE);}};
        total = new Text() {{setFill(Color.WHITE);}};
        rent = new Text() {{setFill(Color.WHITE);}};
        plot = new Text() {{setFill(Color.WHITE); setFont(bold);}};

        rentFlow = new TextFlow() {{
            setTextAlignment(TextAlignment.RIGHT);
            getChildren().addAll(
                    new Text("Charged: ") {{setFill(Color.WHITE);}},
                    rent
            );
        }};
        collectionFlow = new TextFlow() {{
            setTextAlignment(TextAlignment.RIGHT);
            getChildren().addAll(
                    new Text("Paid in ") {{setFill(Color.WHITE);}},
                    new Text("cash: ") {{setFill(Color.WHITE); setFont(bold);}},
                    cash,
                    new Text(" kind: ") {{setFill(Color.WHITE); setFont(bold);}},
                    kind,
                    new Text(" mobile: ") {{setFill(Color.WHITE); setFont(bold);}},
                    mobile,
                    new Text(". Total: ") {{setFill(Color.WHITE); setFont(bold);}},
                    total
            );
        }};
        plotFlow = new TextFlow(){{
            setTextAlignment(TextAlignment.RIGHT);
            getChildren().addAll(
                    new Text("in ") {{setFill(Color.WHITE);}},
                    plot
            );
        }};

        pinLine = new PinLineChart("Charges", "Collections");

        var box = new VBox(rentFlow, collectionFlow, plotFlow, pinLine) {{
            setPadding(new Insets(5));
            setMargin(pinLine, new Insets(20, 0, 0, 0));
            setVgrow(pinLine, Priority.ALWAYS);
            setAlignment(Pos.CENTER_RIGHT);
        }};
        setCenter(box);

        refresh = new CommandButton(Icons.Reload, 16, "refresh");
        state = new BiState(false, "All");
        status = new Text() {{setFill(Color.WHITE);}};
        spinner = new SpinningArc();

        addAction(spinner);
        addAction(status);
        addAction(state);
        addAction(refresh);
    }

    private void bind() {
        pinLine.seriesProperty.bind(vm.seriesProperty);
        refresh.setAction(vm::refresh);
        vm.stateProperty.bind(state.isCheckedProperty);
        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);

        rent.textProperty().bind(vm.rentProperty.asString("%,d"));
        cash.textProperty().bind(vm.cashProperty.asString("%,d"));
        kind.textProperty().bind(vm.kindProperty.asString("%,d"));
        mobile.textProperty().bind(vm.mobileProperty.asString("%,d"));
        plot.textProperty().bind(vm.plotProperty);
        plotFlow.visibleProperty().bind(plot.textProperty().isNotNull());

        var flowVisibility = Bindings.createBooleanBinding(() -> vm.seriesProperty.get() != null && vm.seriesProperty.get().size() > 0, vm.seriesProperty);
        rentFlow.visibleProperty().bind(flowVisibility);
        rentFlow.managedProperty().bind(flowVisibility);
        collectionFlow.visibleProperty().bind(flowVisibility);
        collectionFlow.managedProperty().bind(flowVisibility);

        total.textProperty().bind(new StringBinding() {
            {
                bind(vm.cashProperty);
                bind(vm.kindProperty);
                bind(vm.mobileProperty);
            }

            @Override
            protected String computeValue() {
                return String.format("%,d", vm.cashProperty.get() + vm.kindProperty.get() + vm.mobileProperty.get());
            }
        });
    }
}
