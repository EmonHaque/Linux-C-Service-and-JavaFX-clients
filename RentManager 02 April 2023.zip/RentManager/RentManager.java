import Views.*;
import controls.MainPanel;
import controls.Window;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import ridiculous.AppData;
import ridiculuous.Addresses;

public class RentManager extends ClientApp {
    public static AppData appData;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    protected Image getIcon() {
        return new Image("resources/images/icon.png");
    }

    @Override
    protected String IP() {
        return Addresses.RentManagerIP;
    }

    @Override
    protected int port() {
        return Addresses.RentManagerPort;
    }

    @Override
    protected String getTitle() {
        return "Rent Manager";
    }

    @Override
    protected void initializeAppData() {
        appData = new AppData(loading, stage);
    }

    @Override
    protected Window getWindow(Stage stage) {
        return new Window(stage, getTitle()){{
            setContent(new MainPanel(stage){{
                addView(new HomeView());
                addView(new AddView());
                addView(new EditView());
                addView(new TransactionView());
                addView(new ReportView());
                addNotificationView(new NotificationView());
                setTitle(getTitle());
            }});
        }};
    }
}
