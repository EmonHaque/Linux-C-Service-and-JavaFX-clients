package Models;

import interfaces.IReturnNameAndId;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Head extends IReturnNameAndId<Head> {
    private final IntegerProperty id, controlId;
    private final StringProperty name, description;

    public Head() {
        id = new SimpleIntegerProperty();
        controlId = new SimpleIntegerProperty();
        name = new SimpleStringProperty("");
        description = new SimpleStringProperty("");
    }
    public Head(int id, int controlId, String name, String description) {
        this.id = new SimpleIntegerProperty(id);
        this.controlId = new SimpleIntegerProperty(controlId);
        this.name = new SimpleStringProperty(name);
        this.description = new SimpleStringProperty(description);
    }
    @Override
    public String getName(){
        return name.get();
    }

    @Override
    public int getId() {
        return id.get();
    }

    public int getControlId(){return controlId.get();}

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public IntegerProperty controlIdProperty() {
        return controlId;
    }

    public void setControlId(int controlId) {
        this.controlId.set(controlId);
    }

    public StringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getDescription() {
        return description.get();
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public void setDescription(String description) {
        this.description.set(description);
    }
}
