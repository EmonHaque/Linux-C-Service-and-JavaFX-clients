package Models;

import javafx.beans.property.*;

import java.time.LocalDate;

public class Entry {
    private IntegerProperty tenantId, plotId, spaceId, controlId, headId, amount, isCash;
    private ObjectProperty<LocalDate> date;
    private StringProperty narration;

    public Entry() {
        tenantId = new SimpleIntegerProperty();
        plotId = new SimpleIntegerProperty();
        spaceId = new SimpleIntegerProperty();
        controlId = new SimpleIntegerProperty();
        headId = new SimpleIntegerProperty();
        amount = new SimpleIntegerProperty();
        isCash = new SimpleIntegerProperty();
        date = new SimpleObjectProperty<>(LocalDate.now());
        narration = new SimpleStringProperty("");
    }

    public int getTenantId() {
        return tenantId.get();
    }

    public IntegerProperty tenantIdProperty() {
        return tenantId;
    }

    public void setTenantId(int tenantId) {
        this.tenantId.set(tenantId);
    }

    public int getPlotId() {
        return plotId.get();
    }

    public IntegerProperty plotIdProperty() {
        return plotId;
    }

    public void setPlotId(int plotId) {
        this.plotId.set(plotId);
    }

    public int getSpaceId() {
        return spaceId.get();
    }

    public IntegerProperty spaceIdProperty() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId.set(spaceId);
    }

    public int getControlId() {
        return controlId.get();
    }

    public IntegerProperty controlIdProperty() {
        return controlId;
    }

    public void setControlId(int controlId) {
        this.controlId.set(controlId);
    }

    public int getHeadId() {
        return headId.get();
    }

    public IntegerProperty headIdProperty() {
        return headId;
    }

    public void setHeadId(int headId) {
        this.headId.set(headId);
    }

    public int getAmount() {
        return amount.get();
    }

    public IntegerProperty amountProperty() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount.set(amount);
    }

    public int getIsCash() {
        return isCash.get();
    }

    public IntegerProperty isCashProperty() {
        return isCash;
    }

    public void setIsCash(int isCash) {
        this.isCash.set(isCash);
    }

    public LocalDate getDate() {
        return date.get();
    }

    public ObjectProperty<LocalDate> dateProperty() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date.set(date);
    }

    public String getNarration() {
        return narration.get();
    }

    public StringProperty narrationProperty() {
        return narration;
    }

    public void setNarration(String narration) {
        this.narration.set(narration);
    }
}
