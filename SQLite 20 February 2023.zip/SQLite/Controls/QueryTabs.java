package Controls;

import Helpers.Icons;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;

import java.util.ArrayList;
import java.util.List;

public class QueryTabs extends Region {
    private final ActionButton add;
    private final StackPane headerArea;
    private int count = 1;
    private final List<QueryPage> tabs;
    private QueryPage selected;

    public QueryTabs() {
        tabs = new ArrayList<>();
        add = new ActionButton(Icons.PlusCircle, 20, "add Tab"){{ setManaged(false);}};
        add.setAction(this::addTab);
        headerArea = new StackPane(add);
        getChildren().add(headerArea);
        addTab();
    }
    private void onSelectionChange(QueryPage page){
        if(selected != null) getChildren().remove(selected);

        selected = page;
        getChildren().add(selected);
        selected.getHeader().setSelected(true);
        headerArea.toFront();
    }

    private void addTab() {
        if (selected != null) {
            selected.getHeader().setSelected(false);
        }
        var tab = new QueryPage("SQL " + count++);
        headerArea.getChildren().add(tab.getHeader());
        tabs.add(tab);
        onSelectionChange(tab);

        tab.getHeader().addEventHandler(TabHeader.TabClickEvent.CLICK_EVENT, new TabHeader.TabClickHandler() {
            @Override
            public void onSelect(TabHeader header) {
                if (header.equals(selected.getHeader())) return;
                if (selected != null) {
                    selected.getHeader().setSelected(false);
                }
                for (var item : tabs) {
                    if (!item.getHeader().equals(header)) continue;
                    onSelectionChange(item);
                    break;
                }
            }

            @Override
            public void onClose(TabHeader header) {
                if (tabs.size() == 1) return;
                header.removeEventHandler(TabHeader.TabClickEvent.CLICK_EVENT, this);

                int index = 0;
                QueryPage current = null;
                for (var item : tabs) {
                    if (!item.getHeader().equals(header)) {
                        index++;
                        continue;
                    }
                    current = item;
                    break;
                }
                if (selected.getHeader().equals(header)) {
                    var adjacent = index == 0 ? tabs.get(1) : tabs.get(index - 1);
                    onSelectionChange(adjacent);
                }
                tabs.remove(current);
                headerArea.getChildren().remove(header);
                layoutHeaders();
            }
        });
    }

    private void layoutHeaders() {
        double currentX = 10;
        double headWidth = (getWidth() - 10) / (headerArea.getChildren().size() - 1);
        for (var chi : headerArea.getChildren()) {
            if (chi.equals(add)) continue;
            chi.resizeRelocate(currentX, 0, chi.prefWidth(-1), chi.prefHeight(-1));
            currentX += chi.prefWidth(-1) + 5;
        }
        add.resizeRelocate(currentX, 1, 20, 20);
    }

    @Override
    protected void layoutChildren() {
        var headerHeight = 22;
        var padding = 0.75;
        selected.resizeRelocate(0, headerHeight - padding, getWidth(), getHeight()-headerHeight + padding);
        layoutHeaders();
    }
}
