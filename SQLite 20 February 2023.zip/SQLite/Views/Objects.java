package Views;

import Abstracts.View;
import Controls.ActionButton;
import Controls.SpinningArc;
import Controls.TableViewTabs;
import Helpers.Constants;
import Helpers.Icons;
import Skins.ExtendedSplitPaneSkin;
import Trees.DBTree;
import ViewModels.ObjectVM;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class Objects extends View {
    private ObjectVM vm;
    private Text status;
    private SpinningArc spinner;

    private ActionButton connect, refresh;
    private DBTree tree;
    private VBox leftBox;
    private Tooltip dbNameTip;
    private TableViewTabs tabs;

    @Override
    protected String getIcon() {
        return Icons.Database;
    }

    @Override
    protected String getTip() {
        return "Database";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new ObjectVM();

        initializeLeftBox();
        tabs = new TableViewTabs(){{ setPadding(new Insets(0, 0, 0, 5));}};
        var split = new SplitPane();
        split.setSkin(new ExtendedSplitPaneSkin(split));
        split.setDividerPositions(0.3);

        split.getItems().addAll(leftBox, tabs);

        bind();
        setCenter(split);
    }

    private void initializeLeftBox(){
        status = new Text(){{ setFill(Color.WHITE);}};
        spinner = new SpinningArc();
        connect = new ActionButton(Icons.SocketPlug, 16, "choose database");
        refresh = new ActionButton(Icons.Reload, 16, "refresh");
        var nameBox = new HBox(status);
        dbNameTip = new Tooltip();
        Tooltip.install(nameBox, dbNameTip);
        var topBox = new HBox(nameBox, spinner, connect, refresh){{
            setHgrow(nameBox, Priority.ALWAYS);
            setAlignment(Pos.CENTER_RIGHT);
            setSpacing(2.5);
        }};


        tree = new DBTree();
        tree.setBorder(Constants.TopBorder);
        leftBox = new VBox(topBox, tree){{
            setSpacing(5);
            setVgrow(tree, Priority.ALWAYS);
            setPadding(new Insets(0, 5, 0, 0));
        }};
    }

    private void bind(){
        connect.setAction(vm::choose);
        refresh.setAction(vm::refresh);
        status.textProperty().bind(vm.status);
        dbNameTip.textProperty().bind(vm.fullPath);
        spinner.visibleProperty().bind(vm.isRunning);
        tree.objects.bind(vm.objects);
        tree.requestedPage.addListener((o, ov, nv) -> tabs.addTab(nv));
    }
}
