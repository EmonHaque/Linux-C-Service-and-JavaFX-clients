package Skins;

import javafx.scene.control.TextField;
import javafx.scene.control.skin.TextFieldSkin;
import javafx.scene.paint.Color;

public class ExtendedTextFieldSkin extends TextFieldSkin {

    public ExtendedTextFieldSkin(TextField control) {
        super(control);
        control.setBackground(null);
        setTextFill(Color.WHITE);
        setHighlightFill(Color.rgb(0, 0, 0, 0.5));
    }
}
