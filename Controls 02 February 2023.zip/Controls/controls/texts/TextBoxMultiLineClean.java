package controls.texts;

import javafx.scene.control.TextArea;
import javafx.scene.input.ScrollEvent;
import javafx.scene.text.Font;
import skins.ExtendedTextAreaSkin;


public class TextBoxMultiLineClean extends TextArea {
    private double fontSize;

    public TextBoxMultiLineClean() {
        setSkin(new ExtendedTextAreaSkin(this));
        setContextMenu(null);
        fontSize = getFont().getSize();
        addEventFilter(ScrollEvent.SCROLL, this::onScroll);
    }

    private void onScroll(ScrollEvent e){
        if (!e.isControlDown())  return;
        // this function is called twice on every scroll, first with 0
        if (e.getDeltaY() == 0)  return;

        if(e.getDeltaY() > 0){
            fontSize++;
            setFont(Font.font(fontSize));
        }
        else {
            if(fontSize == 13) return;
            fontSize--;
            setFont(Font.font(fontSize));
        }
        e.consume();
    }
}
