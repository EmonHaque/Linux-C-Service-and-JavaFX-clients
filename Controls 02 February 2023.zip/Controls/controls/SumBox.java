package controls;

import controls.buttons.ActionButton;
import controls.texts.SuggestionBoxLess;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.StringConverter;
import model.SumBoxModel;
import skinned.ExtendedListView;
import skins.ExtendedTextFieldSkin;

public class SumBox<T> extends GridPane {
    private final String suggestionProperty, suggestionTemplate;
    private final ObservableList<T> suggestionList;
    private ObservableList<SumBoxModel> list;
    private ExtendedListView<SumBoxModel> listView;
    private ActionButton addButton, removeButton;
    private Text particulars, amount, totalText, totalValue;

    private final DoubleProperty sum;
    private final BooleanProperty modified;

    public SumBox(ObservableList<T> suggestionList, String suggestionProperty, String suggestionTemplate) {
        this.suggestionList = suggestionList;
        this.suggestionProperty = suggestionProperty;
        this.suggestionTemplate = suggestionTemplate;
        sum = new SimpleDoubleProperty();
        modified = new SimpleBooleanProperty();

        addButtons();
        addTexts();
        addListView();

        getColumnConstraints().addAll(
                new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                new ColumnConstraints(70)
        );
    }
    public DoubleProperty sumProperty(){ return sum; }
    public BooleanProperty modifiedProperty(){ return modified; }

    public void setList(ObservableList<SumBoxModel> list) {
        // remove handlers?
        double total = 0;
        for (var item : list) {
            total += item.getValue();
            item.key.addListener(this::onKeyChanged);
            item.value.addListener(this::onValueChanged);
        }
        totalValue.setText(String.format("%,.2f", total));
        sum.set(total);

        this.list = list;
        getChildren().remove(listView);
        addListView();
    }

    private void addListView(){
        listView = new ExtendedListView<>(list);
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setCellFactory(v -> new CellTemplate());
        add(listView, 0, 2, 2, 1);
        setVgrow(listView, Priority.ALWAYS);
    }

    public void setHeader(String text) {
        particulars.setText(text);
    }

    private void onKeyChanged(Observable o, String ov, String nv){
        modified.set(true);
    }

    private void onValueChanged(ObservableValue<?> o, Number ov, Number nv) {
        double total = sum.get();
        total -= ov.doubleValue();
        total += nv.doubleValue();
        totalValue.setText(String.format("%,.2f", total));
        sum.set(total);
        modified.set(true);
    }

    private void addNewRow() {
        var newItem = new SumBoxModel("", 0);
        newItem.value.addListener(this::onValueChanged);

        list.add(newItem);
        listView.getSelectionModel().select(newItem);
        listView.scrollTo(newItem);
        modified.set(true);
        // listView.getSelectionModel().select(list.size() - 1);
    }

    private void removeSelectedRow() {
        var index = listView.getSelectionModel().getSelectedIndex();
        if (index == -1) return;
        var pair = list.get(index);
        double total = this.sum.get();
        total -= pair.value.get();

        totalValue.setText(String.format("%,.2f", total));
        sum.set(total);
        list.remove(index);
        if (index > 0) {
            index--;
            listView.getSelectionModel().select(index);
        }
        modified.set(true);
    }

    private void addTexts() {
        particulars = new Text("Particulars");
        amount = new Text("Amount");
        totalText = new Text("Total");
        totalValue = new Text(String.format("%,.2f", sum.get()));

        particulars.setFill(Color.WHITE);
        amount.setFill(Color.WHITE);
        totalText.setFill(Color.WHITE);
        totalValue.setFill(Color.WHITE);

        var topBorder = new StackPane();
        var bottomBorder = new StackPane();
        topBorder.setBorder(Constants.BottomBorder);
        bottomBorder.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0))));

        add(topBorder, 0, 1, 2, 1);
        add(particulars, 0, 1);
        add(amount, 1, 1);

        add(bottomBorder, 0, 3, 2, 1);
        add(totalText, 0, 3);
        add(totalValue, 1, 3);

        GridPane.setHalignment(amount, HPos.RIGHT);
        GridPane.setHalignment(totalValue, HPos.RIGHT);
        GridPane.setMargin(amount, new Insets(0, Constants.ScrollBarSize, 0, 0));
        GridPane.setMargin(totalValue, new Insets(0, Constants.ScrollBarSize, 0, 0));
    }

    private void addButtons() {
        addButton = new ActionButton(Icons.PlusCircle, 16, "add");
        removeButton = new ActionButton(Icons.MinusCircle, 16, "remove");

        addButton.setAction(this::addNewRow);
        removeButton.setAction(this::removeSelectedRow);

        var hBox = new HBox(addButton, removeButton);
        hBox.setAlignment(Pos.CENTER_RIGHT);
        add(hBox, 1, 0);

        GridPane.setHalignment(hBox, HPos.RIGHT);
        GridPane.setMargin(hBox, new Insets(0, Constants.ScrollBarSize, 0, 0));
    }

    private class CellTemplate extends ListCell<SumBoxModel> {
        private final SuggestionBoxLess<T> keyField;
        private final TextField valueField;
        private final GridPane grid;

        public CellTemplate() {
            setPadding(new Insets(1, 0, 1, 0));
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setBackground(null);

            keyField = new SuggestionBoxLess<>(suggestionList, suggestionProperty, suggestionTemplate);
            valueField = new TextField();
            valueField.setSkin(new ExtendedTextFieldSkin(valueField));
            keyField.setPadding(new Insets(0));
            valueField.setPadding(new Insets(0));
            valueField.setAlignment(Pos.CENTER_RIGHT);

            grid = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints(70)
                );
                add(keyField, 0, 0);
                add(valueField, 1, 0);
            }};

            itemProperty().addListener((o, ov, nv) -> {
                if (ov != null) {
                    keyField.textProperty().unbindBidirectional(ov.key);
                    valueField.textProperty().unbindBidirectional(ov.value);
                    setOnKeyPressed(null);
                }
                if (nv != null) {
                    keyField.textProperty().bindBidirectional(nv.key);
                    valueField.textProperty().bindBidirectional(nv.value, new StringConverter<>() {
                        @Override
                        public String toString(Number object) {
                            return String.format("%.2f", object.doubleValue());
                        }

                        @Override
                        public Number fromString(String string) {
                            return Double.parseDouble(string);
                        }
                    });
                    setOnKeyPressed(this::onKeyPressed);
                }
            });

            focusWithinProperty().addListener(o ->{
                // null ?
                getListView().getSelectionModel().select(getItem());
            });
        }

        private void onKeyPressed(KeyEvent e) {
            if (!e.isControlDown()) return;
            var code = e.getCode();
            if (code == KeyCode.ADD) {
                addNewRow();
            }
            if (code == KeyCode.SUBTRACT) {
                removeSelectedRow();
            }
        }

        @Override
        protected void updateItem(SumBoxModel item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
                return;
            }
            setGraphic(grid);
            if (isSelected()) {
                keyField.requestFocus();
                keyField.end();
            }
        }
    }
}
