package controls.states;

import controls.SVGRegion;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Pair;

public class MultiState extends GridPane {
    private final boolean isIconFirst;
    private String[] icons;
    private String[] texts;
    private SVGRegion icon;

    private final Text text;
    private int index;
    public IntegerProperty stateProperty;
    public ObjectProperty<Pair<String[], String[]>> statesProperty;

    public MultiState(boolean isIconFirst) {
        this.isIconFirst = isIconFirst;
        index = 0;

        text = new Text();
        text.setFill(Color.WHITE);

        stateProperty = new SimpleIntegerProperty();
        statesProperty = new SimpleObjectProperty<>();

        setHgap(5);
        setAlignment(Pos.CENTER_LEFT);

        setOnMouseEntered(e -> icon.animate(Color.CORAL));
        setOnMouseExited(e -> icon.animate(Color.WHITE));
        setOnMouseClicked(this::onClicked);

        statesProperty.addListener(this::onStatesChanged);
        stateProperty.addListener(this::onStateChanged);

        disableProperty().addListener((o, ov, nv) ->{
            if(nv){
                icon.setColor(Color.GRAY);
                text.setFill(Color.GRAY);
            }
            else {
                icon.setColor(Color.WHITE);
                text.setFill(Color.WHITE);
            }
        });
    }

    public MultiState(String[] icons, String[] texts, boolean isIconFirst) {
        this(isIconFirst);
        this.icons = icons;
        this.texts = texts;
        icon = new SVGRegion(icons[index]);

        text.setText(texts[index]);
        addContent();
        stateProperty.set(index);
    }

    private void onStateChanged(ObservableValue<?> o, Number ov, Number nv) {
        icon.setContent(icons[nv.intValue()]);
        text.setText(texts[nv.intValue()]);
    }

    private void onStatesChanged(ObservableValue<?> o, Pair<String[], String[]> ov, Pair<String[], String[]> nv) {
        if (nv == null)
            return;
        icons = nv.getKey();
        texts = nv.getValue();
        index = 0;

        if (icon == null) {
            icon = new SVGRegion(icons[index]);
        }
        else {
            icon.setContent(icons[index]);
        }

        text.setText(texts[index]);
        getChildren().clear();
        addContent();
        stateProperty.set(index);
    }

    private void addContent() {
        if (isIconFirst) {
            addColumn(0, icon);
            addColumn(1, text);
        }
        else {
            addColumn(0, text);
            addColumn(1, icon);
        }
        GridPane.setValignment(icon, VPos.CENTER);
        GridPane.setValignment(text, VPos.CENTER);
    }

    private void onClicked(MouseEvent e) {
        index = index < icons.length - 1 ? ++index : 0;
        icon.setContent(icons[index]);
        text.setText(texts[index]);
        stateProperty.set(index);
    }

    public void setState(int value){
        stateProperty.set(value);
    }
}