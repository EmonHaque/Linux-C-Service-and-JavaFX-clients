package skins;

import javafx.scene.control.ScrollBar;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeView;
import javafx.scene.control.skin.TreeViewSkin;
import javafx.scene.control.skin.VirtualFlow;
import skinned.ExtendedResizableVirtualFlow;

public class ExtendedResizableTreeViewSkin<T> extends TreeViewSkin<T> {
    public ScrollBar vBar;
    public VirtualFlow<?> flow;
    public ExtendedResizableTreeViewSkin(TreeView<T> control) {
        super(control);
    }

    @Override
    protected VirtualFlow<TreeCell<T>> createVirtualFlow() {
        ExtendedResizableVirtualFlow<TreeCell<T>> flow = new ExtendedResizableVirtualFlow<>();
        this.flow = flow;
        vBar = flow.vBar;
        return flow;
    }
}
