package Views.Edit;

import ViewModels.Edit.EditBaseVM;
import abstracts.View;
import controls.SpinningArc;
import controls.texts.TextBox;
import editables.EditPane;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ListCell;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import skinned.ExtendedListView;
import skinned.ExtendedSeparator;
import skinned.ExtendedTreeView;

public abstract class EditBase<T> extends View {
    private EditBaseVM<T> vm;
    protected EditPane pane;
    private Node listOrTree;
    private Text count, status;
    private SpinningArc spinner;

    protected VBox leftBox;
    protected HBox queryBox;
    protected TextBox query;

    protected abstract EditBaseVM<T> getViewModel();

    protected abstract boolean isEditableList();

    protected abstract void initializeEditPane(EditPane pane);

    protected ExtendedTreeView<T> getTree() {return null;}

    protected ListCell<T> getListCellTemplate() {return null;}

    protected abstract void onSelectionChanged(T item);

    protected abstract void onIsOnEditChanged();

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = getViewModel();
        initializeUI();
        bind();
    }

    protected void initializeUI() {
        query = new TextBox("search", Icons.Magnify, false);
        count = new Text() {{setFill(Color.WHITE);}};
        queryBox = new HBox(query, count) {{
            setHgrow(query, Priority.ALWAYS);
            setSpacing(5);
            setAlignment(Pos.BOTTOM_RIGHT);
        }};
        if (isEditableList()) {
            listOrTree = new ExtendedListView<>(vm.editableList) {{
                setCellFactory(v -> getListCellTemplate());
            }};
        }
        else {
            listOrTree = getTree();
        }

        leftBox = new VBox(queryBox, listOrTree) {{
            setSpacing(5);
            setPadding(new Insets(10, 0, 0, 0));
            setVgrow(listOrTree, Priority.ALWAYS);
        }};

        var separator = new ExtendedSeparator() {{setOrientation(Orientation.VERTICAL);}};
        pane = new EditPane(vm::save);
        initializeEditPane(pane);

        var content = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(49.5);}},
                    new ColumnConstraints() {{setPercentWidth(1);}},
                    new ColumnConstraints() {{setPercentWidth(49.5);}}
            );
            getRowConstraints().add(new RowConstraints() {{setPercentHeight(100);}});
            add(leftBox, 0, 0);
            add(separator, 1, 0);
            add(pane, 2, 0);
        }};
        GridPane.setHalignment(separator, HPos.CENTER);

        setCenter(content);

        status = new Text() {{setFill(Color.WHITE);}};
        spinner = new SpinningArc();
        addAction(spinner);
        addAction(status);
    }

    protected void bind() {
        vm.queryProperty.bind(query.textProperty());
        count.textProperty().bind(Bindings.size(vm.editableList).asString());
        spinner.visibleProperty().bind(vm.isRunningProperty);
        status.textProperty().bind(vm.statusProperty);

        if (listOrTree instanceof ExtendedListView<?>) {
            var list = (ExtendedListView<T>) listOrTree;
            list.getSelectionModel().selectedItemProperty().addListener((o, ov, nv) -> setSelected(nv));
        }
        else {
            var tree = (ExtendedTreeView<T>) listOrTree;
            tree.getSelectionModel().selectedItemProperty().addListener((o, ov, nv) -> setSelected(nv == null ? null : nv.getValue()));
        }

        pane.isOnEditProperty().addListener((o, ov, nv) -> {
            if (!nv) return;
            vm.cloneSelected();
            onIsOnEditChanged();
        });
    }

    private void setSelected(T item) {
        pane.setCanEdit(item != null);
        if (pane.onEdit()) pane.setIsOnEdit(false);
        vm.selected = item;
        onSelectionChanged(item);
    }
}
