package Views.Report;

import Models.Space;
import ViewModels.Report.BaseLedgerVM;
import ViewModels.Report.SpaceLedgerVM;
import abstracts.View;
import helpers.Icons;

public class SpaceLedger extends BaseLedger<Space> {

    @Override
    protected String getIcon() {
        return Icons.Space;
    }

    @Override
    protected BaseLedgerVM<Space> getViewModel() {
        return new SpaceLedgerVM();
    }
}
