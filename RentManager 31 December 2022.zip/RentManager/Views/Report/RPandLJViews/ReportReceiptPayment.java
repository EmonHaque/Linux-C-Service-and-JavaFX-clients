package Views.Report.RPandLJViews;

import Models.ReceiptPayment;
import ViewModels.Report.ReportReceiptPaymentVM;
import abstracts.View;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.daymonth.DayPicker;
import controls.states.ExpandedState;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import skinned.ExtendedListView;
import trees.ReceiptPaymentTree;

import javax.swing.*;

public class ReportReceiptPayment extends View {
    private ReportReceiptPaymentVM vm;
    private Text status;
    private DayPicker startDate, endDate;
    private CommandButton refresh;
    private ReceiptPaymentTree tree;
    private ExpandedState isExpanded;
    private SpinningArc spinner;

    @Override
    protected String getHeader() {
        return "Receipt Payment";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new ReportReceiptPaymentVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        startDate = new DayPicker("from", Icons.Month, false);
        endDate = new DayPicker("to", Icons.Month, false);
        refresh = new CommandButton(Icons.Reload, 16, "reload");

        var hBox = new HBox(startDate, endDate, refresh){{
            setSpacing(5);
            setHgrow(startDate, Priority.ALWAYS);
            setHgrow(endDate, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_CENTER);
            setMargin(refresh, new Insets(0, 0, 4, 0));
        }};
        tree = new ReceiptPaymentTree();

        var box = new VBox(hBox, getTableHeader(), tree){{
           setSpacing(5);
           setVgrow(tree, Priority.ALWAYS);
        }};
        setCenter(box);

        spinner = new SpinningArc();
        status = new Text(){{setFill(Color.WHITE);}};
        addAction(spinner);
        addAction(status);
    }

    private void bind(){
        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);
        startDate.selectedDateProperty().bindBidirectional(vm.startDateProperty);
        endDate.selectedDateProperty().bindBidirectional(vm.endDateProperty);
        refresh.setAction(vm::updateReportable);
        tree.itemsProperty.bind(vm.listProperty);
        tree.isExpandedProperty.bind(isExpanded.isExpandedProperty);
    }

    private Node getTableHeader(){
        var bold = Font.font(null, FontWeight.BOLD, -1);

        isExpanded = new ExpandedState(true);
        var particulars = new Text("Particulars"){{ setFill(Color.WHITE); setFont(bold);}};
        var hBox = new HBox(isExpanded, particulars){{
            setSpacing(2.5);
            setAlignment(Pos.CENTER_LEFT);
        }};

        var cash = new Text("Cash"){{ setFill(Color.WHITE); setFont(bold); }};
        var kind = new Text("Kind"){{ setFill(Color.WHITE); setFont(bold); }};
        var mobile = new Text("Mobile"){{ setFill(Color.WHITE); setFont(bold); }};
        var total = new Text("Total"){{ setFill(Color.WHITE); setFont(bold); }};
        return new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.SOMETIMES);}},
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80)
            );
            add(hBox, 0, 0);
            add(cash, 1, 0);
            add(kind, 2, 0);
            add(mobile, 3, 0);
            add(total, 4, 0);

            setHalignment(cash, HPos.RIGHT);
            setHalignment(kind, HPos.RIGHT);
            setHalignment(mobile, HPos.RIGHT);
            setHalignment(total, HPos.RIGHT);

            setPadding(new Insets(0, Constants.ScrollBarSize, 0, 0));
            setBorder(Constants.BottomLine);
        }};
    }
}
