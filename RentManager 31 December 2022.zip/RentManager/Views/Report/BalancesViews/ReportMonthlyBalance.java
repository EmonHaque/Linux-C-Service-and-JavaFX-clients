package Views.Report.BalancesViews;

import ViewModels.Report.ReportMonthlyBalanceVM;
import abstracts.View;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.daymonth.MonthPicker;
import controls.states.ExpandedState;
import controls.states.MultiState;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import trees.MonthlyBalanceTree;

public class ReportMonthlyBalance extends View {
    private ReportMonthlyBalanceVM vm;
    private Text status, entries, due, lastDue, paid, shortOrLong;
    private SpinningArc spiner;
    private MonthPicker month;
    private CommandButton refresh;
    private MultiState states;
    private MonthlyBalanceTree tree;
    private ExpandedState isExpanded;

    @Override
    protected String getHeader() {
        return "Monthly Balance";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new ReportMonthlyBalanceVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        month = new MonthPicker("Month", Icons.Month, false);
        states = new MultiState(new String[]{Icons.All, Icons.CheckCircle, Icons.CloseCircle}, new String[]{"All", "Paid", "Due"}, false) {{
            setAlignment(Pos.BOTTOM_CENTER);
        }};
        refresh = new CommandButton(Icons.Reload, 16, "Reload");
        var hBox = new HBox(month, states, refresh) {{
            setSpacing(5);
            setHgrow(month, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_CENTER);
            setMargin(states, new Insets(0, 0, 4, 0));
            setMargin(refresh, new Insets(0, 0, 4, 0));
        }};
        tree = new MonthlyBalanceTree();

        var box = new VBox(hBox, getTableHeader(), tree, getTableFooter()) {{
            setSpacing(5);
            setVgrow(tree, Priority.ALWAYS);
        }};
        setCenter(box);

        spiner = new SpinningArc();
        status = new Text() {{setFill(Color.WHITE);}};
        addAction(spiner);
        addAction(status);
    }

    private void bind() {
        spiner.visibleProperty().bind(vm.isRunningProperty);
        status.textProperty().bind(vm.statusProperty);
        vm.selectedMonthProperty.bind(month.selectedDateProperty());
        refresh.setAction(vm::updateReportable);
        tree.itemsProperty.bind(vm.balancesProperty);
        vm.stateProperty.bind(states.stateProperty);
        tree.isExpandedProperty.bind(isExpanded.isExpandedProperty);

        entries.textProperty().bind(Bindings.size(vm.balancesProperty).asString());
        due.textProperty().bind(vm.dueProperty.asString("%,d"));
        lastDue.textProperty().bind(vm.lastDueProperty.asString("%,d"));
        paid.textProperty().bind(vm.paidProperty.asString("%,d"));
        shortOrLong.textProperty().bind(vm.shortOrLongProperty.asString("%,d"));
    }

    private Node getTableHeader() {
        isExpanded = new ExpandedState(true);
        var bold = Font.font(null, FontWeight.BOLD, -1);
        var particulars = new Text("Particulars") {{setFill(Color.WHITE); setFont(bold);}};
        var flow = new TextFlow(particulars);
        var hBox = new HBox(isExpanded, flow){{
            setSpacing(2.5);
            setAlignment(Pos.CENTER_LEFT);
        }};

        var date = new Text("Date") {{setFill(Color.WHITE); setFont(bold);}};
        var due = new Text("Due") {{setFill(Color.WHITE); setFont(bold);}};
        var lastDue = new Text("Last due") {{setFill(Color.WHITE); setFont(bold);}};
        var paid = new Text("Paid") {{setFill(Color.WHITE); setFont(bold);}};
        var shortOrLong = new Text("Short") {{setFill(Color.WHITE); setFont(bold);}};

        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.SOMETIMES); }},
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80)
            );
            setBorder(Constants.BottomLine);
            add(hBox, 0, 0);
            add(date, 1, 0);
            add(due, 2, 0);
            add(lastDue, 3, 0);
            add(paid, 4, 0);
            add(shortOrLong, 5, 0);

            setHalignment(date, HPos.CENTER);
            setHalignment(due, HPos.RIGHT);
            setHalignment(lastDue, HPos.RIGHT);
            setHalignment(paid, HPos.RIGHT);
            setHalignment(shortOrLong, HPos.RIGHT);
            setPadding(new Insets(5, Constants.ScrollBarSize, 0, 0));
        }};
    }

    private Node getTableFooter() {
        entries = new Text() {{setFill(Color.WHITE);}};
        due = new Text() {{setFill(Color.WHITE);}};
        lastDue = new Text() {{setFill(Color.WHITE);}};
        paid = new Text() {{setFill(Color.WHITE);}};
        shortOrLong = new Text() {{setFill(Color.WHITE);}};

        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80)
            );
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0))));
            add(new TextFlow() {{
                getChildren().addAll(
                        new Text("Total of ") {{setFill(Color.WHITE);}},
                        entries,
                        new Text(" entries") {{setFill(Color.WHITE);}}
                );
            }}, 0, 0);
            add(due, 1, 0);
            add(lastDue, 2, 0);
            add(paid, 3, 0);
            add(shortOrLong, 4, 0);

            setHalignment(due, HPos.RIGHT);
            setHalignment(lastDue, HPos.RIGHT);
            setHalignment(paid, HPos.RIGHT);
            setHalignment(shortOrLong, HPos.RIGHT);
            setPadding(new Insets(0, Constants.ScrollBarSize, 0, 0));
        }};
    }
}
