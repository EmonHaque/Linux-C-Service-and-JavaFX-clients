package Views.Home;

import ViewModels.Home.RentDetailVM;
import abstracts.View;
import controls.areachart.Area;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public class RentDetail extends View {
    private RentDetailVM vm;
    private Area area;
    @Override
    protected String getHeader() {
        return "Detail Rent Deposit & Dues";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new RentDetailVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        area = new Area();
        BorderPane.setMargin(area, new Insets(25,10,0,0));
        setCenter(area);
    }

    private  void bind(){
        area.seriesProperty.bind(vm.dataProperty);
    }
}
