package Views.Home;

import CellTemplates.SelectionBox.TenantTemplate;
import CellTemplates.Visual.TenantVisual;
import Models.Tenant;
import ViewModels.Home.TenantDetailVM;
import abstracts.View;
import controls.SelectionBox;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.states.BiState;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.TextFlow;

public class TenantDetail extends View {
    private TenantDetailVM vm;
    private SelectionBox<Tenant> tenant;
    private BiState state;
    private TextFlow depositFlow;
    private Text deposit, status;
    private SpinningArc spinner;
    private CommandButton refresh;

    @Override
    protected String getHeader() {
        return "Due & Payments";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new TenantDetailVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        status = new Text(){{setFill(Color.WHITE);}};
        spinner = new SpinningArc();
        refresh = new CommandButton(Icons.Reload, 16, "refresh");

        addAction(spinner);
        addAction(status);
        addAction(refresh);

        tenant = new SelectionBox<>("Tenant", Icons.Tenant, vm.tenants, new TenantVisual(), TenantTemplate.class.getName(), true);
        state = new BiState(true, "Existing"){{ setAlignment(Pos.BOTTOM_RIGHT);}};

        deposit = new Text(){{ setFill(Color.WHITE);}};
        depositFlow = new TextFlow(){{
            getChildren().addAll(
                    new Text("Deposit: ") {{setFill(Color.WHITE);}},
                    deposit
            );
            setTextAlignment(TextAlignment.RIGHT);
        }};

        var grid = new GridPane(){{
           getColumnConstraints().addAll(
                   new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                   new ColumnConstraints()
           );
           getRowConstraints().addAll(
                   new RowConstraints(),
                   new RowConstraints(),
                   new RowConstraints(){{ setVgrow(Priority.ALWAYS);}}
           );
           add(tenant, 0, 0);
           add(state, 1, 0);
           add(depositFlow, 0, 1, 2, 1);

           setVgap(5);
           setMargin(state, new Insets(0,0,5,5));
           setPadding(new Insets(5,0,0,0));
        }};
        setCenter(grid);
    }

    private void bind(){
        refresh.setAction(vm::refresh);
        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);
        vm.stateProperty.bind(state.isCheckedProperty);
        vm.selectedTenantProperty.bind(tenant.selectedValueProperty());
        deposit.textProperty().bind(vm.depositProperty);
    }
}
