package Views.Home;

import ViewModels.Home.PlotDueVM;
import abstracts.View;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.pinchart.PinColumns;
import controls.states.BiState;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class PlotDue extends View {
    private PlotDueVM vm;
    private Text status;
    private BiState state;
    private SpinningArc spinner;
    private CommandButton refresh;
    private PinColumns chart;

    @Override
    protected String getHeader() {
        return  "Due & Tenants";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new PlotDueVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        status = new Text(){{setFill(Color.WHITE);}};
        refresh = new CommandButton(Icons.Reload, 16, "refresh");
        state = new BiState(false, "All");
        spinner = new SpinningArc();

        addAction(spinner);
        addAction(status);
        addAction(state);
        addAction(refresh);

        chart = new PinColumns("Due", "Tenant");
        setCenter(chart);
        BorderPane.setMargin(chart, new Insets(25,0,0,0));
    }

    private void bind(){
        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);
        vm.stateProperty.bind(state.isCheckedProperty);
        chart.seriesProperty.bind(vm.seriesProperty);
    }
}
