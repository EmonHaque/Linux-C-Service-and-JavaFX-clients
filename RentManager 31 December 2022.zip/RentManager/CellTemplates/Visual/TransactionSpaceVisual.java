package CellTemplates.Visual;

import Models.SpaceTransaction;
import interfaces.ISetSelectionBoxContent;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class TransactionSpaceVisual extends BorderPane implements ISetSelectionBoxContent<SpaceTransaction> {
    private final Text name, date;
    private SpaceTransaction item;

    public TransactionSpaceVisual() {
        name = new Text();
        date = new Text();
        setCenter(name);
        setRight(date);
        setAlignment(name, Pos.CENTER_LEFT);
        setAlignment(date, Pos.CENTER_RIGHT);
    }

    @Override
    public void setContent(SpaceTransaction item) {
        name.textProperty().unbind();
        date.textProperty().unbind();

        this.item = item;
        if(item.getIsExpired()){
            name.setFill(Color.GRAY);
            date.setFill(Color.GRAY);
        }
        else{
            name.setFill(Color.WHITE);
            date.setFill(Color.WHITE);
        }
        name.textProperty().bind(item.nameProperty());
        date.textProperty().bind(item.startDateProperty());
    }

    @Override
    public SpaceTransaction getContent() {
        return item;
    }

    @Override
    public Node getVisual() {
        return this;
    }
}
