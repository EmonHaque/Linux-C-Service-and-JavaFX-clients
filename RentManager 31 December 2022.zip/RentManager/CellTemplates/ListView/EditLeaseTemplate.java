package CellTemplates.ListView;

import Models.Lease;
import abstracts.ListCellBase;
import controls.texts.HiText;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class EditLeaseTemplate extends ListCellBase<Lease> {
    private HBox root;
    private Text dash;
    private HiText space, tenant;
    private final StringProperty query;
    private final IntegerProperty state;

    public EditLeaseTemplate(StringProperty query, IntegerProperty state) {
        super();
        this.query = query;
        this.state = state;
    }

    @Override
    protected void initializeUI() {
        space = new HiText();
        tenant = new HiText();
        dash = new Text("-") {{setFill(Color.WHITE);}};
        root = new HBox(space, dash, tenant) {{setSpacing(5);}};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Lease ov, Lease nv) {
        if (nv == null) return;

        space.textProperty().bind(nv.spaceNameProperty());
        tenant.textProperty().bind(nv.tenantNameProperty());
        space.queryProperty().bind(query);
        tenant.queryProperty().bind(query);

        var fillBinding = Bindings.createObjectBinding(() -> {
            if (state.get() != 2) return Color.WHITE;
            return nv.isIsExpired() ? Color.GRAY : Color.WHITE;
        }, state, nv.isExpiredProperty());

        space.fillProperty().bind(fillBinding);
        tenant.fillProperty().bind(fillBinding);
        dash.fillProperty().bind(fillBinding);
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
