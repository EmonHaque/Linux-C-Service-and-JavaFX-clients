package ChartControls.DoubleColimn;

import Models.RentPayment;

import java.util.List;

public class DoubleColumn {
    private List<RentPayment> payments;
    private double cashTotal, kindTotal, mobileTotal, dueTotal;

    public DoubleColumn(List<RentPayment> payments) {
        this.payments = payments;
        dueTotal = payments.get(0).getDue();
        for(var item : payments){
            cashTotal += item.getCash();
            kindTotal += item.getKind();
            mobileTotal += item.getMobile();
        }
    }
}
