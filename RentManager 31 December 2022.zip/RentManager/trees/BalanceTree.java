package trees;

import Models.Balance;
import controls.SVGRegion;
import controls.texts.HiTexts;
import helpers.Icons;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import skinned.ExtendedTreeView;

import java.text.DecimalFormat;
import java.util.List;

public class BalanceTree extends ExtendedTreeView<Balance> {
    private final TreeItem<Balance> root;

    public BalanceTree(FilteredList<Balance> balances, StringProperty query) {
        root = new TreeItem<>();
        addItems(balances);
        setRoot(root);
        setShowRoot(false);
        setCellFactory(v -> new BalanceCell(query));

        balances.addListener(this::onItemsChanged);
    }

    private void onItemsChanged(ListChangeListener.Change<? extends Balance> change) {
        while (change.next()) {
            if (change.wasAdded()) {
                if (change.getRemovedSize() > 0) {
                    root.getChildren().clear();
                }
                addItems((List<Balance>) change.getAddedSubList());
            }
            if (change.wasRemoved()) {
                root.getChildren().clear();
            }
        }
    }

    private void addItems(List<Balance> balances) {
        for (var balance : balances) {
            var hasIt = false;
            TreeItem<Balance> tenant = null;
            for (var item : root.getChildren()) {
                if (item.getValue().getTenant().equals(balance.getTenant())) {
                    tenant = item;
                    var value = tenant.getValue();
                    value.setDue(value.getDue() + balance.getDue());
                    value.setRent(value.getRent() + balance.getRent());
                    value.setSecurity(value.getSecurity() + balance.getSecurity());
                    hasIt = true;
                }
            }
            if (!hasIt) {
                tenant = new TreeItem<>(new Balance() {{
                    setTenant(balance.getTenant());
                    setRent(balance.getRent());
                    setDue(balance.getDue());
                    setSecurity(balance.getSecurity());
                }});
                tenant.setExpanded(true);
                root.getChildren().add(tenant);
            }
            tenant.getChildren().add(new TreeItem<>(balance));
        }
        removeSingle();
    }

    private void removeSingle() {
        for (var item : root.getChildren()) {
            if (item.getChildren().size() > 1) continue;
            if(item.getChildren().size() == 0) continue;

            var single = item.getChildren().get(0);
            item.getValue().setSpace(single.getValue().getSpace());
            item.getValue().setDateStart(single.getValue().getDateStart());
            item.getChildren().remove(single);
        }
    }

    private class BalanceCell extends TreeCell<Balance> {
        private GridPane root;
        private HiTexts flow;
        private Text tenant, space, from, security, rent, due;
        private SVGRegion disclosureIcon;
        private Font normal, bold;
        private DecimalFormat formatter;
        private final StringProperty query;

        public BalanceCell(StringProperty query) {
            this.query = query;

            setPrefWidth(0);
            setPadding(new Insets(2.5, 0, 2.5, 0));
            setBackground(null);

            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            initializeUI();
            itemProperty().addListener(this::onItemChanged);
        }

        private void initializeUI() {
            formatter = new DecimalFormat("#,###;(#,###)");
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            tenant = new Text() {{setFill(Color.WHITE);}};
            space = new Text() {{setFill(Color.WHITE);}};
            from = new Text() {{setFill(Color.WHITE);}};
            security = new Text() {{setFill(Color.WHITE);}};
            rent = new Text() {{setFill(Color.WHITE);}};
            due = new Text() {{setFill(Color.WHITE);}};

            flow = new HiTexts(tenant, space);

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.SOMETIMES);}},
                        new ColumnConstraints(100) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}}
                );
                add(flow, 0, 0);
                add(from, 1, 0);
                add(security, 2, 0);
                add(rent, 3, 0);
                add(due, 4, 0);
            }};
        }

        private void onItemChanged(ObservableValue<?> o, Balance ov, Balance nv) {
            if (ov != null) {
                flow.queryProperty().unbind();
                tenant.setText("");
                space.setText("");
                from.setText("");
                security.setText("");
                rent.setText("");
                due.setText("");

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);
                var size = item.getChildren().size();

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                if (level == 1) {
                    tenant.setText(nv.getTenant());
                    tenant.setFont(bold);

                    if (size == 0) {
                        space.setVisible(true);
                        from.setVisible(true);
                        space.setText(" - " + nv.getSpace());
                        from.setText(nv.getDateStart());
                    }
                    else {
                        space.setVisible(false);
                        from.setVisible(false);
                    }
                }
                else {
                    space.setVisible(true);
                    from.setVisible(true);
                    if (nv.isExpired()) {
                        space.setText(nv.getSpace() + " expired on " + nv.getDateEnd());
                    }
                    else {
                        space.setText(nv.getSpace());
                    }
                    from.setText(nv.getDateStart());
                }
                security.setText(nv.getSecurity() == 0 ? "   -  " : formatter.format(nv.getSecurity()));
                rent.setText(nv.getRent() == 0 ? "   -  " : formatter.format(nv.getRent()));
                due.setText(nv.getDue() == 0 ? "   -  " : formatter.format(nv.getDue()));
                flow.queryProperty().bind(query);
            }
        }

        @Override
        protected void updateItem(Balance item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setBackground(null);
                setGraphic(null);
                return;
            }
            setGraphic(root);
        }
    }
}
