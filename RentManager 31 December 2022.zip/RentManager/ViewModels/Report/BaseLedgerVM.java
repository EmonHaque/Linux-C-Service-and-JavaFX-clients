package ViewModels.Report;

import Enums.Function;
import Models.ReportEntry;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public abstract class BaseLedgerVM<T> {
    public IntegerProperty idProperty, entriesProperty, receivableProperty, receiptProperty, balanceProperty;
    public ObjectProperty<LocalDate> minDateProperty, maxDateProperty, startDateProperty, endDateProperty;
    public StringProperty particularsQueryProperty, statusProperty;
    public BooleanProperty isRunningProperty;
    public FilteredList<T> selectionList;
    public FilteredList<ReportEntry> reportable;

    protected String particularsQueryLower;

    private final ObservableList<ReportEntry> reserved;
    private int entries, receivable, receipt, balance;

    public BaseLedgerVM() {
        initializeSimples();
        reserved = FXCollections.observableArrayList();
        reportable = new FilteredList<>(reserved);
        selectionList = getSelectionList();
        particularsQueryProperty.addListener(this::onQueryChanged);
    }

    private void initializeSimples(){
        idProperty = new SimpleIntegerProperty();
        entriesProperty = new SimpleIntegerProperty();
        receivableProperty = new SimpleIntegerProperty();
        receiptProperty = new SimpleIntegerProperty();
        balanceProperty = new SimpleIntegerProperty();

        minDateProperty = new SimpleObjectProperty<>();
        maxDateProperty = new SimpleObjectProperty<>();
        startDateProperty = new SimpleObjectProperty<>();
        endDateProperty = new SimpleObjectProperty<>();

        particularsQueryProperty = new SimpleStringProperty();
        statusProperty = new SimpleStringProperty();
        isRunningProperty = new SimpleBooleanProperty();
    }

    private void onQueryChanged(Observable o) {
        particularsQueryLower = particularsQueryProperty.get().toLowerCase();
        var isEmpty = particularsQueryLower.isEmpty();

        receivable = receipt = balance = entries = 0;
        if(isEmpty){
            reportable.setPredicate(r -> true);
            for (var e : reportable){
                receivable += e.getReceivable();
                receipt += e.getReceipt();
                entries++;
            }
        }
        else reportable.setPredicate(this::filterReportable);

        receivableProperty.set(receivable);
        receiptProperty.set(receipt);
        entriesProperty.set(entries);
    }

    private boolean filterReportable(ReportEntry e){
        if(e.getParticulars().toLowerCase().contains(particularsQueryLower)){
            receivable += e.getReceivable();
            receipt += e.getReceipt();
            entries++;
            return true;
        }
        return false;
    }

    protected abstract String getWhere();

    public abstract String getHeader();

    protected abstract FilteredList<T> getSelectionList();

    public void updateReportable(){
        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private class ResponseTask extends Task<List<ReportEntry>>{
        @Override
        protected List<ReportEntry> call() throws Exception {
            updateMessage("requesting data ...");
            Thread.sleep(500);

            var whereBytes = (getWhere() + '\0').getBytes(StandardCharsets.US_ASCII);
            var buffer = ByteBuffer.allocate(4 + whereBytes.length).order(ByteOrder.LITTLE_ENDIAN);
            buffer.putInt(idProperty.get());
            buffer.put(whereBytes);
            var request = new Request(Function.GetLedger.ordinal(), buffer);

            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return null;
            }
            int length = response.getPacket().length;
            if (length == 0) {
                updateMessage("no data available");
                Thread.sleep(500);
                return null;
            }
            updateMessage("received " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);

            buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
            return getList(buffer, length);
        }

        @Override
        protected void succeeded() {
            reserved.clear();
            try {
                var result = get();
                if(result == null) return;

                reserved.addAll(get());

                minDateProperty.set(reserved.get(0).getDate());
                maxDateProperty.set(reserved.get(reserved.size() - 1).getDate());
                startDateProperty.set(minDateProperty.get());
                endDateProperty.set(maxDateProperty.get());

                entriesProperty.set(entries);
                receivableProperty.set(receivable);
                receiptProperty.set(receipt);
                balanceProperty.set(balance);
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        private List<ReportEntry> getList(ByteBuffer span, int length){
            var list = new ArrayList<ReportEntry>();
            int read = 0;
            int start = 0;
            entries = receivable = receipt = balance = 0;

            var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            while (read < length) {
                while (span.get(read) != 0) read++;
                var date = new String(span.array(), start, read - start, StandardCharsets.US_ASCII);
                start = ++read;

                while (span.get(read) != 0) read++;
                var particulars = new String(span.array(), start, read - start, StandardCharsets.US_ASCII);
                read++;
                int amount = span.getInt(read);
                int control = span.getInt(read + 4);
                read += 8;
                start = read;

                var entry = new ReportEntry() {{
                    setDate(LocalDate.parse(date, formatter));
                    setParticulars(particulars);
                }};
                if (control == AppData.controlIdOfReceivable || control == AppData.controlIdOfPayment) {
                    receivable += amount;
                    balance -= amount;
                    entry.setReceivable(amount);
                }
                else {
                    receipt += amount;
                    balance += amount;
                    entry.setReceipt(amount);
                }
                entry.setBalance(balance);
                list.add(entry);
                entries++;
            }

            return list;
        }
    }
}
