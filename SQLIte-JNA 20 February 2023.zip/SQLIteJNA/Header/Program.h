#pragma once

typedef void rowAction(char**);
typedef void columnAction(int, char**, int);
typedef void errorAction(char*);
typedef void changeAction(int);