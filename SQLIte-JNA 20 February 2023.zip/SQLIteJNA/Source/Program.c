#include "Program.h"
#include <sqlite3.h>
#include <stdio.h>
#include <string.h>

sqlite3 *db;
rowAction *addRow;
columnAction *addColumn;
changeAction *addChange;
errorAction *addError;
unsigned char isColumnCallNeeded, isCancelled;

void setRowCallback(rowAction action) { addRow = action; }
void setColumnCallback(columnAction action) { addColumn = action; }
void setChangeCallback(changeAction action) { addChange = action; }
void setCErrorCallback(errorAction action) { addError = action; }
void cancel() { isCancelled = 1; }

static int callback(void *arg4, int count, char **values, char **columns) {
    if (isColumnCallNeeded) {
        isColumnCallNeeded = 0;
        int rowLength = count * sizeof(char *);
        addColumn(count, columns, rowLength);
    }
    addRow(values);
    return isCancelled ? -1 : 0;
}

void execute(char *query) {
    if (!db) {
        addError("not connected to a database");
        return;
    }
    isCancelled = 0;
    isColumnCallNeeded = 1;
    char *error;

    int start = sqlite3_total_changes(db);
    sqlite3_exec(db, query, callback, 0, &error);
    int change = sqlite3_total_changes(db) - start;

    if (change > 0) addChange(change);
    if (error) addError(error);

    sqlite3_free(error);
}

void openDatabase(char *dbFile) {
    if (db) sqlite3_close(db);
    sqlite3_open_v2(dbFile, &db, SQLITE_OPEN_READWRITE, NULL);

    char *error;
    sqlite3_exec(db, "pragma quick_check", 0, 0, &error);
    addError(error);
    sqlite3_free(error);
}

void closeDatabase() {
    if (db) sqlite3_close(db);
}

// int main(){
//     isColumnCallNeeded = 1;
//     sqlite3_open("/mnt/HDD/Corpus Quran/quran.db", &db);
//     execute("SELECT * FROM CorpusSegment");
//     //sqlite3_exec(db, "SELECT * FROM CorpusQuran", callback, 0, 0);
// }