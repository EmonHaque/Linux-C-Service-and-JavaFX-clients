package controls.daymonth;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import abstracts.SelectionControlBase;
import controls.buttons.ActionButton;
import helpers.Icons;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.WindowEvent;
import skinned.ExtendedSeparator;

public class MonthPicker extends SelectionControlBase {
    private int year, selectedYear, selectedMonth;
    private Text yearText;
    private ActionButton forward, backward;
    private DateTimeFormatter formatter;
    private Text selectedText;
    private ObjectProperty<LocalDate> selectedDate;

    public MonthPicker(String hint, String leftIcon, boolean isRequired) {
        super(hint, leftIcon, isRequired);
        moveHintUp();
        selectedDate = new SimpleObjectProperty<>(LocalDate.now());
        setSelected(selectedDate.get());
        input.setOnKeyPressed(this::onInputKey);
    }
    @Override
    protected String getRightIcon() {
        return Icons.MonthPicker;
    }
    @Override
    protected Node getSelectedContent() {
        selectedText = new Text();
        selectedText.setFill(Color.WHITE);
        return selectedText;
    }

    @Override
    protected void addPopup() {
        super.addPopup();
        addTopSection();
        addMonths();
    }

    @Override
    protected void removeSelected() {
        super.removeSelected();
        year = LocalDate.now().getYear();
        yearText.setText(String.valueOf(year));
        var children = popupGrid.getChildren();
        for (var c : children) {
            if (c instanceof MonthLabel label)
                if (label.isSelected())
                    label.setSelected(false);
        }
        selectedDate.set(null);
    }

    private void addTopSection() {
        year = LocalDate.now().getYear();
        yearText = new Text(String.valueOf(year));
        yearText.setFont(Font.font(null, FontWeight.BOLD, 14));
        yearText.setFill(Color.WHITE);
        backward = new ActionButton(Icons.ScrollLeft, 18, "back");
        forward = new ActionButton(Icons.ScrollRight, 18, "forward");
        var separator = new ExtendedSeparator();

        popupGrid.setHgap(5);
        popupGrid.setVgap(5);
        popupGrid.addRow(0, backward, yearText, forward);
        popupGrid.addRow(1, separator);
        setColumnSpan(yearText, 2);
        setColumnSpan(separator, 4);
        setColumnIndex(forward, 3);

        GridPane.setMargin(separator, new Insets(2.5, 0, 2.5, 0));
        GridPane.setHalignment(backward, HPos.LEFT);
        GridPane.setHalignment(yearText, HPos.CENTER);
        GridPane.setHalignment(forward, HPos.RIGHT);

        forward.setAction(this::increment);
        backward.setAction(this::decrement);
    }

    private void addMonths() {
        int monthNo = 1;
        for (int row = 2; row < 5; row++) {
            for (int col = 0; col < 4; col++) {
                var label = new MonthLabel(monthNo);

                label.setOnMouseClicked(this::onMonthClicked);
                popupGrid.add(label, col, row);
                monthNo++;
            }
        }
    }

    @Override
    protected void onPopupShowing(WindowEvent e) {
        super.onPopupShowing(e);
        resetSelectedLabel();
    }

    private void increment() {
        year++;
        yearText.setText(String.valueOf(year));
        resetSelectedLabel();
    }

    private void decrement() {
        year--;
        yearText.setText(String.valueOf(year));
        resetSelectedLabel();
    }

    private void resetSelectedLabel() {
        var children = popupGrid.getChildren();
        if (year == selectedYear) {
            for (var c : children) {
                if (c instanceof MonthLabel label) {
                    if (label.getMonthNo() == selectedMonth)
                        label.setSelected(true);
                }
            }
        }
        else {
            for (var c : children) {
                if (c instanceof MonthLabel label) {
                    if (label.isSelected())
                        label.setSelected(false);
                }
            }
        }
    }

    private void onInputKey(KeyEvent e) {
        if (e.getCode() != KeyCode.ENTER)
            return;
        var splits = input.getText().split("/");
        int year = Integer.parseInt(splits[1]);
        int month = Integer.parseInt(splits[0]);
        var date = LocalDate.of(year, month, 1);

        this.year = year;
        yearText.setText(splits[1]);
        setSelected(date);

        var children = popupGrid.getChildren();
        for (var c : children) {
            if (c instanceof MonthLabel label) {
                if (label.getMonthNo() == selectedMonth)
                    label.setSelected(true);
                else if (label.isSelected())
                    label.setSelected(false);
            }
        }
    }

    private void setSelected(LocalDate date) {
        formatter = DateTimeFormatter.ofPattern("MMMM, yyyy");
        selectedText.setText(formatter.format(date));
        selectedYear = date.getYear();
        selectedMonth = date.getMonthValue();
        selectedDate.set(date);
        super.onSelected();
    }

    private void onMonthClicked(MouseEvent e) {
        var month = (MonthLabel) e.getSource();
        setSelected(LocalDate.of(year, month.getMonthNo(), 1));
        month.setSelected(true);

        var children = popupGrid.getChildren();
        for (var c : children) {
            if (c instanceof MonthLabel label) {
                if (label == month)
                    continue;
                if (label.isSelected()) {
                    label.setSelected(false);
                }
            }
        }
        popup.hide();
    }

    public ObjectProperty<LocalDate> selectedDateProperty(){ return selectedDate; }
}
