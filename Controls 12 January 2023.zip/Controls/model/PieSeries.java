package model;

public class PieSeries {
    public int id;
    public String title;
    public double value;

    public PieSeries(int id, String title, double value) {
        this.id = id;
        this.title = title;
        this.value = value;
    }
    @Override
    public String toString() {
        return title + ": " + value;
    }
}
