package skinned;

import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.ListView;
import javafx.scene.control.Skin;
import javafx.scene.control.skin.VirtualFlow;
import skins.ExtendedResizableListViewSkin;

import static java.util.stream.IntStream.range;

public class ExtendedResizableListView <T> extends ListView<T> {
    private final ObservableList<T> list;
    private VirtualFlow<?> vFlow;
    private boolean isLoaded;

    public ExtendedResizableListView(ObservableList<T> list) {
        super(list);
        this.list = list;
        setBackground(null);
        setPadding(new Insets(0));
    }

    private double getCellHeight(VirtualFlow<?> flow, int startIndex, int stopIndex) {
        return range(startIndex, stopIndex).mapToDouble((i) -> flow.getCell(i).getBoundsInLocal().getHeight()).sum();
    }

    private void hookListener(){
        // https://gist.github.com/oddbjornkvalsund/f232c0f61fdc368d704f

        list.addListener((ListChangeListener.Change<? extends T> change) ->{
            double calcHeight = 0;
            while (change.next()) {
                if (change.wasAdded()) {
                    if (calcHeight == 0) {
                        calcHeight = getCellHeight(vFlow, 0, list.size());
                    } else {
                        final double cellHeight = getCellHeight(vFlow, change.getFrom(), change.getTo());
                        calcHeight += cellHeight;
                    }
                } else if (change.wasRemoved()) {
                    if (list.isEmpty()) {
                        calcHeight = 0;
                    } else {
                        calcHeight = getCellHeight(vFlow, 0, list.size());
                    }
                }
            }
            setPrefHeight(calcHeight);
            if(calcHeight < getMaxHeight()){
                ((ExtendedResizableVirtualFlow <?>)vFlow).vBar.setOpacity(0);
            }
            else{
                ((ExtendedResizableVirtualFlow <?>)vFlow).vBar.setOpacity(1);
            }
        });
    }

    @Override
    protected void layoutChildren() {
        if(!isLoaded){
            isLoaded = true;
            hookListener();
        }
        super.layoutChildren();
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        var skin = new ExtendedResizableListViewSkin<>(this);
        vFlow = skin.flow;
        return skin;
    }
}
