package skinned;

import javafx.geometry.Insets;
import javafx.scene.control.Skin;
import javafx.scene.control.TreeView;
import skins.ExtendedTreeViewSkin;

public class ExtendedTreeView<T> extends TreeView<T> {

    public ExtendedTreeView() {
        super();
        setBackground(null);
        setPadding(new Insets(0));
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedTreeViewSkin<>(this);
    }
}
