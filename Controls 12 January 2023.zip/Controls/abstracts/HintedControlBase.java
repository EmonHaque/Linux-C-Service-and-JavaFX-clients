package abstracts;

import controls.SVGIcon;
import helpers.Constants;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.beans.property.StringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;

public abstract class HintedControlBase extends GridPane {
    protected Text errorText;
    protected HBox hintBox;
    protected TranslateTransition moveHint;
    protected boolean isRequired;
    protected SVGIcon leftIcon;
    protected boolean isHintMoved;
    private boolean isLoaded;

    public HintedControlBase(String hint, String icon, boolean isRequired) {
        this.isRequired = isRequired;
        var hintLabel = new Text(hint) {{
            setFill(Color.GRAY);
            setMouseTransparent(true);
        }};
        hintBox = new HBox(hintLabel) {{
            setPadding(new Insets(0));
            setAlignment(Pos.CENTER_LEFT);
            setMouseTransparent(true);
        }};
        if (isRequired) {
            errorText = new Text("is required") {{
                setFill(Color.CORAL);
                setMouseTransparent(true);
            }};
            hintBox.setSpacing(5);
            hintBox.getChildren().add(errorText);
        }

        leftIcon = new SVGIcon(icon);
        leftIcon.setFill(Color.LIGHTBLUE);
        leftIcon.setMouseTransparent(true);

        addRow(0, leftIcon);
        add(hintBox, 1, 0);
        setAlignment(Pos.BOTTOM_LEFT);
        setMargin(hintBox, new Insets(0, 0, 0, 5));
        setBorder(Constants.BottomLine);
        setMinHeight(40);

        moveHint = new TranslateTransition(Duration.millis(100));
        moveHint.setInterpolator(Interpolator.EASE_IN);
        moveHint.setNode(hintBox);
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if (!isLoaded) {
            isLoaded = true;
            if (!isRequired) return;
            if (errorProperty().isBound()) return;

            textProperty().addListener((o, ov, nv) -> {
                if (nv.isEmpty() || nv.isBlank())
                    errorText.setText("is required");
                else errorText.setText("");
            });
        }
    }

    protected void moveHintUp() {
        if (moveHint.getStatus() == Animation.Status.RUNNING) {
            moveHint.stop();
        }
        var x = Constants.hintShiftX + hintBox.getTranslateX();
        var y = Constants.hintShiftY + hintBox.getTranslateY();
        moveHint.setByY(-y);
        moveHint.setByX(-x);
        moveHint.play();
        isHintMoved = true;
    }

    protected void moveHintDown() {
        if (moveHint.getStatus() == Animation.Status.RUNNING) {
            moveHint.stop();
        }
        moveHint.setByY(-hintBox.getTranslateY());
        moveHint.setByX(-hintBox.getTranslateX());
        moveHint.play();
        isHintMoved = false;
    }

    protected void setFocusColor() {
        leftIcon.setFill(Color.CORNFLOWERBLUE);
        setBorder(Constants.BottomLineHighlight);
    }

    protected void resetFocusColor() {
        leftIcon.setFill(Color.LIGHTBLUE);
        setBorder(Constants.BottomLine);
    }

    public StringProperty errorProperty() {return errorText.textProperty();}

    public abstract StringProperty textProperty();
}
