package helpers;

import java.text.DecimalFormat;

public class Helper {
    private static final DecimalFormat integerFormat = new DecimalFormat("#,##0;(#,##0)");
    private static final DecimalFormat doubleFormat = new DecimalFormat("#,##0.00;(#,##0.00)");
    public static String formatNumber(int number){
        if(number == 0) return "   -  ";
        return integerFormat.format(number);
    }
    public static String formatNumber(double number){
        if(number == 0) return "   -  ";
        return doubleFormat.format(number);
    }
}
