package controls.texts;

import controls.SVGIcon;
import interfaces.IExecute;
import javafx.geometry.Pos;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class ContextItem extends HBox {
    private final IExecute action;
    private final Text text;
    private final SVGIcon icon;

    public ContextItem(String icon, String text, IExecute action) {
        this.icon = new SVGIcon(icon);
        this.text = new Text(text){{ setFill(Color.WHITE);}};
        this.action = action;

        setSpacing(5);
        setAlignment(Pos.CENTER_LEFT);
        getChildren().addAll(this.icon, this.text);

        addEventHandler(MouseEvent.ANY, this::onMouse);
    }

    private void onMouse(MouseEvent e){
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED){
            text.setFill(Color.DODGERBLUE);
            icon.setFill(Color.DODGERBLUE);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED){
            text.setFill(Color.WHITE);
            icon.setFill(Color.WHITE);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_CLICKED){
            action.execute();
        }
    }
}
