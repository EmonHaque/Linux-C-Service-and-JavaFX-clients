package controls.texts;


import javafx.geometry.Insets;
import javafx.scene.control.TextFormatter;
import skinned.ExtendedTextField;

import java.text.DecimalFormat;
import java.text.ParsePosition;

public class DoubleBoxClean extends ExtendedTextField {
    private final DecimalFormat numberFormat;

    public DoubleBoxClean() {
        numberFormat = new DecimalFormat("#.0");
        setPadding(new Insets(0));
        setTextFormatter(new TextFormatter<>(change -> {
            if (change.getControlNewText().isEmpty()) {
                return change;
            }
            var position = new ParsePosition(0);
            var obj = numberFormat.parseObject(change.getControlNewText(), position);
            if (obj != null && position.getIndex() == change.getControlNewText().length()) {
                return change;
            }
            return null;
        }));
    }
}
