package ChartControls.PlotRentChart;

import Models.PlotwiseRent;
import abstracts.DualAxisChartBase;
import abstracts.ListCellBase;
import controls.PopupDraggable;
import controls.areachart.AreaStroke;
import controls.pinchart.PinStack;
import controls.texts.HiText;
import controls.texts.TextBox;
import helpers.Constants;
import helpers.Icons;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.Observable;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.util.Duration;
import model.PinColors;
import ridiculous.AppData;
import skinned.ExtendedListView;
import skinned.ExtendedResizableListView;

import java.util.ArrayList;
import java.util.List;

public class PinLineChart extends DualAxisChartBase<PlotwiseRent> {
    private boolean isLoaded;
    private final AreaStroke line;
    private final List<PinStack> pins;
    private final List<String> labels;
    private final List<Double> charges;
    private final PinColors cashColor, kindColor, mobileColor;

    private final Rectangle widthClip;
    private final Timeline lineAnim;
    private record PinLineData(String month, List<PlotwiseRent> payments, int[] summaries){}

    public PinLineChart(String y1Title, String y2Title) {
        super(y1Title, y2Title);
        cashColor = new PinColors(Color.CORNFLOWERBLUE, Color.BLUE);
        kindColor = new PinColors(Color.LIGHTGREEN, Color.CORAL);
        mobileColor = new PinColors(Color.LIGHTCORAL, Color.LIGHTGREEN);

        charges = new ArrayList<>();
        labels = new ArrayList<>();
        widthClip = new Rectangle(0, 0, 0, 0);
        pins = new ArrayList<>();
        line = new AreaStroke() {{
            getTransforms().add(new Scale(1, -1));
            setManaged(false);
            setClip(widthClip);
        }};
        getChildren().add(line);

        lineAnim = new Timeline();
        lineAnim.setDelay(Duration.millis(500));
        lineAnim.setOnFinished(e -> line.setClip(null));
    }

    @Override
    protected void setMinMaxAndXLabels() {
        int index = 0;
        for (var pin : pins) {
            var y1Total = pin.getValues().stream().mapToDouble(x -> x).sum();
            var y2value = charges.get(index);

            if (y1Max < y1Total) y1Max = y1Total;
            if (y2Max < y2value) y2Max = y2value;

            var xLabel = new Text(labels.get(index)) {{
                setFill(Color.WHITE);
                setRotate(-90);
                setManaged(false);
            }};
            xLabels.getChildren().add(xLabel);

            if (xLabelWidth < xLabel.prefWidth(-1))
                xLabelWidth = xLabel.prefWidth(-1);

            index++;
        }

        double y1Step = y1Max / (numLines - 1);
        double y2Step = y2Max / (numLines - 1);
        double y1Current = y1Min;
        double y2Current = y2Min;
        for (int i = 0; i < numLines; i++) {
            var y1 = (Text) y1Labels.getChildren().get(i);
            var y2 = (Text) y2Labels.getChildren().get(i);
            y1.setText(String.format("%,d", (int) y1Current));
            y2.setText(String.format("%,d", (int) y2Current));

            y1LabelWidth = y1.prefWidth(-1);
            y2LabelWidth = y2.prefWidth(-1);

            y1Current += y1Step;
            y2Current += y2Step;
        }
    }

    @Override
    protected void reset() {
        for (var pin : pins) {
            getChildren().remove(pin);
        }
        pins.clear();
        line.clear();
        charges.clear();
        labels.clear();

        var months = series.stream().map(PlotwiseRent::getMonth).distinct().toList();
        for (var month : months) {
            var tenants = series.stream().filter(x -> x.getMonth().equals(month)).toList();
            double rent = 0, cash = 0, kind = 0, mobile = 0, total = 0;
            for (var tenant : tenants) {
                rent += tenant.getRent();
                cash += tenant.getCash();
                kind += tenant.getKind();
                mobile += tenant.getMobile();
                total += tenant.getTotal();
            }
            charges.add(rent);
            labels.add(month);

            var doubles = new ArrayList<Double>();
            var colors = new ArrayList<PinColors>();
            if (cash > 0) {
                doubles.add(cash);
                colors.add(cashColor);
            }
            if(kind > 0){
                doubles.add(kind);
                colors.add(kindColor);
            }
            if(mobile > 0){
                doubles.add(mobile);
                colors.add(mobileColor);
            }

            var pin = new PinStack(doubles, colors) {{setManaged(false);}};
            var data = new PinLineData(month, tenants, new int[]{ (int)rent, (int)cash, (int)kind, (int)mobile, (int)total});
            pin.setToolTip(new Tip(data));

            pins.add(pin);
            getChildren().add(pin);
        }

        line.setData(charges);
        line.toFront();
        if (isLoaded) {
            resetLineAnim();
            lineAnim.play();
        }
    }

    private void resetLineAnim() {
        widthClip.setWidth(0);
        widthClip.setHeight(availableHeight);
        line.setClip(widthClip);

        lineAnim.getKeyFrames().clear();
        var widthKey = new KeyValue(widthClip.widthProperty(), availableWidth, Interpolator.EASE_IN);
        var widthFrame = new KeyFrame(Duration.millis(1000), widthKey);
        lineAnim.getKeyFrames().add(widthFrame);
    }

    @Override
    protected void layoutChildren() {
        if (series == null) return;
        super.layoutChildren();

        var colWidth = availableWidth / pins.size();
        double pinX = startX;
        double xLabelX = pinX + colWidth / 2;

        for (int i = 0; i < pins.size(); i++) {
            var text = (Text) xLabels.getChildren().get(i);
            var pin = pins.get(i);

            text.setY(availableHeight + text.prefWidth(-1) / 2 + text.prefHeight(-1) / 2);
            text.setX(xLabelX - text.prefWidth(-1) / 2);
            xLabelX += colWidth;

            pin.makePin(colWidth, availableHeight, y1Max);
            pin.resizeRelocate(pinX, availableHeight, colWidth, availableHeight);
            pinX += colWidth;
        }
        if (!isLoaded) {
            isLoaded = true;
            resetLineAnim();
            lineAnim.play();
        }
        line.setTranslateX(startX + colWidth / 2);
        line.setTranslateY(availableHeight);
        line.setValue(availableWidth - colWidth, availableHeight, y2Max);
    }

    private class Tip extends PopupDraggable{
        private final double nameWidth = 180;
        private final double amountWidth = 70;

        public Tip(PinLineData data) {
            var bold = Font.font(null, FontWeight.BOLD, -1);

            var heading = new Text("Detail of " + data.month()){{
                setFill(Color.LIGHTGRAY);
                setFont(Font.font(null, FontWeight.BOLD, 14));
            }};

            var header = new GridPane(){{
                getColumnConstraints().addAll(
                        new ColumnConstraints(nameWidth),
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}}
                );
                add(new Text("Tenant"){{ setFill(Color.WHITE); setFont(bold);}}, 0, 0);
                add(new Text("Charge"){{ setFill(Color.WHITE); setFont(bold);}}, 1, 0);
                add(new Text("Cash"){{ setFill(Color.WHITE); setFont(bold);}}, 2, 0);
                add(new Text("Kind"){{ setFill(Color.WHITE); setFont(bold);}}, 3, 0);
                add(new Text("Mobile"){{ setFill(Color.WHITE); setFont(bold);}}, 4, 0);
                add(new Text("Total"){{ setFill(Color.WHITE); setFont(bold);}}, 5, 0);

                setPadding(new Insets(2.5, Constants.ScrollBarSize, 2.5, 0));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25, 0, 0.25, 0))));
            }};

            var footer = new GridPane(){{
                getColumnConstraints().addAll(
                        new ColumnConstraints(nameWidth),
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}}
                );
                add(new Text("Total of " + data.payments().size()){{ setFill(Color.WHITE); setFont(bold);}}, 0, 0);
                add(new Text(AppData.formatNumber(data.summaries()[0])){{ setFill(Color.WHITE); setFont(bold);}}, 1, 0);
                add(new Text(AppData.formatNumber(data.summaries()[1])){{ setFill(Color.WHITE); setFont(bold);}}, 2, 0);
                add(new Text(AppData.formatNumber(data.summaries()[2])){{ setFill(Color.WHITE); setFont(bold);}}, 3, 0);
                add(new Text(AppData.formatNumber(data.summaries()[3])){{ setFill(Color.WHITE); setFont(bold);}}, 4, 0);
                add(new Text(AppData.formatNumber(data.summaries()[4])){{ setFill(Color.WHITE); setFont(bold);}}, 5, 0);

                setPadding(new Insets(2.5, Constants.ScrollBarSize, 2.5, 0));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25, 0, 0, 0))));
            }};

            var query = new TextBox("Search", Icons.Magnify, false);

            var newList = new ArrayList<PlotwiseRent>();
            for(int i = 0; i < 10; i++){
                newList.addAll(data.payments());
            }
            var source = FXCollections.observableList(newList, o -> new Observable[]{ query.textProperty()});
            var filteredList = new FilteredList<>(source, x -> {
                var q = query.getText();
                return q == null || q.isEmpty() || q.isBlank() || x.getTenantName().toLowerCase().contains(query.getText().toLowerCase());
            });
            var listView = new ExtendedResizableListView<>(filteredList){{
                setMaxHeight(400);
            }};
            listView.setCellFactory(v -> new Cell(query.textProperty()));

            var box = new BorderPane(){{
                setPadding(new Insets(5));
                setBackground(Background.fill(Constants.BackgroundColor));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
                setTop(new VBox(heading, query, header){{
                    setMargin(heading, new Insets(0,0,5,0));
                }});
                setCenter(listView);
                setBottom(footer);
            }};

//            var box = new VBox(heading, query, header, listView, footer){{
//                setPadding(new Insets(5));
//                setMargin(heading, new Insets(0,0,5,0));
//                setBackground(Background.fill(Constants.BackgroundColor));
//                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
//                setVgrow(listView, Priority.ALWAYS);
//            }};

            getContent().add(box);
        }

        private class Cell extends ListCellBase<PlotwiseRent> {
            private GridPane root;
            private HiText name;
            private Text rent, cash, kind, mobile, total;
            private final StringProperty query;

            public Cell(StringProperty query) {
                super();
                this.query = query;
            }

            @Override
            protected void initializeUI() {
                name = new HiText();
                rent = new Text(){{setFill(Color.WHITE);}};
                cash = new Text(){{setFill(Color.WHITE);}};
                kind = new Text(){{setFill(Color.WHITE);}};
                mobile = new Text(){{setFill(Color.WHITE);}};
                total = new Text(){{setFill(Color.WHITE);}};

                root = new GridPane(){{
                    getColumnConstraints().addAll(
                            new ColumnConstraints(nameWidth),
                            new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                            new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                            new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                            new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                            new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}}
                    );
                    add(name, 0, 0);
                    add(rent, 1, 0);
                    add(cash, 2, 0);
                    add(kind, 3, 0);
                    add(mobile, 4, 0);
                    add(total, 5, 0);
                }};
            }

            @Override
            protected void onItemChanged(ObservableValue<?> o, PlotwiseRent ov, PlotwiseRent nv) {
                if(ov != null){
                    name.queryProperty().unbind();
                    name.queryProperty().set("");
                }
                if(nv != null){
                    name.setText(nv.getTenantName());
                    rent.setText(AppData.formatNumber(nv.getRent()));
                    cash.setText(AppData.formatNumber(nv.getCash()));
                    kind.setText(AppData.formatNumber(nv.getKind()));
                    mobile.setText(AppData.formatNumber(nv.getMobile()));
                    total.setText(AppData.formatNumber(nv.getTotal()));
                    name.queryProperty().bind(query);
                }
            }

            @Override
            protected Node getRootNode() {
                return root;
            }
        }
    }
}
