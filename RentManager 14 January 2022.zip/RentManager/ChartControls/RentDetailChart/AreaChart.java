package ChartControls.RentDetailChart;

import Models.TenantAreaSeries;
import abstracts.XYChartBase;
import controls.areachart.AreaFill;
import controls.areachart.AreaStroke;
import helpers.Constants;
import javafx.animation.*;
import javafx.geometry.BoundingBox;
import javafx.geometry.Bounds;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.stage.Popup;
import javafx.util.Duration;

import java.util.ArrayList;

public class AreaChart extends XYChartBase<TenantAreaSeries> {
    private boolean isLoaded;
    private final AreaStroke stroke;
    private final AreaFill fill;
    private final Group circles;
    private final double minRadius = 3, maxRadius = 5;
    private final Timeline strokeAnim, fillAnim;
    private final FadeTransition circleAnim;
    private final Rectangle widthClip, heightClip;
    private final Line cursor;
    private Bounds chartBound;

    private Popup popup;
    private Text popTitle, popRent, popFrom;

    public AreaChart() {
        cursor = new Line();
        cursor.setStroke(Color.WHITE);
        cursor.getStrokeDashArray().addAll(5d, 2d);
        cursor.setManaged(false);
        cursor.setMouseTransparent(true);

        circles = new Group() {{setManaged(false);}};
        stroke = new AreaStroke() {{
            setManaged(false);
            setMouseTransparent(true);
            getTransforms().add(new Scale(1, -1));
        }};
        fill = new AreaFill() {{
            setManaged(false);
            setMouseTransparent(true);
            getTransforms().add(new Scale(1, -1));
        }};
        getChildren().addAll(fill, stroke, circles);

        widthClip = new Rectangle(0, 0, 0, 0);
        heightClip = new Rectangle(0, 0, 0, 0);
        stroke.setClip(widthClip);
        fill.setClip(heightClip);

        strokeAnim = new Timeline();
        fillAnim = new Timeline();
        circleAnim = new FadeTransition(Duration.millis(1000), circles);
        circleAnim.setDelay(Duration.seconds(1));
        circleAnim.setToValue(1);

        strokeAnim.setOnFinished(e -> stroke.setClip(null));
        fillAnim.setOnFinished(e -> fill.setClip(null));

        setOnMouseMoved(this::onMouseMove);
        getChildren().add(cursor);

        initializePopup();
    }

    private void initializePopup() {
        popTitle = new Text() {{setFill(Color.WHITE); setFont(Font.font(null, FontWeight.BOLD, -1));}};
        var popTotal = new Text("Amount") {{setFill(Color.WHITE);}};
        popRent = new Text() {{setFill(Color.WHITE);}};
        popFrom = new Text() {{setFill(Color.WHITE); setFont(Font.font(null, FontPosture.ITALIC, -1));}};

        GridPane popGrid = new GridPane() {{
            getRowConstraints().addAll(
                    new RowConstraints(),
                    new RowConstraints() {{setVgrow(Priority.ALWAYS);}},
                    new RowConstraints()
            );
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(50);}},
                    new ColumnConstraints() {{setPercentWidth(50);}}
            );
            add(popTitle, 0, 0, 2, 1);
            add(popTotal, 0, 1);
            add(popRent, 1, 1);
            add(popFrom, 0, 2, 2, 1);

            setHalignment(popRent, HPos.RIGHT);
            setHalignment(popFrom, HPos.RIGHT);

            setVgap(10);
            setPadding(new Insets(5));
            setBackground(Background.fill(Constants.BackgroundColor));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
        }};

        popup = new Popup();
        popup.getContent().add(popGrid);
    }

    private void resetPopup(TenantAreaSeries value) {
        popTitle.setText(value.getTenant());
        popRent.setText(String.format("%,d", (int) value.getAmount()));
        popFrom.setText("from " + value.getFrom());
    }

    @Override
    protected void setMinMaxAndXLabels() {
        double step = (max - min) / (numLines - 1);
        double current = min;
        for (var t : yLabels.getChildren()) {
            var label = (Text) t;
            label.setText(String.format("%,d", (int) current));
            current += step;
            yLabelWidth = label.prefWidth(-1);
        }
    }

    @Override
    protected void reset() {
        circles.getChildren().clear();
        stroke.clear();
        fill.clear();
        circles.setOpacity(0);

        var doubles = new ArrayList<Double>();
        for (var value : series) {
            var v = value.getAmount();
            doubles.add(v);

            if (v < min) min = v;
            if (v > max) max = v;

            var xLabel = new Text(value.getSpace()) {{
                setFill(Color.WHITE);
                setRotate(-90);
                setManaged(false);
            }};
            xLabels.getChildren().add(xLabel);

            if (xLabelWidth < xLabel.prefWidth(-1))
                xLabelWidth = xLabel.prefWidth(-1);

            var circle = new Circle() {{
                setRadius(minRadius);
                setFill(Color.CORAL);
                setManaged(false);
                setUserData(value);
            }};
            circles.getChildren().add(circle);
        }
        stroke.setData(doubles);
        fill.setData(doubles);

        if(!isLoaded) return;

        if(circleAnim.getStatus() == Animation.Status.RUNNING) circleAnim.stop();
        if(fillAnim.getStatus() == Animation.Status.RUNNING) fillAnim.stop();
        if(strokeAnim.getStatus() == Animation.Status.RUNNING) strokeAnim.stop();

        resetAnim();
        requestLayout();
        circleAnim.play();
        fillAnim.play();
        strokeAnim.play();
    }

    private void onMouseMove(MouseEvent e) {
        if (series == null) return;
        double cursorX = e.getX();

        if (!chartBound.contains(localToParent(cursorX, e.getY()))) {
            cursor.setVisible(false);
            resetRadius();
            if (popup.isShowing()) popup.hide();
            return;
        }

        if (!cursor.isVisible()) cursor.setVisible(true);

        cursor.setStartX(cursorX);
        cursor.setEndX(cursorX);
        cursor.setStartY(0);
        cursor.setEndY(availableHeight);

        for (var c : circles.getChildren()) {
            var circle = (Circle) c;
            var bounds = c.getBoundsInLocal();
            if (cursorX >= bounds.getMinX() && cursorX <= bounds.getMaxX()) {
                circle.setFill(Color.WHITE);
                circle.setRadius(maxRadius);
                cursor.setStroke(Color.CORAL);

                var point = localToScreen(circle.getCenterX() + 10, circle.getCenterY());
                resetPopup((TenantAreaSeries) circle.getUserData());
                popup.show(this, point.getX(), point.getY());
            }
            else {
                if (circle.getRadius() == maxRadius) {
                    circle.setFill(Color.CORAL);
                    circle.setRadius(minRadius);
                    cursor.setStroke(Color.WHITE);
                    popup.hide();
                }
            }
        }
    }

    private void resetRadius() {
        for (var c : circles.getChildren()) {
            var circle = (Circle) c;
            if (circle.getRadius() == maxRadius) {
                circle.setFill(Color.CORAL);
                circle.setRadius(minRadius);
                cursor.setStroke(Color.WHITE);
                break;
            }
        }
    }

    private void resetAnim() {
        var width = startX + availableWidth;
        var height = availableHeight + xLabelWidth;
        widthClip.setWidth(0);
        widthClip.setHeight(height);
        heightClip.setHeight(0);
        heightClip.setWidth(width);
        stroke.setClip(widthClip);
        fill.setClip(heightClip);

        strokeAnim.getKeyFrames().clear();
        fillAnim.getKeyFrames().clear();
        var widthKey = new KeyValue(widthClip.widthProperty(), width, Interpolator.EASE_IN);
        var heightKey = new KeyValue(heightClip.heightProperty(), height, Interpolator.EASE_IN);
        KeyFrame widthFrame = new KeyFrame(Duration.millis(1000), widthKey);
        KeyFrame heightFrame = new KeyFrame(Duration.millis(1000), heightKey);
        strokeAnim.getKeyFrames().add(widthFrame);
        fillAnim.getKeyFrames().add(heightFrame);
    }

    @Override
    protected void layoutChildren() {
        if (series == null) return;
        super.layoutChildren();

        if (!isLoaded) {
            isLoaded = true;
            resetAnim();
            circleAnim.play();
            fillAnim.play();
            strokeAnim.play();
        }

        double positiveHeight, negativeHeight;
        if (min < 0) {
            var absMin = Math.abs(min);
            var spread = max - min;
            negativeHeight = availableHeight / spread * absMin;
            positiveHeight = availableHeight - negativeHeight;
        }
        else {
            positiveHeight = availableHeight;
        }
        fill.setTranslateY(positiveHeight);
        stroke.setTranslateY(positiveHeight);
        fill.setTranslateX(startX);
        stroke.setTranslateX(startX);

        double size = series.size();

        fill.setValue(availableWidth, availableHeight, min, max); // same computation thrice
        stroke.setValue(availableWidth, availableHeight, min, max); // same computation thrice

        double xGap = availableWidth / (size - 1);
        double yFactor = availableHeight / (max - min);
        double x = startX, y;

        for (int i = 0; i < size; i++) {
            // same computation thrice
            y = positiveHeight - series.get(i).getAmount() * yFactor;
            var circle = (Circle) circles.getChildren().get(i);

            circle.setCenterX(x);
            circle.setCenterY(y);

            var xLabel = (Text) xLabels.getChildren().get(i);
            xLabel.setX(x - xLabel.prefWidth(-1) / 2);
            xLabel.setY(availableHeight + xLabel.prefWidth(-1) / 2 + xLabel.prefHeight(-1) / 2);
            x += xGap;
        }

        chartBound = localToParent(new BoundingBox(startX, 0, availableWidth, availableHeight));
    }
}
