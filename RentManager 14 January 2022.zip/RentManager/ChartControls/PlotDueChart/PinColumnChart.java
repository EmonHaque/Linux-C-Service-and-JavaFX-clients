package ChartControls.PlotDueChart;

import Models.PlotwiseDue;
import abstracts.DualAxisChartBase;
import abstracts.ListCellBase;
import controls.PopupDraggable;
import controls.pinchart.PinColumn;
import helpers.Constants;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import ridiculous.AppData;
import skinned.ExtendedResizableListView;

import java.util.ArrayList;
import java.util.List;

public class PinColumnChart extends DualAxisChartBase<PlotwiseDue> {
    private final List<PinColumn> pins;
    private final List<String> labels;

    private record PinColumnData(String month, List<PlotwiseDue> list, int total){}

    public PinColumnChart(String y1Title, String y2Title) {
        super(y1Title, y2Title);
        pins = new ArrayList<>();
        labels = new ArrayList<>();
    }

    @Override
    protected void setMinMaxAndXLabels() {
        int index = 0;
        for (var pin : pins) {
            var columnValue = pin.getColumnValue();
            var pinValue = pin.getPinValue();

            if (y1Max < columnValue) y1Max = columnValue;
            if (y2Max < pinValue) y2Max = pinValue;
            if (y1Min > columnValue) y1Min = columnValue;
            if (y2Min > pinValue) y2Min = pinValue;

            var xLabel = new Text(labels.get(index++)) {{
                setFill(Color.WHITE);
                setRotate(-90);
                setManaged(false);
                setMouseTransparent(true);
            }};
            xLabels.getChildren().add(xLabel);

            if (xLabelWidth < xLabel.prefWidth(-1))
                xLabelWidth = xLabel.prefWidth(-1);
        }

        double y1Step = y1Max / (numLines - 1);
        double y2Step = (y2Max - y2Min) / (numLines - 1);
        double y1Current = y1Min;
        double y2Current = y2Min;
        for (int i = 0; i < numLines; i++) {
            var y1 = (Text) y1Labels.getChildren().get(i);
            var y2 = (Text) y2Labels.getChildren().get(i);
            y1.setText(String.format("%,d", (int) y1Current));
            y2.setText(String.format("%,d", (int) y2Current));

            y1LabelWidth = y1.prefWidth(-1);
            y2LabelWidth = y2.prefWidth(-1);

            y1Current += y1Step;
            y2Current += y2Step;
        }
    }

    @Override
    protected void reset() {
        for (var n : pins) {
            getChildren().remove(n);
        }
        pins.clear();
        labels.clear();
        var months = series.stream().map(PlotwiseDue::getMonth).distinct().toList();
        for(var month : months){
            var tenants = series.stream().filter( x -> x.getMonth().equals(month)).toList();
            var due = tenants.stream().mapToDouble(PlotwiseDue::getDue).sum();
            var count = tenants.size();

            labels.add(month);
            var pin = new PinColumn(count, due){{ setManaged(false); }};
            var data = new PinColumnData(month, tenants, (int)due);
            pin.setToolTip(new Tip(data));

            getChildren().add(pin);
            pins.add(pin);
        }
    }

    @Override
    protected void layoutChildren() {
        if (series == null) return;
        super.layoutChildren();

        double pinX = startX;
        double gap = 5;
        var colWidth = (availableWidth - gap * pins.size()) / pins.size();
        double xLabelX = pinX + colWidth / 2;

        double x = pinX;
        for (int i = 0; i < pins.size(); i++) {
            var text = (Text) xLabels.getChildren().get(i);
            text.setY(availableHeight + text.prefWidth(-1) / 2 + text.prefHeight(-1) / 2);
            text.setX(xLabelX - text.prefWidth(-1) / 2);

            var pin = pins.get(i);
            pin.makePin(colWidth, availableHeight, y1Min, y2Min, y1Max, y2Max);
            pin.resizeRelocate(x, availableHeight, colWidth, availableHeight);

            xLabelX += colWidth + gap;
            x += colWidth + gap;
        }
    }

    private class Tip extends PopupDraggable{
        public Tip(PinColumnData data) {
            var bold = Font.font(null, FontWeight.BOLD, -1);

            var heading = new Text("Detail of " + data.month()){{
                setFill(Color.LIGHTGRAY);
                setFont(Font.font(null, FontWeight.BOLD, 14));
            }};

            var header = new GridPane(){{
                getColumnConstraints().addAll(
                        new ColumnConstraints(200),
                        new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}}
                );
                add(new Text("Tenant"){{ setFill(Color.WHITE); setFont(bold);}}, 0, 0);
                add(new Text("Due"){{ setFill(Color.WHITE); setFont(bold);}}, 1, 0);

                setPadding(new Insets(2.5, Constants.ScrollBarSize, 2.5, 0));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25, 0, 0.25, 0))));
            }};

            var footer = new GridPane(){{
                getColumnConstraints().addAll(
                        new ColumnConstraints(200),
                        new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}}
                );
                add(new Text("Total"){{ setFill(Color.WHITE); setFont(bold);}}, 0, 0);
                add(new Text(AppData.formatNumber(data.total())){{ setFill(Color.WHITE); setFont(bold);}}, 1, 0);

                setPadding(new Insets(2.5, Constants.ScrollBarSize, 2.5, 0));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25, 0, 0, 0))));
            }};

            var listView = new ExtendedResizableListView<>(FXCollections.observableArrayList(data.list)){{ setMaxHeight(400);}};
            listView.setCellFactory(v -> new Cell());

            var box = new VBox(heading, header, listView, footer){{
                setPadding(new Insets(5));
                setMargin(heading, new Insets(0,0,5,0));
                setBackground(Background.fill(Constants.BackgroundColor));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
                setVgrow(listView, Priority.SOMETIMES);
            }};
            getContent().add(box);
        }

        private class Cell extends ListCellBase<PlotwiseDue>{
            private GridPane root;
            private Text name, total;
            @Override
            protected void initializeUI() {
                name = new Text(){{
                    setFill(Color.WHITE);
                    setWrappingWidth(200);
                }};
                total = new Text(){{setFill(Color.WHITE);}};

                root = new GridPane(){{
                    getColumnConstraints().addAll(
                            new ColumnConstraints(200),
                            new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}}
                    );
                    add(name, 0, 0);
                    add(total, 1, 0);
                }};
            }

            @Override
            protected void onItemChanged(ObservableValue<?> o, PlotwiseDue ov, PlotwiseDue nv) {
                if(nv != null){
                    name.setText(nv.getTenant());
                    total.setText(AppData.formatNumber(nv.getDue()));
                }
            }

            @Override
            protected Node getRootNode() {
                return root;
            }
        }
    }
}
