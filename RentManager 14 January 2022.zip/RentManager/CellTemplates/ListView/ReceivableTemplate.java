package CellTemplates.ListView;

import Models.Receivable;
import controls.buttons.ActionButtonArg;
import helpers.Icons;
import interfaces.IExecuteArg;
import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import ridiculous.AppData;

public class ReceivableTemplate extends ListCell<Receivable> {
    private final IExecuteArg<Receivable> executor;
    private GridPane root;
    private Text head, amount;
    private ActionButtonArg<Receivable> button;

    public ReceivableTemplate(IExecuteArg<Receivable> executor) {
        this.executor = executor;
        setBackground(null);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        setPadding(new Insets(2.5, 0, 2.5, 0));
        setPrefWidth(0);
        initializeUI();
        itemProperty().addListener(this::onItemChanged);
    }

    public ReceivableTemplate(IExecuteArg<Receivable> executor, BooleanProperty isOnEdit) {
        this(executor);
        button.setVisible(false);
        GridPane.setColumnSpan(amount, 2);
        isOnEdit.addListener(o -> {
            if (isOnEdit.get()) {
                GridPane.setColumnSpan(amount, 1);
                button.setVisible(true);
            }
            else {
                button.setVisible(false);
                GridPane.setColumnSpan(amount, 2);
            }
        });
    }

    private void initializeUI() {
        head = new Text() {{setFill(Color.WHITE);}};
        amount = new Text() {{setFill(Color.WHITE);}};
        button = new ActionButtonArg<>(Icons.MinusCircle, 16, "remove");
        root = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.SOMETIMES);}},
                    new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(20) {{setHalignment(HPos.RIGHT);}}
            );
            add(head, 0, 0);
            add(amount, 1, 0);
            add(button, 2, 0);
        }};
    }

    private void onItemChanged(ObservableValue<?> o, Receivable ov, Receivable nv) {
        if (nv == null) return;

        head.setText(AppData.heads.stream().filter(x -> x.getId() == nv.getHeadId()).findFirst().get().getName());
        amount.setText(String.format("%,d", nv.getAmount()));
        button.setAction(executor, nv);
    }

    @Override
    protected void updateItem(Receivable item, boolean empty) {
        super.updateItem(item, empty);
        setGraphic(isEmpty() ? null : root);
    }
}
