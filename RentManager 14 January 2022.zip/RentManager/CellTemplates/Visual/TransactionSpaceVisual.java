package CellTemplates.Visual;

import Models.SpaceTransaction;
import helpers.Constants;
import interfaces.ISetSelectionBoxContent;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import ridiculous.AppData;
import skinned.ExtendedSeparator;

public class TransactionSpaceVisual extends BorderPane implements ISetSelectionBoxContent<SpaceTransaction> {
    private final Text name, date;
    private SpaceTransaction item;
    private final Popup popup;
    private final GridPane popGrid;

    public TransactionSpaceVisual() {
        name = new Text();
        date = new Text();
        setCenter(name);
        setRight(date);
        setAlignment(name, Pos.CENTER_LEFT);
        setAlignment(date, Pos.CENTER_RIGHT);

        setOnMouseEntered(this::onMouseEnter);
        setOnMouseExited(this::onMouseExit);

        popGrid = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setMinWidth(100); setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Head"){{setFill(Color.WHITE);}}, 0, 0);
            add(new Text("Amount"){{setFill(Color.WHITE);}}, 1, 0);
            add(new ExtendedSeparator(), 0, 1, 2, 1);

            setPadding(new Insets(5));
            setBackground(Background.fill(Constants.BackgroundColor));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
        }};
        popup = new Popup(){{ getContent().add(popGrid); }};
    }

    private void onMouseEnter(MouseEvent e){
        popup.show(this, e.getScreenX() + 15, e.getScreenY());
    }

    private void onMouseExit(MouseEvent e){
        popup.hide();
    }

    @Override
    public void setContent(SpaceTransaction item) {
        name.textProperty().unbind();
        date.textProperty().unbind();

        this.item = item;
        if(item.getIsExpired()){
            name.setFill(Color.GRAY);
            date.setFill(Color.GRAY);
        }
        else{
            name.setFill(Color.WHITE);
            date.setFill(Color.WHITE);
        }
        name.textProperty().bind(item.nameProperty());
        date.textProperty().bind(item.startDateProperty());

        setToolTip();
    }

    private void setToolTip(){
        var receivables = AppData.leases.stream().filter(x -> x.getId() == item.getLeaseId()).findFirst().get().getFixedReceivables();
        int row = 2;
        int total = 0;
        if(popGrid.getRowCount() > row){
            popGrid.getChildren().remove(3, popGrid.getChildren().size());
        }
        for(var receivable : receivables){
            var head = new Text(AppData.heads.stream().filter(x -> x.getId() == receivable.getHeadId()).findFirst().get().getName()){{setFill(Color.WHITE);}};
            var amount = new Text(String.format("%,d", receivable.getAmount())){{ setFill(Color.WHITE);}};
            popGrid.add(head, 0, row);
            popGrid.add(amount, 1, row);
            total += receivable.getAmount();
            row++;
        }
        if(row == 3) return;
        popGrid.add(new ExtendedSeparator(), 0, row, 2, 1);
        popGrid.add(new Text("Total"){{ setFill(Color.WHITE);}}, 0, row + 1);
        popGrid.add(new Text(String.format("%,d", total)){{ setFill(Color.WHITE);}}, 1, row + 1);
    }

    @Override
    public SpaceTransaction getContent() {
        return item;
    }

    @Override
    public Node getVisual() {
        return this;
    }
}
