package trees;

import Models.MonthlyBalance;
import controls.SVGRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

public class MonthlyBalanceTree extends ExtendedTreeView<MonthlyBalance> {
    private final TreeItem<MonthlyBalance> plots;
    public ListProperty<MonthlyBalance> itemsProperty;
    public BooleanProperty isExpandedProperty;

    public MonthlyBalanceTree() {
        itemsProperty = new SimpleListProperty<>();
        isExpandedProperty = new SimpleBooleanProperty();
        itemsProperty.addListener(this::onItemsChanged);
        isExpandedProperty.addListener(this::onIsExpandedChanged);
        plots = new TreeItem<>();
        setRoot(plots);
        setShowRoot(false);
        setCellFactory(v -> new BalanceCell());
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    }

    private void onIsExpandedChanged(ObservableValue<?> o, boolean ov, boolean nv) {
        if (nv) {
            for (var plot : plots.getChildren()) {
                if (!plot.isExpanded()) plot.setExpanded(true);
            }
        }
        else {
            for (var plot : plots.getChildren()) {
                if (plot.isExpanded()) plot.setExpanded(false);
            }
        }
    }

    private void onItemsChanged(ObservableValue<?> o, ObservableList<MonthlyBalance> ov, ObservableList<MonthlyBalance> nv) {
        plots.getChildren().clear();
        if (nv == null) return;

        for (var balance : nv) {
            var hasIt = false;
            TreeItem<MonthlyBalance> item = null;
            for (var tree : plots.getChildren()) {
                if (tree.getValue().getPlot().equals(balance.getPlot())) {
                    item = tree;
                    var value = item.getValue();
                    value.setPayment(balance.getPayment() + value.getPayment());
                    value.setShortOrLong(balance.getShortOrLong() + value.getShortOrLong());
                    value.setDue(balance.getDue() + value.getDue());
                    value.setLastMonthDue(balance.getLastMonthDue() + value.getLastMonthDue());
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                var newItem = new MonthlyBalance() {{
                    setPlot(balance.getPlot());
                    setPayment(balance.getPayment());
                    setShortOrLong(balance.getShortOrLong());
                    setDue(balance.getDue());
                    setLastMonthDue(balance.getLastMonthDue());
                }};
                item = new TreeItem<>(newItem);
                item.setExpanded(isExpandedProperty.get());
                plots.getChildren().add(item);
            }
            var leaf = new TreeItem<>(balance);
            item.getChildren().add(leaf);
        }
    }

    private class BalanceCell extends TreeCell<MonthlyBalance> {
        private SVGRegion disclosureIcon;
        private GridPane root;
        private Text date, due, lastDue, payment, shortOrLong;
        private Font normal, bold;
        private Border topBorder;

        private Text particulars;
        private TextFlow particularsFlow;

        public BalanceCell() {
            setText(null);
            setBackground(null);
            setPrefWidth(0);
            setPadding(new Insets(2.5, 0, 2.5, 0));
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            initializeUI();
            itemProperty().addListener(this::onItemChanged);
            //hoverProperty().addListener(this::onHover);
        }

        private void initializeUI() {
            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0), new Insets(0, 0, 0, -15)));

            particulars = new Text() {{setFill(Color.WHITE);}};
            date = new Text() {{setFill(Color.WHITE); }};
            due = new Text() {{setFill(Color.WHITE);}};
            lastDue = new Text() {{setFill(Color.WHITE);}};
            payment = new Text() {{setFill(Color.WHITE);}};
            shortOrLong = new Text() {{setFill(Color.WHITE);}};

            //TextWrapping doesn't work properly
            particularsFlow = new TextFlow(particulars);

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(){{ setHgrow(Priority.SOMETIMES);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}}
                );
                add(particularsFlow, 0, 0);
                add(date, 1, 0);
                add(due, 2, 0);
                add(lastDue, 3, 0);
                add(payment, 4, 0);
                add(shortOrLong, 5, 0);
            }};
//            root.widthProperty().addListener(o ->{
//                var width = root.getWidth() - 5 * 80;
//                particulars.setWrappingWidth(width);
//                particularsFlow.setMaxWidth(width);
//            });
        }

        private void onHover(ObservableValue<?> o, boolean ov, boolean nv){
            if (nv && !isEmpty()) {
                if(!isSelected())
                    setBackground(Background.fill(Constants.BackgroundColorLight));
            } else {
                if(!isSelected())
                    setBackground(null);
            }
        }

        private void onItemChanged(ObservableValue<?> o, MonthlyBalance ov, MonthlyBalance nv) {
            if (ov != null) {
                particulars.setText(null);
                date.setText(null);
                due.setText(null);
                lastDue.setText(null);
                payment.setText(null);
                shortOrLong.setText(null);

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                root.setBorder(null);
                if (level == 1) {
                    particulars.setText(nv.getPlot() + " (" + item.getChildren().size() + ")");
                    particulars.setFont(bold);
                    due.setFont(bold);
                    lastDue.setFont(bold);
                    payment.setFont(bold);
                    shortOrLong.setFont(bold);
                }
                else if (level == 2) {
                    var ch = item.getParent().getChildren();
                    var index = ch.indexOf(item);
                    if (index == 0) {
                        root.setBorder(topBorder);
                    }
                    else if (index == ch.size() - 1) {
                        root.setBorder(Constants.BottomLine);
                    }
                    particulars.setText(nv.getTenant());
                    particulars.setFont(normal);
                    due.setFont(normal);
                    lastDue.setFont(normal);
                    payment.setFont(normal);
                    shortOrLong.setFont(normal);
                    date.setText(nv.getDate());
                }
                due.setText(AppData.formatNumber(nv.getDue()));
                lastDue.setText(AppData.formatNumber(nv.getLastMonthDue()));
                payment.setText(AppData.formatNumber(nv.getPayment()));
                shortOrLong.setText(AppData.formatNumber(nv.getShortOrLong()));
            }
        }

        @Override
        protected void updateItem(MonthlyBalance item, boolean empty) {
            super.updateItem(item, empty);
            if (isEmpty()) {
                setBackground(null);
                setGraphic(null);
            }
            else {
                setGraphic(root);
                setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
            }
        }

        @Override
        protected double computeMinHeight(double width) {
            if(isEmpty()) return super.computeMinHeight(width);
            if(root.getHeight() == 0) return super.computeMinHeight(width);
            return particularsHeight();
        }

        @Override
        protected double computeMaxHeight(double width) {
            if(isEmpty()) return super.computeMaxHeight(width);
            if(root.getHeight() == 0) return super.computeMaxHeight(width);
            return particularsHeight();
        }

        @Override
        protected double computePrefHeight(double width) {
            if(isEmpty()) return super.computePrefHeight(width);
            if(root.getHeight() == 0) return super.computePrefHeight(width);
            return particularsHeight();
        }

        private double particularsHeight(){
            return particularsFlow.prefHeight(root.getWidth() - 400) + 5;
        }
    }
}
