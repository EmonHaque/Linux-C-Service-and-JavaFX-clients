package Views;

import Views.Add.*;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.util.ArrayList;
import java.util.List;


public class AddView extends View {
    private final View plot;
    private final View space;
    private final View tenant;
    private final View head;
    private final View lease;

    public AddView() {
        plot = new AddPlot();
        space = new AddSpace();
        tenant = new AddTenant();
        head = new AddHead();
        lease = new AddLease();
    }

    @Override
    protected String getIcon() {
        return Icons.Add;
    }

    @Override
    protected String getTip() {
        return "Add";
    }

    @Override
    public boolean isContainer() {
        return true;
    }
    @Override
    public List<View> initialViews() {
        super.views = new ArrayList<>();
        views.add(plot);
        views.add(space);

        views.add(tenant);
        views.add(head);

        views.add(lease);
        return super.views;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();

        var grid = new GridPane();

        grid.add(plot, 0, 0);
        grid.add(space, 1, 0);
        grid.add(lease, 2, 0, 1, 2);

        grid.add(tenant, 0, 1);
        grid.add(head, 1, 1);

        var colCon = new ColumnConstraints();
        var rowCon = new RowConstraints();
        colCon.setPercentWidth(33.33);
        rowCon.setPercentHeight(50);
        grid.getColumnConstraints().addAll(colCon, colCon, colCon);
        grid.getRowConstraints().addAll(rowCon, rowCon);

        grid.setVgap(Constants.CardMargin);
        grid.setHgap(Constants.CardMargin);
        BorderPane.setMargin(grid, new Insets(Constants.CardMargin));

        setCenter(grid);
    }
}
