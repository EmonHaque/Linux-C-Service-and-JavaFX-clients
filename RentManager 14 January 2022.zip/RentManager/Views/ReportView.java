package Views;

import Views.Report.*;
import abstracts.View;
import abstracts.ViewContainer;
import helpers.Icons;

public class ReportView  extends ViewContainer {
    private Balances balances;

    public ReportView() {
        balances = new Balances();
        addView(balances);
        addView(new RPnLJ());
        addView(new PlotLedger());
        addView(new SpaceLedger());
        addView(new TenantLedger());
    }

    @Override
    protected String getIcon() {
        return Icons.Ledger;
    }

    @Override
    protected String getTip() {
        return "Reports";
    }

    @Override
    public View initialView() {
        return balances;
    }
}
