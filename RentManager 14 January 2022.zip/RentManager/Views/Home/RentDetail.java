package Views.Home;

import ChartControls.RentDetailChart.AreaChart;
import ViewModels.Home.RentDetailVM;
import abstracts.View;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;

public class RentDetail extends View {
    private RentDetailVM vm;
    private TextFlow countFlow;
    private Text plot, tenant, space;
    private AreaChart area;

    @Override
    protected String getHeader() {
        return "Detail Rent, Deposit & Dues";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new RentDetailVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        var bold = Font.font(null, FontWeight.BOLD, -1);
        plot = new Text() {{setFill(Color.WHITE); setFont(bold);}};
        tenant = new Text() {{setFill(Color.WHITE); setFont(bold);}};
        space = new Text() {{setFill(Color.WHITE); setFont(bold);}};

        countFlow = new TextFlow() {{
            setTextAlignment(TextAlignment.RIGHT);
            getChildren().addAll(
                    tenant,
                    new Text(" tenants occupied ") {{setFill(Color.WHITE);}},
                    space,
                    new Text(" spaces in") {{setFill(Color.WHITE);}}
            );
        }};
        area = new AreaChart();

        var box = new VBox(countFlow, plot, area) {{
            setSpacing(5);
            setPadding(new Insets(5, 0, 0, 0));
            setVgrow(area, Priority.ALWAYS);
            setAlignment(Pos.CENTER_RIGHT);
        }};
        setCenter(box);
    }

    private void bind() {
        area.seriesProperty.bind(vm.dataProperty);
        plot.textProperty().bind(vm.plotProperty);
        tenant.textProperty().bind(vm.tenantsProperty.asString());
        space.textProperty().bind(vm.spacesProperty.asString());
    }
}
