package Views.Report;

import Views.Report.BalancesViews.ReportBalance;
import Views.Report.BalancesViews.ReportMonthlyBalance;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.util.ArrayList;
import java.util.List;

public class Balances extends View {
    private ReportBalance balance;
    private ReportMonthlyBalance monthlyBalance;

    @Override
    protected String getIcon() {
        return Icons.Balance;
    }

    @Override
    protected String getTip() {
        return "Balances";
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public List<View> initialViews() {
        balance = new ReportBalance();
        monthlyBalance = new ReportMonthlyBalance();
        super.views = new ArrayList<>();
        views.add(balance);
        views.add(monthlyBalance);
        return super.views;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();

        var grid = new GridPane();
        var col1con = new ColumnConstraints();
        var col2con = new ColumnConstraints();
        var rowCon = new RowConstraints();
        col1con.setPercentWidth(55);
        col2con.setPercentWidth(45);
        rowCon.setPercentHeight(100);
        grid.getColumnConstraints().addAll(col1con, col2con);
        grid.getRowConstraints().add(rowCon);

        grid.add(balance, 0, 0);
        grid.add(monthlyBalance, 1, 0);
        grid.setHgap(Constants.CardMargin);
        BorderPane.setMargin(grid, new Insets(Constants.CardMargin));
        setCenter(grid);
    }
}
