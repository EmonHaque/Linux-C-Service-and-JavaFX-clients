package Views.Report;

import Models.Plot;
import ViewModels.Report.BaseLedgerVM;
import ViewModels.Report.PlotLedgerVM;
import abstracts.View;
import helpers.Icons;

public class PlotLedger extends BaseLedger<Plot> {

    @Override
    protected String getIcon() {
        return Icons.Plot;
    }

    @Override
    protected BaseLedgerVM<Plot> getViewModel() {
        return new PlotLedgerVM();
    }
}
