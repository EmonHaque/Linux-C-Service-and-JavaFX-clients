package Views.Report;

import Views.Report.BalancesViews.ReportBalance;
import Views.Report.BalancesViews.ReportMonthlyBalance;
import Views.Report.RPandLJViews.ReportLeftJoined;
import Views.Report.RPandLJViews.ReportReceiptPayment;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.util.ArrayList;
import java.util.List;

public class RPnLJ extends View {
    private ReportReceiptPayment rp;
    private ReportLeftJoined lj;

    @Override
    protected String getIcon() {
        return Icons.Periodic;
    }

    @Override
    protected String getTip() {
        return "RP & LJ";
    }

    @Override
    public boolean isContainer() {
        return true;
    }
    @Override
    public List<View> initialViews() {
        rp = new ReportReceiptPayment();
        lj = new ReportLeftJoined();
        super.views = new ArrayList<>();
        views.add(rp);
        views.add(lj);
        return super.views;
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();

        var grid = new GridPane();
        var col1con = new ColumnConstraints();
        var col2con = new ColumnConstraints();
        var rowCon = new RowConstraints();
        col1con.setPercentWidth(55);
        col2con.setPercentWidth(45);
        rowCon.setPercentHeight(100);
        grid.getColumnConstraints().addAll(col1con, col2con);
        grid.getRowConstraints().add(rowCon);

        grid.add(rp, 0, 0);
        grid.add(lj, 1, 0);

        grid.setHgap(Constants.CardMargin);
        BorderPane.setMargin(grid, new Insets(Constants.CardMargin));
        setCenter(grid);
    }
}
