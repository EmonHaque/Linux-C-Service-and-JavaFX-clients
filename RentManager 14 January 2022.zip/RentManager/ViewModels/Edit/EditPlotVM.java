package ViewModels.Edit;

import Enums.Function;
import javafx.beans.Observable;
import javafx.collections.transformation.FilteredList;
import Models.Plot;
import ridiculous.AppData;
import ridiculous.Jar;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;

public class EditPlotVM extends EditBaseVM<Plot> {

    public EditPlotVM() {
        edited = new Plot();
        var nameAscending = Comparator.comparing(Plot::getName);
        var source = new Jar<>(AppData.plots, o -> new Observable[]{ queryProperty });
        editableList = new FilteredList<>(source.sorted(nameAscending), this::filter);
    }

    private boolean filter(Plot plot){
        if(isQueryEmpty) return true;
        return plot.getName().toLowerCase().contains(trimmedQuery);
    }

    @Override
    public void cloneSelected(){
        edited = new Plot(
                selected.getId(),
                selected.getName(),
                selected.getDescription()
        );
    }

    @Override
    protected int function() {
        return Function.EditPlot.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var nameBytes = (edited.getName().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
        var descBytes = (edited.getDescription().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
        return ByteBuffer.allocate(4 + nameBytes.length + descBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(edited.getId())
                .put(nameBytes)
                .put(descBytes);
    }
}
