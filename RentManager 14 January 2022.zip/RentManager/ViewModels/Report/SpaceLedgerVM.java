package ViewModels.Report;

import Models.Space;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;
import ridiculous.Jar;

public class SpaceLedgerVM extends BaseLedgerVM<Space>{
    @Override
    protected String getWhere() {
        return "SpaceId";
    }

    @Override
    public String getHeader() {
        return "Space";
    }

    @Override
    protected FilteredList<Space> getSelectionList() {
        return new FilteredList<>(new Jar<>(AppData.spaces));
    }
}
