package ViewModels.Add;

import Enums.Function;
import Models.Plot;
import Models.Space;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class AddSpaceVM extends AddBaseVM {
    public Space space;
    public FilteredList<Plot> list;
    public BooleanBinding nameExists;
    public StringProperty nameErrorProperty;

    public AddSpaceVM() {
        list = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.plots));
        space = new Space();
        nameErrorProperty = new SimpleStringProperty("");

        nameExists = new BooleanBinding() {
            {
                bind(space.plotIdProperty());
                bind(space.nameProperty());
            }
            @Override
            protected boolean computeValue() {
                if(space.getName().isEmpty()) {
                    nameErrorProperty.set("is required");
                    return true;
                }
                var matched = AppData.spaces.stream().anyMatch(x ->
                        x.getName().equalsIgnoreCase(space.getName())
                        && x.getPlotId() == space.getPlotId()
                );
                nameErrorProperty.set(matched? "exists" : "");
                return matched;
            }
        };
    }

    @Override
    protected int function() {
        return Function.AddSpace.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var nameBytes = (space.getName() + '\0').getBytes(StandardCharsets.US_ASCII);
        var descBytes = (space.getDescription() + '\0').getBytes(StandardCharsets.US_ASCII);
        return ByteBuffer.allocate(9 + nameBytes.length + descBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(space.getId())
                .putInt(space.getPlotId())
                .put(nameBytes)
                .put(descBytes)
                .put((byte)1);
    }

    @Override
    protected void resetObject() {
        space.setName("");
        space.setDescription("");
    }
}
