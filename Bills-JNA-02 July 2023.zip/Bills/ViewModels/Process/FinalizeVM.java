package ViewModels.Process;

import Enums.Function;
import model.*;
import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import model.ValidationError;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class FinalizeVM {
    private ChangeListener<String> stringListener;
    public static ObjectProperty<RawInfo> info;
    public BooleanProperty errorTrigger, departmentTrigger, accountTrigger, mobileTrigger, headTrigger,
            wrongAccountTrigger, isRunning;
    public StringProperty status;
    public final ObservableList<ValidationError> errors;

    public Department newDepartment;
    public Account newAccount;
    public Mobile newMobile;
    public boolean isHeadCreationConfirmed;
    public final List<String> heads;

    public Task<Void> task;

    public FinalizeVM() {
        errors = FXCollections.observableArrayList();
        info = new SimpleObjectProperty<>();
        errorTrigger = new SimpleBooleanProperty();
        departmentTrigger = new SimpleBooleanProperty();
        accountTrigger = new SimpleBooleanProperty();
        mobileTrigger = new SimpleBooleanProperty();
        headTrigger = new SimpleBooleanProperty();
        wrongAccountTrigger = new SimpleBooleanProperty();
        isRunning = new SimpleBooleanProperty();
        status = new SimpleStringProperty("");
        heads = new ArrayList<>();

        info.addListener(this::onInfoChange);
    }
    
    private void onInfoChange(Observable o, RawInfo ov, RawInfo nv) {
        if (ov != null) {
            if(stringListener != null){
                ov.deptNameProperty().removeListener(stringListener);
                ov.transactionNoProperty().removeListener(stringListener);
                ov.paidFromProperty().removeListener(stringListener);
                ov.paymentDateProperty().removeListener(stringListener);
                ov.periodProperty().removeListener(stringListener);
                ov.billNoProperty().removeListener(stringListener);
                ov.customerNoProperty().removeListener(stringListener);
            }
        }
        if (nv != null) {
            stringListener = this::onTextPropertyChange;
            nv.deptNameProperty().addListener(stringListener);
            nv.transactionNoProperty().addListener(stringListener);
            nv.paidFromProperty().addListener(stringListener);
            nv.paymentDateProperty().addListener(stringListener);
            nv.periodProperty().addListener(stringListener);
            nv.billNoProperty().addListener(stringListener);
            nv.customerNoProperty().addListener(stringListener);
        }
    }

    private void onTextPropertyChange(Observable o, String ov, String nv) {
        if (!info.get().isIsOk()) return;
        info.get().setIsOk(false);
    }

    public void setOk() {
        var i = info.get();
        validate();
        if (errors.size() > 0) {
            errorTrigger.set(true);
            return;
        }

        var department = AppData.departments.stream().filter(x -> x.getName().equalsIgnoreCase(i.getDeptName().trim())).findFirst();
        var account = AppData.accounts.stream().filter(x -> x.getName().equals(i.getCustomerNo().trim())).findFirst();
        var mobile = AppData.mobiles.stream().filter(x -> x.getNumber().equals(i.getPaidFrom())).findFirst();

        if (department.isEmpty()) {
            departmentTrigger.set(true);
            if (newDepartment == null) return;

            startTask(new CreateDepartmentTask());
        }
        else i.setDeptId(department.get().getId());

        if (account.isEmpty()) {
            accountTrigger.set(true);
            if (newAccount == null) return;

            newAccount.setDepartmentId(department.isPresent() ? department.get().getId() : info.get().getDeptId());
            startTask(new CreateAccountTask());
        }
        else {
            i.setCustomerId(account.get().getId());
            if (account.get().isIsWrong()) {
                wrongAccountTrigger.set(true);
            }
        }

        if (mobile.isEmpty()) {
            mobileTrigger.set(true);
            if (newMobile == null) return;
            startTask(new CreateMobileTask());
        }
        else i.setMobileId(mobile.get().getId());

        var headsOk = true;
        heads.clear();

        for (var head : i.getPaymentInfo()) {
            var trimmed = head.getKey().trim();
            var match = AppData.heads.stream().filter(x -> x.getName().equalsIgnoreCase(trimmed)).findFirst();
            if (match.isPresent()) continue;

            headsOk = false;
            if (!heads.contains(trimmed))
                heads.add(trimmed);
        }

        for (var head : i.getBillInfo()) {
            var trimmed = head.getKey().trim();
            var match = AppData.heads.stream().filter(x -> x.getName().equalsIgnoreCase(trimmed)).findFirst();
            if (match.isPresent()) continue;

            headsOk = false;
            if (!heads.contains(trimmed))
                heads.add(trimmed);
        }
        if (headsOk) {
            i.getBills().clear();
            i.getPayments().clear();
            for (var e : i.getBillInfo()) {
                var head = AppData.heads.stream().filter(x -> x.getName().equalsIgnoreCase(e.getKey())).findFirst().get();
                i.getBills().add(new AmountInfo(head.getId(), e.getValue()));
            }
            for (var e : i.getPaymentInfo()) {
                var head = AppData.heads.stream().filter(x -> x.getName().equalsIgnoreCase(e.getKey())).findFirst().get();
                i.getPayments().add(new AmountInfo(head.getId(), e.getValue()));
            }
        }
        else {
            errors.clear();
            for (var head : heads) {
                errors.add(new ValidationError(head, "doesn't exist"));
            }
            headTrigger.set(true);
            if (!isHeadCreationConfirmed) return;
            isHeadCreationConfirmed = false;

            startTask(new CreateHeadTask());
        }

        if (department.isPresent() && account.isPresent() && mobile.isPresent() && headsOk) {
            startTask(new CheckFileExistenceTask());
        }
    }

    private void startTask(Task<Void> creationTask) {
        if (task != null && task.isRunning()) {
            task.setOnSucceeded(e -> {
                task.setOnSucceeded(null);
                task = creationTask;
                isRunning.bind(task.runningProperty());
                status.bind(task.messageProperty());
                new Thread(task) {{setDaemon(true);}}.start();
            });
        }
        else {
            task = creationTask;
            isRunning.bind(task.runningProperty());
            status.bind(task.messageProperty());
            new Thread(task) {{setDaemon(true);}}.start();
        }
    }

    private boolean isNullOrEmpty(String text) {
        return text == null || text.isEmpty() || text.isBlank();
    }

    private void addEmptyError(String key) {
        errors.add(new ValidationError(key, "cannot be empty"));
    }

    private void validate() {
        errors.clear();
        var info = FinalizeVM.info.get();
        if (isNullOrEmpty(info.getPaidFrom())) addEmptyError("paid from");
        if (isNullOrEmpty(info.getDeptName())) addEmptyError("Department");
        else {
            if (info.getDeptName().equals("WASA")) {
                if (isNullOrEmpty(info.getBillNo()))
                    addEmptyError("Bill no");
            }
        }
        if (isNullOrEmpty(info.getTransactionNo())) addEmptyError("Transaction no");
        if (isNullOrEmpty(info.getPaymentDate())) addEmptyError("Date");
        else {
            try {
                LocalDate.parse(info.getPaymentDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            } catch (Exception e) {
                errors.add(new ValidationError("Date", "YYYY-MM-DD format expected"));
            }
        }
        if (isNullOrEmpty(info.getCustomerNo())) addEmptyError("Customer no");
        if (isNullOrEmpty(info.getPeriod())) addEmptyError("Period");
        if (info.getBillInfo().size() == 0) addEmptyError("Bill info");
        else {
            if (info.getTotalBill() <= 0) {
                errors.add(new ValidationError("Total bill", "cannot be negative"));
            }
            else if (info.getTotalBill() > info.getTotalPayment()) {
                errors.add(new ValidationError("Total bill", "cannot exceed payment"));
            }
        }
        if (info.getPaymentInfo().size() == 0) addEmptyError("Payment info");
        else {
            if (info.getTotalPayment() <= 0) {
                errors.add(new ValidationError("Total payment", "cannot be negative"));
            }
            else if (info.getTotalBill() > info.getTotalPayment()) {
                errors.add(new ValidationError("Total payment", "cannot be less than Bill"));
            }
        }
        for (int i = 0; i < info.getBillInfo().size(); i++) {
            var head = info.getBillInfo().get(i).getKey();
            if (isNullOrEmpty(head)) addEmptyError("Bill info " + (i + 1));

            if (info.getBillInfo().get(i).getValue() <= 0) {
                errors.add(new ValidationError("Bill info " + (i + 1), "should be greater than 0"));
            }
        }
        for (int i = 0; i < info.getPaymentInfo().size(); i++) {
            var head = info.getPaymentInfo().get(i).getKey();
            if (isNullOrEmpty(head)) addEmptyError("Payment info " + (i + 1));
            if (info.getPaymentInfo().get(i).getValue() <= 0) {
                errors.add(new ValidationError("Payment info " + (i + 1), "should be greater than 0"));
            }
        }
    }

    private class CreateDepartmentTask extends Task<Void> {

        @Override
        protected Void call() throws Exception {
            updateMessage("preparing Department");
            Thread.sleep(500);

            var nameBytes = (newDepartment.getName().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
            var buffer = ByteBuffer.allocate(nameBytes.length)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .put(nameBytes);

            updateMessage("requesting Department");
            Thread.sleep(500);
            var request = new Request(Function.AddDepartment.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            if (response.isSuccess()) {
                var isSuccess = response.getPacket()[0] == 1;
                var message = new String(response.getPacket(), 1, response.getPacket().length - 1, StandardCharsets.US_ASCII);
                if (isSuccess) {
                    Platform.runLater(() -> {
                        FinalizeVM.info.get().setDeptId(Integer.parseInt(message.trim()));
                    });
                    updateMessage("Successfully created department");
                    Thread.sleep(500);
                }
                else {
                    updateMessage(message);
                    Thread.sleep(500);
                }
            }
            else {
                updateMessage("service down");
                Thread.sleep(500);
            }
            return null;
        }
    }

    private class CreateAccountTask extends Task<Void> {
        @Override
        protected Void call() throws Exception {
            updateMessage("preparing Account");
            Thread.sleep(500);

            var nameBytes = (newAccount.getName().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
            var holderBytes = (newAccount.getHolder().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
            var addressBytes = (newAccount.getAddress().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
            byte isWrong = newAccount.isIsWrong() ? (byte) 0 : 1;
            var buffer = ByteBuffer.allocate(5 + nameBytes.length + holderBytes.length + addressBytes.length)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .put(nameBytes)
                    .put(holderBytes)
                    .put(addressBytes)
                    .putInt(newAccount.getDepartmentId())
                    .put(isWrong);

            updateMessage("requesting Account");
            Thread.sleep(500);

            var request = new Request(Function.AddAccount.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();

            if (response.isSuccess()) {
                var isSuccess = response.getPacket()[0] == 1;
                var message = new String(response.getPacket(), 1, response.getPacket().length - 1, StandardCharsets.US_ASCII);
                if (isSuccess) {
                    Platform.runLater(() -> {
                        FinalizeVM.info.get().setCustomerId(Integer.parseInt(message.trim()));
                    });
                    updateMessage("Successfully created account");
                    Thread.sleep(500);
                }
                else {
                    updateMessage(message);
                    Thread.sleep(500);
                }
            }
            else {
                updateMessage("service down");
                Thread.sleep(500);
            }
            return null;
        }
    }

    private class CreateMobileTask extends Task<Void> {

        @Override
        protected Void call() throws Exception {
            updateMessage("preparing Mobile");
            Thread.sleep(500);

            var numberBytes = (newMobile.getNumber().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
            var nameBytes = (newMobile.getName().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
            var buffer = ByteBuffer.allocate(numberBytes.length + nameBytes.length)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .put(numberBytes)
                    .put(nameBytes);

            updateMessage("requesting Mobile");
            Thread.sleep(500);
            var request = new Request(Function.AddMobile.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            if (response.isSuccess()) {
                var isSuccess = response.getPacket()[0] == 1;
                var message = new String(response.getPacket(), 1, response.getPacket().length - 1, StandardCharsets.US_ASCII);
                if (isSuccess) {
                    Platform.runLater(() -> {
                        FinalizeVM.info.get().setMobileId(Integer.parseInt(message.trim()));
                    });
                    updateMessage("Successfully created Mobile");
                    Thread.sleep(500);
                }
                else {
                    updateMessage(message);
                    Thread.sleep(500);
                }
            }
            else {
                updateMessage("service down");
                Thread.sleep(500);
            }
            return null;
        }
    }

    private class CreateHeadTask extends Task<Void> {

        @Override
        protected Void call() throws Exception {
            updateMessage("preparing Heads");
            Thread.sleep(500);

            int length = 4;
            var arrays = new ArrayList<byte[]>();
            for (var head : heads) {
                var bytes = (head + '\0').getBytes(StandardCharsets.US_ASCII);
                length += bytes.length;
                arrays.add(bytes);
            }
            var buffer = ByteBuffer.allocate(length)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .putInt(arrays.size());

            for (var array : arrays) buffer.put(array);

            updateMessage("requesting Heads");
            Thread.sleep(500);
            var request = new Request(Function.AddHead.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            if (response.isSuccess()) {
                var isSuccess = response.getPacket()[0] == 1;
                var message = new String(response.getPacket(), 1, response.getPacket().length - 1, StandardCharsets.US_ASCII);
                updateMessage(message);
                Thread.sleep(500);

                if (isSuccess) {
                    var sender = Channels.getInstance().sender;
                    var header = sender.getInputStream().readNBytes(4);
                    var size = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN).getInt();
                    var packet = sender.getInputStream().readNBytes(size);

                    var array = ByteBuffer.wrap(packet).order(ByteOrder.LITTLE_ENDIAN);
                    int start = 0;
                    int read = 0;
                    int remaining = array.array().length;
                    var heads = new ArrayList<Head>();

                    while (read < remaining) {
                        int id = array.getInt(read);
                        read += 4;
                        start = read;
                        while (array.get(read) != 0) read++;
                        var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
                        heads.add(new Head(id, name));
                        ++read;
                    }

                    updateMessage("assigning head id");
                    Thread.sleep(500);

                    var i = FinalizeVM.info.get();
                    i.getBills().clear();
                    i.getPayments().clear();
                    for (var e : i.getBillInfo()) {
                        var head = AppData.heads.stream().filter(x -> x.getName().equalsIgnoreCase(e.getKey())).findFirst();
                        if (head.isEmpty()) {
                            head = heads.stream().filter(x -> x.getName().equalsIgnoreCase(e.getKey())).findFirst();
                        }
                        i.getBills().add(new AmountInfo(head.get().getId(), e.getValue()));
                    }
                    for (var e : i.getPaymentInfo()) {
                        var head = AppData.heads.stream().filter(x -> x.getName().equalsIgnoreCase(e.getKey())).findFirst();
                        if (head.isEmpty()) {
                            head = heads.stream().filter(x -> x.getName().equalsIgnoreCase(e.getKey())).findFirst();
                        }
                        i.getPayments().add(new AmountInfo(head.get().getId(), e.getValue()));
                    }
                    updateMessage("successfully assigned");
                }
            }
            else {
                updateMessage("service down");
                Thread.sleep(500);
            }
            return null;
        }
    }

    private class CheckFileExistenceTask extends Task<Void> {

        @Override
        protected Void call() throws Exception {
            updateMessage("preparing File name");
            Thread.sleep(500);
            var i = FinalizeVM.info.get();
            var desiredName = i.getPaymentDate() + "-" + i.getDeptName() + "-" + i.getTransactionNo() + ".png";
            var nameBytes = (desiredName + '\0').getBytes(StandardCharsets.US_ASCII);
            var buffer = ByteBuffer.allocate(nameBytes.length)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .put(nameBytes);

            updateMessage("checking file existence");
            Thread.sleep(500);
            var request = new Request(Function.CheckFileExistence.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();

            if (response.isSuccess()) {
                var isSuccess = response.getPacket()[0] == 1;
                var message = new String(response.getPacket(), 1, response.getPacket().length - 1, StandardCharsets.US_ASCII);
                if (isSuccess) {
                    updateMessage("");
                    Platform.runLater(() -> {
                        i.setOutputFileName(desiredName);
                        i.setIsOk(true);
                    });
                }
                else {
                    updateMessage(message);
                    Thread.sleep(500);
                }
            }
            else {
                updateMessage("service down");
                Thread.sleep(500);
            }

            return null;
        }
    }
}
