package ViewModels.Process;

import Enums.Function;
import model.RawInfo;
import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import javafx.stage.DirectoryChooser;
import model.SumBoxModel;
import model.ValidationError;
import ridiculuous.Channels;
import ridiculuous.Request;

import javax.imageio.ImageIO;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static ridiculous.AppData.tessCV;

public class LoadVM {
    private final ObservableList<RawInfo> infoList;
    private final String WASA = "WASA";
    private final String DESCO = "DESCO";
    private final String TGCL = "TGCL";
    private final String BTCL = "BTCL";
    private boolean isDepartmentChanged;
    private final ChangeListener<Boolean> okListener;
    private final ChangeListener<String> deptNameListener;

    public FilteredList<RawInfo> list;
    public StringProperty status;
    public BooleanProperty isRunning, duplicateTrigger;
    public DoubleProperty progress;
    public ObjectProperty<RawInfo> selectedItem;
    public ObservableList<ValidationError> duplicateList;

    public LoadVM() {
        duplicateList = FXCollections.observableArrayList();
        infoList = FXCollections.observableArrayList();
        list = new FilteredList<>(infoList, x -> true);
        status = new SimpleStringProperty("");
        isRunning = new SimpleBooleanProperty();
        duplicateTrigger = new SimpleBooleanProperty();
        progress = new SimpleDoubleProperty();
        selectedItem = new SimpleObjectProperty<>();
        selectedItem.addListener(this::onSelectionChange);

        okListener = this::onOk;
        deptNameListener = this::onDepartmentChange;
    }

    private void onSelectionChange(Observable o, RawInfo ov, RawInfo nv) {
        if (ov != null) {
            ov.isOkProperty().removeListener(okListener);
            ov.deptNameProperty().removeListener(deptNameListener);
        }
        if (nv != null) {
            isDepartmentChanged = false;
            nv.isOkProperty().addListener(okListener);
            nv.deptNameProperty().addListener(deptNameListener);
        }
    }

    private void onOk(Observable o, boolean ov, boolean nv) {
        var selected = selectedItem.get();
        if (isDepartmentChanged) {
            infoList.remove(selected);
            infoList.add(selected);
        }
        selected.setIsDuplicate(false);
        for (var item : list) {
            if (item.equals(selected)) continue;
            var fileName = item.isIsOk() ? item.getOutputFileName() :
                    item.getPaymentDate() + "-" + item.getDeptName() + "-" + item.getTransactionNo() + ".png";

            if (!fileName.equals(selected.getOutputFileName())) continue;

            item.setIsOk(false);
            selected.setIsOk(false);
            item.setIsDuplicate(true);
            selected.setIsDuplicate(true);
        }
    }

    private void onDepartmentChange(Observable o, String ov, String nv) {
        isDepartmentChanged = true;
    }

    public void onDirectoryChanged() {
        var chooser = new DirectoryChooser();
        var directory = chooser.showDialog(null);
        if (directory == null) return;

        var files = new ArrayList<File>();
        for (var file : directory.listFiles()) {
            var name = file.getName();
            var splits = name.split("\\.");
            var extension = splits[splits.length - 1];
            if (!extension.equalsIgnoreCase("JPG")) continue;

            files.add(file);
        }
        infoList.clear();

        var task = new ProcessTask(files);
        status.bind(task.messageProperty());
        progress.bind(task.progressProperty());
        isRunning.bind(task.runningProperty());
        new Thread(task) {{
            setDaemon(true);
        }}.start();
    }

    public void add() {
        boolean hasOk = false;
        for (var item : list) {
            if (item.isIsOk()) {
                hasOk = true;
                break;
            }
        }
        if (!hasOk) {
            status.unbind();
            status.set("nothing is ok");
            return;
        }

        var task = new EntryAddTask();
        status.bind(task.messageProperty());
        isRunning.bind(task.runningProperty());
        new Thread(task) {{
            setDaemon(true);
        }}.start();
    }

    public void remove(RawInfo info) {
        infoList.remove(info);
    }

    private class ProcessTask extends Task<Void> {
        private final String NagadAccNo = "Nagad Acc. No";
        private final String TransactionId = "Transaction ID";
        private final String BillNumber = "Bill Number";
        private final String BillNo = "Bill No";
        private final String CustomerCode = "Customer Code";
        private final String AccountNo = "Account No";
        private final String PhoneNo = "Phone Number";
        private final String InvoiceArea = "Invoice ID/Area Code";
        private final String Time = "Time";
        private final String Amount = "Amount";
        private final String Fee = "Fee";
        private final String VAT = "VAT";
        private final String FixedCharge = "Fixed Charge";
        private final String SurCharge = "Sur Charge";
        private final String Surcharge = "Surcharge";
        private final String SewerBill = "Sewer Bill";
        private final String WaterBill = "Water Bill";
        private final String MonthYear = "MonthYear (MMYY/MMYYYY)";
        private final String Month = "Month";
        private final String Year = "Year";
        private final String TITAS = "titas";

        private boolean inPaymentInfo;
        private final List<File> files;

        public ProcessTask(List<File> files) {
            this.files = files;
        }

        @Override
        protected Void call() throws Exception {
            int count = 1;
            for (var file : files) {
                updateMessage("processing " + count + "/" + files.size());
                boolean gotToThePoint = false;
                var cleaned = "";
                inPaymentInfo = false;
                var lines = getLines(file);
                var newInfo = new RawInfo() {{
                    setFileName(file.getName());
                    setFilePath(file.getAbsolutePath());
                }};
                for (var line : lines) {
                    if (!gotToThePoint) {
                        if (line.toLowerCase().contains("bill information")) {
                            gotToThePoint = true;
                        }
                        continue;
                    }
                    if (line.isEmpty() || line.isBlank()) continue;
                    if (line.startsWith("Status")) continue;

                    if (line.toLowerCase().contains("payment information")) {
                        inPaymentInfo = true;
                        cleaned += "---------------------------\n";
                        continue;
                    }
                    if (line.toLowerCase().contains("generated electronically")) break;
                    cleaned += line + "\n";
                    processLine(line, newInfo);
                }
                if (!gotToThePoint) {
                    for (var line : lines) {
                        if (line.isEmpty() || line.isBlank()) continue;
                        cleaned += line + "\n";
                        processLine(line, newInfo);
                    }
                }

                newInfo.setRawText(cleaned);
                newInfo.setTotalPayment(newInfo.getPaymentInfo().stream().mapToDouble(SumBoxModel::getValue).sum());
                newInfo.setTotalBill(newInfo.getBillInfo().stream().mapToDouble(SumBoxModel::getValue).sum());

                updateProgress((double) count / files.size(), 1);
                Platform.runLater(() -> infoList.add(newInfo));
                count++;
            }
            updateMessage("processed " + (--count) + "/" + files.size());
            return null;
        }


        private void processLine(String line, RawInfo newInfo) {
            if (line.toLowerCase().contains(TITAS)) {
                newInfo.setDeptName(TGCL);
            } else if (line.contains(WASA)) {
                newInfo.setDeptName(WASA);
            } else if (line.contains(DESCO)) {
                newInfo.setDeptName(DESCO);
            } else if (line.contains(BTCL)) {
                newInfo.setDeptName(BTCL);
            } else if (line.startsWith(Month)) {
                if (newInfo.getDeptName() != null) {
                    if (newInfo.getDeptName().equals(TGCL)) {
                        newInfo.setPeriod(line.replace(MonthYear, "").trim());
                    } else if (newInfo.getDeptName().equals(BTCL)) {
                        newInfo.setPeriod(line.replace(Month, "").trim());
                    }
                }
            } else if (line.startsWith(Year)) {
                newInfo.setPeriod(newInfo.getPeriod() + ", " + line.replace(Year, "").trim());
            } else if (line.startsWith(TransactionId)) {
                newInfo.setTransactionNo(line.replace(TransactionId, "").trim());
            } else if (line.startsWith(NagadAccNo)) {
                newInfo.setPaidFrom(line.replace(NagadAccNo, "").trim());
            } else if (line.startsWith(BillNumber)) {
                newInfo.setBillNo(line.replace(BillNumber, "").trim());
            } else if (line.startsWith(BillNo)) {
                newInfo.setBillNo(line.replace(BillNo, "").trim());
            } else if (line.startsWith(CustomerCode)) {
                newInfo.setCustomerNo(line.replace(CustomerCode, "").trim());
            } else if (line.startsWith(AccountNo)) {
                newInfo.setCustomerNo(line.replace(AccountNo, "").trim());
            } else if (line.startsWith(PhoneNo)) {
                newInfo.setCustomerNo(line.replace(PhoneNo, "").trim());
            } else if (line.startsWith(InvoiceArea)) {
                newInfo.setCustomerNo(line.replace(InvoiceArea, "").trim());
            } else if (line.startsWith(Time)) {
                var str = line.replace(Time, "").trim();
                if (!str.isEmpty() || !str.isBlank()) {
                    var hasComma = true;
                    if (str.indexOf(',') > 0) {
                        str = str.substring(0, str.indexOf(','));
                    } else hasComma = false;

                    var parts = str.split(" ");
                    if (parts.length == 3) {
                        int monthIndex = Arrays.asList(new DateFormatSymbols().getShortMonths()).indexOf(parts[1]) + 1;
                        var day = parts[0];
                        var month = monthIndex < 10 ? "0" + monthIndex : String.valueOf(monthIndex);
                        var year = hasComma ? parts[2] : parts[2].substring(0, 4);
                        newInfo.setPaymentDate(year + "-" + month + "-" + day);
                    }

                }
            } else if (line.startsWith(Amount)) {
                var number = getNumber(line.replace(Fee, "").trim());
                if (number > 0) {
                    var amountInfo = new SumBoxModel(Amount, getNumber(line.replace(Amount, "").trim()));
                    if (inPaymentInfo) newInfo.getPaymentInfo().add(amountInfo);
                    else newInfo.getBillInfo().add(amountInfo);
                }
            } else if (line.startsWith(Fee)) {
                var number = getNumber(line.replace(Fee, "").trim());
                if (number > 0) {
                    newInfo.getPaymentInfo().add(new SumBoxModel(Fee, number));
                }
            } else if (line.startsWith(VAT)) {
                var number = getNumber(line.replace(VAT, "").trim());
                if (number > 0) {
                    var amountInfo = new SumBoxModel(VAT, number);
                    if (inPaymentInfo) newInfo.getPaymentInfo().add(amountInfo);
                    else newInfo.getBillInfo().add(amountInfo);
                }
            } else if (line.startsWith(WaterBill)) {
                var number = getNumber(line.replace(WaterBill, "").trim());
                if (number > 0) {
                    newInfo.getBillInfo().add(new SumBoxModel(Amount, number));
                }
            } else if (line.startsWith(FixedCharge)) {
                var number = getNumber(line.replace(FixedCharge, "").trim());
                if (number > 0) {
                    newInfo.getBillInfo().add(new SumBoxModel(FixedCharge, number));
                }
            } else if (line.startsWith(SurCharge)) {
                var number = getNumber(line.replace(SurCharge, "").trim());
                if (number > 0) {
                    newInfo.getBillInfo().add(new SumBoxModel(Surcharge, number));
                }
            } else if (line.startsWith(SewerBill)) {
                var number = getNumber(line.replace(SewerBill, "").trim());
                if (number > 0) {
                    newInfo.getBillInfo().add(new SumBoxModel(SewerBill, number));
                }
            }
        }

        private String[] getLines(File file) {
            var content = tessCV.getText(file.getAbsolutePath());
            return content.split("\\r?\\n");
        }

        double getNumber(String line) {
            if (line.isEmpty() || line.isBlank()) return 0;

            var array = line.toCharArray();
            var characters = IntStream.range(0, array.length).mapToObj(i -> array[i]).filter(x -> Character.isDigit(x) || x == '.').collect(Collectors.toList());
            if (characters.size() == 0) return 0;
            if (characters.size() == 1 && characters.get(0) == '.') return 0;
            int count = 0;
            for (int i = (characters.size() - 1); i > 0; i--) {
                if (Character.isDigit(characters.get(i))) break;
                count++;
            }
            count = characters.size() - count;
            var numStr = "";
            int dotCount = 0;
            for (int i = 0; i < count; i++) {
                if (characters.get(i) == '.') {
                    dotCount++;
                    if (dotCount > 1) numStr = numStr.replace(".", "");
                }
                numStr += characters.get(i);
            }
            return Double.parseDouble(numStr);
        }
    }

    private class EntryAddTask extends Task<Boolean> {

        @Override
        protected Boolean call() throws Exception {
            updateMessage("preparing buffer");
            Thread.sleep(500);

            int totalLength = 4; // size of list

            var buffers = new ArrayList<ByteBuffer>();
            for (var item : list) {
                if (!item.isIsOk()) continue;

                var billNoBytes = (item.getBillNo().trim() + '\0').getBytes(StandardCharsets.UTF_8);
                var periodBytes = (item.getPeriod().trim() + '\0').getBytes(StandardCharsets.UTF_8);
                var dateBytes = (item.getPaymentDate().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
                var transactionIdBytes = (item.getTransactionNo().trim() + '\0').getBytes(StandardCharsets.UTF_8);
                var fileNameBytes = (item.getOutputFileName().trim() + '\0').getBytes(StandardCharsets.UTF_8);

                var image = ImageIO.read(new File(item.getFilePath()));
                var stream = new ByteArrayOutputStream();
                ImageIO.write(image, "png", stream);
                var imageBytes = stream.toByteArray();

                int billLength = item.getBills().size() * 12;
                int paymentLength = item.getPayments().size() * 12;

                int bufferSize = 6 * 4 + billLength + paymentLength
                        + billNoBytes.length
                        + periodBytes.length
                        + dateBytes.length
                        + transactionIdBytes.length
                        + fileNameBytes.length
                        + imageBytes.length;

                totalLength += bufferSize;

                var buffer = ByteBuffer.allocate(bufferSize).order(ByteOrder.LITTLE_ENDIAN)
                        .putInt(item.getBills().size())
                        .putInt(item.getPayments().size())
                        .putInt(imageBytes.length)
                        .putInt(item.getDeptId())
                        .putInt(item.getCustomerId())
                        .putInt(item.getMobileId())
                        .put(billNoBytes)
                        .put(periodBytes)
                        .put(dateBytes)
                        .put(transactionIdBytes)
                        .put(fileNameBytes)
                        .put(imageBytes);

                for (var entry : item.getBills()) {
                    buffer.putInt(entry.getHeadId());
                    buffer.putDouble(entry.getAmount());
                }
                for (var entry : item.getPayments()) {
                    buffer.putInt(entry.getHeadId());
                    buffer.putDouble(entry.getAmount());
                }
                buffers.add(buffer);
            }

            var buffer = ByteBuffer.allocate(totalLength)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .putInt(list.size());

            for (var array : buffers) {
                buffer.put(array.array());
            }

            updateMessage("requesting");
            Thread.sleep(500);

            boolean result = false;
            var request = new Request(Function.AddEntries.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();

            if (response.isSuccess()) {
                var isSuccess = response.getPacket()[0] == 1;
                var message = new String(response.getPacket(), 1, response.getPacket().length - 1, StandardCharsets.US_ASCII);
                if (isSuccess) {
                    result = true;
                    updateMessage(message);
                    Thread.sleep(500);
                } else {
                    if (message.trim().equals("duplicate")) {
                        var sender = Channels.getInstance().sender;
                        var header = sender.getInputStream().readNBytes(4);
                        var size = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN).getInt();
                        var packet = sender.getInputStream().readNBytes(size);
                        var array = ByteBuffer.wrap(packet).order(ByteOrder.LITTLE_ENDIAN);

                        var duplicates = new ArrayList<String>();
                        int read = 0;
                        int length = array.array().length;
                        while (read < length) {
                            int start = read;
                            while (array.get(read) != 0) read++;
                            var name = new String(array.array(), start, read - start, StandardCharsets.US_ASCII);
                            duplicates.add(name.split("\\.")[0]);
                            read++;
                        }
                        Platform.runLater(() -> {
                            duplicateList.clear();

                            for (var duplicate : duplicates) {
                                duplicateList.add(new ValidationError(duplicate, "file exists"));
                                for (var item : list) {
                                    if (item.getOutputFileName().startsWith(duplicate)) {
                                        item.setIsDuplicate(true);
                                        item.setIsOk(false);
                                        break;
                                    }
                                }
                            }
                            duplicateTrigger.set(true);
                        });
                    } else {
                        updateMessage(message);
                        Thread.sleep(500);
                    }
                }
            } else {
                updateMessage("service down");
                Thread.sleep(500);
            }
            return result;
        }

        @Override
        protected void succeeded() {
            try {
                var isSuccess = get();
                var okList = new ArrayList<RawInfo>();
                if (isSuccess) {
                    for (var item : list) {
                        if (item.isIsOk()) okList.add(item);
                    }
                    infoList.removeAll(okList);
                    selectedItem.set(infoList.size() > 0 ? infoList.get(0) : null);
                }
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
