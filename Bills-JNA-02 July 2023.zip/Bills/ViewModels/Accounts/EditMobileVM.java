package ViewModels.Accounts;

import Enums.Function;
import model.Mobile;
import javafx.collections.ObservableList;
import ridiculous.AppData;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class EditMobileVM extends EditBaseVM<Mobile> {
    @Override
    public ObservableList<Mobile> getList() {
        return AppData.mobiles;
    }

    @Override
    protected int function() {
        return Function.EditMobile.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var numberBytes = (edited.getNumber().trim() + '\0').getBytes(StandardCharsets.UTF_8);
        var nameBytes = (edited.getName().trim() + '\0').getBytes(StandardCharsets.UTF_8);
        return ByteBuffer.allocate(4 + nameBytes.length + numberBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(edited.getId())
                .put(numberBytes)
                .put(nameBytes);
    }
}
