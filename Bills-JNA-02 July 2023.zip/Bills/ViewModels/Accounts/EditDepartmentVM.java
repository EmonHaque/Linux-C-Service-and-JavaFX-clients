package ViewModels.Accounts;

import Enums.Function;
import model.Department;
import javafx.collections.ObservableList;
import ridiculous.AppData;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class EditDepartmentVM extends EditBaseVM<Department> {
    @Override
    public ObservableList<Department> getList() {
        return AppData.departments;
    }

    @Override
    protected int function() {
        return Function.EditDepartment.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var nameBytes = (edited.getName().trim() + '\0').getBytes(StandardCharsets.UTF_8);
        return ByteBuffer.allocate(4 + nameBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(edited.getId())
                .put(nameBytes);
    }
}
