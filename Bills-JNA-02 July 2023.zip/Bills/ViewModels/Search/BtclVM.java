package ViewModels.Search;

public class BtclVM extends DepartmentSearchVM {

    @Override
    public String getDepartmentName() {
        return "BTCL";
    }
}
