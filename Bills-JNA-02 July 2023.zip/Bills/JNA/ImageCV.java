package JNA;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

@Structure.FieldOrder({"size", "data"}) // FieldOrder is important
public class ImageCV extends Structure {
    public int size; // public keyword is important
    public Pointer data;
}
