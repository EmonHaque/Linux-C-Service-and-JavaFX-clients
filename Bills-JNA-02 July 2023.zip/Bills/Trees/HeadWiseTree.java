package Trees;

import model.DayMonthSummary;
import abstracts.WrapTreeCellBase;
import helpers.Constants;
import helpers.Helper;
import javafx.collections.MapChangeListener;
import javafx.collections.ObservableMap;
import javafx.geometry.HPos;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import skinned.ExtendedTreeView;

import java.util.List;

public class HeadWiseTree extends ExtendedTreeView<DayMonthSummary> {
    private final ObservableMap<String, List<DayMonthSummary>> map;
    private final double numColumnWidth = 100;

    public HeadWiseTree(ObservableMap<String, List<DayMonthSummary>> map) {
        this.map = map;
        setRoot(new TreeItem<>());
        setShowRoot(false);

        setCellFactory(v -> new Cell());

        map.addListener(this::onMapChange);
    }

    private void onMapChange(MapChangeListener.Change<? extends String, ? extends List<DayMonthSummary>> change) {
        getRoot().getChildren().clear();
        for (var top : map.keySet()) {
            var branch = new TreeItem<DayMonthSummary>();
            var value = map.get(top);
            double bill = 0, payment = 0;
            for (var v : value) {
                bill += v.getBill();
                payment += v.getPayment();

                branch.getChildren().add(new TreeItem<>(v));
            }
            double finalBill = bill, finalPayment = payment;
            branch.setValue(new DayMonthSummary() {{
                setParticulars(top);
                setBill(finalBill);
                setPayment(finalPayment);
            }});
            getRoot().getChildren().add(branch);
        }

    }

    private class Cell extends WrapTreeCellBase<DayMonthSummary> {
        private Text head, bill, payment;
        private ColumnConstraints firstColumn;

        @Override
        protected void initializeUI() {
            head = new Text() {{setFill(Color.WHITE);}};
            bill = new Text() {{setFill(Color.WHITE);}};
            payment = new Text() {{setFill(Color.WHITE);}};

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(head, 0, 0);
                add(bill, 1, 0);
                add(payment, 2, 0);
            }};
        }

        @Override
        protected void resetValues(DayMonthSummary oldValue) {
            root.setBorder(null);
            head.setText(null);
            bill.setText(null);
            payment.setText(null);
        }

        @Override
        protected void setValues(DayMonthSummary newValue) {
            if (level == 2) {
                var siblings = item.getParent().getChildren();
                if (siblings.size() == 1) {
                    root.setBorder(Constants.DoubleBorder);
                }
                else {
                    var index = siblings.indexOf(item);
                    if (index == 0) {
                        root.setBorder(Constants.TopBorder);
                    }
                    else if (index == siblings.size() - 1) {
                        root.setBorder(Constants.BottomBorder);
                    }
                }
            }
            head.setText(newValue.getParticulars());
            bill.setText(Helper.formatNumber(newValue.getBill()));
            payment.setText(Helper.formatNumber(newValue.getPayment()));
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 2 * numColumnWidth;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            head.setWrappingWidth(remainder);
            return head.prefHeight(remainder);
        }
    }
}
