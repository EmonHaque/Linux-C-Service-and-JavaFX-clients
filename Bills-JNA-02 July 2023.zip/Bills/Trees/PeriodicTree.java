package Trees;

import model.PeriodicEntry;
import abstracts.WrapTreeCellBase;
import controls.states.MultiState;
import helpers.Constants;
import helpers.Helper;
import javafx.beans.Observable;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

import java.util.function.Function;

public class PeriodicTree extends ExtendedTreeView<PeriodicEntry> {
    private final ObservableList<PeriodicEntry> list;
    private int state;
    private final double numColumnWidth = 100;

    public PeriodicTree(ObservableList<PeriodicEntry> list, MultiState state) {
        this.list = list;

        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new Cell());

        state.stateProperty.addListener(this::onStateChange);
        list.addListener(this::onListChange);
    }

    private void onListChange(ListChangeListener.Change<? extends PeriodicEntry> change){
        getRoot().getChildren().clear();
        if(state == 0) {
            for(var e : list) addFourLevel(getRoot(), e);
        }
        else{
            for(var e : list) addThreeLevel(getRoot(), e);
        }
    }

    private void onStateChange(Observable o, Number ov, Number nv){
        getRoot().getChildren().clear();
        state = nv.intValue();
        if(state == 0) {
            for(var e : list) addFourLevel(getRoot(), e);
        }
        else{
            for(var e : list) addThreeLevel(getRoot(), e);
        }
    }

    private void addThreeLevel(TreeItem<PeriodicEntry> node, PeriodicEntry entry){
        var level = getTreeItemLevel(node);
        var hasIt = false;
        TreeItem<PeriodicEntry> item = null;
        Function<PeriodicEntry, Boolean> condition = x -> true;

        switch (level) {
            case 0 -> condition = e -> e.getDepartment().equals(entry.getDepartment());
            case 1 -> condition = e -> e.getAccountNo().equals(entry.getAccountNo());
            case 2 -> condition = e -> e.getHead().equals(entry.getHead());
        }
        for (var branch : node.getChildren()) {
            if (!condition.apply(branch.getValue())) continue;
            var value = branch.getValue();
            value.setBill(value.getBill() + entry.getBill());
            value.setPayment(value.getPayment() + entry.getPayment());
            hasIt = true;
            item = branch;
            break;
        }
        if (!hasIt) {
            var newEntry = new PeriodicEntry() {{
                setBill(entry.getBill());
                setPayment(entry.getPayment());
            }};
            switch (level) {
                case 0 -> newEntry.setDepartment(entry.getDepartment());
                case 1 -> newEntry.setAccountNo(entry.getAccountNo());
                case 2 -> newEntry.setHead(entry.getHead());
            }
            item = new TreeItem<>(newEntry);
            node.getChildren().add(item);
        }
        if(level < 2) addThreeLevel(item, entry);
    }

    private void addFourLevel(TreeItem<PeriodicEntry> node, PeriodicEntry entry){
        var level = getTreeItemLevel(node);
        var hasIt = false;
        TreeItem<PeriodicEntry> item = null;
        Function<PeriodicEntry, Boolean> condition = x -> true;

        switch (level) {
            case 0 -> condition = e -> e.getMobileId() == entry.getMobileId();
            case 1 -> condition = e -> e.getDepartment().equals(entry.getDepartment());
            case 2 -> condition = e -> e.getHead().equals(entry.getHead());
            case 3 -> condition = e -> e.getAccountNo().equals(entry.getAccountNo());
        }
        for (var branch : node.getChildren()) {
            if (!condition.apply(branch.getValue())) continue;
            var value = branch.getValue();
            value.setBill(value.getBill() + entry.getBill());
            value.setPayment(value.getPayment() + entry.getPayment());
            hasIt = true;
            item = branch;
            break;
        }
        if (!hasIt) {
            var newEntry = new PeriodicEntry() {{
                setBill(entry.getBill());
                setPayment(entry.getPayment());
            }};
            switch (level){
                case 0 -> newEntry.setMobileId(entry.getMobileId());
                case 1 -> newEntry.setDepartment(entry.getDepartment());
                case 2 -> newEntry.setHead(entry.getHead());
                case 3 -> newEntry.setAccountNo(entry.getAccountNo());
            }
            item = new TreeItem<>(newEntry);
            node.getChildren().add(item);
        }
        if(level < 3) addFourLevel(item, entry);
    }

    private class Cell extends WrapTreeCellBase<PeriodicEntry>{
        private Text head, bill, payment;
        private ColumnConstraints firstColumn;

        @Override
        protected void initializeUI() {
            head = new Text() {{setFill(Color.WHITE);}};
            bill = new Text() {{setFill(Color.WHITE);}};
            payment = new Text() {{setFill(Color.WHITE);}};

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(head, 0, 0);
                add(bill, 1, 0);
                add(payment, 2, 0);
            }};
        }

        @Override
        protected void resetValues(PeriodicEntry oldValue) {
            root.setBorder(null);
            head.setText(null);
            bill.setText(null);
            payment.setText(null);
        }

        @Override
        protected void setValues(PeriodicEntry newValue) {
            String text = "";
            if(state == 0){
                switch (level){
                    case 1 -> {
                        var mobile = AppData.mobiles.stream().filter(x -> x.getId() == newValue.getMobileId()).findFirst().get();
                        text = mobile.getName() + " - " + mobile.getNumber();
                    }
                    case 2 -> text = newValue.getDepartment();
                    case 3 ->  text = newValue.getHead();
                    case 4 -> text = newValue.getAccountNo();
                }
            }
            else{
                switch (level){
                    case 1 -> text = newValue.getDepartment();
                    case 2 -> text = newValue.getAccountNo();
                    case 3 -> text = newValue.getHead();
                }
            }
            if(level > 1) makeBorder(item);

            head.setText(text);
            bill.setText(Helper.formatNumber(newValue.getBill()));
            payment.setText(Helper.formatNumber(newValue.getPayment()));
        }

        private void makeBorder(TreeItem<PeriodicEntry> item){
            var siblings = item.getParent().getChildren();
            if(siblings.size() == 1) root.setBorder(Constants.DoubleBorder);
            else{
                var index = siblings.indexOf(item);
                if(index == 0) root.setBorder(Constants.TopBorder);
                else if (index == siblings.size() - 1) {
                    root.setBorder(Constants.BottomBorder);
                }
            }
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 2 * numColumnWidth;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            head.setWrappingWidth(remainder);
            return head.prefHeight(remainder);
        }
    }
}
