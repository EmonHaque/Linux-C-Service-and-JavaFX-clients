package Trees;

import model.ReportEntry;
import abstracts.WrapTreeCellBase;
import controls.texts.HiText;
import helpers.Constants;
import helpers.Helper;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

public class DateTree extends ExtendedTreeView<ReportEntry> {
    private final FilteredList<ReportEntry> list;
    public ObjectProperty<ReportEntry> selectedItem;

    public DateTree(FilteredList<ReportEntry> list) {
        this.list = list;
        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new Cell());

        selectedItem = new SimpleObjectProperty<>();
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        getSelectionModel().selectedItemProperty().addListener(this::onSelectionChange);
        list.addListener(this::onListChange);
    }

    private void onSelectionChange(Observable o, TreeItem<ReportEntry> ov, TreeItem<ReportEntry> nv){
        if(nv == null) selectedItem.set(null);
        if(getTreeItemLevel(nv) != 2) {
            selectedItem.set(null);
            return;
        }
        selectedItem.set(nv.getValue());
    }

    private void onListChange(ListChangeListener.Change<? extends ReportEntry> change){
        getRoot().getChildren().clear();
        for(var e : list){
            var hasIt = false;
            TreeItem<ReportEntry> item = null;
            for(var node : getRoot().getChildren()){
                if(node.getValue().getDeptId() == e.getDeptId()){
                    item = node;
                    item.getValue().setPayment(item.getValue().getPayment() + e.getPayment());
                    hasIt = true;
                    break;
                }
            }
            if(!hasIt){
                var newItem = new ReportEntry(){{
                    setDeptId(e.getDeptId());
                    setPayment(e.getPayment());
                }};
                item = new TreeItem<>(newItem);
                getRoot().getChildren().add(item);
            }
            item.getChildren().add(new TreeItem<>(e));
        }
    }

    private class Cell extends WrapTreeCellBase<ReportEntry>{
        private HiText particulars;
        private Text amount;
        private ColumnConstraints firstColumn;
        private Popup toolTip;
        private Text popText;
        private EventHandler<MouseEvent> enterEvent, exitEvent;

        @Override
        protected void initializeUI() {
            popText = new Text(){{ setFill(Color.WHITE);}};
            toolTip = new Popup() {{
                getContent().add(
                        new StackPane(popText){{
                            setPadding(new Insets(5));
                            setBackground(Background.fill(Constants.BackgroundColor));
                            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
                        }}
                );
            }};
            particulars = new HiText();
            amount = new Text() {{setFill(Color.WHITE);}};
            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(90) {{setHalignment(HPos.RIGHT);}}
                );
                add(particulars, 0, 0);
                add(amount, 1, 0);
            }};
        }

        @Override
        protected void resetValues(ReportEntry oldValue) {
            if(enterEvent != null)
                root.removeEventHandler(MouseEvent.MOUSE_ENTERED, enterEvent);
            if(exitEvent != null)
                root.removeEventHandler(MouseEvent.MOUSE_EXITED, exitEvent);

            root.setBorder(null);
            particulars.setText(null);
            particulars.queryProperty().unbind();
            particulars.queryProperty().set("");
            amount.textProperty().unbind();
            amount.setText(null);
        }

        @Override
        protected void setValues(ReportEntry newValue) {
            if(level == 1){
                var dept = AppData.departments.stream().filter(x -> x.getId() == newValue.getDeptId()).findFirst().get().getName();
                particulars.setText(dept + "(" + item.getChildren().size() + ")");
            }
            else {
                var siblings = item.getParent().getChildren();
                if(siblings.size() == 1) root.setBorder(Constants.DoubleBorder);
                else {
                    int index = siblings.indexOf(item);
                    if (index == 0) {
                        root.setBorder(Constants.TopBorder);
                    }
                    else if (index == siblings.size() - 1) {
                        root.setBorder(Constants.BottomBorder);
                    }
                }
                var account = AppData.accounts.stream().filter(x -> x.getId() == newValue.getAccountId()).findFirst().get();
                popText.setText(account.getAddress());
                particulars.setText(newValue.getAccountNo() + " | " + account.getHolder());

                enterEvent = this::onMouseEnter;
                exitEvent = this::onMouseExit;
                root.addEventHandler(MouseEvent.MOUSE_ENTERED, enterEvent);
                root.addEventHandler(MouseEvent.MOUSE_EXITED, exitEvent);
            }
            amount.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(newValue.getPayment()), newValue.paymentProperty()));
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 90;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            particulars.setPrefWidth(remainder);
            return particulars.prefHeight(remainder);
        }

        private void onMouseEnter(MouseEvent e){
            if(level != 2) return;
            toolTip.show(root, e.getScreenX() + 20, e.getScreenY() + 10);
        }

        private void onMouseExit(MouseEvent e){
            toolTip.hide();
        }
    }
}
