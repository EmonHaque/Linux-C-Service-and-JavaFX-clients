package Trees;

import model.Account;
import abstracts.WrapTreeCellBase;
import controls.texts.HiText;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.transformation.FilteredList;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import skinned.ExtendedTreeView;

public class AccountTree extends ExtendedTreeView<Account> {
    private final FilteredList<Account> list;
    public ObjectProperty<Account> selectedItem;

    public AccountTree(FilteredList<Account> list, StringProperty query) {
        this.list = list;
        selectedItem = new SimpleObjectProperty<>();
        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new Cell(query));

        list.addListener(this::onListChange);
        getSelectionModel().selectedItemProperty().addListener(this::onSelectionChange);
        addItem();
    }

    private void onSelectionChange(Observable o, TreeItem<Account> ov, TreeItem<Account> nv) {
        if (nv == null) selectedItem.set(null);
        else {
            if (getTreeItemLevel(nv) == 1) {
                selectedItem.set(null);
                return;
            }
            selectedItem.set(nv.getValue());
        }
    }

    private void onListChange(Observable o) {
        getRoot().getChildren().clear();
        addItem();
    }

    private void addItem() {
        for (var e : list) {
            var hasIt = false;
            TreeItem<Account> item = null;
            for (var branch : getRoot().getChildren()) {
                if (branch.getValue().getDepartmentName().equals(e.getDepartmentName())) {
                    item = branch;
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                var newItem = new Account() {{
                    setDepartmentName(e.getDepartmentName());
                }};
                item = new TreeItem<>(newItem) {{setExpanded(true);}};
                getRoot().getChildren().add(item);
            }
            item.getChildren().add(new TreeItem<>(e));
        }
    }

    private class Cell extends WrapTreeCellBase<Account> {
        private final StringProperty query;
        private HiText accountNo, name, address;

        public Cell(StringProperty query) {
            this.query = query;
        }

        @Override
        protected void initializeUI() {
            accountNo = new HiText();
            name = new HiText();
            address = new HiText();

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setPercentWidth(20);}},
                        new ColumnConstraints() {{setPercentWidth(40);}},
                        new ColumnConstraints() {{setPercentWidth(40);}}
                );
                add(accountNo, 0, 0);
                add(name, 1, 0);
                add(address, 2, 0);
            }};
        }

        @Override
        protected void resetValues(Account oldValue) {
            accountNo.textProperty().unbind();
            name.textProperty().unbind();
            address.textProperty().unbind();

            accountNo.queryProperty().unbind();
            name.queryProperty().unbind();
            address.queryProperty().unbind();

            accountNo.setText(null);
            name.setText(null);
            address.setText(null);

            accountNo.queryProperty().set("");
            name.queryProperty().set("");
            address.queryProperty().set("");
        }

        @Override
        protected void setValues(Account newValue) {
            if (level == 1) {
                accountNo.setText(newValue.getDepartmentName() + " (" + item.getChildren().size() + ")");
            }
            else {
                accountNo.textProperty().bind(newValue.nameProperty());
                name.textProperty().bind(newValue.holderProperty());
                address.textProperty().bind(newValue.addressProperty());
                accountNo.queryProperty().bind(query);
                name.queryProperty().bind(query);
                address.queryProperty().bind(query);
            }
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var width = getAvailableWidth();
            var firstColumnWidth = width * 0.2;
            var remainingColumnWidth = width * 0.4;
            return Math.max(
                    Math.max(name.prefHeight(remainingColumnWidth), address.prefHeight(remainingColumnWidth)),
                    accountNo.prefHeight(firstColumnWidth)
            );
        }
    }
}
