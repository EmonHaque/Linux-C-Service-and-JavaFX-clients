package Views;

import Views.Process.BillImage;
import Views.Process.Extracted;
import Views.Process.Finalize;
import Views.Process.Load;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.util.ArrayList;
import java.util.List;

public class ProcessView extends View {
    private final View load, extracted, bill, finalize;

    public ProcessView() {
        load = new Load();
        extracted = new Extracted();
        bill = new BillImage();
        finalize = new Finalize();
    }

    @Override
    protected String getIcon() {
        return Icons.Home;
    }

    @Override
    protected String getTip() {
        return "Home";
    }
    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public List<View> initialViews() {
        super.views = new ArrayList<>();
        views.add(load);
        views.add(bill);

        views.add(extracted);
        views.add(finalize);
        return super.views;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        setCenter(new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setPercentWidth(33.33);}},
                    new ColumnConstraints(){{ setPercentWidth(33.34);}},
                    new ColumnConstraints(){{ setPercentWidth(33.33);}}
            );
            getRowConstraints().addAll(
                    new RowConstraints(){{ setPercentHeight(50);}},
                    new RowConstraints(){{ setPercentHeight(50);}}
            );
            add(load, 0, 0, 1, 2);
            add(bill, 1, 0, 1, 2);
            add(extracted, 2, 0);
            add(finalize, 2, 1);

            setVgap(Constants.CardMargin);
            setHgap(Constants.CardMargin);
            setPadding(new Insets(Constants.CardMargin));
        }});
    }
}
