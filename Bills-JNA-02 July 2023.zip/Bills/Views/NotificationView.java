package Views;

import CellTemplates.ListView.NotificationCell;
import model.Notification;
import ViewModels.NotificationVM;
import abstracts.View;
import interfaces.INotifyCount;
import javafx.beans.property.IntegerProperty;
import javafx.scene.control.SelectionMode;
import skinned.ExtendedListView;

public class NotificationView extends View implements INotifyCount {
    private NotificationVM vm;
    private ExtendedListView<Notification> list;

    public NotificationView() {
        vm = new NotificationVM();
    }

    @Override
    protected String getHeader() {
        return "Notifications";
    }

    @Override
    protected String getTip() {
        return "Notifications";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();

        initializeUI();
        bind();
    }

    private void initializeUI() {
        list = new ExtendedListView<>(vm.list) {{
            setCellFactory(v -> new NotificationCell());
            getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            getSelectionModel().selectedItemProperty().addListener((o, ov, nv) -> {
                if (nv != null) {
                    if (nv.isIsRead()) return;
                    nv.setIsRead(true);
                    vm.countProperty.set(vm.countProperty.get() - 1);
                }
            });
        }};
        setCenter(list);
    }

    private void bind() {

    }

    @Override
    public IntegerProperty countProperty() {
        return vm.countProperty;
    }
}
