package Views.Search;

import CellTemplates.ListView.LedgerTemplate;
import CellTemplates.SelectionBox.AccountTemplate;
import CellTemplates.Visual.AccountVisual;
import ChartControls.BillPaymentChart;
import model.Account;
import model.ReportEntry;
import ViewModels.Search.DepartmentSearchVM;
import controls.SelectionBox;
import controls.SortHeader;
import controls.buttons.CommandButton;
import helpers.Constants;
import helpers.Helper;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import skinned.ExtendedListView;

public abstract class DepartmentSearch extends SearchBase{
    private SelectionBox<Account> select;
    private ExtendedListView<ReportEntry> list;
    private CommandButton refresh;
    private BillPaymentChart bpChart;
    private Text entries, totalBill, totalPayment;

    @Override
    protected String getHeader() {
        return ((DepartmentSearchVM)getViewModel()).getDepartmentName();
    }

    @Override
    protected String getTip() { return getHeader(); }

    @Override
    protected Node getLeftView() {
        var vm = (DepartmentSearchVM)viewModel;
        select = new SelectionBox<>("Account", Icons.Space, vm.selectionList, new AccountVisual(), AccountTemplate.class.getName(), false);
        refresh = new CommandButton(Icons.Reload, 16, "refresh");
        var hBox = new HBox(select, refresh){{
            setHgrow(select, Priority.ALWAYS);
            setSpacing(5);
            setMargin(refresh, new Insets(0,0,4,0));
            setAlignment(Pos.BOTTOM_RIGHT);
        }};
        list = new ExtendedListView<>(vm.reportable);
        list.setCellFactory(v -> new LedgerTemplate(query.textProperty()));
        return new VBox(hBox, query, getLeftTableHeader(), list, getRightTableFooter()){{
            setVgrow(list, Priority.ALWAYS);
            setSpacing(5);
        }};
    }

    @Override
    protected Node getTopRightView() {
        bpChart = new BillPaymentChart();
        GridPane.setMargin(bpChart, new Insets(20, 0, 10, 0));
        return bpChart;
    }

    @Override
    protected void bind() {
        super.bind();
        var vm = (DepartmentSearchVM)viewModel;
        refresh.setAction(vm::refresh);
        refresh.disableProperty().bind(select.isEmpty());

        vm.selectedEntry.bind(list.getSelectionModel().selectedItemProperty());
        vm.selectedId.bind(select.selectedValueProperty());

        entries.textProperty().bind(Bindings.size(vm.reportable).asString("%,d"));
        totalBill.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(vm.totalBill.get()), vm.totalBill));
        totalPayment.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(vm.totalPayment.get()), vm.totalPayment));
        bpChart.seriesProperty.bind(vm.billPaymentSeries);
    }

    private Node getLeftTableHeader(){
        var vm = (DepartmentSearchVM)viewModel;
        var date = new SortHeader("Date", true, vm::sort);
        //var date = new Text("Date"){{ setFill(Color.WHITE);}};
        var particulars = new Text("Particulars"){{ setFill(Color.WHITE);}};
        var bill = new Text("Bill"){{ setFill(Color.WHITE);}};
        var payment = new Text("Payment"){{ setFill(Color.WHITE);}};

        return new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(90),
                    new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(90){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(90){{ setHalignment(HPos.RIGHT);}}
            );
            add(date, 0, 0);
            add(particulars, 1, 0);
            add(bill, 2, 0);
            add(payment, 3, 0);

            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.BottomBorder);
        }};
    }

    private Node getRightTableFooter(){
        entries = new Text(){{ setFill(Color.WHITE);}};
        totalBill = new Text(){{ setFill(Color.WHITE);}};
        totalPayment = new Text(){{ setFill(Color.WHITE);}};
        var flow = new TextFlow(){{
            getChildren().addAll(
                    new Text("Total of "){{ setFill(Color.WHITE);}},
                    entries
            );
        }};

        return new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(90){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(90){{ setHalignment(HPos.RIGHT);}}
            );
            add(flow, 0, 0);
            add(totalBill, 1, 0);
            add(totalPayment, 2, 0);

            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.TopBorder);
        }};
    }
}
