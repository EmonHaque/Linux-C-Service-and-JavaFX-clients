package Views.Search;

import CellTemplates.ListView.AccountPaymentSummaryTemplate;
import CellTemplates.SelectionBox.MobileTemplate;
import CellTemplates.Visual.MobileVisual;
import model.AccountPaymentSummary;
import model.Mobile;
import Trees.MobileTree;
import ViewModels.Search.MobileSearchVM;
import ViewModels.Search.SearchBaseVM;
import controls.SelectionBox;
import controls.SortHeader;
import controls.buttons.CommandButton;
import controls.piechart.Pie;
import helpers.Constants;
import helpers.Helper;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import skinned.ExtendedListView;

public class MobileSearch extends SearchBase {
    private SelectionBox<Mobile> select;
    private MobileTree tree;
    private CommandButton refresh;
    private Text leftEntries, leftPayment, rightEntries, rightPayment;
    private Pie summaryPie;
    private ExtendedListView<AccountPaymentSummary> accountWisePayment;
    MobileSearchVM vm;

    @Override
    protected String getHeader() {
        return "Mobile";
    }

    @Override
    protected String getIcon() {
        return Icons.Mobile;
    }

    @Override
    protected String getTip() {
        return getHeader();
    }


    @Override
    protected SearchBaseVM getViewModel() {
        vm = new MobileSearchVM();
        return vm;
    }

    @Override
    protected Node getLeftView() {
        select = new SelectionBox<>("Account", Icons.Space, vm.selectionList, new MobileVisual(), MobileTemplate.class.getName(), false);
        refresh = new CommandButton(Icons.Reload, 16, "refresh");
        var hBox = new HBox(select, refresh){{
            setHgrow(select, Priority.ALWAYS);
            setSpacing(5);
            setMargin(refresh, new Insets(0,0,4,0));
            setAlignment(Pos.BOTTOM_RIGHT);
        }};
        tree = new MobileTree(vm.reportable);
        return new VBox(hBox, query, getLeftTableHeader(), tree, getLeftTableFooter()) {{
            setVgrow(tree, Priority.ALWAYS);
            setSpacing(5);
        }};
    }

    @Override
    protected Node getTopRightView() {
        summaryPie = new Pie();

        rightEntries = new Text(){{ setFill(Color.WHITE);}};
        rightPayment = new Text(){{ setFill(Color.WHITE);}};

        var header = new GridPane(){{
           getColumnConstraints().addAll(
                   new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                   new ColumnConstraints(100){{ setHalignment(HPos.RIGHT);}}
           );
           add(new Text("Account"){{ setFill(Color.WHITE);}}, 0, 0);
           add(new Text("Amount"){{ setFill(Color.WHITE);}}, 1, 0);
           setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
           setBorder(Constants.BottomBorder);
        }};

        var totalFlow = new TextFlow(){{
            getChildren().addAll(
                    new Text("Total of "){{ setFill(Color.WHITE);}},
                    rightEntries,
                    new Text(" entries"){{ setFill(Color.WHITE);}}
            );
        }};

        var footer = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(100){{ setHalignment(HPos.RIGHT);}}
            );
            add(totalFlow, 0, 0);
            add(rightPayment, 1, 0);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.TopBorder);
        }};
        accountWisePayment = new ExtendedListView<>(vm.accountWiseList);
        accountWisePayment.setCellFactory(v -> new AccountPaymentSummaryTemplate());

        var box = new VBox(header, accountWisePayment, footer){{
            setPadding(new Insets(10,0,0,0));
        }};

        return new GridPane(){{
            getRowConstraints().add(new RowConstraints(){{ setPercentHeight(100);}});
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setPercentWidth(50);}},
                    new ColumnConstraints(){{ setPercentWidth(50);}}
            );
            add(summaryPie, 0, 0);
            add(box, 1, 0);

            setValignment(box, VPos.CENTER);
        }};
    }

    @Override
    protected void bind() {
        super.bind();
        refresh.setAction(vm::refresh);
        refresh.disableProperty().bind(select.isEmpty());
        vm.selectedId.bind(select.selectedValueProperty());
        vm.query.bind(query.textProperty());
        leftEntries.textProperty().bind(Bindings.size(vm.reportable).asString("%,d"));
        leftPayment.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(vm.totalPayment.get()), vm.totalPayment));
        vm.selectedEntry.bind(tree.selectedItem);

        summaryPie.seriesProperty.bind(vm.pieSeries);
        vm.selectedSlice.bind(summaryPie.selectedSliceProperty);
        rightEntries.textProperty().bind(Bindings.size(vm.accountWiseList).asString("%,d"));
        rightPayment.textProperty().bind(Bindings.createStringBinding(() -> {
            var slice = summaryPie.selectedSliceProperty.get();
            if(slice == null) return "    -  ";
            return Helper.formatNumber(summaryPie.selectedSliceProperty.get().value);
        }, summaryPie.selectedSliceProperty));
    }

    private Node getLeftTableHeader() {
        var particulars = new SortHeader("Particulars", true, tree::sort);
        var payment = new Text("Payment") {{setFill(Color.WHITE);}};
        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(90) {{setHalignment(HPos.RIGHT);}}
            );
            add(particulars, 0, 0);
            add(payment, 1, 0);

            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.BottomBorder);
        }};
    }

    private Node getLeftTableFooter() {
        leftEntries = new Text() {{setFill(Color.WHITE);}};
        leftPayment = new Text() {{setFill(Color.WHITE);}};
        var flow = new TextFlow() {{
            getChildren().addAll(
                    new Text("Total of ") {{setFill(Color.WHITE);}},
                    leftEntries,
                    new Text(" entries") {{setFill(Color.WHITE);}}
            );
        }};
        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(90) {{setHalignment(HPos.RIGHT);}}
            );
            add(flow, 0, 0);
            add(leftPayment, 1, 0);

            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.TopBorder);
        }};
    }
}
