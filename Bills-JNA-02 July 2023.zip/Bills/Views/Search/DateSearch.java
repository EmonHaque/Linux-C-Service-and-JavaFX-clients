package Views.Search;

import CellTemplates.ListView.DatePaymentSummaryTemplate;
import model.DatePaymentSummary;
import Trees.DateTree;
import ViewModels.Search.DateSearchVM;
import ViewModels.Search.SearchBaseVM;
import controls.buttons.CommandButton;
import controls.daymonth.DayPicker;
import controls.piechart.Pie;
import helpers.Constants;
import helpers.Helper;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import skinned.ExtendedListView;

public class DateSearch extends SearchBase{
    private DayPicker date;
    private DateTree tree;
    private Text leftEntries, leftPayment, rightEntries, rightBill, rightPayment;
    private CommandButton refresh;
    private Pie summaryPie;
    private ExtendedListView<DatePaymentSummary> summaryBreakupView;
    DateSearchVM vm;

    @Override
    protected String getHeader() {
        return "Date";
    }

    @Override
    protected String getIcon() {
        return Icons.Month;
    }

    @Override
    protected String getTip() {
        return getHeader();
    }


    @Override
    protected SearchBaseVM getViewModel() {
        vm = new DateSearchVM();
        return vm;
    }

    @Override
    protected Node getLeftView() {
        date = new DayPicker("Date", Icons.Month, false);
        refresh = new CommandButton(Icons.Reload, 16, "refresh");
        var hBox = new HBox(date, refresh){{
            setHgrow(date, Priority.ALWAYS);
            setSpacing(5);
            setMargin(refresh, new Insets(0,0,4,0));
            setAlignment(Pos.BOTTOM_RIGHT);
        }};
        tree = new DateTree(vm.reportable);
        return new VBox(hBox, query, getLeftTableHeader(), tree, getLeftTableFooter()) {{
            setVgrow(tree, Priority.ALWAYS);
            setSpacing(5);
        }};
    }

    @Override
    protected Node getTopRightView() {
        summaryPie = new Pie();

        var header = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Department"){{ setFill(Color.WHITE);}}, 0, 0);
            add(new Text("Payment"){{ setFill(Color.WHITE);}}, 1, 0);
            add(new Text("Bill"){{ setFill(Color.WHITE);}}, 2, 0);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.BottomBorder);
        }};

        rightEntries = new Text(){{ setFill(Color.WHITE);}};
        rightPayment = new Text(){{ setFill(Color.WHITE);}};
        rightBill = new Text(){{ setFill(Color.WHITE);}};

        var totalFlow = new TextFlow(){{
            getChildren().addAll(
                    new Text("Total of "){{ setFill(Color.WHITE);}},
                    rightEntries
            );
        }};

        var footer = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}}
            );
            add(totalFlow, 0, 0);
            add(rightPayment, 1, 0);
            add(rightBill, 2, 0);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.TopBorder);
        }};

        summaryBreakupView = new ExtendedListView<>(vm.summaryPaymentList);
        summaryBreakupView.setCellFactory(v -> new DatePaymentSummaryTemplate());

        var box = new VBox(header, summaryBreakupView, footer){{
            setPadding(new Insets(10,0,0,0));
        }};

        return new GridPane(){{
            getRowConstraints().add(new RowConstraints(){{setPercentHeight(100);}});
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setPercentWidth(40);}},
                    new ColumnConstraints(){{ setPercentWidth(60);}}
            );
            add(summaryPie, 0, 0);
            add(box, 1, 0);
        }};
    }

    @Override
    protected void bind() {
        super.bind();
        refresh.setAction(vm::refresh);
        refresh.disableProperty().bind(date.isEmpty());
        vm.selectedDate.bind(date.selectedDateProperty());
        vm.query.bind(query.textProperty());
        leftEntries.textProperty().bind(Bindings.size(vm.reportable).asString("%,d"));
        leftPayment.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(vm.totalPaymentLeft.get()), vm.totalPaymentLeft));
        vm.selectedEntry.bind(tree.selectedItem);

        summaryPie.seriesProperty.bind(vm.pieSeries);
        vm.selectedSlice.bind(summaryPie.selectedSliceProperty);
        rightEntries.textProperty().bind(Bindings.size(vm.summaryPaymentList).asString("%,d"));
        rightBill.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(vm.totalBillRight.get()), vm.totalBillRight));
        rightPayment.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(vm.totalPaymentRight.get()), vm.totalPaymentRight));
    }

    private Node getLeftTableHeader() {
        var particulars = new Text("Particulars") {{setFill(Color.WHITE);}};
        var payment = new Text("Payment") {{setFill(Color.WHITE);}};
        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(90) {{setHalignment(HPos.RIGHT);}}
            );
            add(particulars, 0, 0);
            add(payment, 1, 0);

            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.BottomBorder);
        }};
    }

    private Node getLeftTableFooter() {
        leftEntries = new Text() {{setFill(Color.WHITE);}};
        leftPayment = new Text() {{setFill(Color.WHITE);}};
        var flow = new TextFlow() {{
            getChildren().addAll(
                    new Text("Total of ") {{setFill(Color.WHITE);}},
                    leftEntries,
                    new Text(" entries") {{setFill(Color.WHITE);}}
            );
        }};
        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(90) {{setHalignment(HPos.RIGHT);}}
            );
            add(flow, 0, 0);
            add(leftPayment, 1, 0);

            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.TopBorder);
        }};
    }
}
