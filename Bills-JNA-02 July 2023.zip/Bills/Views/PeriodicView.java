package Views;

import CellTemplates.ListView.DayMonthSummaryTemplate;
import CellTemplates.ListView.PaymentSummaryTemplate;
import ChartControls.BillPaymentChart;
import model.DayMonthSummary;
import model.PaymentSummary;
import Trees.PeriodicTree;
import Trees.HeadWiseTree;
import ViewModels.PeriodicVM;
import abstracts.View;
import controls.SortHeader;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.daymonth.DayPicker;
import controls.piechart.Pie;
import controls.states.MultiState;
import helpers.Constants;
import helpers.Helper;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.*;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import skinned.ExtendedListView;
import skinned.ExtendedSeparator;

public class PeriodicView extends View {
    private DayPicker start, end;
    private MultiState dateMonthState, mobileAccountState;
    private Text status, forPeriod, dayMonthEntries, headWiseEntries, dayMonthBill, headWiseBill,
            dayMonthPayment, headWisePayment, departmentPayment;
    private BillPaymentChart bpChart;
    private Pie pie;
    private SpinningArc spinner;
    private CommandButton refresh;
    private HeadWiseTree bottomLeftList;
    private ExtendedListView<DayMonthSummary> dayMonthWiseList;
    private ExtendedListView<PaymentSummary> paymentSummaries;
    private PeriodicTree middleTree;
    private GridPane topGrid, leftGrid, middleGrid, rightGrid;
    private VBox bottomRightBox;
    private PeriodicVM vm;
    private final double numColumnWidth = 100;

    @Override
    protected String getHeader() {
        return "Periodic";
    }

    @Override
    protected String getTip() {
        return getHeader();
    }

    @Override
    protected String getIcon() {
        return Icons.Sum;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new PeriodicVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        initializeTopGrid();
        initializeLeftGrid();
        initializeMiddleGrid();
        initializeRightGrid();

        var mainGrid = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(30);}},
                    new ColumnConstraints() {{setPercentWidth(0.5);}},
                    new ColumnConstraints() {{setPercentWidth(39);}},
                    new ColumnConstraints() {{setPercentWidth(0.5);}},
                    new ColumnConstraints() {{setPercentWidth(30);}}
            );
            add(topGrid, 0, 0, 5, 1);
            add(leftGrid, 0, 1);
            add(new ExtendedSeparator() {{setOrientation(Orientation.VERTICAL);}}, 1, 0, 1, 2);
            add(middleGrid, 2, 1);
            add(new ExtendedSeparator() {{setOrientation(Orientation.VERTICAL);}}, 3, 1);
            add(rightGrid, 4, 1);
        }};

        setCenter(mainGrid);

        status = new Text(){{ setFill(Color.WHITE);}};
        spinner = new SpinningArc();
        addAction(spinner);
        addAction(status);
    }

    private void initializeTopGrid() {
        dateMonthState = new MultiState(new String[]{Icons.CalendarEdit, Icons.Month}, new String[]{"Date", "Month"}, false) {{
            setAlignment(Pos.BOTTOM_RIGHT);
            setPadding(new Insets(0, 5, 5, 0));
        }};
        mobileAccountState = new MultiState(new String[]{Icons.Mobile, Icons.ControlHead}, new String[]{"Mobile", "Account"}, true) {{
            setAlignment(Pos.BOTTOM_LEFT);
            setPadding(new Insets(0, 0, 5, 10));
        }};
        forPeriod = new Text("for the period") {{setFill(Color.WHITE);}};
        start = new DayPicker("from", Icons.Month, true);
        end = new DayPicker("to", Icons.Month, true);
        refresh = new CommandButton(Icons.Reload, 16, "refresh");

        var dateBox = new HBox(start, end, refresh) {{
            setHgrow(start, Priority.ALWAYS);
            setHgrow(end, Priority.ALWAYS);
            setSpacing(5);
            setAlignment(Pos.BOTTOM_RIGHT);
            setMargin(refresh, new Insets(0, 0, 4, 0));
        }};
        topGrid = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(30); setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints() {{setPercentWidth(30);}},
                    new ColumnConstraints() {{setPercentWidth(40);}}
            );
            add(dateMonthState, 0, 0);
            add(mobileAccountState, 1, 0);
            add(forPeriod, 1, 0);
            add(dateBox, 2, 0);

            setMargin(forPeriod, new Insets(0, 10, 6, 0));
            setValignment(forPeriod, VPos.BOTTOM);
            setHalignment(forPeriod, HPos.RIGHT);
            setPadding(new Insets(5, 0, 5, 0));
        }};
    }

    private void initializeLeftGrid() {
        var header1 = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}}
            );
            add(new SortHeader("Date / Month ", true, vm::sortDayMonthList), 0, 0);
            add(new Text("Bill") {{setFill(Color.WHITE);}}, 1, 0);
            add(new Text("Payment") {{setFill(Color.WHITE);}}, 2, 0);
            setBorder(Constants.BottomBorder);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};

        var header2 = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Head") {{setFill(Color.WHITE);}}, 0, 0);
            add(new Text("Bill") {{setFill(Color.WHITE);}}, 1, 0);
            add(new Text("Payment") {{setFill(Color.WHITE);}}, 2, 0);
            setBorder(Constants.BottomBorder);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};

        dayMonthEntries = new Text() {{setFill(Color.WHITE);}};
        dayMonthBill = new Text() {{setFill(Color.WHITE);}};
        dayMonthPayment = new Text() {{setFill(Color.WHITE);}};
        var topLeftFlow = new TextFlow() {{
            getChildren().addAll(
                    new Text("Total of ") {{setFill(Color.WHITE);}},
                    dayMonthEntries,
                    new Text(" entries") {{setFill(Color.WHITE);}}
            );
        }};
        var footer1 = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}}
            );
            add(topLeftFlow, 0, 0);
            add(dayMonthBill, 1, 0);
            add(dayMonthPayment, 2, 0);
            setBorder(Constants.TopBorder);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};

        headWiseEntries = new Text() {{setFill(Color.WHITE);}};
        headWiseBill = new Text() {{setFill(Color.WHITE);}};
        headWisePayment = new Text() {{setFill(Color.WHITE);}};
        var bottomLeftFlow = new TextFlow() {{
            getChildren().addAll(
                    new Text("Total of ") {{setFill(Color.WHITE);}},
                    headWiseEntries,
                    new Text(" entries") {{setFill(Color.WHITE);}}
            );
        }};
        var footer2 = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}}
            );
            add(bottomLeftFlow, 0, 0);
            add(headWiseBill, 1, 0);
            add(headWisePayment, 2, 0);
            setBorder(Constants.TopBorder);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};

        dayMonthWiseList = new ExtendedListView<>(vm.dayMonthList);
        bottomLeftList = new HeadWiseTree(vm.headWiseSummaries);
        leftGrid = new GridPane() {{
            getColumnConstraints().add(new ColumnConstraints() {{setPercentWidth(100);}});
            getRowConstraints().addAll(
                    new RowConstraints(),
                    new RowConstraints() {{setVgrow(Priority.ALWAYS);}},
                    new RowConstraints(),
                    new RowConstraints(15),
                    new RowConstraints(),
                    new RowConstraints() {{setVgrow(Priority.ALWAYS);}},
                    new RowConstraints()
            );
            add(header1, 0, 0);
            add(dayMonthWiseList, 0, 1);
            add(footer1, 0, 2);
            add(header2, 0, 4);
            add(bottomLeftList, 0, 5);
            add(footer2, 0, 6);
        }};
    }

    private void initializeMiddleGrid() {
        var header = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Particulars") {{setFill(Color.WHITE);}}, 0, 0);
            add(new Text("Bill") {{setFill(Color.WHITE);}}, 1, 0);
            add(new Text("Payment") {{setFill(Color.WHITE);}}, 2, 0);
            setBorder(Constants.BottomBorder);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};
        middleTree = new PeriodicTree(vm.secondaryList, mobileAccountState);
        middleGrid = new GridPane() {{
            getColumnConstraints().add(new ColumnConstraints() {{setPercentWidth(100);}});
            getRowConstraints().addAll(
                    new RowConstraints(),
                    new RowConstraints() {{setVgrow(Priority.ALWAYS);}}
            );
            add(header, 0, 0);
            add(middleTree, 0, 1);
        }};
    }

    private void initializeRightGrid() {
        bpChart = new BillPaymentChart();
        pie = new Pie();

        var header = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Head") {{setFill(Color.WHITE);}}, 0, 0);
            add(new Text("Amount") {{setFill(Color.WHITE);}}, 1, 0);
            setBorder(Constants.BottomBorder);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};
        departmentPayment = new Text("0"){{ setFill(Color.WHITE);}};
        var footer = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(numColumnWidth) {{setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Total"){{ setFill(Color.WHITE);}}, 0, 0);
            add(departmentPayment, 1, 0);
            setBorder(Constants.TopBorder);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};
        paymentSummaries = new ExtendedListView<>(vm.paymentList);
        bottomRightBox = new VBox(header, paymentSummaries, footer);
        rightGrid = new GridPane() {{
            getColumnConstraints().add(new ColumnConstraints() {{setPercentWidth(100);}});
            getRowConstraints().addAll(
                    new RowConstraints() {{setPercentHeight(33);}},
                    new RowConstraints() {{setPercentHeight(34);}},
                    new RowConstraints() {{setPercentHeight(33);}}
            );
            add(bpChart, 0, 0);
            add(pie, 0, 1);
            add(bottomRightBox, 0, 2);

            setMargin(bpChart, new Insets(20, 0, 0, 0));
        }};
    }

    private void bind() {
        start.selectedDateProperty().bindBidirectional(vm.startDate);
        end.selectedDateProperty().bindBidirectional(vm.endDate);
        refresh.setAction(vm::refresh);
        vm.dayMonthState.bind(dateMonthState.stateProperty);
        bottomRightBox.visibleProperty().bind(pie.selectedSliceProperty.isNotNull());

        bpChart.seriesProperty.bind(vm.billPaymentSeries);
        pie.seriesProperty.bind(vm.pieSeries);
        vm.selectedSlice.bind(pie.selectedSliceProperty);

        dayMonthWiseList.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        paymentSummaries.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        vm.selectedEntry.bind(dayMonthWiseList.getSelectionModel().selectedItemProperty());
        dayMonthWiseList.setCellFactory(v -> new DayMonthSummaryTemplate());
        paymentSummaries.setCellFactory(x -> new PaymentSummaryTemplate());

        dayMonthEntries.textProperty().bind(Bindings.size(vm.dayMonthList).asString("%,d"));
        dayMonthBill.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(vm.dayMonthBill.get()), vm.dayMonthBill));
        dayMonthPayment.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(vm.dayMonthPayment.get()), vm.dayMonthPayment));

        headWiseEntries.textProperty().bind(Bindings.size(vm.headWiseSummaries).asString("%,d"));

        headWiseBill.textProperty().bind(Bindings.createStringBinding(
                () -> Helper.formatNumber(vm.selectedEntry.get() != null ?
                            vm.selectedEntry.get().getBill() : vm.dayMonthBill.get()),
                vm.dayMonthBill, vm.selectedEntry));

        headWisePayment.textProperty().bind(Bindings.createStringBinding(
                () -> Helper.formatNumber(vm.selectedEntry.get() != null ?
                            vm.selectedEntry.get().getPayment() : vm.dayMonthPayment.get()),
                vm.dayMonthPayment, vm.selectedEntry));

        departmentPayment.textProperty().bind(Bindings.createStringBinding(
                () -> Helper.formatNumber(vm.selectedSlice.get() == null ?
                           0 : vm.selectedSlice.get().value),
                vm.selectedSlice
        ));

        status.textProperty().bind(vm.status);
        spinner.visibleProperty().bind(vm.isRunning);

        refresh.disableProperty().bind(vm.isRunning);
        dateMonthState.disableProperty().bind(vm.isRunning);
        mobileAccountState.disableProperty().bind(vm.isRunning);
    }
}
