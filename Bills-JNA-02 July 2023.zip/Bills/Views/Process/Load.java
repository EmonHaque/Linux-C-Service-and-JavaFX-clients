package Views.Process;

import model.RawInfo;
import Trees.LoadTree;
import ViewModels.Process.FinalizeVM;
import ViewModels.Process.LoadVM;
import abstracts.View;
import controls.SpinningArcFinite;
import controls.buttons.CommandButton;
import controls.texts.TextBox;
import dialogs.InfoKeyValueDialog;
import helpers.Constants;
import helpers.Helper;
import helpers.Icons;
import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.collections.ListChangeListener;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

public class Load extends View {
    private CommandButton open;
    private TextBox query;
    private Text status, totalPayment, totalEntries;
    private TextFlow totalFlow;
    private LoadTree tree;
    private CommandButton add;
    private SpinningArcFinite progress;
    private LoadVM vm;

    @Override
    protected String getHeader() {
        return "Load";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new LoadVM();
        initializeUI();
        bind();

        //otherwise cursor will be blinking in query TextBox
        Platform.runLater(() -> tree.requestFocus());
    }

    private void initializeUI(){
        query = new TextBox("Search", Icons.Magnify, false);
        open = new CommandButton(Icons.DirectoryOpen, 16, "choose directory");
        status = new Text(){{ setFill(Color.WHITE);}};
        progress = new SpinningArcFinite();
        var queryBox = new HBox(query, open){{
            setSpacing(5);
            setHgrow(query, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_RIGHT);
        }};
        var progressStatusBox = new HBox(progress, status){{
            setPadding(new Insets(5,Constants.ScrollBarSize + Constants.CellPadding,0,0));
            setSpacing(5);
            setAlignment(Pos.CENTER_RIGHT);
        }};
        tree = new LoadTree(vm.list, vm::remove);
        totalEntries = new Text(){{ setFill(Color.WHITE);}};
        totalPayment = new Text("0"){{ setFill(Color.WHITE);}};
        totalFlow = new TextFlow(){{
           getChildren().addAll(
                   new Text("Total of "){{ setFill(Color.WHITE);}},
                   totalEntries,
                   new Text(" item"){{ setFill(Color.WHITE);}}
           );
        }};
        add = new CommandButton(Icons.Add, 16, "add");
        var bottomBorder = new BorderPane(){{
            setCenter(totalFlow);
            setRight(totalPayment);
            setBottom(add);

            setAlignment(add, Pos.CENTER_RIGHT);
            setBorder(Constants.TopBorder);
            setMargin(totalPayment, new Insets(0, Constants.ScrollBarSize, 0, 0));
        }};

        setCenter(new VBox(queryBox, progressStatusBox, tree, bottomBorder){{
            setVgrow(tree, Priority.ALWAYS);
        }});
    }

    private void bind(){
        open.setAction(vm::onDirectoryChanged);
        add.setAction(vm::add);
        status.textProperty().bind(vm.status);
        progress.progressProperty().bind(vm.progress);
        totalEntries.textProperty().bind(Bindings.size(vm.list).asString());

        vm.selectedItem.bindBidirectional(tree.selectedItem);
        vm.selectedItem.addListener((o, ov, nv) ->{
            if(nv == null){
                Extracted.text.setText("");
                BillImage.file.set(null);
                FinalizeVM.info.set(null);
            }
            else{
                Extracted.text.setText(nv.getRawText());
                BillImage.file.set(nv.getFilePath());
                FinalizeVM.info.set(nv);
            }
        });

        // inefficient?
        vm.list.addListener((ListChangeListener<? super RawInfo>)  o -> {
            totalPayment.textProperty().unbind();
            totalPayment.textProperty().bind(Bindings.createStringBinding(() ->{
                double total = 0;
                for(var item : vm.list){
                    total += item.getTotalPayment();
                }
                return Helper.formatNumber(total);

            }, vm.list.stream().map(RawInfo::totalPaymentProperty).toArray(Observable[]::new)));
        });

        vm.duplicateTrigger.addListener((o, ov, nv) ->{
            if(nv){
                var dialog = new InfoKeyValueDialog("File exists", vm.duplicateList);
                var bound = localToScreen(getBoundsInLocal());
                dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
                vm.duplicateTrigger.set(false);
            }
        });
    }
}
