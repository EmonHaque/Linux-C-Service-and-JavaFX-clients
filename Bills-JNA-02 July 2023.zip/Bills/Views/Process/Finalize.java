package Views.Process;

import Dialogs.AccountCreateDialog;
import Dialogs.MobileCreateDialog;
import model.Account;
import model.Department;
import model.Head;
import model.Mobile;
import ViewModels.Process.FinalizeVM;
import abstracts.View;
import controls.SpinningArc;
import controls.SumBox;
import controls.buttons.CommandButton;
import controls.texts.TextBox;
import dialogs.ConfirmDialog;
import dialogs.ConfirmKeyValueDialog;
import dialogs.InfoDialog;
import dialogs.InfoKeyValueDialog;
import helpers.Icons;
import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import ridiculous.AppData;

public class Finalize extends View {
    private TextBox department, transactionNo, paidForm, date, customerNo, billNo, period;
    private Text status;
    private SpinningArc spinner;
    private SumBox<String> billDetail, paymentDetail;
    private CommandButton update;
    private FinalizeVM vm;
    private ObservableList<String> suggestionList;
    private ChangeListener<Boolean> paymentDetailListener, billDetailListener;

    @Override
    protected String getHeader() {
        return "Finalize";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new FinalizeVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        department = new TextBox("Department", Icons.Description, true);
        transactionNo = new TextBox("Transaction No", Icons.Magnify, true);
        paidForm = new TextBox("Paid from", Icons.Mobile, true);
        date = new TextBox("Date", Icons.Month, true) {{
            setErrorText("yyyy-mm-dd required");
        }};
        customerNo = new TextBox("Customer No", Icons.DirectoryOpen, true);
        billNo = new TextBox("Bill No", Icons.ImageColor, false);
        period = new TextBox("Period", Icons.Description, true);

        suggestionList = FXCollections.observableArrayList(AppData.heads.stream().map(Head::getName).toList());
        paymentDetail = new SumBox<>(suggestionList, null, null) {{
            setHeader("Payments");
        }};
        billDetail = new SumBox<>(suggestionList, null, null) {{
            setHeader("Bills");
        }};

        update = new CommandButton(Icons.CheckCircle, 16, "Finalize");

        setCenter(new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{
                        setPercentWidth(50);
                    }},
                    new ColumnConstraints() {{
                        setPercentWidth(50);
                    }}
            );
            add(department, 0, 0);
            add(transactionNo, 1, 0);
            add(paidForm, 0, 1);
            add(date, 1, 1);
            add(customerNo, 0, 2);
            add(billNo, 1, 2);
            add(period, 0, 3, 2, 1);
            add(paymentDetail, 0, 4);
            add(billDetail, 1, 4);

            setHgap(5);
            setVgap(5);
            setPadding(new Insets(5, 0, 0, 0));
        }});

        status = new Text() {{
            setFill(Color.WHITE);
        }};
        spinner = new SpinningArc();

        addAction(spinner);
        addAction(status);
        addAction(update);
    }

    private void bind() {
        getCenter().visibleProperty().bind(FinalizeVM.info.isNotNull());
        update.visibleProperty().bind(FinalizeVM.info.isNotNull());
        update.setAction(vm::setOk);
        status.textProperty().bind(vm.status);
        spinner.visibleProperty().bind(vm.isRunning);
        bindDialogs();

        AppData.onHeadAdded.addListener((o, ov, nv) -> {
            for (var head : nv) {
                suggestionList.add(head.getName());
            }
        });

        paymentDetailListener = this::onSumBoxModified;
        billDetailListener = this::onSumBoxModified;

        FinalizeVM.info.addListener((o, ov, nv) -> {
            if (ov != null) {
                department.textProperty().unbindBidirectional(ov.deptNameProperty());
                transactionNo.textProperty().unbindBidirectional(ov.transactionNoProperty());
                paidForm.textProperty().unbindBidirectional(ov.paidFromProperty());
                date.textProperty().unbindBidirectional(ov.paymentDateProperty());
                customerNo.textProperty().unbindBidirectional(ov.customerNoProperty());
                billNo.textProperty().unbindBidirectional(ov.billNoProperty());
                period.textProperty().unbindBidirectional(ov.periodProperty());
                paymentDetail.modifiedProperty().removeListener(paymentDetailListener);
                billDetail.modifiedProperty().removeListener(billDetailListener);

                ov.totalPaymentProperty().unbind(); // weak ?
                ov.totalBillProperty().unbind();
                update.disableProperty().unbind();
            }
            if (nv != null) {
                department.textProperty().bindBidirectional(nv.deptNameProperty());
                transactionNo.textProperty().bindBidirectional(nv.transactionNoProperty());
                paidForm.textProperty().bindBidirectional(nv.paidFromProperty());
                date.textProperty().bindBidirectional(nv.paymentDateProperty());
                customerNo.textProperty().bindBidirectional(nv.customerNoProperty());
                billNo.textProperty().bindBidirectional(nv.billNoProperty());
                period.textProperty().bindBidirectional(nv.periodProperty());

                paymentDetail.setList(FinalizeVM.info.get().getPaymentInfo());
                billDetail.setList(FinalizeVM.info.get().getBillInfo());

                nv.totalPaymentProperty().bind(paymentDetail.sumProperty());
                nv.totalBillProperty().bind(billDetail.sumProperty());

                paymentDetail.modifiedProperty().addListener(paymentDetailListener);
                billDetail.modifiedProperty().addListener(billDetailListener);
                update.disableProperty().bind(nv.isOkProperty());
            }
        });
    }

    private void bindDialogs() {
        vm.errorTrigger.addListener((o, ov, nv) -> {
            if (nv) {
                var dialog = new InfoKeyValueDialog("Finalize", vm.errors);
                var bound = localToScreen(getBoundsInLocal());
                dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
                vm.errorTrigger.set(false);
            }
        });

        vm.departmentTrigger.addListener((o, ov, nv) -> {
            if (nv) {
                var i = FinalizeVM.info.get();
                var dialog = new ConfirmDialog("Department", i.getDeptName() + " doesn't exist\nDo you want to create?");
                var bound = localToScreen(getBoundsInLocal());
                dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
                vm.departmentTrigger.set(false);

                vm.newDepartment = dialog.isOk ? new Department(0, i.getDeptName().trim()) : null;
            }
        });

        vm.accountTrigger.addListener((o, ov, nv) -> {
            if (nv) {
                var i = FinalizeVM.info.get();
                var account = new Account() {{
                    setDepartmentName(i.getDeptName());
                    setName(i.getCustomerNo());
                }};
                var dialog = new AccountCreateDialog("Add Account", account);
                var bound = localToScreen(getBoundsInLocal());
                dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
                vm.accountTrigger.set(false);

                vm.newAccount = dialog.isOk ? dialog.getAccount() : null;
            }
        });

        vm.mobileTrigger.addListener((o, ov, nv) -> {
            if (nv) {
                var i = FinalizeVM.info.get();
                var account = new Mobile(0, "", i.getPaidFrom());
                var dialog = new MobileCreateDialog("Add Mobile", account);
                var bound = localToScreen(getBoundsInLocal());
                dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
                vm.mobileTrigger.set(false);

                vm.newMobile = dialog.isOk ? dialog.getMobile() : null;
            }
        });

        vm.headTrigger.addListener((o, ov, nv) -> {
            if (nv) {
                var dialog = new ConfirmKeyValueDialog("Add Head", vm.errors);
                var bound = localToScreen(getBoundsInLocal());
                dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
                vm.headTrigger.set(false);
                vm.isHeadCreationConfirmed = dialog.isOk;
            }
        });

        vm.wrongAccountTrigger.addListener((o, ov, nv) -> {
            if (nv) {
                var i = FinalizeVM.info.get();
                var dialog = new InfoDialog("Account No ", i.getCustomerNo() + " is wrong");
                var bound = localToScreen(getBoundsInLocal());
                dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
                vm.departmentTrigger.set(false);
            }
        });
    }

    private void onSumBoxModified(Observable o, boolean ov, boolean nv) {
        if (!nv) return;
        FinalizeVM.info.get().setIsOk(false);
        paymentDetail.modifiedProperty().set(false);
        billDetail.modifiedProperty().set(false);
    }
}
