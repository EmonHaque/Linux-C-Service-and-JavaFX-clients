package CellTemplates.SelectionBox;

import model.Mobile;
import abstracts.ListCellBase;
import controls.texts.HiText;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class MobileTemplate extends ListCellBase<Mobile> {
    private BorderPane root;
    private HiText name;
    private Text number;
    private final StringProperty query;

    public MobileTemplate(StringProperty query) {
        this.query = query;
        setPadding(new Insets(5));
    }

    @Override
    protected void initializeUI() {
        name = new HiText();
        number = new Text(){{ setFill(Color.WHITE);}};
        root = new BorderPane() {{
            setCenter(name);
            setRight(number);
            setAlignment(number, Pos.CENTER_LEFT);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Mobile ov, Mobile nv) {
        if (ov != null) {
            name.queryProperty().unbind();
            name.queryProperty().set("");
        }
        if (nv == null) return;
        name.textProperty().bind(nv.nameProperty());
        number.textProperty().bind(nv.numberProperty());
        name.queryProperty().bind(query);
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
