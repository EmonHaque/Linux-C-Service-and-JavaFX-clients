package CellTemplates.Visual;

import model.Mobile;
import interfaces.ISetSelectionBoxContent;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class MobileVisual extends BorderPane implements ISetSelectionBoxContent<Mobile> {
    private final Text number, name;
    private Mobile item;

    public MobileVisual() {
        number = new Text(){{ setFill(Color.WHITE);}};
        name = new Text(){{ setFill(Color.WHITE);}};
        setCenter(number);
        setRight(name);
        setAlignment(number, Pos.CENTER_LEFT);
        setAlignment(name, Pos.CENTER_RIGHT);
    }
    @Override
    public void setContent(Mobile item) {
        number.textProperty().unbind();
        name.textProperty().unbind();

        this.item = item;
        number.textProperty().bind(item.numberProperty());
        name.textProperty().bind(item.nameProperty());
    }

    @Override
    public Mobile getContent() {
        return item;
    }

    @Override
    public Node getVisual() {
        return this;
    }
}
