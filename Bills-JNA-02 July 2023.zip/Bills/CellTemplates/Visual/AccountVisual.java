package CellTemplates.Visual;

import model.Account;
import interfaces.ISetSelectionBoxContent;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class AccountVisual extends BorderPane implements ISetSelectionBoxContent<Account> {
    private final Text accountNo, name;
    private Account item;

    public AccountVisual() {
        accountNo = new Text(){{ setFill(Color.WHITE);}};
        name = new Text(){{ setFill(Color.WHITE);}};
        setCenter(accountNo);
        setRight(name);
        setAlignment(accountNo, Pos.CENTER_LEFT);
        setAlignment(name, Pos.CENTER_RIGHT);
    }

    @Override
    public void setContent(Account item) {
        accountNo.textProperty().unbind();
        name.textProperty().unbind();

        this.item = item;
        accountNo.textProperty().bind(item.nameProperty());
        name.textProperty().bind(item.holderProperty());
    }

    @Override
    public Account getContent() {
        return item;
    }

    @Override
    public Node getVisual() {
        return this;
    }
}
