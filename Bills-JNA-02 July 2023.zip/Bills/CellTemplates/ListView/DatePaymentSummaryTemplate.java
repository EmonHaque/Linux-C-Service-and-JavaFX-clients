package CellTemplates.ListView;

import model.DatePaymentSummary;
import abstracts.ListCellBase;
import helpers.Helper;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class DatePaymentSummaryTemplate extends ListCellBase<DatePaymentSummary> {
    private GridPane root;
    private Text department, payment, bill;
    @Override
    protected void initializeUI() {
        department = new Text(){{ setFill(Color.WHITE);}};
        payment = new Text(){{ setFill(Color.WHITE);}};
        bill = new Text(){{ setFill(Color.WHITE);}};
        root = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(80){{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(80){{setHalignment(HPos.RIGHT);}}
            );
            add(department, 0, 0);
            add(payment, 1, 0);
            add(bill, 2, 0);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, DatePaymentSummary ov, DatePaymentSummary nv) {
        if(ov != null){
            department.setText(null);
            payment.setText(null);
            bill.setText(null);
        }
        if(nv != null){
            department.setText(nv.getDepartment());
            payment.setText(Helper.formatNumber(nv.getPayment()));
            bill.setText(Helper.formatNumber(nv.getBill()));
        }
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
