package CellTemplates.ListView;

import model.PaymentSummary;
import abstracts.ListCellBase;
import helpers.Helper;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class PaymentSummaryTemplate extends ListCellBase<PaymentSummary> {
    private GridPane root;
    private Text dayMonth, payment;

    @Override
    protected void initializeUI() {
        dayMonth = new Text() {{setFill(Color.WHITE);}};
        payment = new Text() {{setFill(Color.WHITE);}};
        root = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(100){{setHalignment(HPos.RIGHT);}}
            );
            add(dayMonth, 0, 0);
            add(payment, 1, 0);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, PaymentSummary ov, PaymentSummary nv) {
        if (ov != null) {
            dayMonth.setText(null);
            payment.setText(null);
        }
        if (nv != null) {
            dayMonth.setText(nv.getHead());
            payment.setText(Helper.formatNumber(nv.getAmount()));
        }
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
