package CellTemplates.ListView;

import model.ReportEntry;
import abstracts.ListCellBase;
import controls.texts.HiText;
import helpers.Helper;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class LedgerTemplate extends ListCellBase<ReportEntry> {
    private GridPane root;
    private Text date, bill, payment;
    private HiText particulars;
    private final StringProperty query;

    public LedgerTemplate(StringProperty query) {
        super();
        this.query = query;
    }

    @Override
    protected void initializeUI() {
        particulars = new HiText();
        date = new Text() {{setFill(Color.WHITE);}};
        bill = new Text() {{setFill(Color.WHITE);}};
        payment = new Text() {{setFill(Color.WHITE);}};

        root = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints(90) {{setValignment(date, VPos.TOP);}},
                    new ColumnConstraints() {{setHgrow(Priority.SOMETIMES);}},
                    new ColumnConstraints(90) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(90) {{setHalignment(HPos.RIGHT);}}
            );
            add(date, 0, 0);
            add(particulars, 1, 0);
            add(bill, 2, 0);
            add(payment, 3, 0);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, ReportEntry ov, ReportEntry nv) {
        if(ov != null){
            particulars.queryProperty().unbind();
            particulars.queryProperty().set("");
        }
        if (nv == null) return;

        date.textProperty().bind(nv.dateProperty());
        particulars.textProperty().bind(nv.periodProperty());
        bill.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(nv.getBill()), nv.billProperty()));
        payment.textProperty().bind(Bindings.createStringBinding(() -> Helper.formatNumber(nv.getPayment()), nv.paymentProperty()));
        particulars.queryProperty().bind(query);
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
