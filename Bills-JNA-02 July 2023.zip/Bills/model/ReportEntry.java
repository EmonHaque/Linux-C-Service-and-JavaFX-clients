package model;

import Interfaces.IBillEntry;
import javafx.beans.property.*;

public class ReportEntry extends IBillEntry {
    private final IntegerProperty accountId;
    private final StringProperty accountNo;

    public ReportEntry() {
        accountId = new SimpleIntegerProperty();
        accountNo = new SimpleStringProperty("");
    }

    public int getAccountId() {
        return accountId.get();
    }

    public IntegerProperty accountIdProperty() {
        return accountId;
    }

    public void setAccountId(int accountId) {
        this.accountId.set(accountId);
    }

    public String getAccountNo() {
        return accountNo.get();
    }

    public StringProperty accountNoProperty() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo.set(accountNo);
    }
}
