package model;

public class EditedEntry {
    private final int billId, headId;
    private final double payment, bill;

    public EditedEntry(int billId, int headId, double payment, double bill) {
        this.billId = billId;
        this.headId = headId;
        this.payment = payment;
        this.bill = bill;
    }

    public int getBillId() {
        return billId;
    }

    public int getHeadId() {
        return headId;
    }

    public double getPayment() {
        return payment;
    }

    public double getBill() {
        return bill;
    }
}
