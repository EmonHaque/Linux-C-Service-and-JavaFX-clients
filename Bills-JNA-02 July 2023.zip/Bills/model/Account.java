package model;

import interfaces.IReturnNameAndId;
import javafx.beans.property.*;

public class Account extends IReturnNameAndId<Account> {
    private final IntegerProperty id, departmentId;
    private final StringProperty name, holder,  address;
    private final BooleanProperty isWrong;
    private String departmentName;

    public Account() {
        id = new SimpleIntegerProperty();
        departmentId = new SimpleIntegerProperty();
        name = new SimpleStringProperty("");
        holder = new SimpleStringProperty("");
        address = new SimpleStringProperty("");
        isWrong = new SimpleBooleanProperty();
    }

    @Override
    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    @Override
    public String getName() {
        return name.get();
    }

    @Override
    public StringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getHolder() {
        return holder.get();
    }

    public StringProperty holderProperty() {
        return holder;
    }

    public void setHolder(String holder) {
        this.holder.set(holder);
    }

    public int getDepartmentId() {
        return departmentId.get();
    }

    public IntegerProperty departmentIdProperty() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId.set(departmentId);
    }

    public String getAddress() {
        return address.get();
    }

    public StringProperty addressProperty() {
        return address;
    }

    public void setAddress(String address) {
        this.address.set(address);
    }

    public boolean isIsWrong() {
        return isWrong.get();
    }

    public BooleanProperty isWrongProperty() {
        return isWrong;
    }

    public void setIsWrong(boolean isWrong) {
        this.isWrong.set(isWrong);
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }
}
