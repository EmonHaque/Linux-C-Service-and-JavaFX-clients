package model;

import javafx.beans.property.*;

public class Breakup {
    private final StringProperty head;
    private final IntegerProperty billId, paymentId;
    private final DoubleProperty billAmount, paymentAmount;

    public Breakup() {
        head = new SimpleStringProperty("");
        billId = new SimpleIntegerProperty();
        paymentId = new SimpleIntegerProperty();
        billAmount = new SimpleDoubleProperty();
        paymentAmount = new SimpleDoubleProperty();
    }

    public String getHead() {
        return head.get();
    }

    public StringProperty headProperty() {
        return head;
    }

    public void setHead(String head) {
        this.head.set(head);
    }

    public int getBillId() {
        return billId.get();
    }

    public IntegerProperty billIdProperty() {
        return billId;
    }

    public void setBillId(int billId) {
        this.billId.set(billId);
    }

    public int getPaymentId() {
        return paymentId.get();
    }

    public IntegerProperty paymentIdProperty() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId.set(paymentId);
    }

    public double getBillAmount() {
        return billAmount.get();
    }

    public DoubleProperty billAmountProperty() {
        return billAmount;
    }

    public void setBillAmount(double billAmount) {
        this.billAmount.set(billAmount);
    }

    public double getPaymentAmount() {
        return paymentAmount.get();
    }

    public DoubleProperty paymentAmountProperty() {
        return paymentAmount;
    }

    public void setPaymentAmount(double paymentAmount) {
        this.paymentAmount.set(paymentAmount);
    }
}
