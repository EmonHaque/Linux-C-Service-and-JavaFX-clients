package model;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Notification {
    private final BooleanProperty isRead;
    private final StringProperty category, message;

    public Notification() {
        this.isRead = new SimpleBooleanProperty();
        this.category = new SimpleStringProperty("");
        this.message = new SimpleStringProperty("");
    }

    public boolean isIsRead() {
        return isRead.get();
    }

    public BooleanProperty isReadProperty() {
        return isRead;
    }

    public void setIsRead(boolean isRead) {
        this.isRead.set(isRead);
    }

    public String getCategory() {
        return category.get();
    }

    public StringProperty categoryProperty() {
        return category;
    }

    public void setCategory(String category) {
        this.category.set(category);
    }

    public String getMessage() {
        return message.get();
    }

    public StringProperty messageProperty() {
        return message;
    }

    public void setMessage(String message) {
        this.message.set(message);
    }
}
