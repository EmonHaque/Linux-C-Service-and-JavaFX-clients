package Dialogs;

import model.Account;
import abstracts.DialogBase;
import controls.buttons.ActionButton;
import controls.states.BiState;
import controls.texts.TextBox;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class AccountCreateDialog extends DialogBase {
    private ActionButton okButton, closeButton;
    public boolean isOk;
    private final VBox box;
    private final Account account;

    public AccountCreateDialog(String title, Account account) {
        super();
        this.account = account;
        titlelabel.setText(title);

        box = new VBox() {{
            setBackground(Background.fill(Color.BLACK));
            setPadding(new Insets(10));
            setSpacing(10);
            getChildren().addAll(
                    new HBox() {{
                        getChildren().addAll(
                                new Text("Department: ") {{setFill(Color.WHITE); setFont(Constants.Bold);}},
                                new Text(account.getDepartmentName()) {{setFill(Color.WHITE);}}
                        );
                        setSpacing(5);
                    }},
                    new HBox() {{
                        getChildren().addAll(
                                new Text("Account: ") {{setFill(Color.WHITE); setFont(Constants.Bold);}},
                                new Text(account.getName()) {{setFill(Color.WHITE);}}
                        );
                        setSpacing(5);
                    }},
                    new TextBox("Holder", Icons.Tenant, true){{ account.holderProperty().bind(textProperty());}},
                    new TextBox("Address", Icons.Add, true){{ account.addressProperty().bind(textProperty());}},
                    new BiState(true, "Is Correct"){{ account.isWrongProperty().bind(isCheckedProperty);}}
            );

        }};
        root.setCenter(box);

        okButton = new ActionButton(Icons.CheckCircle, 16, "Yes");
        closeButton = new ActionButton(Icons.CloseCircle, 16, "No");
        okButton.setAction(this::confirm);
        closeButton.setAction(this::cancel);
        buttonsPane.getChildren().addAll(okButton, closeButton);
        GridPane.setHgrow(closeButton, Priority.ALWAYS);
        GridPane.setHalignment(closeButton, HPos.LEFT);
        GridPane.setHalignment(closeButton, HPos.RIGHT);
        GridPane.setMargin(okButton, new Insets(5, 0, 5, 5));
        GridPane.setMargin(closeButton, new Insets(5, 5, 5, 0));
    }

    @Override
    public void showDialog(double left, double top, double width, double height) {
        var h = height / 2;
        box.setMinHeight(h);
        box.setPrefHeight(h);
        box.setMaxHeight(h);

        super.showDialog(left, top, width, height);
        showAndWait();
    }

    public void cancel() {
        super.closeDialog();
        isOk = false;
    }

    public void confirm() {
        super.closeDialog();
        isOk = true;
    }

    public Account getAccount() { return account; }
}
