package ViewModels.Accounts;

import javafx.beans.property.*;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public abstract class EditBaseVM<T> {
    public StringProperty status;
    public BooleanProperty isRunning;
    public T edited;

    public EditBaseVM() {
        status = new SimpleStringProperty("");
        isRunning = new SimpleBooleanProperty();
    }
    public abstract ObservableList<T> getList();
    protected abstract int function();
    protected abstract ByteBuffer buffer();

    public void startTask(){
        var task = new EditTask();
        status.bind(task.messageProperty());
        isRunning.bind(task.runningProperty());
        new Thread(task){{setDaemon(true);}}.start();
    }

    private class EditTask extends Task<Void>{

        @Override
        protected Void call() throws Exception {
            var request = new Request(function(), buffer());
            var response = Channels.getInstance().getResponse(request).get();
            if (response.isSuccess()) {
                var isSuccess = response.getPacket()[0] == 1;
                var message = new String(response.getPacket(), 1, response.getPacket().length - 1, StandardCharsets.US_ASCII);
                updateMessage(message);
                Thread.sleep(500);
            }
            else {
                updateMessage("service down");
                Thread.sleep(500);
            }
            return null;
        }
    }
}
