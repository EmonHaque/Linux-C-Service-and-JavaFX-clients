package ViewModels.Accounts;

import Model.Account;
import Model.MobileEntry;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;

import java.util.function.Predicate;

public class AccountsVM {
    public final FilteredList<Account> list;
    public StringProperty query;

    public AccountsVM() {
        query = new SimpleStringProperty("");
        list = new FilteredList<>(AppData.accounts);
        query.addListener(this::onQueryChange);
    }

    private void onQueryChange(Observable o, String ov, String nv){
        var trimmed = nv.trim().toLowerCase();
        Predicate<Account> pred = x -> trimmed.isBlank() || trimmed.isEmpty() ?
                true :
                x.getName().toLowerCase().contains(trimmed)
                        || x.getHolder().toLowerCase().contains(trimmed)
                        || x.getAddress().toLowerCase().contains(trimmed);
        list.setPredicate(pred);
    }
}
