package ViewModels.Search;

import Enums.Function;
import Interfaces.IBillEntry;
import Model.Account;
import Model.BillPaymentSeries;
import Model.EditedBillInfo;
import Model.ReportEntry;
import javafx.beans.Observable;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutionException;

public abstract class DepartmentSearchVM extends SearchBaseVM {
    public final ObservableList<ReportEntry> list;

    public FilteredList<ReportEntry> reportable;
    public FilteredList<Account> selectionList;
    public DoubleProperty totalBill;

    public ObjectProperty<List<BillPaymentSeries>> billPaymentSeries;

    private boolean isSorted;

    public DepartmentSearchVM() {
        selectionList = new FilteredList<>(AppData.accounts, x -> x.getDepartmentName().equals(getDepartmentName()));
        totalBill = new SimpleDoubleProperty();
        billPaymentSeries = new SimpleObjectProperty<>();

        list = FXCollections.observableArrayList(o -> new Observable[]{query});
        reportable = new FilteredList<>(list, x -> {
            if (query.get() == null || query.get().isEmpty() || query.get().isBlank()) return true;
            return x.getPeriod().toLowerCase().contains(query.get().toLowerCase());
        });

        selectedEntry.addListener((o, ov, nv) -> startImageBreakupTask(nv));
        query.addListener(this::onQueryChange);
        AppData.onBillInfoEdited.addListener(this::onBillInfoEdited);
    }

    public abstract String getDepartmentName();

    @Override
    protected int getBillIdForBreakup() {
        return selectedEntry.get().getBillId();
    }

    @Override
    protected String getImageFileName() {
        return selectedEntry.get().getFileName();
    }

    @SuppressWarnings("rawtypes")
    @Override
    protected Task getEntriesTask() {
        return new GetEntriesTask();
    }

    @Override
    protected IBillEntry getEditedEntry(int billId) {
        IBillEntry entry = null;
        if (list.size() == 0) entry = null;
        for(var e : list){
            if(e.getBillId() != billId) continue;
            entry = e;
            break;
        }
        return entry;
    }

    public void refresh(){
        startEntryTask();
    }

    public void sort(){
        isSorted = !isSorted;
        if(isSorted)
            list.sort(Comparator.comparing(ReportEntry::getDate).reversed());
        else
            list.sort(Comparator.comparing(ReportEntry::getDate));
    }

    private void onQueryChange(Observable o, String ov, String nv) {
        double bill = 0, payment = 0;
        for (var item : reportable) {
            bill += item.getBill();
            payment += item.getPayment();
        }
        totalBill.set(bill);
        totalPayment.set(payment);
    }

    private void onBillInfoEdited(Observable o, EditedBillInfo ov, EditedBillInfo nv){
        var entry = list.stream().filter(x -> x.getBillId() == nv.getBillId()).findFirst();
        if(entry.isEmpty()) return;

        var e = entry.get();
        if(nv.isFileRenamed()){
            e.setDate(nv.getDate());
            e.setTransactionId(nv.getTransactionId());
            e.setFileName(nv.getNewFile());
        }
        if(e.getMobileId() != nv.getMobileId()){
            var mobile = AppData.mobiles.stream().filter(x -> x.getId() == nv.getMobileId()).findFirst().get();
            e.setMobileId(mobile.getId());
            e.setMobileNo(mobile.getNumber());
        }
        e.setBillNo(nv.getBillNo());
        e.setPeriod(nv.getPeriod());
    }

    private class GetEntriesTask extends Task<List<ReportEntry>> {
        private int length;
        private final int seriesSize = 18;
        private double bill, payment;
        private List<BillPaymentSeries> series;

        @Override
        protected List<ReportEntry> call() {
            try {
                updateMessage("requesting");
                Thread.sleep(250);

                if (isCancelled()) return null;

                var buffer = ByteBuffer.allocate(4)
                        .order(ByteOrder.LITTLE_ENDIAN)
                        .putInt(selectedId.intValue());
                var request = new Request(Function.GetEntriesByAccount.ordinal(), buffer);
                var response = Channels.getInstance().getResponse(request).get();
                length = response.getPacket().length;

                if (isCancelled()) return null;

                updateMessage("received " + String.format("%,d", length) + " bytes");
                Thread.sleep(250);

                updateMessage("processing " + String.format("%,d", length) + " bytes");
                Thread.sleep(250);

                if (isCancelled()) return null;
                buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);

                var list = getEntries(buffer);
                series = new ArrayList<>();
                if (list.size() < seriesSize) {
                    for (var x : list) {
                        series.add(new BillPaymentSeries(x.getDate(), x.getBill(), x.getPayment()));
                    }
                }
                else {
                    var start = list.size() - seriesSize;
                    for (int i = start; i < list.size(); i++) {
                        var x = list.get(i);
                        series.add(new BillPaymentSeries(x.getDate(), x.getBill(), x.getPayment()));
                    }
                }
                return list;
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        protected void succeeded() {
            try {
                var entries = get();
                list.clear();
                list.addAll(entries);

                billPaymentSeries.set(series);

                totalBill.set(bill);
                totalPayment.set(payment);
                updateMessage("processed " + String.format("%,d", length) + " bytes");
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        private List<ReportEntry> getEntries(ByteBuffer buffer) {
            bill = payment = 0;
            var list = new ArrayList<ReportEntry>();
            int start = 0;
            int read = 0;

            while (read < length) {
                if (isCancelled()) break;

                int id = buffer.getInt(start);
                int deptId = buffer.getInt(start + 4);
                int accountId = buffer.getInt(start + 8);
                int mobileId = buffer.getInt(start + 12);

                read += 16;
                start = read;
                int index = 0;
                var segments = new String[6];
                while (read < length) {
                    if (buffer.get(read) != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }

                double bill = buffer.getDouble(read);
                double payment = buffer.getDouble(read + 8);

                read += 16;
                start = read;

                this.bill += bill;
                this.payment += payment;

                list.add(new ReportEntry() {{
                    setBillId(id);
                    setDeptId(deptId);
                    setAccountId(accountId);
                    setMobileId(mobileId);
                    setBillNo(segments[0]);
                    setPeriod(segments[1]);
                    setTransactionId(segments[2]);
                    setDate(segments[3]);
                    setFileName(segments[4]);
                    setAccountNo(segments[5]);
                    setBill(bill);
                    setPayment(payment);
                }});
            }

            return list;
        }
    }
}
