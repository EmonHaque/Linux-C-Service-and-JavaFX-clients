package ViewModels.Search;

public class DescoVM extends DepartmentSearchVM {
    @Override
    public String getDepartmentName() {
        return "DESCO";
    }
}
