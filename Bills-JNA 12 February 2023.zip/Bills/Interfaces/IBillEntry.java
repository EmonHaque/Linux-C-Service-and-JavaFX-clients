package Interfaces;

import javafx.beans.property.*;

public class IBillEntry {
    private final IntegerProperty billId, deptId, mobileId;
    private final StringProperty billNo, period, transactionId, date, fileName, mobileNo;
    private final DoubleProperty bill, payment;

    public IBillEntry() {
        billId = new SimpleIntegerProperty();
        deptId = new SimpleIntegerProperty();
        mobileId = new SimpleIntegerProperty();
        billNo = new SimpleStringProperty("");
        period = new SimpleStringProperty("");
        transactionId = new SimpleStringProperty("");
        date = new SimpleStringProperty("");
        fileName = new SimpleStringProperty("");
        mobileNo = new SimpleStringProperty("");
        bill = new SimpleDoubleProperty();
        payment = new SimpleDoubleProperty();
    }

    public int getBillId() {
        return billId.get();
    }

    public IntegerProperty billIdProperty() {
        return billId;
    }

    public void setBillId(int billId) {
        this.billId.set(billId);
    }

    public int getDeptId() {
        return deptId.get();
    }

    public IntegerProperty deptIdProperty() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId.set(deptId);
    }

    public int getMobileId() {
        return mobileId.get();
    }

    public IntegerProperty mobileIdProperty() {
        return mobileId;
    }

    public void setMobileId(int mobileId) {
        this.mobileId.set(mobileId);
    }

    public String getMobileNo() {
        return mobileNo.get();
    }

    public StringProperty mobileNoProperty() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo.set(mobileNo);
    }

    public String getBillNo() {
        return billNo.get();
    }

    public StringProperty billNoProperty() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo.set(billNo);
    }

    public String getPeriod() {
        return period.get();
    }

    public StringProperty periodProperty() {
        return period;
    }

    public void setPeriod(String period) {
        this.period.set(period);
    }

    public String getTransactionId() {
        return transactionId.get();
    }

    public StringProperty transactionIdProperty() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId.set(transactionId);
    }

    public String getDate() {
        return date.get();
    }

    public StringProperty dateProperty() {
        return date;
    }

    public void setDate(String date) {
        this.date.set(date);
    }

    public String getFileName() {
        return fileName.get();
    }

    public StringProperty fileNameProperty() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName.set(fileName);
    }

    public double getBill() {
        return bill.get();
    }

    public DoubleProperty billProperty() {
        return bill;
    }

    public void setBill(double bill) {
        this.bill.set(bill);
    }

    public double getPayment() {
        return payment.get();
    }

    public DoubleProperty paymentProperty() {
        return payment;
    }

    public void setPayment(double payment) {
        this.payment.set(payment);
    }
}
