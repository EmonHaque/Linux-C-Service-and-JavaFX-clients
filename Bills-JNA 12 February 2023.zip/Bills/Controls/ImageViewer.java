package Controls;

import controls.ImageZoomer;
import controls.buttons.CommandButton;
import helpers.Icons;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.PixelFormat;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import ridiculous.AppData;

import java.awt.image.BufferedImage;


public class ImageViewer extends BorderPane {
    public StringProperty fileProperty;
    public ObjectProperty<byte[]> bufferProperty;
    private final CommandButton blackWhite, grayScale, color;
    private final ImageZoomer zoomer;
    private Image image;

    public ImageViewer(boolean isOfBuffer) {
        blackWhite = new CommandButton(Icons.ImageBW, 16, "Black & White");
        grayScale = new CommandButton(Icons.ImageGray, 16, "Gray Scale");
        color = new CommandButton(Icons.ImageColor, 16, "Original");

        blackWhite.setAction(this::makeBlackWhite);
        grayScale.setAction(this::makeGray);
        color.setAction(this::reset);

        var button = new HBox(blackWhite, grayScale, color) {{
            setAlignment(Pos.CENTER_RIGHT);
        }};

        zoomer = new ImageZoomer();
        setTop(button);
        setCenter(zoomer);


        BooleanBinding disableBinding;
        if (isOfBuffer) {
            bufferProperty = new SimpleObjectProperty<>();
            bufferProperty.addListener((o, ov, nv) -> {
                if (nv == null) {
                    image = null;
                    zoomer.imageProperty.set(null);
                }
                else {
                    AppData.tessCV.setImageBuffer(nv.length, nv);
                    makeGray();
                }
            });
            disableBinding = bufferProperty.isNull();
        }
        else {
            fileProperty = new SimpleStringProperty("");
            fileProperty.addListener((o, ov, nv) -> {
                if (nv == null) {
                    image = null;
                    zoomer.imageProperty.set(null);
                }
                else {
                    AppData.tessCV.setImageFile(nv);
                    makeGray();
                }
            });
            disableBinding = fileProperty.isNull().or(fileProperty.isEmpty());
        }
        blackWhite.disableProperty().bind(disableBinding);
        grayScale.disableProperty().bind(disableBinding);
        color.disableProperty().bind(disableBinding);
    }

    private void makeBlackWhite() {
        var mat = AppData.tessCV.getInvertedBinaryMat();
        var array = mat.data.getByteArray(0, mat.size);
        var buffered = new BufferedImage(mat.width, mat.height, BufferedImage.TYPE_BYTE_GRAY);
        buffered.getRaster().setDataElements(0, 0, mat.width, mat.height, array);
        image = SwingFXUtils.toFXImage(buffered, null);
        zoomer.imageProperty.set(image);
    }

    private void makeGray() {
        var mat = AppData.tessCV.getInvertedGrayMat();
        var array = mat.data.getByteArray(0, mat.size);
        var buffered = new BufferedImage(mat.width, mat.height, BufferedImage.TYPE_BYTE_GRAY);
        buffered.getRaster().setDataElements(0, 0, mat.width, mat.height, array);
        image = SwingFXUtils.toFXImage(buffered, null);
        zoomer.imageProperty.set(image);
    }

    private void reset() {
        var mat = AppData.tessCV.getOriginalMat();
        var array = mat.data.getByteArray(0, mat.size);
        var writable = new WritableImage(mat.width, mat.height);
        writable.getPixelWriter().setPixels(0, 0, mat.width, mat.height, PixelFormat.getByteRgbInstance(), array, 0, mat.width * 3);
        zoomer.imageProperty.set(writable);
    }
}
