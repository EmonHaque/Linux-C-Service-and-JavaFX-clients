package JNA;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

@Structure.FieldOrder({"width", "height", "size", "data"})
public class FXMat extends Structure {
    public int width;
    public int height;
    public int size;
    public Pointer data;
}
