package Model;

import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.SumBoxModel;

import java.util.ArrayList;
import java.util.List;

public class RawInfo {
    private final StringProperty deptName, period, transactionNo, paidFrom, billNo, customerNo, paymentDate;
    private final DoubleProperty totalPayment, totalBill;
    private final BooleanProperty isOk, isDuplicate;
    private String fileName, outputFileName, filePath, rawText;
    private int deptId, customerId, mobileId;
    private boolean hasImageWithSameName;
    private ObservableList<SumBoxModel> paymentInfo, billInfo;
    private List<AmountInfo> payments, bills;

    public RawInfo() {
        deptName = new SimpleStringProperty("");
        period = new SimpleStringProperty("");
        transactionNo = new SimpleStringProperty("");
        paidFrom = new SimpleStringProperty("");
        billNo = new SimpleStringProperty("");
        customerNo = new SimpleStringProperty("");
        paymentDate = new SimpleStringProperty("");
        totalPayment = new SimpleDoubleProperty();
        totalBill = new SimpleDoubleProperty();
        isOk = new SimpleBooleanProperty();
        isDuplicate = new SimpleBooleanProperty();
        paymentInfo = FXCollections.observableArrayList();
        billInfo = FXCollections.observableArrayList();
        payments = new ArrayList<>();
        bills = new ArrayList<>();
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getOutputFileName() {
        return outputFileName;
    }

    public void setOutputFileName(String outputFileName) {
        this.outputFileName = outputFileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getRawText() {
        return rawText;
    }

    public void setRawText(String rawText) {
        this.rawText = rawText;
    }

    public double getTotalBill() {
        return totalBill.get();
    }

    public DoubleProperty totalBillProperty() {
        return totalBill;
    }

    public void setTotalBill(double totalBill) {
        this.totalBill.set(totalBill);
    }

    public String getDeptName() {
        return deptName.get();
    }

    public StringProperty deptNameProperty() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName.set(deptName);
    }

    public String getPeriod() {
        return period.get();
    }

    public StringProperty periodProperty() {
        return period;
    }

    public void setPeriod(String period) {
        this.period.set(period);
    }

    public String getTransactionNo() {
        return transactionNo.get();
    }

    public double getTotalPayment() {
        return totalPayment.get();
    }

    public DoubleProperty totalPaymentProperty() {
        return totalPayment;
    }

    public void setTotalPayment(double totalPayment) {
        this.totalPayment.set(totalPayment);
    }

    public boolean isIsOk() {
        return isOk.get();
    }

    public BooleanProperty isOkProperty() {
        return isOk;
    }

    public void setIsOk(boolean isOk) {
        this.isOk.set(isOk);
    }

    public StringProperty transactionNoProperty() {
        return transactionNo;
    }

    public void setTransactionNo(String transactionNo) {
        this.transactionNo.set(transactionNo);
    }

    public String getPaidFrom() {
        return paidFrom.get();
    }

    public StringProperty paidFromProperty() {
        return paidFrom;
    }

    public void setPaidFrom(String paidFrom) {
        this.paidFrom.set(paidFrom);
    }

    public String getBillNo() {
        return billNo.get();
    }

    public StringProperty billNoProperty() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo.set(billNo);
    }

    public String getCustomerNo() {
        return customerNo.get();
    }

    public StringProperty customerNoProperty() {
        return customerNo;
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo.set(customerNo);
    }

    public String getPaymentDate() {
        return paymentDate.get();
    }

    public StringProperty paymentDateProperty() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate.set(paymentDate);
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getMobileId() {
        return mobileId;
    }

    public void setMobileId(int mobileId) {
        this.mobileId = mobileId;
    }

    public boolean isIsDuplicate() {
        return isDuplicate.get();
    }

    public BooleanProperty isDuplicateProperty() {
        return isDuplicate;
    }

    public void setIsDuplicate(boolean isDuplicate) {
        this.isDuplicate.set(isDuplicate);
    }

    public boolean isHasImageWithSameName() {
        return hasImageWithSameName;
    }

    public void setHasImageWithSameName(boolean hasImageWithSameName) {
        this.hasImageWithSameName = hasImageWithSameName;
    }

    public ObservableList<SumBoxModel> getPaymentInfo() {
        return paymentInfo;
    }

    public void setPaymentInfo(ObservableList<SumBoxModel> paymentInfo) {
        this.paymentInfo = paymentInfo;
    }

    public ObservableList<SumBoxModel> getBillInfo() {
        return billInfo;
    }

    public void setBillInfo(ObservableList<SumBoxModel> billInfo) {
        this.billInfo = billInfo;
    }

    public List<AmountInfo> getPayments() {
        return payments;
    }

    public List<AmountInfo> getBills() {
        return bills;
    }
}
