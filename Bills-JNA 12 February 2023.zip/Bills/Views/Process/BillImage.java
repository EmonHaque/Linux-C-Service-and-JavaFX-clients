package Views.Process;

import Controls.ImageViewer;
import abstracts.View;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class BillImage extends View {
    public static StringProperty file;
    private ImageViewer viewer;
    @Override
    protected String getHeader() {
        return "Image";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        file = new SimpleStringProperty("");
        viewer = new ImageViewer(false);
        setCenter(viewer);
        viewer.fileProperty.bind(file);
    }
}
