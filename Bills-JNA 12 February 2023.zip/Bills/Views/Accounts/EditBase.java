package Views.Accounts;

import ViewModels.Accounts.EditBaseVM;
import abstracts.View;
import controls.SpinningArc;
import javafx.beans.binding.Bindings;
import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public abstract class EditBase<T> extends View {
    private EditBaseVM<T> vm;
    private Text status;
    private SpinningArc spinner;

    protected abstract EditBaseVM<T> getViewModel();

    protected abstract Node getCentralNode();

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = getViewModel();

        setCenter(getCentralNode());

        spinner = new SpinningArc();
        status = new Text(){{ setFill(Color.WHITE);}};
        addAction(spinner);
        addAction(status);

        addAction(new Text(){{
            setFill(Color.WHITE);
            textProperty().bind(Bindings.size(vm.getList()).asString("%,d"));
        }});

        status.textProperty().bind(vm.status);
        spinner.visibleProperty().bind(vm.isRunning);
    }
}
