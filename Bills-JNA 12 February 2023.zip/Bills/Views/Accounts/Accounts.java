package Views.Accounts;

import Trees.AccountTree;
import ViewModels.Accounts.AccountEditVM;
import ViewModels.Accounts.AccountsVM;
import abstracts.View;
import controls.texts.TextBox;
import helpers.Icons;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class Accounts extends View {
    private TextBox query;
    private AccountTree tree;
    private AccountsVM vm;

    @Override
    protected String getHeader() {
        return "Accounts";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new AccountsVM();
        initializeUI();
        bind();

    }

    private void initializeUI() {
        query = new TextBox("Search", Icons.ControlHead, false);
        tree = new AccountTree(vm.list, query.textProperty());
        setCenter(
                new VBox(query, tree) {{
                    setVgrow(tree, Priority.ALWAYS);
                }}
        );
    }

    private void bind() {
        vm.query.bind(query.textProperty());
        AccountEditVM.selected.bind(tree.selectedItem);
    }
}
