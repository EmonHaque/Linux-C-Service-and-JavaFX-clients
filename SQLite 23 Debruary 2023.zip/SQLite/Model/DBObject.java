package Model;

import Enums.DBObjectType;

public class DBObject {
    private DBObjectType type;
    private String name;
    private boolean isPrimaryKey;
    private String ColumnName;
    private String DataType;

    public DBObjectType getType() {
        return type;
    }

    public void setType(DBObjectType type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean getIsPrimaryKey() {
        return isPrimaryKey;
    }

    public void setIsPrimaryKey(boolean isPrimaryKey) {
        this.isPrimaryKey = isPrimaryKey;
    }

    public String getColumnName() {
        return ColumnName;
    }

    public void setColumnName(String columnName) {
        ColumnName = columnName;
    }

    public String getDataType() {
        return DataType;
    }

    public void setDataType(String dataType) {
        DataType = dataType;
    }
}
