package Controls;

import Helpers.Constants;
import com.sun.jna.ptr.PointerByReference;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;
import javafx.util.Pair;
import ridiculous.SQLiteWrapper;

import java.util.ArrayList;
import java.util.List;

public class TableViewPage extends BorderPane {
    private final TabHeader header;
    private final Text status;
    private final SpinningArc spinner;
    private final ExtendedTableView<String[]> table;
    private final ObservableList<String[]> resultSet;
    private final String tableName;
    private final List<Pair<Text, TextBoxClean>> queryBoxes;
    private final IntegerProperty fontSize;
    private String clause = "";
    private ResultTask task;
    private boolean isLoaded;

    public TableViewPage(String header) {
        tableName = header;
        this.header = new TabHeader(header) {{setManaged(false);}};
        fontSize = new SimpleIntegerProperty(12);
        queryBoxes = new ArrayList<>();
        resultSet = FXCollections.observableArrayList();
        table = new ExtendedTableView<>();
        table.setItems(resultSet);
        table.setPlaceholder(new Text(""));

        status = new Text() {{setFill(Color.WHITE);}};
        spinner = new SpinningArc();
        var statusBox = new HBox(spinner, status) {{
            setSpacing(5);
            setPadding(new Insets(5));
            setAlignment(Pos.CENTER_RIGHT);
        }};
        setTop(statusBox);
        setCenter(table);
        setBorder(Constants.TopBorder);
        setManaged(false);
        update();

        table.addEventFilter(ScrollEvent.SCROLL, this::onControlWheel);
    }

    private void onControlWheel(ScrollEvent e) {
        if (!e.isControlDown()) return;
        // this function is called twice on every scroll, first with 0
        if (e.getDeltaY() == 0) return;

        e.consume();
        if (e.getDeltaY() > 0) {
            fontSize.set(fontSize.get() + 1);
        }
        else {
            var current = fontSize.get();
            if (current > 12) fontSize.set(current - 1);
        }
    }

    public TabHeader getHeader() {return header;}

    private void onQuery(KeyEvent e) {
        if (e.getCode() != KeyCode.ENTER) return;
        clause = "";
        for (var item : queryBoxes) {
            var content = item.getValue().getText().trim();
            if (content.isEmpty()) continue;
            clause += item.getKey().getText() + " " + content + " AND ";
        }
        if (!clause.isEmpty()) {
            clause = clause.substring(0, clause.lastIndexOf(" AND "));
        }
        update();
    }

    private void update() {
        if (task != null && task.isRunning()) {
            task.setOnCancelled(e -> {
                task.setOnCancelled(null);
                startTask();
            });
            task.cancel();
        }
        else startTask();
    }

    private void startTask() {
        task = new ResultTask();
        status.textProperty().bind(task.messageProperty());
        spinner.visibleProperty().bind(task.runningProperty());
        new Thread(task) {{setDaemon(true);}}.start();
    }

    private class ResultTask extends Task<Void> {
        private List<String[]> result;
        private String[] columns;
        private String error;
        private long time;
        private int pointerLength, numRow, numColumn, numChange;

        private void getColumnNames(int count, PointerByReference values, int length) {
            updateMessage(count + " columns found");
            numColumn = count;
            pointerLength = length;
            var pointers = values.getPointer().getPointerArray(0, length);
            columns = new String[count];
            for (int i = 0; i < count; i++) {
                columns[i] = pointers[i].getString(0);
            }
            updateMessage("adding rows");
        }

        private void getRows(PointerByReference values) {
            var pointers = values.getPointer().getPointerArray(0, pointerLength);
            var array = new String[numColumn];
            for (int i = 0; i < numColumn; i++) {
                array[i] = pointers[i] == null ? "NULL" : pointers[i].getString(0);
            }
            result.add(array);
            numRow++;
            if (numRow % 1000 == 0) {
                updateMessage("got " + String.format("%,d", numRow) + " rows");
            }
            if (isCancelled()) {
                updateMessage("cancelled");
            }
        }

        private void getChange(int count) {
            numChange = count;
        }

        private void getError(String error) {this.error = error;}

        @Override
        protected Void call() {
            updateMessage("waiting for key");
            synchronized (SQLiteWrapper.key) {
                var start = System.currentTimeMillis();
                updateMessage("submitting task");
                result = new ArrayList<>();

                SQLiteWrapper.setColumnCallback(this::getColumnNames);
                SQLiteWrapper.setRowCallback(this::getRows);
                SQLiteWrapper.setChangeCallback(this::getChange);
                SQLiteWrapper.setCErrorCallback(this::getError);

                var query = "SELECT * FROM " + tableName;
                if (!clause.isEmpty()) query += " WHERE " + clause;

                SQLiteWrapper.execute(query);
                time = System.currentTimeMillis() - start;
            }
            return null;
        }

        private void addColumns() {
            for (int i = 0; i < numColumn; i++) {
                final int index = i;
                var headerBox = new VBox() {{setSpacing(5);}};

                var name = columns[i];
                var text = new Text(name) {{setFill(Color.WHITE);}};
                var box = new TextBoxClean();
                box.setText("");
                queryBoxes.add(new Pair<>(text, box));
                box.addEventHandler(KeyEvent.KEY_RELEASED, TableViewPage.this::onQuery);
                VBox.setMargin(box, new Insets(0, 0, 2.5, 0));
                headerBox.getChildren().addAll(text, box);

                var column = new TableColumn<String[], String>() {{
                    setGraphic(headerBox);
                    setSortable(false);
                    setCellFactory(v -> new TableCell<>() {
                        private String content;
                        {
                            setBackground(null);
                            setBorder(null);
                            setContentDisplay(ContentDisplay.TEXT_ONLY);
                            fontSize.addListener(o -> {
                                if (isEmpty()) return;
                                var posture = content.equals("NULL") ? FontPosture.ITALIC : FontPosture.REGULAR;
                                setFont(Font.font(null, posture, fontSize.get()));
                            });
                            // itemProperty().addListener((o, ov, nv) -> { }); // doesn't work
                        }

                        @Override
                        protected void updateItem(String item, boolean empty) {
                            super.updateItem(item, empty);
                            if (empty) {
                                setTextFill(null);
                                setText(null);
                            }
                            else {
                                content = resultSet.get(getIndex())[index];
                                if (content.equals("NULL")) {
                                    setTextFill(Color.GRAY);
                                    setFont(Font.font(null, FontPosture.ITALIC, fontSize.get()));
                                }
                                else {
                                    setTextFill(Color.WHITE);
                                    setFont(Font.font(null, FontPosture.REGULAR, fontSize.get()));
                                }
                                setText(content);
                            }
                        }
                    });
                }};

                table.getColumns().add(column);
            }
        }

        @Override
        protected void succeeded() {
            // Why do you get: JNA: callback object has been garbage collected
            // It's to be when it's in a task

            if (error != null) {
                status.setFill(Color.LIGHTCORAL);
                updateMessage(error);
            }
            else {
                status.setFill(Color.WHITE);
                String timeText;
                if (time > 1000) {
                    double seconds = time / (double) 1000;
                    timeText = String.format("%.2f", seconds) + " seconds";
                }
                else timeText = String.format("%,d", time) + " milliseconds";

                if (numChange > 0) updateMessage(String.format("%,d", numChange) + " rows affected in " + timeText);
                else if (numColumn > 0) {
                    resultSet.clear();
                    resultSet.addAll(result);
                    if (!isLoaded) {
                        isLoaded = true;
                        addColumns();
                    }
                    updateMessage(String.format("%,d", numColumn) + " columns, " + String.format("%,d", numRow) + " rows returned in " + timeText);
                }
                else updateMessage("successfully executed in " + timeText);
            }
        }
    }
}
