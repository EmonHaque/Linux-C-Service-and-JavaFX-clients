package Controls;

import Helpers.Constants;
import Helpers.Icons;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Insets;
import javafx.scene.SnapshotParameters;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DataFormat;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.transform.Transform;
import javafx.stage.Screen;

public class TabHeader extends GridPane {
    private final Border normalBorder, selectedBorder;
    private final Text header;
    private boolean isDragged;

    public TabHeader(String text) {
        var radi = new CornerRadii(10, 10, 0, 0, false);
        header = new Text(text) {{setFill(Color.WHITE);}};
        var close = new ActionButton(Icons.CloseCircle, 16, "close"){{ setAction(TabHeader.this::onClose);}};

        normalBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, radi, new BorderWidths(0.25)));
        selectedBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, radi, new BorderWidths(0.5, 0.5, 0, 0.5)));

        add(header, 0, 0);
        add(close, 1, 0);
        setHgap(5);
        setPadding(new Insets(2.5, 2.5, 2.5, 5));
        setBackground(Background.fill(Constants.BackgroundColor));
        setBorder(selectedBorder);
        setOnMouseClicked(this::onSelect);

        setOnDragDetected(e -> {
            isDragged = true;
            var screen = Screen.getPrimary();
            double scaleX = screen.getOutputScaleX();
            double scaleY = screen.getOutputScaleY();
            var para = new SnapshotParameters(){{
                setTransform(Transform.scale(scaleX, scaleY));
            }};

            var content = new ClipboardContent();
            content.putString(header.getText());

            var db = startDragAndDrop(TransferMode.ANY);
            db.setContent(content);

            db.setDragView(snapshot(para, null));
        });

        setOnDragEntered(e ->{
            var db = e.getDragboard();
            if(!db.getString().equals(header.getText())){
                setBackground(Background.fill(Constants.BackgroundColorLight));
            }
            e.consume();
        });

        setOnDragExited(e ->{
            setBackground(Background.fill(Constants.BackgroundColor));
            e.consume();
        });

        setOnDragOver(e ->{
            var db = e.getDragboard();

            if(!db.getString().equals(header.getText()) && !db.hasFiles()){
                e.acceptTransferModes(TransferMode.ANY);
            }
            else  e.acceptTransferModes(TransferMode.NONE);
            e.consume();
        });

        setOnDragDone(e -> isDragged = false);
    }

    public void setSelected(boolean isSelected) {
        if (isSelected) {
            setBorder(selectedBorder);
            setPadding(new Insets(2.5, 2.5, 2.5, 5));
            header.setFill(Color.WHITE);
        }
        else {
            setBorder(normalBorder);
            setPadding(new Insets(2.5, 2.5, 2, 5));
            header.setFill(Color.GRAY);
        }
    }

    public boolean isDragged() { return isDragged; }

    private void onSelect(MouseEvent e){
        this.fireEvent(new SelectEvent(this));
    }

    private void onClose(){
        this.fireEvent(new CloseEvent(this));
    }

    public abstract class TabClickEvent extends Event{
        public static final EventType<TabClickEvent> CLICK_EVENT = new EventType(ANY);

        public TabClickEvent(EventType<? extends Event> eventType) {
            super(eventType);
        }
        public abstract void invokeHandler(TabClickHandler handler);
    }

    private class SelectEvent extends TabClickEvent{
        public static final EventType<TabClickEvent> SELECT = new EventType(CLICK_EVENT, "SelectEvent");
        private final TabHeader header;

        public SelectEvent(TabHeader header) {
            super(SELECT);
            this.header = header;
        }

        @Override
        public void invokeHandler(TabClickHandler handler) {
            handler.onSelect(header);
        }
    }

    private class CloseEvent extends TabClickEvent{
        public static final EventType<TabClickEvent> CLOSE = new EventType(CLICK_EVENT, "CloseEvent");
        private final TabHeader header;

        public CloseEvent(TabHeader header) {
            super(CLOSE);
            this.header = header;
        }

        @Override
        public void invokeHandler(TabClickHandler handler) {
            handler.onClose(header);
        }
    }

    public static abstract class TabClickHandler implements EventHandler<TabClickEvent> {
        public abstract void onSelect(TabHeader header);
        public abstract void onClose(TabHeader header);

        @Override
        public void handle(TabClickEvent event) {
            event.invokeHandler(this);
        }
    }
}
