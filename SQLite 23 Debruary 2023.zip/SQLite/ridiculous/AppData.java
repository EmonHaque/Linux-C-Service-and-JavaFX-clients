package ridiculous;

import Enums.SuggestionType;
import Model.Suggestion;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.util.List;

public class AppData {
    public static ObservableList<Suggestion> suggestions;

    public AppData() {
        suggestions = FXCollections.observableArrayList();
        //ClassLoader loader = Thread.currentThread().getContextClassLoader();
        var loader = getClass().getClassLoader();
        var files = List.of(
                "funcMath.txt",
                "funcWindow.txt",
                "funcDateTime.txt",
                "funcJSON.txt",
                "Keyword.txt",
                "funcScalar.txt",
                "funcAggregate.txt",
                "dataType.txt"
        );
        for (var file : files) {
            SuggestionType type;
            if (file.contains("funcMath")) type = SuggestionType.Math;
            else if (file.contains("funcWindow")) type = SuggestionType.Window;
            else if (file.contains("funcDateTime")) type = SuggestionType.DateTime;
            else if (file.contains("funcJSON")) type = SuggestionType.JSON;
            else if (file.contains("funcScalar")) type = SuggestionType.Scalar;
            else if (file.contains("funcAggregate")) type = SuggestionType.Aggregate;
            else if (file.contains("dataType")) type = SuggestionType.DataType;
            else type = SuggestionType.Keyword;

            try (var in = loader.getResourceAsStream("textFiles/" + file);
                 var reader = new BufferedReader(new InputStreamReader(in))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    suggestions.add(new Suggestion(type, line));
                }
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
}
