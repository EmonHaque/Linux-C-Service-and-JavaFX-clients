package Abstracts;

import Helpers.Constants;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

import java.util.List;

public class View extends BorderPane {
    private String header;
    private BorderPane headerPane;
    private GridPane actionsPane;

    protected List<View> views;

    public String icon;
    public String toolTip;
    public boolean isSeen;
    
    public View() {
        icon = getIcon();
        header = getHeader();
        toolTip = getTip();

        if (header != null) {
            if(headerPane == null){
                headerPane = new BorderPane();
                headerPane.setBorder(Constants.BottomBorder);
                setTop(headerPane);
            }
            
            var text = new Text(header);
            text.setFont(Font.font(Font.getDefault().getFamily(), FontWeight.BOLD, 14));
            text.setFill(Color.DARKGRAY);
            headerPane.setLeft(text);
        }

        if (!isContainer()) {
            setPadding(new Insets(10));
            setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, new CornerRadii(Constants.CardRadius, false), null)));
        }
    }

    public boolean isContainer() {
        return false;
    }

    protected String getIcon() {
        /* virtual */ return null;
    }

    protected String getHeader() {
        /* virtual */ return null;
    };

    protected String getTip() {
        /* virtual */ return null;
    };

    public void onFirstSight() {
        /* virtual */ isSeen = true;
    }

    public List<View> initialViews() {
        /* virtual */ return null;
    }

    public void addAction(Node action){
        if(actionsPane == null){
            actionsPane = new GridPane();
            actionsPane.setHgap(5);
            if(headerPane == null){
                headerPane = new BorderPane();
                headerPane.setBorder(Constants.BottomBorder);
                setTop(headerPane);
            }
            headerPane.setRight(actionsPane);
        }
        actionsPane.addColumn(actionsPane.getColumnCount(), action);
        GridPane.setValignment(action, VPos.CENTER);
    }
}
