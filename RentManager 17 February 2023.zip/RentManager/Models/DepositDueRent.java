package Models;

import Enums.DepositDueRentState;

public class DepositDueRent {
    private DepositDueRentState state;
    private int plotId;
    private int spaceId;
    private int tenantId;
    private int amount;

    public void setState(DepositDueRentState state) {
        this.state = state;
    }

    public void setPlotId(int plotId) {
        this.plotId = plotId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }

    public void setTenantId(int tenantId) {
        this.tenantId = tenantId;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public DepositDueRentState getState() {
        return state;
    }

    public int getPlotId() {
        return plotId;
    }

    public int getSpaceId() {
        return spaceId;
    }

    public int getTenantId() {
        return tenantId;
    }

    public int getAmount() {
        return amount;
    }
}
