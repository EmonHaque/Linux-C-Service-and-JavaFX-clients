package Views.Home;

import abstracts.View;
import controls.buttons.ActionButton;
import controls.piechart.Pie;
import controls.states.MultiState;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import ViewModels.Home.CountsVM;
import javafx.geometry.Pos;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.TextFlow;

public class Counts extends View {
    private Pie pie;
    private MultiState primaryState, secondaryState;
    private Text totalPlot, totalInPlot;
    private TextFlow status;
    private ActionButton refresh;
    private CountsVM vm;

    @Override
    protected String getHeader() {
        return "Space, Lease & Tenants";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new CountsVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        var icons = new String[] { Icons.Space, Icons.Lease, Icons.Tenant };
        var texts = new String[] { "Space", "Lease", "Tenant" };
        primaryState = new MultiState(icons, texts, true);
        secondaryState = new MultiState(false){{ setAlignment(Pos.CENTER_RIGHT);}};
        pie = new Pie();
        totalPlot = new Text() {{ setFill(Color.WHITE);}};
        totalInPlot = new Text() {{ setFill(Color.WHITE);}};
        status = new TextFlow(){{
           getChildren().addAll(
                   new Text("Total "){{ setFill(Color.WHITE);}},
                   totalInPlot,
                   new Text(" in "){{ setFill(Color.WHITE);}},
                   totalPlot,
                   new Text(" plots"){{ setFill(Color.WHITE);}}
           );
           setTextAlignment(TextAlignment.CENTER);
        }};

        var grid = new GridPane(){{
            getRowConstraints().addAll(
                new RowConstraints(),
                new RowConstraints(){{ setVgrow(Priority.ALWAYS);}},
                new RowConstraints()
            );
            getColumnConstraints().addAll(
                new ColumnConstraints(){{ setPercentWidth(50);}},
                new ColumnConstraints(){{ setPercentWidth(50);}}
            );
            add(primaryState, 0, 0);
            add(secondaryState, 1, 0);
            add(pie, 0, 1, 2, 1);
            add(status, 0, 2, 2, 1);

            setHalignment(status, HPos.CENTER);
            setPadding(new Insets(5,0,0,0));
        }};

        setCenter(grid);

        refresh = new ActionButton(Icons.Reload, 16, "refresh");
        addAction(refresh);
    }

    private void bind(){
        refresh.setAction(vm::refresh);
        secondaryState.statesProperty.bind(vm.secondaryStates);
        vm.secondaryState.bind(secondaryState.stateProperty);
        vm.primaryState.bind(primaryState.stateProperty);
        pie.seriesProperty.bind(vm.seriesProperty);
        totalInPlot.textProperty().bind(vm.totalInPlot.asString());
        totalPlot.textProperty().bind(vm.totalPlot.asString());
    }
}
