package Views.Report;

import Views.Report.BalancesViews.ReportBalance;
import Views.Report.BalancesViews.ReportMonthlyBalance;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.util.ArrayList;
import java.util.List;

public class Balances extends View {
    private ReportBalance balance;
    private ReportMonthlyBalance monthlyBalance;

    @Override
    protected String getIcon() {
        return Icons.Balance;
    }

    @Override
    protected String getTip() {
        return "Balances";
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public List<View> initialViews() {
        balance = new ReportBalance();
        monthlyBalance = new ReportMonthlyBalance();
        super.views = new ArrayList<>();
        views.add(balance);
        views.add(monthlyBalance);
        return super.views;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        setCenter(new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setPercentWidth(55);}},
                    new ColumnConstraints(){{ setPercentWidth(45);}}
            );
            getRowConstraints().add(new RowConstraints(){{ setPercentHeight(100);}});
            add(balance, 0, 0);
            add(monthlyBalance, 1, 0);
            setHgap(Constants.CardMargin);
            setPadding(new Insets(Constants.CardMargin));
        }});
    }
}
