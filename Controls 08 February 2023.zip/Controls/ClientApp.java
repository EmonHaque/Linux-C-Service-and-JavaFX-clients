import controls.LoadingWindow;
import controls.LoginWindow;
import controls.Window;
import dialogs.ErrorDialog;
import javafx.application.Application;
import javafx.beans.Observable;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import ridiculuous.Addresses;
import ridiculuous.Channels;
import ridiculuous.ClientInfo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.Socket;

public abstract class ClientApp extends Application {
    static { System.setProperty("javafx.sg.warn", "false"); } // what's this?

    private LoginWindow login;
    protected Stage stage;
    protected LoadingWindow loading;

    protected abstract Image getIcon();

    protected abstract String IP();
    protected abstract int port();

    protected abstract String getTitle();

    protected abstract void initializeAppData();

    protected abstract Window getWindow(Stage stage);

    private void globalExceptionHandler(Thread thread, Throwable throwable){
        var writer = new StringWriter();
        throwable.printStackTrace(new PrintWriter(writer));
        var message = writer.toString();
        var dialog = new ErrorDialog("Exception", message);
        dialog.showDialog(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight());
    }

    @Override
    public void start(Stage stage) throws Exception {
        // does these work?
        // Thread.currentThread().setUncaughtExceptionHandler(this::globalExceptionHandler);
        Thread.setDefaultUncaughtExceptionHandler(this::globalExceptionHandler);

        this.stage = stage;
        Channels.getInstance().IP = IP();
        Channels.getInstance().port = port();

        var debug = true;
        if(debug){
            Channels.getInstance().userId = 5;
            Channels.getInstance().sender = new Socket(IP(), port());
            var info = new ClientInfo((byte)0, Channels.getInstance().userId);
            Channels.getInstance().sender.getOutputStream().write(info.getBytes());
            Channels.getInstance().sender.getOutputStream().flush();
            loading = new LoadingWindow(getTitle(), getIcon());

            initializeAppData();
            loading.show();
            loading.isSuccessProperty.addListener(this::onLoaded);
        }
        else {
            login = new LoginWindow(getTitle(), getIcon());
            login.isSuccessProperty.addListener(this::onLoggedIn);
            login.show();
        }
    }

    private void onLoggedIn(Observable ob){
        login.isSuccessProperty.removeListener(this::onLoggedIn);
        login.close();

        loading = new LoadingWindow(getTitle(), getIcon());
        initializeAppData();
        loading.show();
        loading.isSuccessProperty.addListener(this::onLoaded);
    }

    private void onLoaded(Observable ob){
        loading.isSuccessProperty.removeListener(this::onLoaded);
        loading.close();
        stage.getIcons().add(getIcon());
        getWindow(stage).show();
    }

    @Override
    public void stop() throws Exception {
        super.stop();
        if(Channels.getInstance().signatory != null){
            Channels.getInstance().signatory.close();
        }
        if(Channels.getInstance().sender != null){
            Channels.getInstance().sender.close();
        }
        if(Channels.getInstance().receiver != null){
            Channels.getInstance().receiver.close();
        }
        Channels.getInstance().shutDown();
    }
}
