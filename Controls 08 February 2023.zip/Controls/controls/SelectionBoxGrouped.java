package controls;

import abstracts.SelectionControlBase;
import helpers.Constants;
import helpers.Icons;
import interfaces.IReturnNameAndId;
import interfaces.ISetSelectionBoxContent;
import javafx.animation.RotateTransition;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import skinned.ExtendedResizableTreeView;

//Created for SpaceLedger, for other usage test it
public class SelectionBoxGrouped<T extends IReturnNameAndId<T>> extends SelectionControlBase {
    private final ExtendedResizableTreeView<T> tree;
    private final ISetSelectionBoxContent<T> visual;
    private RotateTransition rotationAnim;
    private boolean isLoaded, isInteractiveChange;

    private ObjectProperty<T> selectedItem;
    private IntegerProperty selectedValue;

    public SelectionBoxGrouped(String hint, String leftIcon, ExtendedResizableTreeView<T> tree, ISetSelectionBoxContent<T> visual, boolean isRequired) {
        super(hint, leftIcon, isRequired);
        this.tree = tree;
        this.visual = visual;
        initializeUI();
    }

    private void initializeUI() {
        super.setSelectedContent(visual.getVisual());
        tree.setMaxHeight(200);
        popup.getContent().remove(0); // remove popupGrid
        popup.getContent().add(new VBox(tree){{
            setPadding(new Insets(5, 5, 5, 0));
            setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, null, null)));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25))));
        }});
        input.setText("");

        selectedItem = new SimpleObjectProperty<>();
        selectedValue = new SimpleIntegerProperty();
        selectedItem.addListener(this::onSelectedItemChanged);
        selectedValue.addListener(this::onSelectedValueChanged);

        rotationAnim = new RotateTransition(Duration.millis(500));
        rotationAnim.setNode(open);

        tree.setOnKeyReleased(this::onKeyReleasedOnListView);
        tree.setOnMouseClicked(this::onMouseClickedOnListView);
    }

    private void onSelectedItemChanged(ObservableValue<?> o, T ov, T nv) {
        if (!isLoaded) return;
        if (isInteractiveChange) return;

        int id = -1;
        if (nv != null) {
            if (isDisabled()) setDisable(false);
            visual.setContent(nv);
            super.onSelected();
            id = nv.getId();
        }
        else {
            super.removeSelected();
            setDisable(true);
        }
        isInteractiveChange = true;
        selectedValue.set(id);
        isInteractiveChange = false;
    }

    private void onSelectedValueChanged(ObservableValue<?> o, Number ov, Number nv) {
        if (!isLoaded) return;
        if (isInteractiveChange) return;

        var item = tree.getRoot().getChildren().stream().filter(x -> x.getValue().getId() == nv.intValue()).findFirst();
        if (item.isPresent()) {
            if (isDisabled()) setDisable(false);
            visual.setContent(item.get().getValue());
            super.onSelected();
        }
        else {
            super.removeSelected();
            setDisable(true);
        }
        isInteractiveChange = true;
        selectedItem.set(item.isPresent() ?  item.get().getValue() : null);
        isInteractiveChange = false;
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if (!isLoaded) {
            isLoaded = true;

            isInteractiveChange = true;
            if (tree.getRoot().getChildren().size() > 0) selectFirst();
            else {
                nullify();
                setDisable(true);
            }
            isInteractiveChange = false;
        }
    }
    @Override
    protected String getRightIcon() {
        return Icons.DownArrow;
    }

    @Override
    protected void removeSelected() {
        isInteractiveChange = true;
        nullify();
        showPopup();
        isInteractiveChange = false;
        super.removeSelected();
    }

    private void setSelected() {
        var selected = tree.getSelectionModel().getSelectedItem().getValue();
        int value = -1;
        if (selected != null) {
            visual.setContent(selected);
            value = selected.getId();
        }
        selectedItem.set(selected);
        selectedValue.set(value);
        super.onSelected();
    }

    private void nullify() {
        super.removeSelected();
        selectedItem.set(null);
        selectedValue.set(-1);
    }

    private void selectFirst() {
        for(var node : tree.getRoot().getChildren()){
            for(var leaf : node.getChildren()){
                tree.getSelectionModel().select(leaf);
                break;
            }
            break;
        }
        //tree.getSelectionModel().selectFirst();
        setSelected();
    }

    @Override
    protected void onPopupShowing(WindowEvent e) {
        super.onPopupShowing(e);
        rotationAnim.setToAngle(180);
        rotationAnim.play();
        open.setTip("close");
    }

    @Override
    protected void onPopupHiding(WindowEvent e) {
        super.onPopupHiding(e);
        rotationAnim.setToAngle(0);
        rotationAnim.play();
        open.setTip("show");
    }

    private void onKeyReleasedOnListView(KeyEvent e) {
        if (e.getCode() == KeyCode.ENTER) {
            // when you enter on input ListView gets event and selected item can be null
            if(tree.getSelectionModel().getSelectedItem() == null) return;

            isInteractiveChange = true;
            setSelected();
            isInteractiveChange = false;
        }
    }

    private void onMouseClickedOnListView(MouseEvent e) {
        isInteractiveChange = true;
        setSelected();
        isInteractiveChange = false;
    }

    private void showPopup() {
        var point = input.localToScreen(0, 0);
        tree.setMinWidth(input.getWidth());
        popup.show(getScene().getWindow(), point.getX(), point.getY() + input.getHeight());
    }

    public ObjectProperty<T> selectedItemProperty() {return selectedItem;}

    public IntegerProperty selectedValueProperty() {return selectedValue;}

    public StringProperty queryProperty() { return input.textProperty(); }
}
