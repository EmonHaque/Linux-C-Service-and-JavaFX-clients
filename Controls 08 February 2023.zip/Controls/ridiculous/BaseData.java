package ridiculous;

import controls.LoadingWindow;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import ridiculuous.Addresses;
import ridiculuous.Channels;
import ridiculuous.ClientInfo;
import ridiculuous.Request;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.DecimalFormat;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public abstract class BaseData {
    protected Stage stage;
    protected LoadingWindow window;
    protected boolean isConnected;
    protected BlockingQueue<byte[]> messages;

    public BaseData(LoadingWindow window, Stage stage) {
        this.window = window;
        this.stage = stage;
        window.setOnShown(this::onActivated);
    }

    private void onActivated(WindowEvent e) {
        initializeCollections();
        getInitialLoad();
    }

    private void getInitialLoad() {
        var request = new Request(getInitialMethod(), ByteBuffer.allocate(0));
        var bytes = request.getBytes();
        try {
            Channels.getInstance().sender.getOutputStream().write(bytes, 0, bytes.length);
            Channels.getInstance().sender.getOutputStream().flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        populateCollections();
        isConnected = true;
        messages = new ArrayBlockingQueue<>(1000, true);

        new Thread(this::receiveBroadcast) {{setDaemon(true);}}.start();
        new Thread(this::processMessage) {{setDaemon(true);}}.start();
    }

    protected ByteBuffer getPacket() {
        try {
            var header = Channels.getInstance().sender.getInputStream().readNBytes(4);
            var size = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN).getInt();
            if (size == 0) return ByteBuffer.allocate(0);

            var packet = Channels.getInstance().sender.getInputStream().readNBytes(size);
            return ByteBuffer.wrap(packet).order(ByteOrder.LITTLE_ENDIAN);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void receiveBroadcast() {
        InputStream in;
        try {
            Channels.getInstance().receiver = new Socket(Channels.getInstance().IP, Channels.getInstance().port);
            var info = new ClientInfo((byte)1, Channels.getInstance().userId);
            Channels.getInstance().receiver.getOutputStream().write(info.getBytes());
            Channels.getInstance().receiver.getOutputStream().flush();
            in = Channels.getInstance().receiver.getInputStream();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        while (isConnected) {
            try {
                int size = ByteBuffer.wrap(in.readNBytes(4)).order(ByteOrder.LITTLE_ENDIAN).getInt();
                messages.add(in.readNBytes(size));
            } catch (IOException e) {
                isConnected = false;
            }
        }
    }

    protected abstract int getInitialMethod();

    protected abstract void initializeCollections();

    protected abstract void populateCollections();

    protected abstract void processMessage();
}
