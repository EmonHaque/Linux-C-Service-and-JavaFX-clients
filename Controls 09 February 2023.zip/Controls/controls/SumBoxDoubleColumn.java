package controls;

import controls.buttons.ActionButton;
import controls.texts.DoubleBoxClean;
import controls.texts.SuggestionBoxLess;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.StringConverter;
import model.SumBoxModel;
import model.SumBoxModelDoubleColumn;
import skinned.ExtendedListView;
import skins.ExtendedTextFieldSkin;

public class SumBoxDoubleColumn <T> extends GridPane {
    private final String suggestionProperty, suggestionTemplate;
    private final ObservableList<T> suggestionList;
    private ObservableList<SumBoxModelDoubleColumn> list;
    private ExtendedListView<SumBoxModelDoubleColumn> listView;
    private ActionButton addButton, removeButton;
    private Text particulars, amountColumn1, amountColumn2, totalText, totalColumn1, totalColumn2;

    private final DoubleProperty sumColumn1, sumColumn2;
    private final BooleanProperty modified;

    public SumBoxDoubleColumn(ObservableList<T> suggestionList, String suggestionProperty, String suggestionTemplate) {
        this.suggestionList = suggestionList;
        this.suggestionProperty = suggestionProperty;
        this.suggestionTemplate = suggestionTemplate;

        sumColumn1 = new SimpleDoubleProperty();
        sumColumn2 = new SimpleDoubleProperty();
        modified = new SimpleBooleanProperty();

        addButtons();
        addTexts();
        addListView();

        getColumnConstraints().addAll(
                new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                new ColumnConstraints(70),
                new ColumnConstraints(70)
        );
    }

    private void addListView(){
        if(list == null) list = FXCollections.observableArrayList();
        listView = new ExtendedListView<>(list);
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setCellFactory(v -> new CellTemplate());
        add(listView, 0, 2, 3, 1);
        setVgrow(listView, Priority.ALWAYS);
    }

    public void setHeader(String col1, String col2, String col3) {
        particulars.setText(col1);
        amountColumn1.setText(col2);
        amountColumn2.setText(col3);
    }

    public void setList(ObservableList<SumBoxModelDoubleColumn> list) {
        if(this.list != null){
            for(var item : this.list){
                item.key.removeListener(this::onKeyChanged);
                item.value1.removeListener(this::onValue1Changed);
                item.value2.removeListener(this::onValue2Changed);
            }
        }
        double totalColumn1 = 0, totalColumn2 = 0;
        for (var item : list) {
            totalColumn1 += item.getValue1();
            totalColumn2 += item.getValue2();
            item.key.addListener(this::onKeyChanged);
            item.value1.addListener(this::onValue1Changed);
            item.value2.addListener(this::onValue2Changed);
        }
        this.totalColumn1.setText(String.format("%,.2f", totalColumn1));
        this.totalColumn2.setText(String.format("%,.2f", totalColumn2));
        sumColumn1.set(totalColumn1);
        sumColumn2.set(totalColumn2);

        this.list = list;
        getChildren().remove(listView);
        addListView();
    }

    private void onKeyChanged(Observable o, String ov, String nv){
        modified.set(true);
    }

    private void onValue1Changed(ObservableValue<?> o, Number ov, Number nv) {
        double total = sumColumn1.get();
        total -= ov.doubleValue();
        total += nv.doubleValue();
        totalColumn1.setText(String.format("%,.2f", total));
        sumColumn1.set(total);
        modified.set(true);
    }

    private void onValue2Changed(ObservableValue<?> o, Number ov, Number nv){
        double total = sumColumn2.get();
        total -= ov.doubleValue();
        total += nv.doubleValue();
        totalColumn2.setText(String.format("%,.2f", total));
        sumColumn2.set(total);
        modified.set(true);
    }

    private void addNewRow() {
        var newItem = new SumBoxModelDoubleColumn("", 0, 0);
        newItem.value1.addListener(this::onValue1Changed);
        newItem.value2.addListener(this::onValue2Changed);

        list.add(newItem);
        listView.getSelectionModel().select(newItem);
        listView.scrollTo(newItem);
        modified.set(true);
        // listView.getSelectionModel().select(list.size() - 1);
    }

    private void removeSelectedRow() {
        var index = listView.getSelectionModel().getSelectedIndex();
        if (index == -1) return;
        var pair = list.get(index);
        double totalColumn1 = this.sumColumn1.get();
        double totalColumn2 = this.sumColumn2.get();
        totalColumn1 -= pair.value1.get();
        totalColumn2 -= pair.value2.get();

        this.totalColumn1.setText(String.format("%,.2f", totalColumn1));
        sumColumn1.set(totalColumn1);
        this.totalColumn2.setText(String.format("%,.2f", totalColumn2));
        sumColumn2.set(totalColumn2);

        list.remove(index);
        if (index > 0) {
            index--;
            listView.getSelectionModel().select(index);
        }
        modified.set(true);
    }

    private void addTexts() {
        particulars = new Text("Particulars"){{ setFill(Color.WHITE);}};
        amountColumn1 = new Text("Amount"){{ setFill(Color.WHITE);}};
        amountColumn2 = new Text("Amount"){{ setFill(Color.WHITE);}};
        totalText = new Text("Total"){{ setFill(Color.WHITE);}};
        totalColumn1 = new Text(String.format("%,.2f", sumColumn1.get())){{ setFill(Color.WHITE);}};
        totalColumn2= new Text(String.format("%,.2f", sumColumn1.get())){{ setFill(Color.WHITE);}};

        var topBorder = new StackPane();
        var bottomBorder = new StackPane();
        topBorder.setBorder(Constants.BottomBorder);
        bottomBorder.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0))));

        add(topBorder, 0, 1, 2, 1);
        add(particulars, 0, 1);
        add(amountColumn1, 1, 1);
        add(amountColumn2, 2, 1);

        add(bottomBorder, 0, 3, 2, 1);
        add(totalText, 0, 3);
        add(totalColumn1, 1, 3);
        add(totalColumn2, 2, 3);

        GridPane.setHalignment(amountColumn1, HPos.RIGHT);
        GridPane.setHalignment(totalColumn1, HPos.RIGHT);
        GridPane.setHalignment(amountColumn2, HPos.RIGHT);
        GridPane.setHalignment(totalColumn2, HPos.RIGHT);
        GridPane.setMargin(amountColumn1, new Insets(0, Constants.ScrollBarSize, 0, 0));
        GridPane.setMargin(totalColumn1, new Insets(0, Constants.ScrollBarSize, 0, 0));
        GridPane.setMargin(amountColumn2, new Insets(0, Constants.ScrollBarSize, 0, 0));
        GridPane.setMargin(totalColumn2, new Insets(0, Constants.ScrollBarSize, 0, 0));
    }

    private void addButtons() {
        addButton = new ActionButton(Icons.PlusCircle, 16, "add");
        removeButton = new ActionButton(Icons.MinusCircle, 16, "remove");

        addButton.setAction(this::addNewRow);
        removeButton.setAction(this::removeSelectedRow);

        var hBox = new HBox(addButton, removeButton);
        hBox.setAlignment(Pos.CENTER_RIGHT);
        add(hBox, 2, 0);

        GridPane.setHalignment(hBox, HPos.RIGHT);
        GridPane.setMargin(hBox, new Insets(0, Constants.ScrollBarSize, 0, 0));
    }

    private class CellTemplate extends ListCell<SumBoxModelDoubleColumn> {
        private final SuggestionBoxLess<T> keyField;
        private final DoubleBoxClean valueField1, valueField2;
        private final GridPane grid;

        public CellTemplate() {
            setPadding(new Insets(1, 0, 1, 0));
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setBackground(null);
            setPrefWidth(0);

            keyField = new SuggestionBoxLess<>(suggestionList, suggestionProperty, suggestionTemplate);
            valueField1 = new DoubleBoxClean(){{
                setAlignment(Pos.CENTER_RIGHT);
            }};
            valueField2 = new DoubleBoxClean(){{
                setAlignment(Pos.CENTER_RIGHT);
            }};
            keyField.setPadding(new Insets(0));

            grid = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints(70),
                        new ColumnConstraints(70)
                );
                add(keyField, 0, 0);
                add(valueField1, 1, 0);
                add(valueField2, 2, 0);

                setFillWidth(keyField, false);
            }};

            itemProperty().addListener((o, ov, nv) -> {
                if (ov != null) {
                    keyField.textProperty().unbindBidirectional(ov.key);
                    valueField1.textProperty().unbindBidirectional(ov.value1);
                    valueField2.textProperty().unbindBidirectional(ov.value2);
                    setOnKeyPressed(null);
                }
                if (nv != null) {
                    keyField.textProperty().bindBidirectional(nv.key);
                    valueField1.textProperty().bindBidirectional(nv.value1, new StringConverter<>() {
                        @Override
                        public String toString(Number object) {
                            return String.format("%.2f", object.doubleValue());
                        }

                        @Override
                        public Number fromString(String string) {
                            try {
                                return Double.parseDouble(string);
                            }
                            catch (Exception ignored){
                                return 0;
                            }
                        }
                    });
                    valueField2.textProperty().bindBidirectional(nv.value2, new StringConverter<>() {
                        @Override
                        public String toString(Number object) {
                            return String.format("%.2f", object.doubleValue());
                        }

                        @Override
                        public Number fromString(String string) {
                            try {
                                return Double.parseDouble(string);
                            }
                            catch (Exception ignored){
                                return 0;
                            }
                        }
                    });
                    setOnKeyPressed(this::onKeyPressed);
                }
            });

            focusWithinProperty().addListener(o ->{
                // null ?
                getListView().getSelectionModel().select(getItem());
            });
        }

        private void onKeyPressed(KeyEvent e) {
            if (!e.isControlDown()) return;
            var code = e.getCode();
            if (code == KeyCode.ADD) {
                addNewRow();
            }
            if (code == KeyCode.SUBTRACT) {
                removeSelectedRow();
            }
        }

        @Override
        protected void updateItem(SumBoxModelDoubleColumn item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
                return;
            }
            setGraphic(grid);
            if (isSelected()) {
                keyField.requestFocus();
                keyField.end();
            }
        }
    }
}
