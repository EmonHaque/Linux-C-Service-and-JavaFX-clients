package controls;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.ScaleTransition;
import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.util.Duration;

public class SpinningArcFinite extends StackPane {
    private double radius = 5;
    private final DoubleProperty progress;
    private ScaleTransition anim;

    public SpinningArcFinite() {
        var size = radius * 2;
        setMinSize(size, size);
        setPrefSize(size, size);
        setMaxSize(size, size);
        setScaleX(0);
        setScaleY(0);

        var arc = new Arc(radius, radius, radius, radius, 0, 0);
        arc.setType(ArcType.ROUND);
        arc.setFill(Color.WHITE);
        arc.setManaged(false);
        getChildren().add(arc);

        anim = new ScaleTransition(Duration.seconds(2), this);
        anim.setDelay(Duration.seconds(3));
        anim.setInterpolator(Interpolator.EASE_OUT);
        anim.setToX(0);
        anim.setToY(0);

        progress = new SimpleDoubleProperty();
        progress.addListener((o, ov, nv) -> {
            if (nv.doubleValue() > 0 && nv.doubleValue() < 1) {
                if(getScaleX() == 0) {
                    setScaleX(1);
                    setScaleY(1);
                }
                arc.setLength(nv.doubleValue() * 360);
            }
            else if(nv.doubleValue() == 1) {
                arc.setLength(360);
                if(anim.getStatus() == Animation.Status.RUNNING) anim.stop();
                anim.play();
            }
        });
    }

    public DoubleProperty progressProperty() {return progress;}
}
