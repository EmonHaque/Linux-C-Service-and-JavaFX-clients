package dialogs;

import abstracts.DialogBase;
import controls.buttons.ActionButton;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.Observable;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.ValidationError;
import skinned.ExtendedListView;

public class InfoKeyValueDialog extends DialogBase {
    private final ActionButton closeButton;
    private final ExtendedListView<ValidationError> view;

    public InfoKeyValueDialog(String title, ObservableList<ValidationError> list) {
        super();
        titlelabel.setText(title);

        view = new ExtendedListView<>(list){{ setBackground(Background.fill(Color.BLACK));}};
        view.setCellFactory(v -> new Cell());
        root.setCenter(view);

        closeButton = new ActionButton(Icons.CloseCircle, 16, "close");
        closeButton.setAction(this::closeDialog);

        buttonsPane.getChildren().add(closeButton);
        GridPane.setHgrow(closeButton, Priority.ALWAYS);
        GridPane.setHalignment(closeButton, HPos.RIGHT);
        GridPane.setMargin(closeButton, new Insets(5, 5, 5, 0));
    }

    @Override
    public void showDialog(double left, double top, double width, double height) {
        super.showDialog(left, top, width, height);
        var h = height / 3;
        view.setMaxHeight(h);
        view.setPrefHeight(h);
        view.setMinHeight(h);
        show();
    }

    private class Cell extends ListCell<ValidationError>{
        private final GridPane root;
        private final Text key, value;

        public Cell() {
            setBackground(null);
            setPadding(new Insets(0));
            setPrefWidth(0);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

            key = new Text(){{ setFont(Constants.Bold); setFill(Color.WHITE);}};
            value = new Text(){{ setFill(Color.WHITE);}};
            root = new GridPane(){{
                getColumnConstraints().addAll(
                        new ColumnConstraints(){{ setPercentWidth(50); setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(){{ setPercentWidth(50); setHalignment(HPos.LEFT);}}
                );
                add(key, 0, 0);
                add(value, 1, 0);
                setHgap(10);
            }};
            itemProperty().addListener(this::onItemChanged);
        }

        private void onItemChanged(Observable o, ValidationError ov, ValidationError nv){
            if(ov != null){
                key.setText(null);
                value.setText(null);
            }
            if(nv != null){
                key.setText(nv.getKey());
                value.setText(nv.getValue());
            }
        }

        @Override
        protected void updateItem(ValidationError item, boolean empty) {
            super.updateItem(item, empty);
            setGraphic(isEmpty()? null : root);
        }
    }
}
