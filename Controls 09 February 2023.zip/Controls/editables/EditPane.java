package editables;

import controls.buttons.CommandButton;
import helpers.Icons;
import interfaces.IExecute;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public class EditPane extends BorderPane {
    private boolean isLoaded, isCancelled, isEditable;
    private final CommandButton edit, cancel, save;
    private final BooleanProperty isOnEditProperty, canEditProperty, canSave;
    private final GridPane buttons;

    public EditPane(IExecute saveAction) {
        isEditable = true;
        isOnEditProperty = new SimpleBooleanProperty();
        canEditProperty = new SimpleBooleanProperty();
        canSave = new SimpleBooleanProperty(true);

        edit = new CommandButton(Icons.Pencil, 16, "edit") {{
            visibleProperty().bind(canEditProperty.and(isOnEditProperty.not()));
            setAction(() -> isOnEditProperty.set(true));
        }};
        cancel = new CommandButton(Icons.CloseCircle, 16, "cancel") {{
            visibleProperty().bind(isOnEditProperty);
            setAction(() -> {
                isCancelled = true;
                isOnEditProperty.set(false);
            });
        }};
        save = new CommandButton(Icons.CheckCircle, 16, "save") {{
            visibleProperty().bind(isOnEditProperty);
            disableProperty().bind(canSave.not());
            setAction(() -> {
                saveAction.execute();
                isCancelled = false;
                isOnEditProperty.set(false);
            });
        }};

        buttons = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints(),
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS); setHalignment(HPos.RIGHT);}}
            );
            add(save, 0, 0);
            add(cancel, 1, 0);
            add(edit, 1, 0);
            setPadding(new Insets(5, 0, 0, 0));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0))));
            visibleProperty().bind(canEditProperty);
        }};
        setBottom(buttons);


    }

    public void makeHoverEdit(){
        getChildren().remove(buttons);
        buttons.getChildren().clear();
        buttons.getColumnConstraints().clear();
        buttons.visibleProperty().unbind();
        buttons.setBorder(null);

        buttons.getColumnConstraints().addAll(
                new ColumnConstraints(){{setHgrow(Priority.ALWAYS); setHalignment(HPos.RIGHT);}},
                new ColumnConstraints() {{setHalignment(HPos.RIGHT);}}
        );
        buttons.add(save, 0, 0);
        buttons.add(cancel, 1, 0);
        buttons.add(edit, 1, 0);
        buttons.setPadding(new Insets(5, 0, 0, 0));
        buttons.setVisible(false);
        setTop(buttons);

        setOnMouseEntered(this::onMouseEnter);
        setOnMouseExited(this::onMouseExit);
    }

    public void makeUneditable(){
        buttons.visibleProperty().unbind();
        buttons.setVisible(false);
        isEditable = false;
    }

    private void onMouseExit(MouseEvent e) {
        if(!isEditable) return;
        if(isOnEditProperty.get()) return;
        buttons.setVisible(false);
    }

    private void onMouseEnter(MouseEvent e) {
        if(!isEditable) return;
        if(isOnEditProperty.get()) return;
        buttons.setVisible(true);
    }

    public BooleanProperty canEditProperty() {return canEditProperty;}

    public BooleanProperty isOnEditProperty() {return isOnEditProperty;}

    public void setCanEdit(boolean value){
        canEditProperty.set(value);
    }
    public void setIsOnEdit(boolean value){
        isOnEditProperty.set(value);
    }

    public boolean canEdit(){return canEditProperty.get();}
    public boolean onEdit(){return isOnEditProperty.get();}
    public boolean isCancelled() { return  isCancelled; }

    public boolean isCanSave() {
        return canSave.get();
    }

    public BooleanProperty canSaveProperty() {
        return canSave;
    }

    public void setCanSave(boolean canSave) {
        this.canSave.set(canSave);
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();

        if(isLoaded) return;
        isLoaded = true;
        visibleProperty().bind(canEditProperty);
    }
}
