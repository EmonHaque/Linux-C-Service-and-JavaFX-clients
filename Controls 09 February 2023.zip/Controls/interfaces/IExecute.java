package interfaces;

public interface IExecute {
    void execute();
}
