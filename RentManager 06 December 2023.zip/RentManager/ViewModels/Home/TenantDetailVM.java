package ViewModels.Home;

import Enums.Function;
import Models.RentPayment;
import Models.Tenant;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import ridiculous.AppData;
import ridiculous.Jar;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class TenantDetailVM {
    public FilteredList<Tenant> tenants;
    public StringProperty statusProperty, depositProperty;
    public BooleanProperty stateProperty, isRunningProperty;
    public IntegerProperty selectedTenantProperty;
    public ObjectProperty<List<RentPayment>> seriesProperty;

    public TenantDetailVM() {
        statusProperty = new SimpleStringProperty("");
        depositProperty = new SimpleStringProperty("");
        stateProperty = new SimpleBooleanProperty();
        isRunningProperty = new SimpleBooleanProperty();
        selectedTenantProperty = new SimpleIntegerProperty();
        seriesProperty = new SimpleObjectProperty<>();

        var tenantSource = new Jar<>(AppData.tenants, o -> new Observable[]{
                stateProperty,
                o.hasLeftProperty()
        });
        tenants = new FilteredList<>(tenantSource, t -> stateProperty.get() != t.isHasLeft());

        stateProperty.addListener(this::onStateChanged);
        selectedTenantProperty.addListener(this::onTenantChanged);
    }

    public void refresh(){
        depositProperty.set("0");
        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private void onStateChanged(ObservableValue<?> o, boolean ov, boolean nv){
        // onTenantChanged is called several times on state change probably because of Jar<> technology and inefficient filtering
        // refresh();
    }

    private void onTenantChanged(ObservableValue<?> o, Number ov, Number nv){
        if(nv.intValue() <= 0) return;
        refresh();
    }

    private class ResponseTask extends Task<List<RentPayment>>{
        private int length, deposit;

        @Override
        protected List<RentPayment> call() throws Exception {
            updateMessage("requesting ...");
            Thread.sleep(500);

            var request = new Request(Function.GetTenantDetail.ordinal(), ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(selectedTenantProperty.get()));
            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return null;
            }
            length = response.getPacket().length;
            var buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
            updateMessage("received " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);

            updateMessage("processing " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);

            deposit = buffer.getInt();

            var list = new ArrayList<RentPayment>();
            int read, start, index;
            read = start = 4;
            index = 0;
            while (read < length) {
                var segments = new String[4];
                while (read < length) {
                    if (buffer.get(read) != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }
                var rp = new RentPayment();
                rp.setDate(LocalDate.parse(segments[0], DateTimeFormatter.ofPattern("yyyy-MM-dd")));
                rp.setPlot(segments[1]);
                rp.setSpace(segments[2]);
                rp.setTenant(segments[3]);
                rp.setDue(buffer.getInt(start));
                rp.setCash(buffer.getInt(start + 4));
                rp.setMobile(buffer.getInt(start + 8));
                rp.setKind(buffer.getInt(start + 12));
                rp.setTotal(buffer.getInt(start + 16));
                list.add(rp);

                read += 20;
                start = read;
                index = 0;
            }

            return list;
        }

        @Override
        protected void succeeded() {
            try {
                depositProperty.set(String.format("%,d", deposit));
                var list = get();
                seriesProperty.set(list);
                updateMessage("processed " + String.format("%,d", length) + " bytes");
                Thread.sleep(500);
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
