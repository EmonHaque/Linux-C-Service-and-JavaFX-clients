package ViewModels.Report;

import Models.Tenant;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;
import ridiculous.Jar;

public class TenantLedgerVM extends BaseLedgerVM<Tenant>{
    @Override
    protected String getWhere() {
        return "TenantId";
    }

    @Override
    public String getHeader() {
        return "Tenant";
    }

    @Override
    protected FilteredList<Tenant> getSelectionList() {
        return new FilteredList<>(new Jar<>(AppData.tenants));
    }
}
