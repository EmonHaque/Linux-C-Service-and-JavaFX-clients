package ViewModels.Report;

import Enums.Function;
import Models.Balance;
import Models.Plot;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Press;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class ReportBalanceVM {
    public IntegerProperty selectedPlotProperty;
    public StringProperty statusProperty, queryProperty;
    public BooleanProperty stateProperty, isRunningProperty;
    public FilteredList<Plot> plots;
    public FilteredList<Balance> balances;
    public Press press;

    private final ObservableList<Balance> summary;

    public ReportBalanceVM() {
        press = new Press();
        selectedPlotProperty = new SimpleIntegerProperty();
        statusProperty = new SimpleStringProperty();
        queryProperty = new SimpleStringProperty("");
        stateProperty = new SimpleBooleanProperty();
        isRunningProperty = new SimpleBooleanProperty();

        plots = new FilteredList<>(AppData.plots);
        summary = FXCollections.observableArrayList(o -> new Observable[]{queryProperty});
        balances = new FilteredList<>(summary, x -> {
            var lower = queryProperty.get().trim().toLowerCase();
            if (lower.isEmpty()) return true;
            return x.getSpace().toLowerCase().contains(lower)
                    || x.getTenant().toLowerCase().contains(lower);
        });

        selectedPlotProperty.addListener(o -> updateReportable());
        stateProperty.addListener(o -> updateReportable());
    }

    public void updateReportable() {
        if (selectedPlotProperty.get() <= 0) return;

        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    public void print() {
        press.resetPrinterList();
        if (!press.available()) {
            // show info dialog
            return;
        }
        press.setSelected(null);
        if (press.getPrinters().size() == 1) {
            press.setSelected(press.getPrinters().get(0));
        }
        else {
            press.dialogTrigger.set(true);
            if (press.getPrinterJob() == null) return;
        }
        var task = new PrintTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task) {{setDaemon(true);}}.start();
    }

    private class PrintTask extends Task<Void> {
        private final double dateWidth = 65, amountWidth = 50;
        private double width, accumulatedHeight, leftOverHeight;
        private int pageNo;
        private GridPane pageGrid, contentGrid;
        private Text pageNoText;
        private final Font normal = Font.font(9);
        private final Border topBorder = new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 0, 0)));
        private Map<String, List<Balance>> multiple;
        private List<Balance> single;

        @Override
        protected Void call() throws Exception {
            updateMessage("setting up header and footers");
            Thread.sleep(250);

            sort();
            var layout = press.getPrinterJob().getJobSettings().getPageLayout();
            width = layout.getPrintableWidth();

            var header = getHeader();
            var footer = getFooter();
            leftOverHeight = layout.getPrintableHeight() - header.prefHeight(-1) - footer.prefHeight(-1);

            contentGrid = new GridPane() {{
                setMinSize(width, leftOverHeight);
                setPrefSize(width, leftOverHeight);
                setMaxSize(width, leftOverHeight);
            }};
            pageGrid = new GridPane() {{
                addRow(0, header);
                addRow(1, contentGrid);
                addRow(2, footer);
            }};

            updateMessage("generating pages");
            Thread.sleep(250);

            pageNo = 1;
            setPageNo(pageNo);

            int totalSecurity = 0, totalRent = 0, totalDue = 0;
            GridPane row;

            for(var tenant : multiple.keySet()){
                var name = new Text(tenant){{ setFont(normal);}};
                checkLimit(name);
                contentGrid.addRow(contentGrid.getRowCount(), name);

                var value = multiple.get(tenant);
                int sumSecurity = 0, sumRent = 0, sumDue = 0;

                for (var item : value) {
                    row = getRow(item, 1);
                    checkLimit(row);
                    contentGrid.addRow(contentGrid.getRowCount(), row);

                    sumSecurity += item.getSecurity();
                    sumRent += item.getRent();
                    sumDue += item.getDue();
                }
                row = getSubtotalRow(sumSecurity, sumRent, sumDue);
                GridPane.setHalignment(row, HPos.RIGHT);
                checkLimit(row);

                contentGrid.addRow(contentGrid.getRowCount(), row);

                totalSecurity += sumSecurity;
                totalRent += sumRent;
                totalDue += sumDue;
            }
            for(var tenant : single){
                row = getRow(tenant, 0);
                checkLimit(row);
                contentGrid.addRow(contentGrid.getRowCount(), row);

                totalSecurity += tenant.getSecurity();
                totalRent += tenant.getRent();
                totalDue += tenant.getDue();
            }

            row = getTotalRow(totalSecurity, totalRent, totalDue);
            checkLimit(row);
            contentGrid.addRow(contentGrid.getRowCount(), row);

            updateMessage("printing page " + pageNo);
            press.getPrinterJob().printPage(pageGrid);
            press.getPrinterJob().endJob();

            updateMessage("Finished printing " + pageNo + " page(s)");
            Thread.sleep(500);
            return null;
        }

        private void sort(){
            multiple = new LinkedHashMap<>();
            single = new ArrayList<>();
            int index;
            for (int i = 0; i < summary.size(); i += index){
                index = summary.get(i).getCount();
                if (summary.get(i).getCount() > 1) {
                    var internalList = new ArrayList<Balance>();
                    for (int j = i; j < i + summary.get(i).getCount(); j++) {
                        if (!summary.get(j).isExpired()) internalList.add(summary.get(j));
                        else if (summary.get(j).getSecurity() != summary.get(j).getDue())
                            internalList.add(summary.get(j));
                    }
                    var first = internalList.get(0);
                    if (internalList.size() > 1) {
                        multiple.put(first.getTenant(), internalList);
                    }
                    else single.add(first);
                }
                else single.add(summary.get(i));
            }
        }

        private void checkLimit(Node row){
            double requiredHeight = row.prefHeight(-1);
            accumulatedHeight += requiredHeight;

            if ((leftOverHeight - accumulatedHeight) < 0) {
                updateMessage("printing page " + pageNo);
                press.getPrinterJob().printPage(pageGrid);
                contentGrid.getChildren().clear();
                setPageNo(++pageNo);
                accumulatedHeight = requiredHeight;
            }
        }

        private GridPane getRow(Balance e, int level) {
            // level 0 = tenant and space combined
            // level 1 = space name

            var date = new Text(e.getDateStart()) {{setFont(normal);}};
            var particulars = new Text() {{setWrappingWidth(width - dateWidth - 3 * amountWidth); setFont(normal);}};
            var security = new Text(AppData.formatNumber(e.getSecurity())) {{setFont(normal);}};
            var rent = new Text(AppData.formatNumber(e.getRent())) {{setFont(normal);}};
            var due = new Text(AppData.formatNumber(e.getDue())) {{setFont(normal);}};

            switch (level) {
                case 0 -> particulars.setText(e.getTenant() + " : " + e.getSpace());
                case 1 -> {
                    if(e.isExpired()){
                        particulars.setText(e.getSpace() + " expired on " + e.getDateEnd());
                    }
                    else{
                        particulars.setText(e.getSpace());
                    }
                    GridPane.setMargin(particulars, new Insets(0, 0, 0, 10));
                }
            }

            return new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(width - dateWidth - 3 * amountWidth),
                        new ColumnConstraints(dateWidth),
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(particulars, 0, 0);
                add(date, 1, 0);
                add(security, 2, 0);
                add(rent, 3, 0);
                add(due, 4, 0);
                setPadding(new Insets(2.5, 0, 2.5, 0));
            }};
        }

        private GridPane getSubtotalRow(int security, int rent, int due) {
            var securityText = new Text(AppData.formatNumber(security)) {{setFont(normal);}};
            var rentText = new Text(AppData.formatNumber(rent)) {{setFont(normal);}};
            var dueText = new Text(AppData.formatNumber(due)) {{setFont(normal);}};

            return new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(securityText, 0, 0);
                add(rentText, 1, 0);
                add(dueText, 2, 0);

                setMinWidth(3 * amountWidth);
                setMaxWidth(3 * amountWidth);
                setPrefWidth(3 * amountWidth);

                setPadding(new Insets(1, 0, 1, 0));
                setBorder(topBorder);
            }};
        }

        private GridPane getTotalRow(int security, int rent, int due) {
            var particulars = new Text("Total") {{
                setWrappingWidth(width - dateWidth - 3 * amountWidth); setFont(normal);
            }};
            var securityText = new Text(AppData.formatNumber(security)) {{setFont(normal);}};
            var rentText = new Text(AppData.formatNumber(rent)) {{setFont(normal);}};
            var dueText = new Text(AppData.formatNumber(due)) {{setFont(normal);}};

            return new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(width - 3 * amountWidth),
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(particulars, 0, 0);
                add(securityText, 1, 0);
                add(rentText, 2, 0);
                add(dueText, 3, 0);

                setPadding(new Insets(1, 0, 1, 0));
                setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 0, 0))));
            }};
        }

        private Node getHeader() {
            String head1, head2;
            var plot = AppData.plots.stream().filter(x -> x.getId() == selectedPlotProperty.get()).findFirst().get();
            head1 = plot.getName();
            head2 = plot.getDescription();


            var row1 = new Text(head1) {{
                setTextAlignment(TextAlignment.CENTER);
                setFont(Font.font(12));
            }};
            var row2 = new Text(head2) {{
                setTextAlignment(TextAlignment.CENTER);
                setFont(Font.font(11));
            }};
            var row3 = new Text("as at " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"))) {{
                setTextAlignment(TextAlignment.CENTER);
                setFont(Font.font(10));
            }};

            var tableHeader = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(width - dateWidth - 3 * amountWidth),
                        new ColumnConstraints(dateWidth){{ setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(new Text("Particulars") {{setFont(normal);}}, 0, 0);
                add(new Text("From") {{setFont(normal);}}, 1, 0);
                add(new Text("Security") {{setFont(normal);}}, 2, 0);
                add(new Text("Rent") {{setFont(normal);}}, 3, 0);
                add(new Text("Due") {{setFont(normal);}}, 4, 0);

                setPadding(new Insets(1, 0, 1, 0));
                setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 1, 0))));
            }};

            return new VBox(row1, row2, row3, tableHeader) {{
                setAlignment(Pos.TOP_CENTER);
                setPrefWidth(width);
                setMargin(tableHeader, new Insets(2.5, 0, 2.5, 0));
            }};
        }

        private Node getFooter() {
            var date = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));
            var time = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a"));
            var left = new Text("Generated on " + date + " | " + time) {{setFont(normal);}};
            pageNoText = new Text() {{setFont(normal);}};
            return new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints()
                );
                add(left, 0, 0);
                add(pageNoText, 1, 0);

                setPrefWidth(width);
                setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 0, 0))));
            }};
        }

        void setPageNo(int pageNo) {
            pageNoText.setText("Page No: " + pageNo);
        }
    }

    private class ResponseTask extends Task<List<Balance>> {
        private int length;
        @Override
        protected List<Balance> call() throws Exception {
            updateMessage("requesting data ...");
            Thread.sleep(250);

            var buffer = ByteBuffer.allocate(5)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .putInt(selectedPlotProperty.get())
                    .put(stateProperty.get() ? (byte) 1 : 0);

            var request = new Request(Function.GetBalance.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                return null;
            }
            length = response.getPacket().length;
            if (length == 0) {
                updateMessage("no data available");
                Thread.sleep(500);
                return null;
            }
            updateMessage("processing " + String.format("%,d", length) + " bytes");
            Thread.sleep(250);

            buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
            return getList(buffer, length);
        }

        @Override
        protected void succeeded() {
            summary.clear();
            try {
                var result = get();
                if (result == null) return;
                summary.addAll(result);
                updateMessage("processed " + String.format("%,d", length) + " bytes");
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        private List<Balance> getList(ByteBuffer buffer, int length) {
            var list = new ArrayList<Balance>();
            var span = buffer.array();
            int start, index, read;
            start = read = index = 0;
            var segments = new String[4];

            while (read < length) {
                while (read < length) {
                    if (span[read] != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(span, start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }
                var balance = new Balance() {{
                    setSpace(segments[0]);
                    setTenant(segments[1]);
                    setDateStart(segments[2]);
                    setDateEnd(segments[3]);
                }};
                balance.setSecurity(buffer.getInt(read));
                balance.setRent(buffer.getInt(read + 4));
                balance.setDue(buffer.getInt(read + 8));
                balance.setCount(buffer.getInt(read + 12));
                balance.setExpired(buffer.get(read + 16) != 0);
                list.add(balance);

                index = 0;
                read += 17;
                start = read;
            }

            //what's this?
            var reoccupied = list.stream().collect(Collectors.groupingBy(Balance::getTenant,
                            Collectors.groupingBy(Balance::getSpace)))
                    .values().stream()
                    .flatMap(x -> x.values().stream())
                    .filter(x -> x.size() > 1)
                    .flatMap(Collection::stream).toList();

            if (reoccupied.size() > 0) {
                if (stateProperty.get()) {
                    for (var occupation : reoccupied) {
                        if (!occupation.isExpired()) continue;
                        if (occupation.getSecurity() > 0)
                            occupation.setSecurity(0);
                    }
                }
                else {
                    int exceptLastOne = reoccupied.size() - 1;
                    for (int i = 0; i < exceptLastOne; i++) {
                        reoccupied.get(i).setSecurity(0);
                    }
                }
            }

            return list;
        }
    }
}
