package ViewModels.Report;

import Enums.Function;
import Models.ReceiptPayment;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Press;
import ridiculuous.Request;
import trees.ReceiptPaymentTree;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class ReportReceiptPaymentVM {
    private final ObservableList<ReceiptPayment> list;
    public ListProperty<ReceiptPayment> listProperty;
    public ObjectProperty<LocalDate> startDateProperty, endDateProperty;
    public StringProperty statusProperty;
    public BooleanProperty isRunningProperty;

    public Press press;

    public ReportReceiptPaymentVM() {
        press = new Press();
        statusProperty = new SimpleStringProperty();
        isRunningProperty = new SimpleBooleanProperty();

        var now = LocalDate.now();
        startDateProperty = new SimpleObjectProperty<>(now.minusMonths(1));
        endDateProperty = new SimpleObjectProperty<>(now);

        list = FXCollections.observableArrayList();
        listProperty = new SimpleListProperty<>(list);
    }

    public void updateReportable() {
        var task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    public void print(){
        press.resetPrinterList();
        if (!press.available()) {
            // show info dialog
            return;
        }
        press.setSelected(null);
        if (press.getPrinters().size() == 1) {
            press.setSelected(press.getPrinters().get(0));
        }
        else {
            press.dialogTrigger.set(true);
            if (press.getPrinterJob() == null) return;
        }

        var task = new PrintTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task) {{setDaemon(true);}}.start();
    }

    private class PrintTask extends Task<Void>{
        private final double amountWidth = 55;
        private double width, accumulatedHeight, leftOverHeight;
        private int pageNo;
        private GridPane pageGrid, contentGrid;
        private Text pageNoText;
        private final Font normal = Font.font(9);
        private final Font bold = Font.font(null, FontWeight.BOLD, 9);
        private final Border topBorder = new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 0, 0), new Insets(-1,0,-1,0)));
        private final Border bottomBorder = new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(0, 0, 1, 0), new Insets(-1,0,-1,0)));

        @Override
        protected Void call() throws Exception {
            var tree = (ReceiptPaymentTree)press.getPrintable();
            if(tree.getRoot().getChildren().size() == 0){
                updateMessage("nothing to print");
                Thread.sleep(250);
                return null;
            }
            updateMessage("setting up header and footers");
            Thread.sleep(250);
            var layout = press.getPrinterJob().getJobSettings().getPageLayout();
            width = layout.getPrintableWidth();

            var header = getHeader();
            var footer = getFooter();
            leftOverHeight = layout.getPrintableHeight() - header.prefHeight(-1) - footer.prefHeight(-1);

            contentGrid = new GridPane() {{
                setMinSize(width, leftOverHeight);
                setPrefSize(width, leftOverHeight);
                setMaxSize(width, leftOverHeight);
            }};
            pageGrid = new GridPane() {{
                addRow(0, header);
                addRow(1, contentGrid);
                addRow(2, footer);
            }};

            updateMessage("generating pages");
            Thread.sleep(250);

            pageNo = 1;
            setPageNo(pageNo);

            GridPane row;
            for(var control : tree.getRoot().getChildren()){
                row = getRow(control.getValue(), 1, true, false);
                checkLimit(row);
                contentGrid.addRow(contentGrid.getRowCount(), row);

                for(var head : control.getChildren()){
                    row = getRow(head.getValue(), 2, true, false);
                    checkLimit(row);
                    contentGrid.addRow(contentGrid.getRowCount(), row);

                    for(var plot : head.getChildren()){
                        row = getRow(plot.getValue(), 3, true, false);
                        checkLimit(row);
                        contentGrid.addRow(contentGrid.getRowCount(), row);

                        for(var tenant : plot.getChildren()){
                            row = getRow(tenant.getValue(), 4, false, false);
                            checkLimit(row);
                            contentGrid.addRow(contentGrid.getRowCount(), row);

                            int index = 0;
                            for(var space : tenant.getChildren()){
                                row = getRow(space.getValue(), 5, index == tenant.getChildren().size() - 1, index == 0);
                                checkLimit(row);
                                contentGrid.addRow(contentGrid.getRowCount(), row);
                                index++;
                            }
                        }
                    }
                }
            }

            updateMessage("printing page " + pageNo);
            press.getPrinterJob().printPage(pageGrid);
            press.getPrinterJob().endJob();

            updateMessage("Finished printing " + pageNo + " page(s)");
            Thread.sleep(500);

            return null;
        }

        private Node getHeader() {
            var from = startDateProperty.get().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));
            var to = endDateProperty.get().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));

            var row1 = new Text("Receipt & Payment") {{
                setTextAlignment(TextAlignment.CENTER);
                setFont(Font.font(12));
            }};
            var row2 = new Text("for the period from " + from + " to " + to) {{
                setTextAlignment(TextAlignment.CENTER);
                setFont(Font.font(10));
            }};

            var tableHeader = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(width - 4 * amountWidth),
                        new ColumnConstraints(amountWidth){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(new Text("Particulars") {{setFont(bold);}}, 0, 0);
                add(new Text("Cash") {{setFont(bold);}}, 1, 0);
                add(new Text("Kind") {{setFont(bold);}}, 2, 0);
                add(new Text("Mobile") {{setFont(bold);}}, 3, 0);
                add(new Text("Total") {{setFont(bold);}}, 4, 0);

                setPadding(new Insets(1, 0, 1, 0));
                setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 1, 0))));
            }};

            return new VBox(row1, row2, tableHeader) {{
                setAlignment(Pos.TOP_CENTER);
                setPrefWidth(width);
                setMargin(tableHeader, new Insets(2.5, 0, 2.5, 0));
            }};
        }

        private Node getFooter() {
            var date = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));
            var time = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a"));
            var left = new Text("Generated on " + date + " | " + time) {{setFont(normal);}};
            pageNoText = new Text() {{setFont(normal);}};
            return new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints()
                );
                add(left, 0, 0);
                add(pageNoText, 1, 0);

                setPrefWidth(width);
                setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 0, 0))));
            }};
        }

        private GridPane getRow(ReceiptPayment e, int level, boolean needBottomBorder, boolean needTopBorder) {
            int indent = 10;
            var particulars = new Text() {{setWrappingWidth(width - 4 * amountWidth); setFont(bold);}};
            var cash = new Text(AppData.formatNumber(e.getCash())) {{setFont(bold);}};
            var kind = new Text(AppData.formatNumber(e.getKind())) {{setFont(bold);}};
            var mobile = new Text(AppData.formatNumber(e.getMobile())) {{setFont(bold);}};
            var total = new Text(AppData.formatNumber(e.getTotal())) {{setFont(bold);}};

            switch (level) {
                case 1 -> particulars.setText(e.getControl());
                case 2 -> particulars.setText(e.getHead());
                case 3 -> particulars.setText(e.getPlot());
                case 4 -> {
                    if(e.getSpace() == null){
                        particulars.setText(e.getTenant());
                    }
                    else {
                        particulars.setText(e.getTenant() + " - " + e.getSpace());
                    }
                }
                case 5 -> particulars.setText(e.getSpace());
            }

            if(level >= 4){
                particulars.setFont(normal);
                cash.setFont(normal);
                kind.setFont(normal);
                mobile.setFont(normal);
                total.setFont(normal);
            }
            var leftMargin = indent * (level - 1);
            particulars.setWrappingWidth(width - 4 * amountWidth - leftMargin);
            var grid = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(width - 4 * amountWidth - leftMargin),
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(amountWidth) {{setHalignment(HPos.RIGHT);}}
                );
                add(particulars, 0, 0);
                add(cash, 1, 0);
                add(kind, 2, 0);
                add(mobile, 3, 0);
                add(total, 4, 0);
                setPadding(new Insets(2.5, 0, 2.5, 0));
            }};
            if(needBottomBorder) grid.setBorder(bottomBorder);
            else if(needTopBorder) grid.setBorder(topBorder);
            GridPane.setMargin(grid, new Insets(0,0,0, leftMargin));
            return grid;
        }

        private void checkLimit(Node row){
            double requiredHeight = row.prefHeight(-1);
            accumulatedHeight += requiredHeight;

            if ((leftOverHeight - accumulatedHeight) < 0) {
                updateMessage("printing page " + pageNo);
                press.getPrinterJob().printPage(pageGrid);
                contentGrid.getChildren().clear();
                setPageNo(++pageNo);
                accumulatedHeight = requiredHeight;
            }
        }

        void setPageNo(int pageNo) {
            pageNoText.setText("Page No: " + pageNo);
        }
    }

    private class ResponseTask extends Task<List<ReceiptPayment>> {
        @Override
        protected List<ReceiptPayment> call() throws Exception {
            updateMessage("requesting data ...");
            Thread.sleep(500);

            var start = (startDateProperty.get().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
            var end = (endDateProperty.get().toString() + '\0').getBytes(StandardCharsets.US_ASCII);
            var buffer = ByteBuffer.allocate(start.length + end.length).order(ByteOrder.LITTLE_ENDIAN);
            buffer.put(start);
            buffer.put(end);
            var request = new Request(Function.GetReceiptPayment.ordinal(), buffer);

            var response = Channels.getInstance().getResponse(request).get();
            if (!response.isSuccess()) {
                updateMessage("service down ...");
                Thread.sleep(500);
                return null;
            }
            int length = response.getPacket().length;
            if (length == 0) {
                updateMessage("no data available");
                Thread.sleep(500);
                return null;
            }
            updateMessage("received " + String.format("%,d", length) + " bytes");
            Thread.sleep(500);

            buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
            return getList(buffer, length);
        }

        @Override
        protected void succeeded() {
            list.clear();
            try {
                var result = get();
                if (result == null) return;
                list.addAll(result);
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        private List<ReceiptPayment> getList(ByteBuffer buffer, int length) {
            var list = new ArrayList<ReceiptPayment>();
            var span = buffer.array();
            int start, index, read;
            start = read = index = 0;
            var segments = new String[5];
            while (read < length) {
                while (read < length) {
                    if (span[read] != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }
                var rp = new ReceiptPayment() {{
                    setControl(segments[0]);
                    setHead(segments[1]);
                    setPlot(segments[2]);
                    setSpace(segments[3]);
                    setTenant(segments[4]);

                }};
                rp.setCash(buffer.getInt(read));
                rp.setMobile(buffer.getInt(read + 4));
                rp.setKind(buffer.getInt(read + 8));
                rp.setTotal(buffer.getInt(read + 12));
                list.add(rp);

                index = 0;
                read += 16;
                start = read;
            }
            return list;
        }
    }
}
