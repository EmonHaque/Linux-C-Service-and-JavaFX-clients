package ChartControls.DoubleColimn;

import Models.RentPayment;
import abstracts.ListCellBase;
import abstracts.XYChartBase;
import controls.PopupDraggable;
import controls.columnstackchart.DoubleBar;
import helpers.Constants;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import skinned.ExtendedResizableListView;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DoubleColumnChart extends XYChartBase<RentPayment> {
    private final List<DoubleBar> bars;

    public DoubleColumnChart() {
        bars = new ArrayList<>();
    }

    @Override
    protected void setMinMaxAndXLabels() {
        double step = (max - min) / (numLines - 1);
        double current = min;
        for (var t : yLabels.getChildren()) {
            var label = (Text) t;
            label.setText(String.format("%,d", (int) current));
            current += step;
            yLabelWidth = label.prefWidth(-1);
        }
    }

    @Override
    protected void reset() {
        for(var bar : bars) getChildren().remove(bar);
        bars.clear();

        var days = series.stream().map(RentPayment::getDate).distinct().toList();
        for(var day : days){
            var list = series.stream().filter(x -> x.getDate().isEqual(day)).toList();
            double dueTotal = 0, cash = 0, kind = 0, mobile = 0, total = 0;
            for(var item : list){
                dueTotal += item.getDue();
                cash += item.getCash();
                kind += item.getKind();
                mobile += item.getMobile();
                total += item.getTotal();
            }
            if(max < total) max = total;
            if(max < dueTotal) max = dueTotal;
            if(min > dueTotal) min = dueTotal;

            var xLabel = new Text(day.toString());
            xLabel.setFill(Color.WHITE);
            xLabel.setRotate(-90);
            xLabel.setManaged(false);
            xLabels.getChildren().add(xLabel);

            if (xLabelWidth < xLabel.prefWidth(-1))
                xLabelWidth = xLabel.prefWidth(-1);

            var doubles = new ArrayList<Double>();
            if (cash > 0) doubles.add(cash);
            if (kind > 0) doubles.add(kind);
            if (mobile > 0) doubles.add(mobile);
            var bar = new DoubleBar(dueTotal, doubles){{ setManaged(false);}};
            bar.setToolTip(getToolTip(day, list, new int[]{ (int)dueTotal, (int)cash, (int)kind, (int)mobile, (int)total}));
            getChildren().add(bar);
            bars.add(bar);
        }
    }

    @Override
    protected void layoutChildren() {
        if(series == null) return;
        super.layoutChildren();

        double barX = startX;
        double gap = 5;
        var colWidth = (availableWidth - gap * bars.size()) / bars.size();
        double xLabelX = barX + colWidth / 2;

        double x = barX;
        for (int i = 0; i < bars.size(); i++) {
            var text = (Text) xLabels.getChildren().get(i);
            text.setY(availableHeight + text.prefWidth(-1) / 2 + text.prefHeight(-1) / 2);
            text.setX(xLabelX - text.prefWidth(-1) / 2);

            var bar = bars.get(i);
            bar.makeColumn(colWidth, availableHeight, min, max);
            bar.resizeRelocate(x, availableHeight, colWidth, availableHeight);

            xLabelX += colWidth + gap;
            x += colWidth + gap;
        }
    }

    private PopupDraggable getToolTip(LocalDate date, List<RentPayment> list, int[] summaries){
        var bold = Font.font(null, FontWeight.BOLD, -1);

        var heading = new Text("Detail of " + date.toString()){{
            setFill(Color.LIGHTGRAY);
            setFont(Font.font(null, FontWeight.BOLD, 14));
        }};
        var header = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(150),
                    new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Space"){{ setFill(Color.WHITE); setFont(bold);}}, 0, 0);
            add(new Text("Due"){{ setFill(Color.WHITE); setFont(bold);}}, 1, 0);
            add(new Text("Cash"){{ setFill(Color.WHITE); setFont(bold);}}, 2, 0);
            add(new Text("Kind"){{ setFill(Color.WHITE); setFont(bold);}}, 3, 0);
            add(new Text("Mobile"){{ setFill(Color.WHITE); setFont(bold);}}, 4, 0);
            add(new Text("Total"){{ setFill(Color.WHITE); setFont(bold);}}, 5, 0);

            setPadding(new Insets(2.5, Constants.ScrollBarSize, 2.5, 0));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25, 0, 0.25, 0))));
        }};

        var footer = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(150),
                    new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Total of " + list.size()){{ setFill(Color.WHITE); setFont(bold);}}, 0, 0);
            add(new Text(String.format("%,d", summaries[0])){{ setFill(Color.WHITE); setFont(bold);}}, 1, 0);
            add(new Text(String.format("%,d", summaries[1])){{ setFill(Color.WHITE); setFont(bold);}}, 2, 0);
            add(new Text(String.format("%,d", summaries[2])){{ setFill(Color.WHITE); setFont(bold);}}, 3, 0);
            add(new Text(String.format("%,d", summaries[3])){{ setFill(Color.WHITE); setFont(bold);}}, 4, 0);
            add(new Text(String.format("%,d", summaries[4])){{ setFill(Color.WHITE); setFont(bold);}}, 5, 0);

            setPadding(new Insets(2.5, Constants.ScrollBarSize, 2.5, 0));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25, 0, 0, 0))));
        }};

        var listView = new ExtendedResizableListView<>(FXCollections.observableArrayList(list));
        listView.setCellFactory(v -> new Cell());

        var box = new VBox(heading, header, listView, footer){{
            setPadding(new Insets(5));
            setMargin(heading, new Insets(0,0,5,0));
            setBackground(Background.fill(Constants.BackgroundColor));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
            setVgrow(listView, Priority.SOMETIMES);
        }};
        return new PopupDraggable(){{ getContent().add(box);}};
    }

    private class Cell extends ListCellBase<RentPayment>{
        private GridPane root;
        private Text name, due, cash, kind, mobile, total;
        @Override
        protected void initializeUI() {
            name = new Text(){{
                setFill(Color.WHITE);
                setWrappingWidth(150);
            }};
            due = new Text(){{setFill(Color.WHITE);}};
            cash = new Text(){{setFill(Color.WHITE);}};
            kind = new Text(){{setFill(Color.WHITE);}};
            mobile = new Text(){{setFill(Color.WHITE);}};
            total = new Text(){{setFill(Color.WHITE);}};

            root = new GridPane(){{
                getColumnConstraints().addAll(
                        new ColumnConstraints(150),
                        new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}}
                );
                add(name, 0, 0);
                add(due, 1, 0);
                add(cash, 2, 0);
                add(kind, 3, 0);
                add(mobile, 4, 0);
                add(total, 5, 0);
            }};
        }

        @Override
        protected void onItemChanged(ObservableValue<?> o, RentPayment ov, RentPayment nv) {
            if(nv != null){
                name.setText(nv.getPlot() + "; " + nv.getSpace());
                due.setText(String.format("%,d", nv.getDue()));
                cash.setText(String.format("%,d", nv.getCash()));
                kind.setText(String.format("%,d", nv.getKind()));
                mobile.setText(String.format("%,d", nv.getMobile()));
                total.setText(String.format("%,d", nv.getTotal()));
            }
        }

        @Override
        protected Node getRootNode() {
            return root;
        }
    }
}
