package Views.Transaction;

import ViewModels.Transaction.BulkRentVM;
import abstracts.View;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.daymonth.MonthPicker;
import controls.texts.TextBox;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import trees.BulkRentTree;

public class BulkRent extends View {
    private BulkRentVM vm;
    private BulkRentTree tree;
    private TextBox query;
    private HBox countBox;
    private Text count, excluded, status;
    private MonthPicker month;
    private CommandButton add;
    private SpinningArc spinner;

    @Override
    protected String getHeader() {
        return "Rent for month";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new BulkRentVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        month = new MonthPicker("Month", Icons.Month, true);
        query = new TextBox("Search", Icons.Magnify, false);
        count = new Text() {{setFill(Color.WHITE);}};
        excluded = new Text() {{setFill(Color.WHITE);}};
        countBox = new HBox() {{
            getChildren().addAll(
                    excluded,
                    new Text("/") {{setFill(Color.WHITE);}},
                    count,
                    new Text(" excluded") {{setFill(Color.WHITE);}}
            );
            setAlignment(Pos.BOTTOM_LEFT);
        }};
        tree = new BulkRentTree(vm.leases, vm.queryProperty);
        add = new CommandButton(Icons.Add, 16, "add");

        var queryCount = new HBox(query, countBox) {{
            setHgrow(query, Priority.ALWAYS);
            setSpacing(10);
        }};
        setCenter(new VBox(month, queryCount, tree, add) {{
            setVgrow(tree, Priority.ALWAYS);
            setSpacing(5);
            setPadding(new Insets(5,0,0,0));
            setAlignment(Pos.BOTTOM_RIGHT);
        }});

        status = new Text(){{ setFill(Color.WHITE);}};
        spinner = new SpinningArc();

        addAction(spinner);
        addAction(status);
    }

    private void bind() {
        vm.selectedDate.bind(month.selectedDateProperty());
        vm.queryProperty.bind(query.textProperty());
        count.textProperty().bind(Bindings.size(vm.leases).asString());
        excluded.textProperty().bind(Bindings.size(tree.selectedItems).asString());
        Bindings.bindContent(vm.excluded, tree.selectedItems);
        add.disableProperty().bind(month.isEmpty());
        add.setAction(vm::add);

        spinner.visibleProperty().bind(vm.isRunningProperty);
        status.textProperty().bind(vm.statusProperty);
    }
}
