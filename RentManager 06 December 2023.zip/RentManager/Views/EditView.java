package Views;

import Views.Edit.*;
import abstracts.View;
import abstracts.ViewContainer;
import helpers.Icons;

public class EditView extends ViewContainer {
    private final View editPlot;

    public EditView() {
        editPlot = new EditPlot();
        addView(editPlot);
        addView(new EditSpace());
        addView(new EditTenant());
        addView(new EditLease());
        addView(new EditHead());
        addView(new EditTransaction());
    }

    @Override
    public View initialView() {
        return editPlot;
    }

    @Override
    protected String getIcon() {
        return Icons.Edit;
    }

    @Override
    protected String getTip() {
        return "Edit";
    }
}
