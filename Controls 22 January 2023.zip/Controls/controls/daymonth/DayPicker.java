package controls.daymonth;

import abstracts.SelectionControlBase;
import controls.buttons.ActionButton;
import enums.CalendarState;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.WindowEvent;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DayPicker extends SelectionControlBase {
    private GridPane headerContainer, dayMonthYearContainer, dayNameContainer;
    private LocalDate currentDate;
    private final LocalDate today = LocalDate.now();
    private DateTimeFormatter formatter;
    private ActionButton back, forward;
    private Text headerText, selectedText;
    private CalendarState currentState;
    private int floorYear, capYear;
    //private boolean isLoaded;

    private final ObjectProperty<LocalDate> selectedDate, startDate, endDate;

    public DayPicker(String hint, String leftIcon, boolean isRequired) {
        super(hint, leftIcon, isRequired);
        selectedDate = new SimpleObjectProperty<>();
        startDate = new SimpleObjectProperty<>();
        endDate = new SimpleObjectProperty<>();

        checkSelectedOnInitialization();

        input.setOnKeyPressed(this::onInputKey);
        selectedDate.addListener(this::onSelectedDayChanged);
    }

    @Override
    protected String getRightIcon() {
        return Icons.MonthPicker;
    }

    @Override
    protected Node getSelectedContent() {
        selectedText = new Text();
        selectedText.setFill(Color.WHITE);
        return selectedText;
    }

    @Override
    protected void addPopup() {
        super.addPopup();
        initializeDayContainer();
        addHeader();
    }

    @Override
    protected void onPopupShowing(WindowEvent e) {
        super.onPopupShowing(e);
        if (currentState != CalendarState.Day) {
            currentState = CalendarState.Day;
        }
        currentDate = selectedDate.get() == null ? LocalDate.now() : selectedDate.get();
        addDays(currentDate);
        checkDateValidity();
    }

    @Override
    protected void removeSelected() {
        super.removeSelected();
        selectedDate.set(null);
    }

    private void onSelectedDayChanged(ObservableValue<?> o, LocalDate ov, LocalDate nv) {
        if (nv != null) {
//            if (!isLoaded && !currentDate.isEqual(nv)) {
//                addDays(nv);
//                checkDateValidity();
//                isLoaded = true;
//            }
            if (!currentDate.isEqual(nv)) {
                addDays(nv);
            }
            currentDate = nv;
            setSelected(nv);
            checkDateValidity();
        }
    }

    private void checkSelectedOnInitialization() {
        if (selectedDate.get() == null) {
            currentDate = LocalDate.now();
            selectedDate.set(currentDate);
            addDays(currentDate);
            setSelected(currentDate);
        }
        else {
            addDays(selectedDate.get());
        }
        moveHintUp();
    }

    private void onInputKey(KeyEvent e) {
        if (isOpen) {
            popup.hide();
            isOpen = false;
        }
        if (e.getCode() != KeyCode.ENTER)
            return;

        formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate inputDate = null;
        boolean isSuccess = false;
        try {
            inputDate = LocalDate.parse(input.getText(), formatter);
            if (startDate.get() != null) {
                if (inputDate.isEqual(startDate.get()) || inputDate.isAfter(startDate.get())) {
                    isSuccess = true;
                }
            }
            else {
                isSuccess = true;
            }
            if (isSuccess) {
                if (endDate.get() != null) {
                    isSuccess = inputDate.isEqual(endDate.get()) || inputDate.isBefore(endDate.get());
                }
            }

        } catch (Exception ex) {
            isSuccess = false;
        }
        if (isSuccess) {
            selectedDate.set(inputDate);
            super.onSelected();
            addDays(currentDate);
            checkDateValidity();
        }
    }

    private void addHeader() {
        headerText = new Text();
        headerText.setFill(Color.WHITE);
        headerText.setFont(Font.font(null, FontWeight.BOLD, -1));

        back = new ActionButton(Icons.ScrollLeft, 16, "back");
        forward = new ActionButton(Icons.ScrollRight, 16, "forward");
        back.setAction(this::decrease);
        forward.setAction(this::increase);

        headerContainer = new GridPane();
        headerContainer.addColumn(0, back);
        headerContainer.addColumn(1, headerText);
        headerContainer.addColumn(2, forward);
        GridPane.setHgrow(headerText, Priority.ALWAYS);
        GridPane.setHalignment(headerText, HPos.CENTER);
        popupGrid.addRow(0, headerContainer);
        GridPane.setMargin(headerContainer, new Insets(0, 0, 5, 0));
        headerContainer.setBorder(Constants.BottomLine);
        headerContainer.setPadding(new Insets(0, 0, 5, 0));
        headerText.addEventHandler(MouseEvent.MOUSE_PRESSED, this::resetState);
    }

    private void initializeDayContainer() {
        String[] days = {"Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri"};
        dayMonthYearContainer = new GridPane();
        dayNameContainer = new GridPane();
        for (int i = 0; i < 7; i++) {
            var dayName = new Text(days[i]);
            dayName.setFill(Color.WHITE);
            dayName.setFont(Font.font(null, FontWeight.BOLD, -1));
            dayNameContainer.addColumn(i, dayName);
            GridPane.setHgrow(dayName, Priority.ALWAYS);
            GridPane.setHalignment(dayName, HPos.CENTER);
        }
        dayNameContainer.setBorder(Constants.BottomLine);
        dayNameContainer.setPadding(new Insets(0, 0, 2.5, 0));
        GridPane.setMargin(dayMonthYearContainer, new Insets(5, 0, 0, 0));
        dayNameContainer.setHgap(5);

        popupGrid.addRow(2, dayMonthYearContainer);
        dayMonthYearContainer.setHgap(5);
        dayMonthYearContainer.setVgap(5);
        dayMonthYearContainer.getChildren().addListener(this::onDayMonthYearContainerChange);
    }

    private void onDayMonthYearContainerChange(ListChangeListener.Change<? extends Node> change) {
        while (change.next()) {
            if (change.wasRemoved()) {
                var label = change.getRemoved().get(0);
                if (label instanceof DayLabel)
                    for (var item : change.getRemoved())
                        item.removeEventHandler(MouseEvent.MOUSE_CLICKED, this::onDayClicked);
                else if (label instanceof MonthLabel)
                    for (var item : change.getRemoved())
                        item.removeEventHandler(MouseEvent.MOUSE_CLICKED, this::onMonthClicked);
                else
                    for (var item : change.getRemoved())
                        item.removeEventHandler(MouseEvent.MOUSE_CLICKED, this::onYearClicked);
            }
        }
    }

    private void setSelected(LocalDate date) {
        super.onSelected();
        formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy");
        selectedText.setText(formatter.format(date));
    }

    private void onDayClicked(MouseEvent e) {
        var day = (DayLabel) e.getSource();
        //selected color doesn't change when you set it like thus, in EditTenant/EditSpace views, addDays works

//        for(var item : dayMonthYearContainer.getChildren()){
//            if(((DayLabel)item).isSelected()){
//                ((DayLabel)item).setSelected(false);
//                break;
//            }
//        }
//        day.setSelected(true);
        currentDate = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), day.getDayNo());
        selectedDate.set(currentDate);
        setSelected(currentDate);
        addDays(currentDate);
    }

    private void onMonthClicked(MouseEvent e) {
        var month = (MonthLabel) e.getSource();
        currentDate = LocalDate.of(currentDate.getYear(), month.getMonthNo(), 1);
        addDays(currentDate);
        checkDateValidity();
    }

    private void onYearClicked(MouseEvent e) {
        var year = (YearLabel) e.getSource();
        currentDate = LocalDate.of(year.getYearNo(), 1, 1);
        addMonths();
        checkDateValidity();
    }

    private void increase() {
        switch (currentState) {
            case Day -> {
                currentDate = currentDate.plusMonths(1);
                currentDate = LocalDate.of(currentDate.getYear(), currentDate.getMonthValue(), currentDate.lengthOfMonth());
                addDays(currentDate);
            }
            case Month -> {
                currentDate = currentDate.plusYears(1);
                currentDate = LocalDate.of(currentDate.getYear(), 12, 31);
                addMonths();
            }
            case Year -> {
                floorYear = currentDate.getYear();
                currentDate = currentDate.plusYears(12);
                capYear = currentDate.getYear();
                addYears();
            }
        }
        checkDateValidity();
    }

    private void decrease() {
        switch (currentState) {
            case Day -> {
                currentDate = currentDate.minusMonths(1);
                currentDate = LocalDate.of(currentDate.getYear(), currentDate.getMonthValue(), 1);
                addDays(currentDate);
            }
            case Month -> {
                currentDate = currentDate.minusYears(1);
                currentDate = LocalDate.of(currentDate.getYear(), 1, 31);
                addMonths();
            }
            case Year -> {
                capYear = currentDate.getYear();
                currentDate = currentDate.minusYears(12);
                floorYear = currentDate.getYear();
                addYears();
            }
        }
        checkDateValidity();
    }

    private void resetState(MouseEvent e) {
        switch (currentState) {
            case Day -> addMonths();
            case Month -> addYears();
            case Year -> {
                currentDate = selectedDate == null ? LocalDate.now() : selectedDate.get();
                addDays(currentDate);
            }
        }
        checkDateValidity();
    }

    private void checkDateValidity() {
        if (endDate.get() == null && startDate.get() == null)
            return;
        if (currentState == CalendarState.Day) {
            forward.setDisable(currentDate.getMonthValue() == endDate.get().getMonthValue() && currentDate.getYear() == endDate.get().getYear());
            back.setDisable(currentDate.getMonthValue() == startDate.get().getMonthValue() && currentDate.getYear() == startDate.get().getYear());
        }
        else if (currentState == CalendarState.Month) {
            forward.setDisable(currentDate.getYear() >= endDate.get().getYear());

            back.setDisable(currentDate.getYear() <= startDate.get().getYear());
        }
        else {
            forward.setDisable(capYear >= endDate.get().getYear());

            back.setDisable(floorYear <= startDate.get().getYear());
        }
    }

    private void addDays(LocalDate currentDate) {
        currentState = CalendarState.Day;
        formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
        headerText.setText(formatter.format(currentDate));
        dayMonthYearContainer.getChildren().clear();

        var numberOfDays = currentDate.lengthOfMonth();
        var currentDay = 1;
        var dayOfWeek = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), currentDay).getDayOfWeek().getValue();
        int newDayOfWeek = switch (dayOfWeek) {
            case 6 -> 0;
            case 7 -> 1;
            default -> dayOfWeek + 1;
        };

        int requiredRows = 1;
        var remainingDays = numberOfDays - 7 + newDayOfWeek;
        requiredRows += remainingDays / 7;
        var remainder = remainingDays % 7;
        if (remainder != 0)
            requiredRows++;

        if (!popupGrid.getChildren().contains(dayNameContainer))
            popupGrid.addRow(1, dayNameContainer);

        var isInSelectedMonth = selectedDate.get() != null && (
                (selectedDate.get().getMonthValue() == currentDate.getMonthValue())
                        && (selectedDate.get().getYear() == currentDate.getYear())
        );

        for (int i = 0; i < requiredRows; i++) {
            int k = currentDay == 1 ? newDayOfWeek : 0;
            for (int j = k; j < 7; j++) {
                if (currentDay < numberOfDays + 1) {
                    var day = new DayLabel(currentDay);
                    day.addEventHandler(MouseEvent.MOUSE_CLICKED, this::onDayClicked);

                    if (isInSelectedMonth) {
                        if (selectedDate.get() != null) {
                            if (currentDay == selectedDate.get().getDayOfMonth())
                                day.setSelected(true);
                        }
                    }
                    if (currentDay == today.getDayOfMonth() && currentDate.getMonthValue() == today.getMonthValue() && currentDate.getYear() == today.getYear()) {
                        day.setToday(true);
                    }

                    if (startDate.get() != null && endDate.get() != null) {
                        if (currentDate.getMonthValue() == startDate.get().getMonthValue() && currentDate.getYear() == startDate.get().getYear()) {
                            if (currentDay < startDate.get().getDayOfMonth())
                                day.setVisible(false);
                        }
                        if (currentDate.getMonthValue() == endDate.get().getMonthValue() && currentDate.getYear() == endDate.get().getYear()) {
                            if (currentDay > endDate.get().getDayOfMonth())
                                day.setVisible(false);
                        }
                    }
                    dayMonthYearContainer.add(day, j, i);
                    currentDay++;
                }
            }
        }
    }

    private void addMonths() {
        currentState = CalendarState.Month;
        formatter = DateTimeFormatter.ofPattern("yyyy");
        headerText.setText(formatter.format(currentDate));
        dayMonthYearContainer.getChildren().clear();
        popupGrid.getChildren().remove(dayNameContainer);

        int currentMonth = 1;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                var month = new MonthLabel(currentMonth);
                month.addEventHandler(MouseEvent.MOUSE_CLICKED, this::onMonthClicked);

                if (selectedDate.get() != null) {
                    if (currentMonth == selectedDate.get().getMonthValue() && currentDate.getYear() == selectedDate.get().getYear()) {
                        month.setSelected(true);
                    }
                }
                if (currentMonth == today.getMonth().getValue() && currentDate.getYear() == today.getYear()) {
                    month.setThisMonth(true);
                }
                if (startDate.get() != null && endDate.get() != null) {
                    if (currentDate.getYear() == startDate.get().getYear()) {
                        if (currentMonth < startDate.get().getMonth().getValue())
                            month.setVisible(false);
                    }
                    if (currentDate.getYear() == endDate.get().getYear()) {
                        if (currentMonth > endDate.get().getMonth().getValue())
                            month.setVisible(false);
                    }
                }
                dayMonthYearContainer.add(month, j, i);
                currentMonth++;
            }
        }
    }

    private void addYears() {
        currentState = CalendarState.Year;
        capYear = currentDate.getYear();
        int currentYear = currentDate.getYear() - 11;
        floorYear = currentYear;
        headerText.setText(currentYear + " - " + currentDate.getYear());
        dayMonthYearContainer.getChildren().clear();
        popupGrid.getChildren().remove(dayNameContainer);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                var year = new YearLabel(currentYear);
                year.addEventHandler(MouseEvent.MOUSE_CLICKED, this::onYearClicked);

                if (selectedDate.get() != null) {
                    if (currentYear == selectedDate.get().getYear()) {
                        year.setSelected(true);
                    }
                }
                if (currentYear == today.getYear()) {
                    year.setThisYear(true);
                }
                if (startDate.get() != null && endDate.get() != null) {
                    if (currentYear < startDate.get().getYear())
                        year.setVisible(false);
                    if (currentYear > endDate.get().getYear())
                        year.setVisible(false);
                }
                dayMonthYearContainer.add(year, j, i);
                currentYear++;
            }
        }
    }

    public ObjectProperty<LocalDate> selectedDateProperty() {return selectedDate;}

    public ObjectProperty<LocalDate> startDateProperty() {return startDate;}

    public ObjectProperty<LocalDate> endDateProperty() {return endDate;}
}
