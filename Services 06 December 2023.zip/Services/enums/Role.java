package enums;

public enum Role {
    None,
    Super,
    Admin,
    Reader
}
