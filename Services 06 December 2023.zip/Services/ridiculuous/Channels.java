package ridiculuous;

import enums.Role;

import java.io.IOException;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Channels {
    public Socket signatory;
    public Socket sender;
    public Socket receiver;
    public Role role;
    public int userId;

    private final ExecutorService executor;

    private static Channels instance;

    public static Channels getInstance(){
        if(instance == null){
            instance = new Channels();
        }
        return instance;
    }
    private Channels() {
        executor = Executors.newSingleThreadExecutor();
    }

    public Future<Response> getResponse(Request r) {
        return executor.submit(() -> {
            var bytes = r.getBytes();
            var response = new Response();
            try {
                sender.getOutputStream().write(bytes, 0, bytes.length);
                sender.getOutputStream().flush();
                var header = sender.getInputStream().readNBytes(4);
                var size = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN).getInt();
                var packet = sender.getInputStream().readNBytes(size);
                response.setSuccess(true);
                response.setPacket(packet);
            } catch (IOException e) {
                response.setSuccess(false);
                //throw new RuntimeException(e);
            }
            return response;
        });
    }
    public void shutDown(){
        executor.shutdown();
    }
}
