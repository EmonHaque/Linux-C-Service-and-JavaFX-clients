#include "CommonStructures.h"
#include "BlockingQueue.h"
#include "List.h"
#include "Messenger.h"
#include "Structures.h"
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>


extern byte isRunning;
extern List receivers;
extern BlockingQueue publicResponses;
extern pthread_mutex_t criticalReceiver;

static pthread_t broadcastThread;

static void sendPlot(ResponsePublic *r) {
    int **list = receivers.data;
    Plot *plot = r->data;
   
    for (int i = 0; i < receivers.count; i++) {
        Receiver* client = list[i];
        // unnecessary check, it never fails even if it's disconnected, you get SIGPIPE
        if (sendInt(client->socket, r->size) < 0) {
            continue;
        }
		sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, plot->id);
        sendString(client->socket, plot->name);
        sendString(client->socket, plot->description);
    }
}
static void sendSpace(ResponsePublic *r) {
    int **list = receivers.data;
    Space *space = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver* client = list[i];
        // unnecessary check, it never fails even if it's disconnected, you get SIGPIPE
        if (sendInt(client->socket, r->size) < 0) {
            continue;
        }
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, space->id);
        sendInt(client->socket, space->plotId);
        sendString(client->socket, space->name);
        sendString(client->socket, space->description);
        sendByte(client->socket, space->isVacant);
    }
}
static void sendEditedSpace(ResponsePublic *r) {
    int **list = receivers.data;
    EditedSpace *ep = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver* client = list[i];
        // unnecessary check, it never fails even if it's disconnected, you get SIGPIPE
        if (sendInt(client->socket, r->size) < 0) {
            continue;
        }
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, ep->leaseId);
        sendString(client->socket, ep->vaccatedOn);
        sendInt(client->socket, ep->space->id);
        sendInt(client->socket, ep->space->plotId);
        sendString(client->socket, ep->space->name);
        sendString(client->socket, ep->space->description);
        sendByte(client->socket, ep->space->isVacant);
    }
    free(ep->vaccatedOn);
    free(ep);
}
static void sendTenant(ResponsePublic *r) {
    int **list = receivers.data;
    Tenant *tenant = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver* client = list[i];
        // unnecessary check, it never fails even if it's disconnected, you get SIGPIPE
        if (sendInt(client->socket, r->size) < 0) {
            continue;
        }
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);
        sendInt(client->socket, tenant->id);
        sendString(client->socket, tenant->name);
        sendString(client->socket, tenant->father);
        sendString(client->socket, tenant->mother);
        sendString(client->socket, tenant->husband);
        sendString(client->socket, tenant->address);
        sendString(client->socket, tenant->NID);
        sendString(client->socket, tenant->contactNo);
        sendByte(client->socket, tenant->hasLeft);
    }
}
static void sendEditedTenant(ResponsePublic *r) {
    int **list = receivers.data;
    EditedTenant *et = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver* client = list[i];
        if (sendInt(client->socket, r->size) < 0) {
            continue;
        }
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendString(client->socket, et->leftOn);
        sendInt(client->socket, et->tenant->id);
        sendString(client->socket, et->tenant->name);
        sendString(client->socket, et->tenant->father);
        sendString(client->socket, et->tenant->mother);
        sendString(client->socket, et->tenant->husband);
        sendString(client->socket, et->tenant->address);
        sendString(client->socket, et->tenant->NID);
        sendString(client->socket, et->tenant->contactNo);
        sendByte(client->socket, et->tenant->hasLeft);
    }
    free(et->leftOn);
    free(et);
}
static void sendHead(ResponsePublic *r) {
    int **list = receivers.data;
    Head *head = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver* client = list[i];
        // unnecessary check, it never fails even if it's disconnected, you get SIGPIPE
        if (sendInt(client->socket, r->size) < 0) {
            continue;
        }
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, head->id);
        sendInt(client->socket, head->controlId);
        sendString(client->socket, head->name);
        sendString(client->socket, head->description);
    }
}
static void sendLease(ResponsePublic *r) {
    int **list = receivers.data;
    NewLease *nl = r->data;
    int count = nl->receivables.count;
    Receivable **receivables = nl->receivables.data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver* client = list[i];
        // unnecessary check, it never fails even if it's disconnected, you get SIGPIPE
        if (sendInt(client->socket, r->size) < 0) {
            continue;
        }
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, nl->lease->id);
        sendInt(client->socket, nl->lease->plotId);
        sendInt(client->socket, nl->lease->spaceId);
        sendInt(client->socket, nl->lease->tenantId);
        sendString(client->socket, nl->lease->dateStart);
        sendString(client->socket, nl->lease->dateEnd);
        sendString(client->socket, nl->lease->business);
        sendByte(client->socket, nl->lease->isExpired);

        for (int j = 0; j < count; j++) {
            sendInt(client->socket, receivables[j]->leaseId);
            sendInt(client->socket, receivables[j]->headId);
            sendInt(client->socket, receivables[j]->amount);
        }
    }
    free(receivables);
    free(nl);
}
static void sendTransaction(ResponsePublic *r) {
    int **list = receivers.data;
    Transaction *action = r->data;

    for (int i = 0; i < receivers.count; i++) {
        Receiver* client = list[i];
        // unnecessary check, it never fails even if it's disconnected, you get SIGPIPE
        if (sendInt(client->socket, r->size) < 0) {
            continue;
        }
        sendInt(client->socket, r->function);
        sendInt(client->socket, r->userId);

        sendInt(client->socket, action->id);
        sendInt(client->socket, action->plotId);
        sendInt(client->socket, action->spaceId);
        sendInt(client->socket, action->tenantId);
        sendInt(client->socket, action->controlId);
        sendInt(client->socket, action->headId);
        sendInt(client->socket, action->amount);
        sendByte(client->socket, action->isCash);
        sendString(client->socket, action->date);
        sendString(client->socket, action->narration);
    }
    free(action->date);
    free(action->narration);
    free(action);
}

static void *BroadcastResponse(void *p) {
    pthread_detach(pthread_self());

    while (isRunning) {
        ResponsePublic *r = takeOutFrom(&publicResponses);
        if (!r) break;

        pthread_mutex_lock(&criticalReceiver);
        switch (r->function) {
            case AddPlot:
            case EditPlot: sendPlot(r); break;
            case AddSpace: sendSpace(r); break;
            case EditSpace: sendEditedSpace(r); break;
            case AddTenant: sendTenant(r); break;
            case EditTenant: sendEditedTenant(r); break;
            case AddLease:
            case EditLease: sendLease(r); break;
            case AddHead:
            case EditHead: sendHead(r); break;
            case EditTransaction:
            case DeleteTransaction: sendTransaction(r); break;
        }
        pthread_mutex_unlock(&criticalReceiver);
        free(r);
    }
    pthread_exit(0);
}

void InitializeBroadcaster() {
    pthread_create(&broadcastThread, 0, BroadcastResponse, 0);
}

void ShutdownBroadcaster() {
}