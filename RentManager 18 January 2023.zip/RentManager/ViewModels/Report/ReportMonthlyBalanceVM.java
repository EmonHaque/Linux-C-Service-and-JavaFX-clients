package ViewModels.Report;

import Enums.Function;
import Models.MonthlyBalance;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class ReportMonthlyBalanceVM {
    private final ObservableList<MonthlyBalance> list;
    private final FilteredList<MonthlyBalance> balances;
    public ListProperty<MonthlyBalance> balancesProperty;
    private int due, lastDue, paid, shortOrLong;

    public IntegerProperty stateProperty, dueProperty, lastDueProperty, paidProperty, shortOrLongProperty;
    public StringProperty statusProperty;
    public BooleanProperty isRunningProperty;
    public ObjectProperty<LocalDate> selectedMonthProperty;

    private ResponseTask task;

    public ReportMonthlyBalanceVM() {
        stateProperty = new SimpleIntegerProperty();
        dueProperty = new SimpleIntegerProperty();
        lastDueProperty = new SimpleIntegerProperty();
        paidProperty = new SimpleIntegerProperty();
        shortOrLongProperty = new SimpleIntegerProperty();
        statusProperty = new SimpleStringProperty();
        isRunningProperty = new SimpleBooleanProperty();
        selectedMonthProperty = new SimpleObjectProperty<>();
        list = FXCollections.observableArrayList();
        balances = new FilteredList<>(list);
        balancesProperty = new SimpleListProperty<>(balances);

        stateProperty.addListener(this::onStateChanged);

        updateReportable();
    }

    private void onStateChanged(Observable o) {
        paid = lastDue = due = shortOrLong = 0;

        balances.setPredicate(this::filter);

        dueProperty.set(due);
        lastDueProperty.set(lastDue);
        paidProperty.set(paid);
        shortOrLongProperty.set(shortOrLong);
    }

    private boolean filter(MonthlyBalance balance) {
        switch (stateProperty.get()) {
            case 0 -> {
                due += balance.getDue();
                lastDue += balance.getLastMonthDue();
                paid += balance.getPayment();
                shortOrLong += balance.getShortOrLong();
                return true;
            }
            case 1 -> {
                if (balance.getLastMonthDue() - balance.getPayment() <= 0) {
                    due += balance.getDue();
                    lastDue += balance.getLastMonthDue();
                    paid += balance.getPayment();
                    shortOrLong += balance.getShortOrLong();
                    return true;
                }
            }
            case 2 -> {
                if (balance.getLastMonthDue() - balance.getPayment() > 0) {
                    due += balance.getDue();
                    lastDue += balance.getLastMonthDue();
                    paid += balance.getPayment();
                    shortOrLong += balance.getShortOrLong();
                    return true;
                }
            }
        }
        return false;
    }

    public void updateReportable() { update(); }

    private void update(){
        statusProperty.unbind();
        isRunningProperty.unbind();
        statusProperty.set("");
        isRunningProperty.set(false);

        if (task != null && task.isRunning()){
            task.setOnCancelled(e -> {
                task.setOnCancelled(null);
                startTask();
            });
            task.cancel();
        }
        else startTask();
    }

    private void startTask(){
        task = new ResponseTask();
        statusProperty.bind(task.messageProperty());
        isRunningProperty.bind(task.runningProperty());
        new Thread(task).start();
    }

    private class ResponseTask extends Task<List<MonthlyBalance>> {
        private int length;
        @Override
        protected List<MonthlyBalance> call() {
            try{
                updateMessage("requesting data ...");
                Thread.sleep(500);

                due = lastDue = paid = shortOrLong = 0;
                var request = new Request(Function.GetMonthlyBalance.ordinal(), getBytes());
                if(isCancelled()) return null;

                var response = Channels.getInstance().getResponse(request).get();
                if (!response.isSuccess()) {
                    updateMessage("service down ...");
                    return null;
                }
                if(isCancelled()) return null;

                length = response.getPacket().length;
                if (length == 0) {
                    updateMessage("no data available");
                    Thread.sleep(500);
                    return null;
                }
                updateMessage("received " + String.format("%,d", length) + " bytes");
                Thread.sleep(500);
                if(isCancelled()) return null;
                
                var buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
                return isCancelled() ? null : getList(buffer, length);
            }
            catch (Exception e){
                return null;
            }
        }

        @Override
        protected void succeeded() {
            list.clear();
            dueProperty.set(due);
            lastDueProperty.set(lastDue);
            paidProperty.set(paid);
            shortOrLongProperty.set(shortOrLong);
            try {
                var result = get();
                if (result == null) return;
                list.addAll(result);
                updateMessage("processed " + String.format("%,d", length) + " bytes");

            } catch (InterruptedException | ExecutionException e) {

            }
        }

        private ByteBuffer getBytes() {
            var date = selectedMonthProperty.get();
            var lastDayOfPreviousMonth = date.minusMonths(1);
            var lastDay = lastDayOfPreviousMonth.getMonth().length(lastDayOfPreviousMonth.isLeapYear());
            lastDayOfPreviousMonth = LocalDate.of(lastDayOfPreviousMonth.getYear(), lastDayOfPreviousMonth.getMonthValue(), lastDay);
            var firstDayOfPreviousMonth = LocalDate.of(lastDayOfPreviousMonth.getYear(), lastDayOfPreviousMonth.getMonthValue(), 1);
            lastDay = date.getMonth().length(date.isLeapYear());
            var lastDayOfSelectedMonth = LocalDate.of(date.getYear(), date.getMonthValue(), lastDay);

            var ldp = (lastDayOfPreviousMonth.toString() + '\0').getBytes(StandardCharsets.US_ASCII);
            var fdp = (firstDayOfPreviousMonth.toString() + '\0').getBytes(StandardCharsets.US_ASCII);
            var lds = (lastDayOfSelectedMonth.toString() + '\0').getBytes(StandardCharsets.US_ASCII);

            return ByteBuffer.allocate(ldp.length + fdp.length + lds.length)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .put(fdp)
                    .put(ldp)
                    .put(lds);
        }

        private List<MonthlyBalance> getList(ByteBuffer buffer, int length) {
            var list = new ArrayList<MonthlyBalance>();
            var span = buffer.array();
            int start, index, read;
            start = read = index = 0;
            var segments = new String[3];
            while (read < length) {
                if(isCancelled()) break;

                while (read < length) {
                    if (span[read] != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(span, start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }
                int due = buffer.getInt(start);
                int lastDue = buffer.getInt(start + 4);
                int payment = buffer.getInt(start + 8);
                int shortOrLong = lastDue - payment;
                list.add(new MonthlyBalance() {{
                    setDate(segments[0]);
                    setPlot(segments[1]);
                    setTenant(segments[2]);
                    setDue(due);
                    setPayment(payment);
                    setLastMonthDue(lastDue);
                    setShortOrLong(shortOrLong);
                }});

                ReportMonthlyBalanceVM.this.due += due;
                ReportMonthlyBalanceVM.this.lastDue += lastDue;
                paid += payment;
                ReportMonthlyBalanceVM.this.shortOrLong += shortOrLong;

                index = 0;
                read += 12;
                start = read;
            }
            return list;
        }
    }
}
