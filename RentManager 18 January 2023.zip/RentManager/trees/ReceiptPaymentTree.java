package trees;

import Models.ReceiptPayment;
import controls.SVGRegion;
import controls.texts.HiText;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

import java.util.Comparator;
import java.util.function.Function;

public class ReceiptPaymentTree extends ExtendedTreeView<ReceiptPayment> {
    private final FilteredList<ReceiptPayment> list;
    public BooleanProperty isExpandedProperty;

    public ReceiptPaymentTree(FilteredList<ReceiptPayment> list, StringProperty query) {
        this.list = list;
        isExpandedProperty = new SimpleBooleanProperty();
        setRoot(new TreeItem<>());
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new ReceiptPaymentCell(query));

        list.addListener(this::onItemsChanged);

        isExpandedProperty.addListener(o -> {
            var value = isExpandedProperty.get();
            for (var level1 : getRoot().getChildren())
                for (var level2 : level1.getChildren())
                    resetExpandState(level2, value);
        });

        query.addListener((o, ov, nv) ->{
            if(nv == null || nv.isBlank() || nv.isEmpty()) return;
            for(var node : getRoot().getChildren())
                resetExpandState(node, true);
        });
    }

    private void onItemsChanged(ListChangeListener.Change<? extends ReceiptPayment> change) {
        // the most efficient way that works in all situation
        getRoot().getChildren().clear();
        for (var e : list) addItem(getRoot(), e);
        removeSingleLeaf();
        for (var node : getRoot().getChildren()) sort(node);
        for (var level1 : getRoot().getChildren()){
            level1.setExpanded(true);
            for (var level2 : level1.getChildren())
                resetExpandState(level2, isExpandedProperty.get());
        }
    }

    private void resetExpandState(TreeItem<ReceiptPayment> node, boolean value) {
        node.setExpanded(value);
        for (var item : node.getChildren()) {
            if (item.isLeaf()) continue;
            resetExpandState(item, value);
        }
    }

    @SuppressWarnings("unchecked")
    private void sort(TreeItem<ReceiptPayment> node) {
        node.getChildren().sort(
                Comparator.comparing(x -> ((TreeItem<ReceiptPayment>) x).getChildren().size()).reversed()
                        .thenComparing(x -> ((TreeItem<ReceiptPayment>) x).getValue().getHead())
                        .thenComparing(x -> ((TreeItem<ReceiptPayment>) x).getValue().getPlot())
                        .thenComparing(x -> ((TreeItem<ReceiptPayment>) x).getValue().getTenant())
        );
        for (var item : node.getChildren()) sort(item);
    }

    private void addItem(TreeItem<ReceiptPayment> node, ReceiptPayment entry) {
        var level = getTreeItemLevel(node);
        var hasIt = false;
        TreeItem<ReceiptPayment> item = null;
        Function<ReceiptPayment, Boolean> condition = x -> true;

        switch (level) {
            case 0 -> condition = e -> e.getControl().equals(entry.getControl());
            case 1 -> condition = e -> e.getHead().equals(entry.getHead());
            case 2 -> condition = e -> e.getPlot().equals(entry.getPlot());
            case 3 -> condition = e -> e.getTenant().equals(entry.getTenant());
        }

        for (var branch : node.getChildren()) {
            if (!condition.apply(branch.getValue())) continue;
            var value = branch.getValue();
            value.setCash(value.getCash() + entry.getCash());
            value.setKind(value.getKind() + entry.getKind());
            value.setMobile(value.getMobile() + entry.getMobile());
            value.setTotal(value.getTotal() + entry.getTotal());
            hasIt = true;
            item = branch;
            break;
        }
        if (!hasIt) {
            var newEntry = new ReceiptPayment() {{
                setCash(entry.getCash());
                setKind(entry.getKind());
                setMobile(entry.getMobile());
                setTotal(entry.getTotal());
                setHead("");
                setPlot("");
                setTenant("");
                setSpace("");
            }};
            switch (level) {
                case 0 -> newEntry.setControl(entry.getControl());
                case 1 -> newEntry.setHead(entry.getHead());
                case 2 -> newEntry.setPlot(entry.getPlot());
                case 3 -> newEntry.setTenant(entry.getTenant());
            }
            item = new TreeItem<>(newEntry);
            node.getChildren().add(item);
        }

        if (level == 3) item.getChildren().add(new TreeItem<>(entry));
        else addItem(item, entry);
    }

    private void removeSingleLeaf() {
        for (var control : getRoot().getChildren()) {
            for (var head : control.getChildren()) {
                for (var plot : head.getChildren()) {
                    for (var tenant : plot.getChildren()) {
                        if (tenant.getChildren().size() > 1) continue;
                        var item = tenant.getChildren().get(0).getValue();
                        tenant.getChildren().clear();
                        tenant.getValue().setSpace(item.getSpace());
                    }
                }
            }
        }
    }

    private class ReceiptPaymentCell extends TreeCell<ReceiptPayment> {
        private SVGRegion disclosureIcon;
        private GridPane root;
        private Font normal, bold;
        private Border topBorder;
        private Text cash, kind, mobile, total;
        private HiText particulars;
        private final StringProperty query;

        public ReceiptPaymentCell(StringProperty query) {
            setBackground(null);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setPadding(new Insets(2.5, 0, 2.5, 0));
            setPrefWidth(0);
            this.query = query;
            initializeUI();
            itemProperty().addListener(this::onItemChanged);
        }

        private void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0)));

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            particulars = new HiText();
            cash = new Text() {{setFill(Color.WHITE);}};
            kind = new Text() {{setFill(Color.WHITE);}};
            mobile = new Text() {{setFill(Color.WHITE);}};
            total = new Text() {{setFill(Color.WHITE);}};


            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}}
                );
                add(particulars, 0, 0);
                add(cash, 1, 0);
                add(kind, 2, 0);
                add(mobile, 3, 0);
                add(total, 4, 0);
            }};
            makeFontBold();
        }

        private void onItemChanged(ObservableValue<?> o, ReceiptPayment ov, ReceiptPayment nv) {
            if (ov != null) {
                makeFontBold();
                root.setBorder(null);
                particulars.setText(null);
                particulars.queryProperty().unbind();
                particulars.queryProperty().set("");
                cash.setText(null);
                kind.setText(null);
                mobile.setText(null);
                total.setText(null);

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                String text = "";
                switch (level) {
                    case 1 -> text = nv.getControl() + " (" + item.getChildren().size() + ")";
                    case 2 -> text = nv.getHead() + " (" + item.getChildren().size() + ")";
                    case 3 -> text = nv.getPlot() + " (" + item.getChildren().size() + ")";
                    case 4 -> {
                        text = !nv.getSpace().isEmpty() ?
                                nv.getTenant() + " - " + nv.getSpace() :
                                nv.getTenant() + " (" + item.getChildren().size() + ")";
                        makeBorder(item);
                        makeFontNormal();
                    }
                    case 5 -> {
                        text = nv.getSpace();
                        makeBorder(item);
                        makeFontNormal();
                    }
                }
                particulars.setText(text);
                particulars.queryProperty().bind(query);
                cash.setText(AppData.formatNumber(nv.getCash()));
                kind.setText(AppData.formatNumber(nv.getKind()));
                mobile.setText(AppData.formatNumber(nv.getMobile()));
                total.setText(AppData.formatNumber(nv.getTotal()));
            }
        }

        private void makeFontNormal() {
            particulars.setFont(normal);
            cash.setFont(normal);
            kind.setFont(normal);
            mobile.setFont(normal);
            total.setFont(normal);
        }

        private void makeFontBold() {
            particulars.setFont(bold);
            cash.setFont(bold);
            kind.setFont(bold);
            mobile.setFont(bold);
            total.setFont(bold);
        }

        private void makeBorder(TreeItem<ReceiptPayment> item) {
            var siblings = item.getParent().getChildren();
            int index = siblings.indexOf(item);
            if (index == 0) {
                root.setBorder(topBorder);
            }
            else if (index == siblings.size() - 1) {
                root.setBorder(Constants.BottomLine);
            }
        }

        @Override
        protected void updateItem(ReceiptPayment item, boolean empty) {
            super.updateItem(item, empty);
            if (isEmpty()) {
                setBackground(null);
                setGraphic(null);
                return;
            }
            setGraphic(root);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}
