package trees;

import Models.TransactionEditable;
import controls.SVGRegion;
import controls.texts.HiTexts;
import controls.SVGIconRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import skinned.ExtendedTreeView;

import java.util.List;

public class EditTransactionTree extends ExtendedTreeView<TransactionEditable> {
    private final TreeItem<TransactionEditable> plots;

    public EditTransactionTree(ObservableList<TransactionEditable> list, StringProperty query) {
        plots = new TreeItem<>();
        setRoot(plots);
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new TransactionCell(query));
        list.addListener(this::onItemsChanged);
    }

    private void onItemsChanged(ListChangeListener.Change<? extends TransactionEditable> change) {
        // why while?
        getSelectionModel().clearSelection();
        while (change.next()) {
            if(change.getRemovedSize() > 0){
                removeItems((List<TransactionEditable>) change.getRemoved());
            }
            if(change.getAddedSize() > 0){
                addItems((List<TransactionEditable>) change.getAddedSubList());
            }
        }
    }

    private void removeItems(List<TransactionEditable> list) {
        for(var transaction : list){
            TreeItem<TransactionEditable> plot = null;
            for (var tree : plots.getChildren()){
                if(tree.getValue().getPlotName().equals(transaction.getPlotName())){
                    plot = tree;
                    plot.getValue().setAmount(plot.getValue().getAmount() - transaction.getAmount());
                    break;
                }
            }
            TreeItem<TransactionEditable> leaf = null;
            for(var item : plot.getChildren()){
                if(item.getValue().getId() == transaction.getId()){
                    leaf = item;
                    break;
                }
            }
            plot.getChildren().remove(leaf);
            if(plot.getChildren().size() == 0){
                plots.getChildren().remove(plot);
            }
        }
    }

    private void addItems(List<TransactionEditable> list) {
        for (var transaction : list) {
            var hasIt = false;
            TreeItem<TransactionEditable> item = null;
            for (var tree : plots.getChildren()) {
                if (tree.getValue().getPlotName().equals(transaction.getPlotName())) {
                    item = tree;
                    item.getValue().setAmount(item.getValue().getAmount() + transaction.getAmount());
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                item = new TreeItem<>(new TransactionEditable() {{
                    setPlotName(transaction.getPlotName());
                    setAmount(transaction.getAmount());
                }});
                item.setExpanded(true);
                plots.getChildren().add(item);
            }
            var leaf = new TreeItem<>(transaction);
            item.getChildren().add(leaf);
        }
    }

    private class TransactionCell extends TreeCell<TransactionEditable> {
        private GridPane root;
        private HiTexts flow;
        private Text space, tenant, control, amount;
        private SVGIconRegion icon;
        private SVGRegion disclosureIcon;
        private Font normal, bold;
        private final StringProperty query;

        public TransactionCell(StringProperty query) {
            this.query = query;

            setPrefWidth(0);
            setPadding(new Insets(2.5, 0, 2.5, 0));
            setBackground(null);

            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            initializeUI();
            itemProperty().addListener(this::onItemChanged);
        }

        private void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            space = new Text() {{setFill(Color.WHITE);}};
            tenant = new Text() {{setFill(Color.WHITE);}};
            control = new Text() {{
                setFill(Color.GRAY);
                setFont(Font.font(null, FontPosture.ITALIC, -1));
            }};
            amount = new Text() {{setFill(Color.WHITE);}};

            flow = new HiTexts(space, tenant, control);
            icon = new SVGIconRegion(Icons.Cash);

            root = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.SOMETIMES); setWrapText(true);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints() {{setFillWidth(true);}}
                );
                add(flow, 0, 0);
                add(amount, 1, 0);
                add(icon, 2, 0);
                setMargin(icon, new Insets(0, 0, 0, 5));
            }};
        }

        private void onItemChanged(ObservableValue<?> o, TransactionEditable ov, TransactionEditable nv) {
            if (ov != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);
                if(level == 2){
                    nv.isCashProperty().removeListener(this::onIsCashChanged);
                }
                flow.queryProperty().unbind();
                flow.queryProperty().set("");
                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }

            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                if (level == 1) {
                    GridPane.setColumnSpan(amount, 2);
                    control.textProperty().unbind();
                    control.setText("");

                    space.textProperty().bind(nv.plotNameProperty().concat(" ("));
                    tenant.textProperty().bind(Bindings.size(item.getChildren()).asString().concat(")"));

                    space.setFont(bold);
                    amount.setFont(bold);
                    icon.setVisible(false);
                }
                else {
                    GridPane.setColumnSpan(amount, 1);
                    space.textProperty().bind(nv.spaceNameProperty().concat(" - "));
                    tenant.textProperty().bind(nv.tenantNameProperty().concat(" "));
                    control.textProperty().bind(nv.controlNameProperty());
                    flow.queryProperty().bind(query);

                    space.setFont(normal);
                    amount.setFont(normal);
                    icon.setVisible(true);
                    setIcon(nv.getIsCash());
                    nv.isCashProperty().addListener(this::onIsCashChanged);
                }
                amount.textProperty().bind(nv.amountProperty().asString("%,d"));
            }
        }

        private void setIcon(int value){
            switch (value) {
                case 0 -> {
                    icon.setContent(Icons.Cash);
                    icon.setFill(Color.LIGHTGREEN);
                }
                case 1 -> {
                    icon.setContent(Icons.NonCash);
                    icon.setFill(Color.LIGHTCORAL);
                }
                case 2 -> {
                    icon.setContent(Icons.Mobile);
                    icon.setFill(Color.CORNFLOWERBLUE);
                }
            }
        }

        private void onIsCashChanged(ObservableValue<?> o, Number ov, Number nv){
            setIcon(nv.intValue());
        }

        @Override
        protected void updateItem(TransactionEditable item, boolean empty) {
            super.updateItem(item, empty);
            if (isEmpty()) {
                setBackground(null);
                setGraphic(null);
            }
            else {
                setGraphic(root);
                if (getTreeView().getTreeItemLevel(getTreeItem()) == 2) {
                    setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
                    setDisable(false);
                }
                else {
                    setDisable(true);
                }
            }
        }
    }
}
