package trees;

import Models.LastPayment;
import controls.SVGIcon;
import controls.SVGRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.Observable;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

public class LastPaymentTree extends ExtendedTreeView<LastPayment> {
    private final ObservableList<LastPayment> list;

    public LastPaymentTree(ObservableList<LastPayment> list) {
        this.list = list;
        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new Cell());
        list.addListener(this::onItemsChanged);
    }

    private void onItemsChanged(ListChangeListener.Change<? extends LastPayment> change){
        getRoot().getChildren().clear();
        addItems();
    }

    private void addItems(){
        TreeItem<LastPayment> node = null;
        boolean hasIt = false;

        for(LastPayment item : list){
            for(var branch : getRoot().getChildren()){
                if(branch.getValue().getPlot().equals(item.getPlot())){
                    var value = branch.getValue();
                    value.setAmount(value.getAmount() + item.getAmount());
                    node = branch;
                    hasIt = true;
                    break;
                }
            }
            if(!hasIt){
                var newItem = new LastPayment(){{
                    setPlot(item.getPlot());
                    setAmount(item.getAmount());
                }};
                node = new TreeItem<>(newItem){{ setExpanded(true);}};
                getRoot().getChildren().add(node);
            }
            node.getChildren().add(new TreeItem<>(item));
            hasIt = false;
        }
    }

    private class Cell extends TreeCell<LastPayment>{
        private final GridPane root;
        private final Text name, amount;
        private final SVGIcon icon;
        private final SVGRegion disclosureIcon;
        private final Border topBorder, doubleBorder;

        public Cell() {
            setPrefWidth(0);
            setText(null);
            setBackground(null);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setPadding(new Insets(2.5, 0, 2.5, 0));

            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0)));
            doubleBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0.25, 0)));

            name = new Text(){{ setFill(Color.WHITE);}};
            icon = new SVGIcon(Icons.Cash);
            amount = new Text(){{ setFill(Color.WHITE);}};

            var nameFlow = new TextFlow(name);

            root = new GridPane(){{
                getColumnConstraints().addAll(
                        new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints(35){{ setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(65){{ setHalignment(HPos.RIGHT);}}
                );
                getRowConstraints().add(new RowConstraints(){{ setPercentHeight(100);}});
                add(nameFlow, 0, 0);
                add(icon, 1, 0);
                add(amount, 2, 0);
            }};
            itemProperty().addListener(this::onItemChanged);
        }

        private void onItemChanged(Observable o , LastPayment ov, LastPayment nv){
            if(ov != null){
                name.setText(null);
                amount.setText(null);
                root.setBorder(null);
                icon.setVisible(true);

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if(nv != null){
                var item = getTreeItem();
                var level = getTreeItemLevel(item);
                var size = item.getParent().getChildren().size();

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                amount.setText(AppData.formatNumber(nv.getAmount()));
                if(level == 1){
                    name.setText(nv.getPlot());
                    icon.setVisible(false);
                }
                else {
                    name.setText(nv.getSpace());
                    if(size == 1){
                        root.setBorder(doubleBorder);
                    }
                    else{
                        var index = item.getParent().getChildren().indexOf(item);
                        if(index == 0) root.setBorder(topBorder);
                        else if(index == item.getParent().getChildren().size() -1) root.setBorder(Constants.BottomLine);
                    }
                    switch (nv.getIsCash()){
                        case 0 ->{
                            icon.setFill(Color.LIGHTGREEN);
                            icon.setContent(Icons.Cash);
                        }
                        case 1 ->{
                            icon.setFill(Color.LIGHTCORAL);
                            icon.setContent(Icons.NonCash);
                        }
                        case 2 ->{
                            icon.setFill(Color.DODGERBLUE);
                            icon.setContent(Icons.Mobile);
                        }
                    }
                }
            }
        }

        @Override
        protected void updateItem(LastPayment item, boolean empty) {
            super.updateItem(item, empty);
            if(empty){
                setBackground(null);
                setGraphic(null);
            }
            else {
                setGraphic(root);
                setBackground(isSelected()? Background.fill(Constants.BackgroundColorLight) : null);
            }
        }
    }
}
