package model;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class SumBoxModelDoubleColumn {
    public StringProperty key;
    public DoubleProperty value1, value2;

    public SumBoxModelDoubleColumn(String key, double value1, double value2) {
        this.key = new SimpleStringProperty(key);
        this.value1 = new SimpleDoubleProperty(value1);
        this.value2 = new SimpleDoubleProperty(value2);
    }

    public String getKey() {
        return key.get();
    }

    public double getValue1() {
        return value1.get();
    }
    public double getValue2() {
        return value2.get();
    }
}
