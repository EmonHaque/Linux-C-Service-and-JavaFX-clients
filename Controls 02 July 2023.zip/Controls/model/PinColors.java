package model;

import javafx.scene.paint.Color;

public class PinColors {
    private Color normal, highlight;

    public PinColors(Color normal, Color highlight) {
        this.normal = normal;
        this.highlight = highlight;
    }

    public Color getNormal() {
        return normal;
    }

    public void setNormal(Color normal) {
        this.normal = normal;
    }

    public Color getHighlight() {
        return highlight;
    }

    public void setHighlight(Color highlight) {
        this.highlight = highlight;
    }
}
