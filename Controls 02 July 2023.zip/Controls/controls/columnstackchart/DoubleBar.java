package controls.columnstackchart;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Scale;
import javafx.stage.Popup;
import javafx.util.Duration;
import model.PinColors;

import java.util.ArrayList;
import java.util.List;

public class DoubleBar extends Region {
    private boolean isPinned, isLoaded;
    private final Column bar;
    private final ColumnStack stack;

    private final double barValue;
    private double stackTotal;

    private Popup popup;

    private final Timeline barAnim;
    private final DoubleProperty barHeight;

    private final Rectangle barClip;

    public DoubleBar(double barValue, List<Double> stackValues) {
        this.barValue = barValue;
        getTransforms().add(new Scale(1, -1));
        bar = new Column(Color.LIGHTBLUE, Color.LIGHTGREEN, true, barValue < 0) {{
            setManaged(false);
            setMouseTransparent(true);
        }};
        getChildren().add(bar);

        var colors = new ArrayList<PinColors>();
        for (int i = 0; i < stackValues.size(); i++){
            stackTotal += stackValues.get(i);
            switch (i){
                case 0 -> colors.add(new PinColors(Color.LIGHTGRAY, Color.GRAY));
                case 1 -> colors.add(new PinColors(Color.LIGHTCORAL, Color.CORAL));
                case 2 -> colors.add(new PinColors(Color.CORNFLOWERBLUE, Color.BLUE));
            }
        }
        stack = new ColumnStack(stackValues, colors);
        stack.setManaged(false);
        getChildren().add(stack);

        barHeight = new SimpleDoubleProperty(0);

        barClip = new Rectangle();
        bar.setClip(barClip);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseClicked(this::onClicked);
        setOnMouseExited(this::onMouseExited);

        barAnim = new Timeline();
        barAnim.setDelay(Duration.millis(500));
        barAnim.setOnFinished(e -> bar.setClip(null));
    }

    public void makeColumn(double width, double height, double min, double max) {
        double spread = max - min;
        double negativeHeight = 0;
        if (min < 0) {
            var absMin = Math.abs(min);
            negativeHeight = height / spread * absMin;
        }

        double y = negativeHeight;
        double halfWidth = width / 2;

        var barHeight = height / spread * barValue;
        var stackHeight = height / spread * stackTotal;

        bar.setValue(0, y, halfWidth, barHeight);
        stack.makePin(halfWidth, stackHeight);
        stack.resizeRelocate(halfWidth, negativeHeight, halfWidth, stackHeight);

        barClip.setWidth(halfWidth);
        barClip.setX(0);
        barClip.setY(y);

        if (!isLoaded) {
            isLoaded = true;
            this.barHeight.addListener((o, ov, nv) -> {
                if(nv.doubleValue() < 0){
                    barClip.setTranslateY(nv.intValue());
                    barClip.setHeight(-1 * nv.doubleValue());

                }
                else barClip.setHeight(nv.doubleValue());
            });
            barAnim.getKeyFrames().clear();
            var key = new KeyValue(this.barHeight, barHeight, Interpolator.EASE_IN);
            var frame = new KeyFrame(Duration.millis(500), key);
            barAnim.getKeyFrames().add(frame);

            barAnim.play();
        }
    }

    void onMouseEntered(MouseEvent e) {
        if (isPinned) return;
        bar.highlightColor();
        stack.highlightColor();
        if (popup != null)
            popup.show(this, e.getScreenX() + 20, e.getScreenY() + 20);
    }

    private void onClicked(MouseEvent e) {isPinned = !isPinned;}

    private void onMouseExited(MouseEvent e) {
        if (isPinned) return;
        bar.normalColor();
        stack.normalColor();
        if (popup != null)
            popup.hide();
    }

    public void setToolTip(Popup popup) {
        this.popup = popup;
    }
}
