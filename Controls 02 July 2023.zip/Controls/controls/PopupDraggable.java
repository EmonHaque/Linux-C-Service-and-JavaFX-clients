package controls;

import javafx.scene.Cursor;
import javafx.scene.input.MouseEvent;
import javafx.stage.Popup;

public class PopupDraggable extends Popup {
    private double offsetX, offsetY;

    public PopupDraggable() {
        addEventHandler(MouseEvent.MOUSE_ENTERED, e -> getScene().setCursor(Cursor.OPEN_HAND));
        addEventHandler(MouseEvent.MOUSE_PRESSED, this::onPress);
        addEventHandler(MouseEvent.MOUSE_DRAGGED, this::onDrag);
        addEventHandler(MouseEvent.MOUSE_RELEASED, e -> getScene().setCursor(Cursor.DEFAULT));
        addEventHandler(MouseEvent.MOUSE_EXITED, e -> getScene().setCursor(Cursor.DEFAULT));
    }

    private void onPress(MouseEvent e) {
        getScene().setCursor(Cursor.CLOSED_HAND);
        offsetX = getX() - e.getScreenX();
        offsetY = getY() - e.getScreenY();
    }

    private void onDrag(MouseEvent e) {
        if (!e.isPrimaryButtonDown()) return;
        setX(e.getScreenX() + offsetX);
        setY(e.getScreenY() + offsetY);
    }


}
