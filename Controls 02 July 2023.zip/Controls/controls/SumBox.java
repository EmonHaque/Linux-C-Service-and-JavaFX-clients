package controls;

import controls.buttons.ActionButton;
import controls.texts.DoubleBoxClean;
import controls.texts.SuggestionBoxLess;
import helpers.Constants;
import helpers.Icons;
import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.control.SelectionMode;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.StringConverter;
import model.SumBoxModel;
import skinned.ExtendedListView;

import java.util.ArrayList;
import java.util.List;

public class SumBox<T> extends GridPane {
    private boolean isRowAddedOrRemoved;
    private final String suggestionProperty, suggestionTemplate;
    private final ObservableList<T> suggestionList;
    private final List<ChangeListener<String>> keyListeners;
    private final List<ChangeListener<Number>> valueListeners;

    private ObservableList<SumBoxModel> list, listBacking;
    private ExtendedListView<SumBoxModel> listView;
    private ActionButton addButton, removeButton;
    private Text particulars, amount, totalText, totalValue;

    private final DoubleProperty sum;
    private final BooleanProperty modified;

    public SumBox(ObservableList<T> suggestionList, String suggestionProperty, String suggestionTemplate) {
        this.suggestionList = suggestionList;
        this.suggestionProperty = suggestionProperty;
        this.suggestionTemplate = suggestionTemplate;
        sum = new SimpleDoubleProperty();
        modified = new SimpleBooleanProperty();

        keyListeners = new ArrayList<>();
        valueListeners = new ArrayList<>();

        addButtons();
        addTexts();
        addListView();

        getColumnConstraints().addAll(
                new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                new ColumnConstraints(70)
        );
    }

    public DoubleProperty sumProperty(){ return sum; }

    public BooleanProperty modifiedProperty(){ return modified; }

    public void setList(ObservableList<SumBoxModel> list) {
        if(this.list != null){
            for (int i = 0; i < this.list.size(); i++){
                this.list.get(i).key.removeListener(keyListeners.get(i));
                this.list.get(i).value.removeListener(valueListeners.get(i));
            }
            keyListeners.clear();
            valueListeners.clear();

            this.list.clear();
            listView.getSelectionModel().clearSelection();
        }

        double total = 0;
        for (var item : list) {
            total += item.getValue();

            keyListeners.add(this::onKeyChanged);
            valueListeners.add(this::onValueChanged);

            item.key.addListener(keyListeners.get(keyListeners.size() - 1));
            item.value.addListener(valueListeners.get(valueListeners.size() - 1));
            this.list.add(item);
        }
        totalValue.setText(String.format("%,.2f", total));
        sum.set(total);

        listBacking = list;
        if(list.size() > 0){
            isRowAddedOrRemoved = true;
            listView.getSelectionModel().select(0);
        }
    }

    private void addListView(){
        this.list = FXCollections.observableArrayList();
        listView = new ExtendedListView<>(list);
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setCellFactory(v -> new CellTemplate());
        add(listView, 0, 2, 2, 1);
        setVgrow(listView, Priority.ALWAYS);
    }

    public void setHeader(String text) {
        particulars.setText(text);
    }

    private void onKeyChanged(Observable o, String ov, String nv){
        modified.set(true);
    }

    private void onValueChanged(ObservableValue<?> o, Number ov, Number nv) {
        double total = sum.get();
        total -= ov.doubleValue();
        total += nv.doubleValue();
        totalValue.setText(String.format("%,.2f", total));
        sum.set(total);
        modified.set(true);
    }

    private void addNewRow() {
        var newItem = new SumBoxModel("", 0);

        keyListeners.add(this::onKeyChanged);
        valueListeners.add(this::onValueChanged);

        newItem.key.addListener(keyListeners.get(keyListeners.size() - 1));
        newItem.value.addListener(valueListeners.get(valueListeners.size() - 1));

        list.add(newItem);
        listBacking.add(newItem);

        isRowAddedOrRemoved = true;

        listView.getSelectionModel().select(newItem);
        listView.scrollTo(newItem);
        modified.set(true);
    }

    private void removeSelectedRow() {
        var index = listView.getSelectionModel().getSelectedIndex();
        if (index == -1) return;

        var pair = list.get(index);
        double total = this.sum.get();
        total -= pair.value.get();

        totalValue.setText(String.format("%,.2f", total));
        sum.set(total);

        pair.key.removeListener(keyListeners.get(index));
        pair.value.removeListener(valueListeners.get(index));

        keyListeners.remove(index);
        valueListeners.remove(index);

        list.remove(index);
        listBacking.remove(index);

        if (index > 0) {
            index--;
            isRowAddedOrRemoved = true;
            listView.getSelectionModel().select(index);
        }
        modified.set(true);
    }

    private void addTexts() {
        particulars = new Text("Particulars");
        amount = new Text("Amount");
        totalText = new Text("Total");
        totalValue = new Text(String.format("%,.2f", sum.get()));

        particulars.setFill(Color.WHITE);
        amount.setFill(Color.WHITE);
        totalText.setFill(Color.WHITE);
        totalValue.setFill(Color.WHITE);

        var topBorder = new StackPane();
        var bottomBorder = new StackPane();
        topBorder.setBorder(Constants.BottomBorder);
        bottomBorder.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0))));

        add(topBorder, 0, 1, 2, 1);
        add(particulars, 0, 1);
        add(amount, 1, 1);

        add(bottomBorder, 0, 3, 2, 1);
        add(totalText, 0, 3);
        add(totalValue, 1, 3);

        GridPane.setHalignment(amount, HPos.RIGHT);
        GridPane.setHalignment(totalValue, HPos.RIGHT);
        GridPane.setMargin(amount, new Insets(0, Constants.ScrollBarSize, 0, 0));
        GridPane.setMargin(totalValue, new Insets(0, Constants.ScrollBarSize, 0, 0));
    }

    private void addButtons() {
        addButton = new ActionButton(Icons.PlusCircle, 16, "add");
        removeButton = new ActionButton(Icons.MinusCircle, 16, "remove");

        addButton.setAction(this::addNewRow);
        removeButton.setAction(this::removeSelectedRow);

        var hBox = new HBox(addButton, removeButton);
        hBox.setAlignment(Pos.CENTER_RIGHT);
        add(hBox, 1, 0);

        GridPane.setHalignment(hBox, HPos.RIGHT);
        GridPane.setMargin(hBox, new Insets(0, Constants.ScrollBarSize, 0, 0));
    }

    private class CellTemplate extends ListCell<SumBoxModel> {
        private boolean isSelectedOnFocus;
        private final SuggestionBoxLess<T> keyField;
        private final DoubleBoxClean valueField;
        private final GridPane grid;
        private final ChangeListener<Boolean> focusChangeListener, selectChangeListener;

        public CellTemplate() {
            setPadding(new Insets(1, 0, 1, 0));
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setBackground(null);

            focusChangeListener = this::onFocusChange;
            selectChangeListener = this::onSelectionChange;

            keyField = new SuggestionBoxLess<>(suggestionList, suggestionProperty, suggestionTemplate){{ setPadding(new Insets(0));}};
            valueField = new DoubleBoxClean(){{setAlignment(Pos.CENTER_RIGHT);}};

            grid = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints(70)
                );
                add(keyField, 0, 0);
                add(valueField, 1, 0);
            }};

            itemProperty().addListener((o, ov, nv) -> {
                if (ov != null) {
                    keyField.textProperty().unbindBidirectional(ov.key);
                    valueField.textProperty().unbindBidirectional(ov.value);
                    setOnKeyPressed(null);
                    focusWithinProperty().removeListener(focusChangeListener);
                    selectedProperty().removeListener(selectChangeListener);
                }
                if (nv != null) {
                    keyField.textProperty().bindBidirectional(nv.key);
                    valueField.textProperty().bindBidirectional(nv.value, new StringConverter<>() {
                        @Override
                        public String toString(Number object) {
                            return String.format("%.2f", object.doubleValue());
                        }

                        @Override
                        public Number fromString(String string) {
                            try {
                                return Double.parseDouble(string);
                            }
                            catch (Exception ignored){
                                return 0;
                            }
                        }
                    });

                    setOnKeyPressed(this::onKeyPressed);
                    focusWithinProperty().addListener(focusChangeListener);
                    selectedProperty().addListener(selectChangeListener);
                }
            });
        }

        private void onFocusChange(Observable o, Boolean ov, Boolean nv){
            // null ?
            if(nv){
                if(isSelected()) return;
                if(isRowAddedOrRemoved){
                    isRowAddedOrRemoved = false;
                    return;
                }
                isSelectedOnFocus = true;
                // System.out.println("SumBox onFocusChange " + getItem().key + " : " + getItem().value);
                // ignore when addNewRow or removeSelectedRow selects item to avoid duplicate call
                getListView().getSelectionModel().select(getItem());
            }
        }

        private void onSelectionChange(Observable o, Boolean ov, Boolean nv){
            if(isSelectedOnFocus){
                isSelectedOnFocus = false;
                return;
            }
            if(nv && !ov){
                // System.out.println("SumBox onSelectionChange "  + getItem().key + " : " + getItem().value);
                Platform.runLater(() ->{
                    keyField.requestFocus();
                    keyField.end();
                });
            }
        }

        private void onKeyPressed(KeyEvent e) {
            if (!e.isControlDown()) return;
            e.consume();
            var code = e.getCode();
            if (code == KeyCode.ADD) {
                addNewRow();
            }
            if (code == KeyCode.SUBTRACT) {
                System.out.println("SumBox onKeyPressed SUBTRACT " + getItem().key + " : " + getItem().value);
                removeSelectedRow();
            }
        }

        @Override
        protected void updateItem(SumBoxModel item, boolean empty) {
            super.updateItem(item, empty);
            setGraphic(empty ? null : grid);
        }
    }
}
