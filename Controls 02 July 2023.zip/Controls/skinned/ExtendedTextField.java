package skinned;

import controls.texts.ContextItem;
import helpers.Constants;
import helpers.Icons;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.scene.control.Skin;
import javafx.scene.control.TextField;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Popup;
import skins.ExtendedTextFieldSkin;

public class ExtendedTextField extends TextField {
    private Popup contextMenu;

    public ExtendedTextField() {
        super();
        setBackground(null);
        addContextMenu();
        addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
            if (e.getButton() == MouseButton.SECONDARY) {
                contextMenu.show(this, e.getScreenX() + 15, e.getScreenY() + 15);
            }
            else contextMenu.hide();
        });
        addEventFilter(ContextMenuEvent.CONTEXT_MENU_REQUESTED, Event::consume);
    }

    private void addContextMenu(){
        contextMenu = new Popup() {{setAutoHide(true);}};
        contextMenu.getContent().add(new VBox() {{
            setPadding(new Insets(5, 15, 5, 5));
            setSpacing(5);
            setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, new CornerRadii(5), new Insets(0))));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
            getChildren().addAll(
                    new ContextItem(Icons.Cut, "Cut", () -> {
                        cut();
                        contextMenu.hide();
                    }),
                    new ContextItem(Icons.Copy, "Copy", () -> {
                        copy();
                        contextMenu.hide();
                    }),
                    new ContextItem(Icons.Paste, "Paste", () -> {
                        paste();
                        contextMenu.hide();
                    })
            );
        }});
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedTextFieldSkin(this);
    }
}