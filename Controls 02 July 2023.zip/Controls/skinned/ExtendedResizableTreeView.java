package skinned;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.geometry.Insets;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.Skin;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.skin.VirtualFlow;
import skins.ExtendedResizableTreeViewSkin;

public class ExtendedResizableTreeView<T> extends TreeView<T> {
    private VirtualFlow<?> vFlow;
    private ScrollBar vBar;
    private boolean isLoaded;
    private double height;

    public ExtendedResizableTreeView() {
        super();
        setBackground(null);
        setPadding(new Insets(0));
    }

    private void calculateHeight(TreeItem<T> item){
        for(var node : item.getChildren()){
            height += vFlow.getCell(getRow(node)).getHeight();
            calculateHeight(node);
        }
    }

    private void resetHeight(){
        height = 0;
        calculateHeight(getRoot());
        vBar.setOpacity(height < getMaxHeight() ? 0 : 1);
        setPrefHeight(Math.min(getMaxHeight(), height));
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if(!isLoaded){
            isLoaded = true;
            vBar = ((ExtendedResizableVirtualFlow <?>)vFlow).vBar;
            getRoot().getChildren().addListener((ListChangeListener.Change<? extends TreeItem<T>> change) -> resetHeight());
            Platform.runLater(this::resetHeight);
        }
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        var skin = new ExtendedResizableTreeViewSkin<>(this);
        vFlow = skin.flow;
        //vBar = skin.vBar;
        return skin;
    }
}
