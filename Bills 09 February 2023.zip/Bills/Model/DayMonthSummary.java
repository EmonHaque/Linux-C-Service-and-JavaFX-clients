package Model;

public class DayMonthSummary {
    private String particulars;
    private double bill, payment;

    public String getParticulars() {
        return particulars;
    }

    public double getBill() {
        return bill;
    }

    public double getPayment() {
        return payment;
    }

    public void setParticulars(String particulars) {
        this.particulars = particulars;
    }

    public void setBill(double bill) {
        this.bill = bill;
    }

    public void setPayment(double payment) {
        this.payment = payment;
    }
}
