import Views.*;
import controls.MainPanel;
import controls.Window;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import ridiculous.AppData;
import ridiculuous.Addresses;

public class Bills extends ClientApp {
    public static AppData appData;

    @Override
    protected Image getIcon() {
        return new Image("resources/images/icon.png");
    }

    @Override
    protected String IP() {
        return Addresses.BillIP;
    }

    @Override
    protected int port() {
        return Addresses.BillPort;
    }

    @Override
    protected String getTitle() {
        return "Bills";
    }

    @Override
    protected void initializeAppData() {
        appData = new AppData(loading, stage);
    }

    @Override
    protected Window getWindow(Stage stage) {
        return new Window(stage, getTitle()){{
            setContent(new MainPanel(stage){{
                addView(new ProcessView());
                addView(new SearchView());
                addView(new PeriodicView());
                addView(new AccountsView());
                addNotificationView(new NotificationView());
                setTitle(getTitle());
            }});
        }};
    }
}
