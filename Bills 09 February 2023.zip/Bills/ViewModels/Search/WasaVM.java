package ViewModels.Search;

public class WasaVM extends DepartmentSearchVM {
    @Override
    public String getDepartmentName() {
        return "WASA";
    }
}
