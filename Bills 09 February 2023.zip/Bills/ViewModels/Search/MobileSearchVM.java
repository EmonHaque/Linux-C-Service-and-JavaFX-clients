package ViewModels.Search;

import Enums.Function;
import Interfaces.IBillEntry;
import Model.AccountPaymentSummary;
import Model.EditedBillInfo;
import Model.Mobile;
import Model.MobileEntry;
import javafx.beans.Observable;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.concurrent.Task;
import model.PieSeries;
import model.SumBoxModel;
import ridiculous.AppData;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class MobileSearchVM extends SearchBaseVM {
    public final ObservableList<MobileEntry> list;
    public final ObservableList<AccountPaymentSummary> accountWiseList;

    public FilteredList<MobileEntry> reportable;
    public FilteredList<Mobile> selectionList;
    public ObjectProperty<List<PieSeries>> pieSeries;
    public ObjectProperty<PieSeries> selectedSlice;

    public MobileSearchVM() {
        pieSeries = new SimpleObjectProperty<>();
        selectedSlice = new SimpleObjectProperty<>();

        accountWiseList = FXCollections.observableArrayList();

        selectionList = new FilteredList<>(AppData.mobiles);
        list = FXCollections.observableArrayList();
        reportable = new FilteredList<>(list);

        selectedEntry.addListener((o, ov, nv) -> startImageBreakupTask(nv));
        selectedSlice.addListener(this::onSliceSelectionChange);
        AppData.onBillInfoEdited.addListener(this::onBillInfoEdited);
    }

    @Override
    protected String getImageFileName() {
        return selectedEntry.get().getFileName();
    }

    @Override
    protected int getBillIdForBreakup() {
        return selectedEntry.get().getBillId();
    }

    @SuppressWarnings("rawtypes")
    @Override
    protected Task getEntriesTask() {
        return new GetEntriesTask();
    }

    @Override
    protected IBillEntry getEditedEntry(int billId) {
        IBillEntry entry = null;
        if (list.size() == 0) entry = null;
        for (var e : list) {
            if (e.getBillId() != billId) continue;
            entry = e;
            break;
        }
        return entry;
    }

    public void refresh() {startEntryTask();}

    private void onBillInfoEdited(Observable o, EditedBillInfo ov, EditedBillInfo nv) {
        var entry = list.stream().filter(x -> x.getBillId() == nv.getBillId()).findFirst();
        if (entry.isEmpty()) return;

        var e = entry.get();
        if (nv.isFileRenamed()) {
            boolean hasBeenRemoved = false;
            if (!e.getDate().equals(nv.getDate())) {
                list.remove(e);
                hasBeenRemoved = true;
            }
            e.setDate(nv.getDate());
            e.setTransactionId(nv.getTransactionId());
            e.setFileName(nv.getNewFile());

            if (hasBeenRemoved) {
                var splits = e.getDate().split("-");
                e.setMonth(splits[1] + ", " + splits[0]);
                list.add(e);
            }
        }
        if (e.getMobileId() != nv.getMobileId()) {
            var mobile = AppData.mobiles.stream().filter(x -> x.getId() == nv.getMobileId()).findFirst().get();
            e.setMobileId(mobile.getId());
            e.setMobileNo(mobile.getNumber());
        }
        e.setBillNo(nv.getBillNo());
        e.setPeriod(nv.getPeriod());
    }

    private void onSliceSelectionChange(Observable o, PieSeries ov, PieSeries nv) {
        if (nv == null) {

        }
        else {
            accountWiseList.clear();
            var items = list.stream().filter(x -> x.getDepartment().equals(nv.title))
                    .collect(Collectors.groupingBy(MobileEntry::getAccountId))
                    .entrySet().stream().map(x -> new AccountPaymentSummary(
                            x.getKey(),
                            x.getValue().get(0).getAccountHolder(),
                            x.getValue().get(0).getAddress(),
                            x.getValue().stream().mapToDouble(IBillEntry::getPayment).sum())
                    ).toList();

            accountWiseList.addAll(items);
        }
    }

    private class GetEntriesTask extends Task<List<MobileEntry>> {
        private int length;
        private double payment;
        private List<PieSeries> ps;

        @Override
        protected List<MobileEntry> call() throws Exception {
            updateMessage("requesting");
            Thread.sleep(250);

            var buffer = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(selectedId.intValue());
            var request = new Request(Function.GetEntriesByMobile.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            length = response.getPacket().length;
            updateMessage("received " + length + " bytes");
            Thread.sleep(250);

            updateMessage("processing " + length + " bytes");
            Thread.sleep(250);
            buffer = ByteBuffer.wrap(response.getPacket()).order(ByteOrder.LITTLE_ENDIAN);
            var list = getEntries(buffer);
            ps = makePieSeries(list);
            return list;
        }

        @Override
        protected void succeeded() {
            try {
                var entries = get();
                list.clear();
                list.addAll(entries);
                totalPayment.set(payment);

                pieSeries.set(ps);

                updateMessage("processed " + String.format("%,d", length) + " bytes");
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }

        private List<MobileEntry> getEntries(ByteBuffer buffer) {
            payment = 0;
            var entries = new ArrayList<MobileEntry>();
            int read = 0;
            while (read < length) {
                var billId = buffer.getInt(read);
                var amount = buffer.getDouble(read + 4);
                payment += amount;

                read += 12;
                int start = read;
                int index = 0;
                var segments = new String[10];

                while (read < length) {
                    if (buffer.get(read) != 0) {
                        read++;
                        continue;
                    }
                    segments[index++] = new String(buffer.array(), start, read - start, StandardCharsets.US_ASCII);
                    start = ++read;
                    if (index == segments.length) break;
                }

                entries.add(new MobileEntry() {{
                    setBillId(billId);
                    setPayment(amount);
                    setMonth(segments[0]);
                    setDepartment(segments[1]);
                    setDate(segments[2]);
                    setFileName(segments[3]);
                    setAccountId(segments[4]);
                    setAccountHolder(segments[5]);
                    setAddress(segments[6]);
                    setBillNo(segments[7]);
                    setPeriod(segments[8]);
                    setTransactionId(segments[9]);
                }});
            }
            return entries;
        }

        private List<PieSeries> makePieSeries(List<MobileEntry> list) {
            return list.stream().collect(
                    Collectors.groupingBy(MobileEntry::getDepartment)
            ).entrySet().stream().map(x -> new PieSeries(
                    0,
                    x.getKey(),
                    x.getValue().stream().mapToDouble(y -> y.getPayment()).sum())
            ).toList();
        }
    }
}
