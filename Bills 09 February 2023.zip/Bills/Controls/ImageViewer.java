package Controls;

import controls.ImageZoomer;
import controls.buttons.CommandButton;
import helpers.Icons;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import net.sourceforge.tess4j.util.ImageHelper;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


public class ImageViewer extends BorderPane {
    public StringProperty fileProperty;
    public ObjectProperty<byte[]> bufferProperty;
    private final CommandButton blackWhite, grayScale, color;
    private final ImageZoomer zoomer;
    private Image image;

    public ImageViewer(boolean isOfBuffer) {
        blackWhite = new CommandButton(Icons.ImageBW, 16, "Black & White");
        grayScale = new CommandButton(Icons.ImageGray, 16, "Gray Scale");
        color = new CommandButton(Icons.ImageColor, 16, "Original");

        blackWhite.setAction(this::makeBlackWhite);
        grayScale.setAction(this::makeGray);
        color.setAction(this::reset);

        var button = new HBox(blackWhite, grayScale, color) {{
            setAlignment(Pos.CENTER_RIGHT);
        }};

        zoomer = new ImageZoomer();
        setTop(button);
        setCenter(zoomer);


        BooleanBinding disableBinding = null;
        if(isOfBuffer){
            bufferProperty = new SimpleObjectProperty<>();
            bufferProperty.addListener((o, ov, nv) -> {
                if (nv == null) {
                    image = null;
                    zoomer.imageProperty.set(null);
                }
                else {
                    image = new Image(new ByteArrayInputStream(nv));
                    makeGray();
                }
            });
            disableBinding = bufferProperty.isNull();
        }
        else{
            fileProperty = new SimpleStringProperty("");
            fileProperty.addListener((o, ov, nv) -> {
                if (nv == null) {
                    image = null;
                    zoomer.imageProperty.set(null);
                }
                else {
                    try {
                        image = new Image(new FileInputStream(nv));
                        makeGray();
                    } catch (FileNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            disableBinding = fileProperty.isNull().or(fileProperty.isEmpty());
        }
        blackWhite.disableProperty().bind(disableBinding);
        grayScale.disableProperty().bind(disableBinding);
        color.disableProperty().bind(disableBinding);
    }

    private void makeBlackWhite() {
        var converted = ImageHelper.convertImageToBinary(SwingFXUtils.fromFXImage(image, null));
        var convertedAgainWhy = new BufferedImage(converted.getWidth(null), converted.getHeight(null), BufferedImage.TYPE_INT_RGB);
        convertedAgainWhy.createGraphics().drawImage(converted, 0, 0, null);
        var inverted = ImageHelper.invertImageColor(convertedAgainWhy);
        zoomer.imageProperty.set(SwingFXUtils.toFXImage(inverted, null));
    }

    private void makeGray() {
        var converted = ImageHelper.convertImageToGrayscale(SwingFXUtils.fromFXImage(image, null));
        var convertedAgainWhy = new BufferedImage(converted.getWidth(null), converted.getHeight(null), BufferedImage.TYPE_INT_RGB);
        convertedAgainWhy.createGraphics().drawImage(converted, 0, 0, null);
        var inverted = ImageHelper.invertImageColor(convertedAgainWhy);

        zoomer.imageProperty.set(SwingFXUtils.toFXImage(inverted, null));
    }

    private void reset() {
        zoomer.imageProperty.set(image);
    }
}
