package Skins;

import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.skin.ListViewSkin;
import javafx.scene.control.skin.VirtualFlow;
import Controls.ExtendedResizableVirtualFlow;

public class ExtendedResizableListViewSkin<T> extends ListViewSkin<T> {
    public VirtualFlow<ListCell<T>> flow;
    public ExtendedResizableListViewSkin(ListView<T> control) {
        super(control);
    }

    @Override
    protected VirtualFlow<ListCell<T>> createVirtualFlow() {
        flow = new ExtendedResizableVirtualFlow<>();
        return flow;
    }
}
