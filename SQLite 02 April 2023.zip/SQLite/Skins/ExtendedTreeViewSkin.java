package Skins;

import javafx.scene.control.ScrollBar;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeView;
import javafx.scene.control.skin.TreeViewSkin;
import javafx.scene.control.skin.VirtualFlow;
import Controls.ExtendedVirtualFlow;

public class ExtendedTreeViewSkin<T> extends TreeViewSkin<T> {
    public ScrollBar vBar;
    public ExtendedTreeViewSkin(TreeView<T> control) {
        super(control);
    }

    @Override
    protected VirtualFlow<TreeCell<T>> createVirtualFlow() {
        ExtendedVirtualFlow<TreeCell<T>> flow = new ExtendedVirtualFlow<>();
        vBar = flow.vBar;
        return flow;
    }   
}
