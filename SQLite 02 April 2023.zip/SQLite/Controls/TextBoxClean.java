package Controls;

import Helpers.Constants;
import javafx.beans.binding.BooleanBinding;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.scene.control.Skin;
import javafx.scene.control.TextField;
import javafx.scene.input.ContextMenuEvent;
import Skins.ExtendedTextFieldSkin;

public class TextBoxClean extends TextField {
    
    public TextBoxClean() {
        setPadding(new Insets(0));
//        setSkin(new ExtendedTextFieldSkin(this)); // this messes the TableView Column header. use createDefaultSkin;
        setContextMenu(null);
        addEventFilter(ContextMenuEvent.CONTEXT_MENU_REQUESTED, Event::consume);
        setBorder(Constants.TopBorder);
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedTextFieldSkin(this);
    }

    public BooleanBinding isEmpty() {return textProperty().isEmpty();}
}
