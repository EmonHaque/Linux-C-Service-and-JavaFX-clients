package Controls;

import CellTemplates.SuggestionTemplate;
import Helpers.Constants;
import Helpers.Icons;
import Model.Suggestion;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.transformation.FilteredList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.scene.control.Skin;
import javafx.scene.control.TextArea;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.TextFlow;
import javafx.stage.Popup;
import Skins.ExtendedTextAreaSkin;
import ridiculous.AppData;

import java.io.*;

public class TextBoxMultiLineClean extends TextArea {
    private double fontSize;
    private boolean isLetter, isAdded;
    private String word = "";
    private Popup contextMenu;
    private Point2D caret;

    private final Popup suggestion;
    private final ExtendedResizableListView<Suggestion> suggestionList;
    private final FilteredList<Suggestion> filtered;
    private final StringProperty query;

    public TextBoxMultiLineClean() {
        setContextMenu(null);
        fontSize = getFont().getSize();
        query = new SimpleStringProperty("");
        addContextMenu();

        filtered = new FilteredList<>(AppData.suggestions);
        suggestionList = new ExtendedResizableListView<>(filtered) {{

            setCellFactory(v -> new SuggestionTemplate(query));
            setMaxHeight(200);
            setMinWidth(400);
        }};
        var filterCount = new Text(){{ setFill(Color.WHITE);}};
        var totalCount = new Text(){{ setFill(Color.WHITE);}};
        var countFlow = new TextFlow(){{
            getChildren().addAll(
                    filterCount,
                    new Text("/"){{ setFill(Color.WHITE);}},
                    totalCount,
                    new Text(" matched"){{ setFill(Color.WHITE);}}
            );
            setTextAlignment(TextAlignment.RIGHT);
            setBorder(Constants.BottomBorder);
            setPadding(new Insets(2.5, Constants.ScrollBarSize, 2.5, 0));
        }};
        filterCount.textProperty().bind(Bindings.size(filtered).asString("%,d"));
        totalCount.textProperty().bind(Bindings.size(AppData.suggestions).asString("%,d"));
        suggestion = new Popup();
        suggestion.getContent().add(new BorderPane(){{
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
            setTop(countFlow);
            setCenter(suggestionList);
        }});

        addEventFilter(ContextMenuEvent.CONTEXT_MENU_REQUESTED, Event::consume);
        addEventFilter(ScrollEvent.SCROLL, this::onScroll);

        setOnMouseClicked(this::onRightClick);
        setOnDragEntered(this::onDragEnter);
        setOnDragExited(this::onDragExit);
        setOnDragOver(this::onDragOver);
        setOnDragDropped(this::onDrop);

        setOnKeyPressed(this::onKeyPress);
        setOnKeyTyped(this::onKeyType);

        suggestionList.setOnKeyPressed(this::onKeyPressOnListView);

        caretPositionProperty().addListener(this::onCaretPositionChange);
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedTextAreaSkin(this);
    }

    private void onCaretPositionChange(Observable e, Number ov, Number nv){
        var skin = (ExtendedTextAreaSkin)getSkin();
        if (skin != null) {
            var caretBound =  skin.getCharacterBounds(nv.intValue());
            caret = localToScreen(caretBound.getMaxX(), caretBound.getMaxY());
        }
    }

    private void onKeyPress(KeyEvent e){
        isLetter = e.getCode().isLetterKey();
    }

    private void onKeyPressOnListView(KeyEvent e){
        if(e.getCode() == KeyCode.TAB){
            if(!suggestion.isShowing()) return;
            e.consume();
            addWord();
        }
        else if(e.getCode() == KeyCode.ENTER){
            if(!suggestion.isShowing()) return;
            addWord();
        }
    }

    private void onKeyType(KeyEvent e){
        //normal enter comes here, number pad enter doesn't
        if(!isLetter){
            hideSuggestion();
            return;
        }
        if(isAdded){
            isAdded = false;
            hideSuggestion();
            return;
        }

        if(caret == null) return;
        word += e.getCharacter();
        query.set(word);
        filtered.setPredicate(x -> x.getValue().toLowerCase().contains(word.toLowerCase()));
        if(filtered.size() == 0) {
            suggestion.hide();
            return;
        }
        if(!suggestion.isShowing()){
            suggestion.show(this, caret.getX(), caret.getY());
        }
        else {
            suggestion.setX(caret.getX());
            suggestion.setY(caret.getY());
        }
    }

    private void onScroll(ScrollEvent e) {
        if (!e.isControlDown()) return;
        // this function is called twice on every scroll, first with 0
        if (e.getDeltaY() == 0) return;

        if (e.getDeltaY() > 0) {
            fontSize++;
            setFont(Font.font(fontSize));
        }
        else {
            if (fontSize == 13) return;
            fontSize--;
            setFont(Font.font(fontSize));
        }
        e.consume();
    }

    private void onDragEnter(DragEvent e){
        var db = e.getDragboard();
        if(db.hasFiles()){
            setBackground(Background.fill(Constants.BackgroundColorLight));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25))));
        }
        e.consume();
    }

    private void onDragExit(DragEvent e){
        setBackground(null);
        setBorder(null);
        e.consume();
    }

    private void onDragOver(DragEvent e){
        if (e.getDragboard().hasFiles()) {
            var db = e.getDragboard();
            if (db.getFiles().size() == 1) {
                var name = db.getFiles().get(0).getName().toLowerCase();
                if (name.endsWith(".sql")) {
                    e.acceptTransferModes(TransferMode.COPY_OR_MOVE);
                }
                else e.acceptTransferModes(TransferMode.NONE);
            }
            else e.acceptTransferModes(TransferMode.NONE);
        }
        e.consume();
    }

    private void onDrop(DragEvent e){
        var db = e.getDragboard();
        boolean result = false;
        if (db.hasFiles()) {
            try (var reader = new BufferedReader(new FileReader(db.getFiles().get(0).getAbsolutePath()))) {
                String line;
                while ((line = reader.readLine()) != null){
                    appendText(line + '\n');
                }
                result = true;
            } catch (IOException exp) {
                result = false;
                exp.printStackTrace();
            }
        }
        e.setDropCompleted(result);
        e.consume();
    }

    private void onRightClick(MouseEvent e){
        if (e.getButton() == MouseButton.SECONDARY) {
            contextMenu.show(this, e.getScreenX() + 15, e.getScreenY() + 15);
        }
        else contextMenu.hide();
    }

    private void addContextMenu() {
        contextMenu = new Popup() {{setAutoHide(true);}};
        contextMenu.getContent().add(new VBox() {{
            setPadding(new Insets(5, 15, 5, 5));
            setSpacing(5);
            setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, new CornerRadii(5), new Insets(0))));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
            getChildren().addAll(
                    new ContextItem(Icons.Cut, "Cut", () -> {
                        cut();
                        contextMenu.hide();
                    }),
                    new ContextItem(Icons.Copy, "Copy", () -> {
                        copy();
                        contextMenu.hide();
                    }),
                    new ContextItem(Icons.Paste, "Paste", () -> {
                        paste();
                        contextMenu.hide();
                    })
            );
        }});
    }

    private void addWord(){
        var selected = suggestionList.getSelectionModel().getSelectedItem();
        if(selected == null) selected = filtered.get(0);
        var start = getCaretPosition() - word.length();
        replaceText(start, getCaretPosition(), selected.getValue());
        isAdded = true;
    }

    private void hideSuggestion(){
        word = "";
        suggestion.hide();
    }
}
