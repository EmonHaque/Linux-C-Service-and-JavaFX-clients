package Controls;

import javafx.event.EventHandler;
import javafx.scene.input.DragEvent;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;

import java.util.ArrayList;
import java.util.List;

public class TableViewTabs  extends Region {
    private final StackPane headerArea;
    private final List<TableViewPage> tabs;
    private TableViewPage selected;
    private EventHandler<TabHeader.TabClickEvent> tabClickEvent;
    private EventHandler<DragEvent> dragEvent;

    public TableViewTabs() {
        tabs = new ArrayList<>();
        headerArea = new StackPane();
        getChildren().add(headerArea);
    }

    private void onSelectionChange(TableViewPage page){
        if(selected != null) getChildren().remove(selected);

        selected = page;
        getChildren().add(selected);
        selected.getHeader().setSelected(true);
        headerArea.toFront();
    }

    public void addTab(String name) {
        if (selected != null) {
            selected.getHeader().setSelected(false);
        }
        var tab = new TableViewPage(name);
        headerArea.getChildren().add(tab.getHeader());
        tabs.add(tab);
        onSelectionChange(tab);

        tabClickEvent = new TabHeader.TabClickHandler() {
            @Override
            public void onSelect(TabHeader header) {
                if (header.equals(selected.getHeader())) return;
                if (selected != null) {
                    selected.getHeader().setSelected(false);
                }
                for (var item : tabs) {
                    if (!item.getHeader().equals(header)) continue;
                    onSelectionChange(item);
                    break;
                }
            }

            @Override
            public void onClose(TabHeader header) {
                if (tabs.size() == 1) return;
                if(tabClickEvent != null)
                    header.removeEventHandler(TabHeader.TabClickEvent.CLICK_EVENT, tabClickEvent);
                if(dragEvent != null)
                    header.removeEventHandler(DragEvent.DRAG_DROPPED, dragEvent);

                int index = 0;
                TableViewPage current = null;
                for (var item : tabs) {
                    if (!item.getHeader().equals(header)) {
                        index++;
                        continue;
                    }
                    current = item;
                    break;
                }
                if (selected.getHeader().equals(header)) {
                    var adjacent = index == 0 ? tabs.get(1) : tabs.get(index - 1);
                    onSelectionChange(adjacent);
                }
                tabs.remove(current);
                headerArea.getChildren().remove(header);
                layoutHeaders();
            }
        };
        dragEvent = this::onDragDrop;
        tab.getHeader().addEventHandler(TabHeader.TabClickEvent.CLICK_EVENT, tabClickEvent);
        tab.getHeader().addEventHandler(DragEvent.DRAG_DROPPED, dragEvent);
    }

    private void onDragDrop(DragEvent e){
        var list = new ArrayList<>(tabs);

        var droppedOn = (TabHeader)e.getSource();
        int indexDroppedOn = 0;
        TableViewPage dragged = null;
        boolean dragFound = false;
        boolean dropFound = false;

        for(int i = 0; i < tabs.size(); i++){
            if(droppedOn.equals(tabs.get(i).getHeader())){
                indexDroppedOn = i;
                dropFound = true;
            }
            else if(tabs.get(i).getHeader().isDragged()){
                dragged = tabs.get(i);
                dragFound = true;
            }
            if(dragFound && dropFound) break;
        }
        tabs.clear();
        list.remove(dragged);
        tabs.addAll(list);
        tabs.add(indexDroppedOn, dragged);

        headerArea.getChildren().clear();
        for(var item : tabs){
            headerArea.getChildren().add(item.getHeader());
        }
        requestLayout();
    }

    private void layoutHeaders() {
        double currentX = getInsets().getLeft() + 10;
        double headWidth = (getWidth() - 10) / (headerArea.getChildren().size() - 1);
        for (var chi : headerArea.getChildren()) {
            chi.resizeRelocate(currentX, 0, chi.prefWidth(-1), chi.prefHeight(-1));
            currentX += chi.prefWidth(-1) + 5;
        }
    }

    @Override
    protected void layoutChildren() {
        var headerHeight = 22;
        var padding = 0.75;
        if(selected != null)
            selected.resizeRelocate(getInsets().getLeft(), headerHeight - padding, getWidth() - getInsets().getLeft(), getHeight()-headerHeight + padding);
        layoutHeaders();
    }
}
