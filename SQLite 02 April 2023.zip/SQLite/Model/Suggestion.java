package Model;

import Enums.SuggestionType;

public class Suggestion {
    private SuggestionType type;
    private String value;

    public Suggestion(SuggestionType type, String value) {
        this.type = type;
        this.value = value;
    }

    public SuggestionType getType() {
        return type;
    }

    public String getValue() {
        return value;
    }
}
