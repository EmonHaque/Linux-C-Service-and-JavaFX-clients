package interfaces;

import javafx.beans.property.StringProperty;

public abstract class IReturnNameAndId<T> {
    public abstract String getName();
    public abstract StringProperty nameProperty();
    public abstract int getId();
}
