package editables;

import controls.SVGIcon;
import controls.daymonth.DayPicker;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

import java.time.LocalDate;

public class EditDate extends GridPane {
    private final Text label, content;
    private final DayPicker box;
    private final SVGIcon icon;
    private final EditPane parent;

    public EditDate(String hint, String icon, boolean isRequired, EditPane parent) {
        this.parent = parent;
        box = new DayPicker(hint, icon, isRequired){{ setVisible(false);}};
        this.icon = new SVGIcon(icon);
        label = new Text(hint) {{setFill(Color.GRAY);}};
        content = new Text() {{setFill(Color.WHITE);}};

        add(box, 0, 0, 2, 2);
        add(this.icon, 0, 0);
        add(label, 1, 0);
        add(content, 0, 1, 2, 1);

        getColumnConstraints().addAll(
                new ColumnConstraints(),
                new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}}
        );
        setVgap(5);
        setHgap(5);
        parent.isOnEditProperty().addListener(this::onIsOnEditChanged);
        box.selectedDateProperty().addListener(this::onDateChanged);
    }

    private void onIsOnEditChanged(Observable o) {
        if (parent.isOnEditProperty().get()) {
            icon.setVisible(false);
            label.setVisible(false);
            content.setVisible(false);
            box.setVisible(true);
        }
        else {
            box.setVisible(false);
            icon.setVisible(true);
            label.setVisible(true);
            content.setVisible(true);
        }
    }

    private void onDateChanged(Observable o){
        var date = box.selectedDateProperty().get();
        content.setText(date == null ? "" : date.toString());
    }
    public ObjectProperty<LocalDate> dateProperty() { return box.selectedDateProperty(); }
}
