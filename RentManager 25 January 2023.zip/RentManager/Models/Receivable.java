package Models;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Receivable {
    private final IntegerProperty leaseId, headId, amount;

    public Receivable() {
        leaseId = new SimpleIntegerProperty();
        headId = new SimpleIntegerProperty();
        amount = new SimpleIntegerProperty();
    }
    public Receivable(int leaseId, int headId, int amount) {
        this.leaseId = new SimpleIntegerProperty(leaseId);
        this.headId = new SimpleIntegerProperty(headId);
        this.amount = new SimpleIntegerProperty(amount);
    }

    public int getLeaseId() {
        return leaseId.get();
    }

    public IntegerProperty leaseIdProperty() {
        return leaseId;
    }

    public void setLeaseId(int leaseId) {
        this.leaseId.set(leaseId);
    }

    public int getHeadId() {
        return headId.get();
    }

    public IntegerProperty headIdProperty() {
        return headId;
    }

    public void setHeadId(int headId) {
        this.headId.set(headId);
    }

    public int getAmount() {
        return amount.get();
    }

    public IntegerProperty amountProperty() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount.set(amount);
    }
}
