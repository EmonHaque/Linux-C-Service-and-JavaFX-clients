package ViewModels.Edit;

import Enums.Function;
import Models.Tenant;
import javafx.beans.Observable;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;
import ridiculous.Jar;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Comparator;

public class EditTenantVM extends EditBaseVM<Tenant> {
    public IntegerProperty stateProperty;
    public ObjectProperty<LocalDate> selectedDate;

    public EditTenantVM() {
        edited = new Tenant();
        stateProperty = new SimpleIntegerProperty();
        selectedDate = new SimpleObjectProperty<>();
        var source = new Jar<>(AppData.tenants, o -> new Observable[]{
                stateProperty,
                queryProperty,
                o.hasLeftProperty()
        });
        editableList = new FilteredList<>(source.sorted(Comparator.comparing(Tenant::getName)), this::filter);
        stateProperty.addListener(this::onQueryEditableListChanged);
    }

    private boolean filter(Tenant tenant){
        var isMatch = true;
        if(!isQueryEmpty){
            isMatch = tenant.getName().toLowerCase().contains(trimmedQuery);
        }
        switch (stateProperty.get()){
            case 0 ->  isMatch = isMatch && !tenant.isHasLeft();
            case 1 -> isMatch = isMatch && tenant.isHasLeft();
        }
        return isMatch;
    }

    @Override
    protected int function() { return Function.EditTenant.ordinal(); }

    @Override
    protected ByteBuffer buffer() {
        var leftOn = "";
        byte hasLeft = 0;
        if (edited.isHasLeft() && !selected.isHasLeft()) {
            leftOn = selectedDate.get().toString();
            hasLeft = 1;
        }

        var leftOnBytes = (leftOn + '\0').getBytes(StandardCharsets.US_ASCII);
        var nameBytes = (edited.getName().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
        var fatherBytes = (edited.getFather().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
        var motherBytes = (edited.getMother().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
        var husbandBytes = (edited.getHusband().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
        var addressBytes = (edited.getAddress().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
        var nidBytes = (edited.getNid().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
        var phoneBytes = (edited.getContactNo().trim() + '\0').getBytes(StandardCharsets.US_ASCII);

        return ByteBuffer.allocate(5 + leftOnBytes.length + nameBytes.length + fatherBytes.length + motherBytes.length
                        + husbandBytes.length + addressBytes.length + nidBytes.length + phoneBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .put(leftOnBytes)
                .putInt(edited.getId())
                .put(nameBytes)
                .put(fatherBytes)
                .put(motherBytes)
                .put(husbandBytes)
                .put(addressBytes)
                .put(nidBytes)
                .put(phoneBytes)
                .put(hasLeft);
    }

    @Override
    public void cloneSelected() {
        edited = new Tenant(){{
           setId(selected.getId());
           setName(selected.getName());
           setFather(selected.getFather());
           setMother(selected.getMother());
           setHusband(selected.getHusband());
           setAddress(selected.getAddress());
           setNid(selected.getNid());
           setContactNo(selected.getContactNo());
           setHasLeft(selected.isHasLeft());
        }};
    }
}
