package ViewModels.Report;

import Models.Space;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;
import ridiculous.Jar;

public class SpaceLedgerVM extends BaseLedgerVM<Space>{
    private Jar<Space> source;
    public FilteredList<Space> list;
    public StringProperty queryProperty;

    public SpaceLedgerVM() {
        queryProperty = new SimpleStringProperty("");
        source = new Jar<>(AppData.spaces, o -> new Observable[]{ queryProperty });
        list = new FilteredList<>(source, x -> {
            if(queryProperty.get().isEmpty()) return true;
            return x.getName().toLowerCase().contains(queryProperty.get().trim().toLowerCase());
        });
    }

    @Override
    protected String getWhere() {
        return "SpaceId";
    }

    @Override
    public String getHeader() {
        return "Space";
    }

    @Override
    protected FilteredList<Space> getSelectionList() {
        return list;
    }
}
