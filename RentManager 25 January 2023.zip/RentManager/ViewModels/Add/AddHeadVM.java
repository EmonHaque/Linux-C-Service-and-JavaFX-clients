package ViewModels.Add;

import Enums.Function;
import Models.ControlHead;
import Models.Head;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.transformation.FilteredList;
import ridiculous.AppData;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class AddHeadVM extends AddBaseVM{
    public FilteredList<ControlHead> list;
    public Head head;
    public BooleanBinding nameExists;
    public StringProperty nameErrorProperty;

    public AddHeadVM() {
        head = new Head();
        list = new FilteredList<>(AppData.controlHeads);
        nameErrorProperty = new SimpleStringProperty("");
        nameExists = new BooleanBinding() {
            {
                bind(head.controlIdProperty());
                bind(head.nameProperty());
            }
            @Override
            protected boolean computeValue() {
                if(head.getName().isEmpty()) {
                    nameErrorProperty.set("is required");
                    return true;
                }
                var matched = AppData.heads.stream().anyMatch(x ->
                        x.getControlId() == head.getControlId()
                        && x.getName().equalsIgnoreCase(head.getName()));
                nameErrorProperty.set(matched? "exists" : "");
                return matched;
            }
        };
    }

    @Override
    protected int function() {
        return Function.AddHead.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var nameBytes = (head.getName() + '\0').getBytes(StandardCharsets.US_ASCII);
        var descBytes = (head.getDescription() + '\0').getBytes(StandardCharsets.US_ASCII);

        return ByteBuffer.allocate(8 + nameBytes.length + descBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(head.getId())
                .putInt(head.getControlId())
                .put(nameBytes)
                .put(descBytes);
    }

    @Override
    protected void resetObject() {
        head.setName("");
        head.setDescription("");
    }
}
