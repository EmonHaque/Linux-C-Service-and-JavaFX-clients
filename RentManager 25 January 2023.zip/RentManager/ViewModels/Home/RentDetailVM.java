package ViewModels.Home;

import Models.DepositDueRent;
import Models.TenantAreaSeries;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import ridiculous.AppData;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class RentDetailVM {
    private int selectedPlot;
    public ObjectProperty<List<TenantAreaSeries>> dataProperty;
    public IntegerProperty tenantsProperty, spacesProperty;
    public StringProperty plotProperty;

    public RentDetailVM() {
        dataProperty = new SimpleObjectProperty<>();
        tenantsProperty = new SimpleIntegerProperty();
        spacesProperty = new SimpleIntegerProperty();
        plotProperty = new SimpleStringProperty("");

        RentVM.selectedPlot.addListener(this::onPlotChanged);
        RentVM.depositDueRentList.addListener(o -> reset());
        if (RentVM.selectedPlot.get() > 0) {
            onPlotChanged(null, null, RentVM.selectedPlot.get());
        }
    }

    private void onPlotChanged(ObservableValue<?> o, Number ov, Number nv) {
        selectedPlot = nv.intValue();
        reset();
    }


    private void reset() {
        if (selectedPlot <= 0) return;

        var list = RentVM.depositDueRentList.get().stream().filter(x -> x.getPlotId() == selectedPlot).toList();
        var tenants = list.stream().mapToInt(DepositDueRent::getTenantId).distinct().count();
        var series = new ArrayList<TenantAreaSeries>();

        for (var point : list) {
            var l = AppData.leases.stream().filter(x -> x.getPlotId() == point.getPlotId()
                    && x.getSpaceId() == point.getSpaceId()
                    && x.getTenantId() == point.getTenantId()
                    && !x.isIsExpired()
            ).findFirst();

            if (l.isEmpty()) continue;
            var lease = l.get();

            var s = new TenantAreaSeries() {{
                setSpace(AppData.spaces.stream().filter(x -> x.getId() == point.getSpaceId()).findFirst().get().getName());
                setTenant(AppData.tenants.stream().filter(x -> x.getId() == point.getTenantId()).findFirst().get().getName());
                setFrom(lease.dateStartProperty().get().format(DateTimeFormatter.ofPattern("dd MMMM yyyy")));
                setAmount(point.getAmount());
            }};
            series.add(s);
        }

        plotProperty.set(AppData.plots.stream().filter(x -> x.getId() == selectedPlot).findFirst().get().getName());
        dataProperty.set(series);
        tenantsProperty.set((int) tenants);
        spacesProperty.set(list.size());
    }
}
