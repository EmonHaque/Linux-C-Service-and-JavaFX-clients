package Views.Add;

import Models.Tenant;
import ViewModels.Add.AddTenantVM;
import abstracts.View;
import controls.buttons.CommandButton;
import controls.texts.TextBox;
import controls.texts.TextBoxMultiLine;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import skinned.ExtendedScrollPane;

public class AddTenant extends AddBase {
    private AddTenantVM vm;
    private TextBox name, father, mother, husband, nid, phone;
    private TextBoxMultiLine address;

    @Override
    protected String getHeader() {
        return "Tenant";
    }

    @Override
    protected Node getUI() {
        viewModel =  vm = new AddTenantVM();
        name = new TextBox("Name", Icons.Tenant, true);
        father = new TextBox("Father", Icons.Father, true);
        mother = new TextBox("Mother", Icons.Mother, false);
        husband = new TextBox("Husband", Icons.Husband, false);
        address = new TextBoxMultiLine("Address", Icons.Description, true){{ setMaxHeight(100);}};
        nid = new TextBox("NID", Icons.ID, false);
        phone = new TextBox("Phone", Icons.Mobile, true);

        var box = new VBox(name, father, mother, husband, address, nid, phone){{
            setSpacing(5);
            setAlignment(Pos.CENTER_RIGHT);
        }};
        var scroll = new ExtendedScrollPane(box){{
            setFitToWidth(true);
            setPadding(new Insets(0, 5, 0, 0));
        }};
        BorderPane.setMargin(scroll, new Insets(5,0,0,0));
        return scroll;
    }

    @Override
    protected void bind(){
        name.textProperty().bindBidirectional(vm.tenant.nameProperty());
        name.errorProperty().bind(vm.nameErrorProperty);
        father.textProperty().bindBidirectional(vm.tenant.fatherProperty());
        mother.textProperty().bindBidirectional(vm.tenant.motherProperty());
        husband.textProperty().bindBidirectional(vm.tenant.husbandProperty());
        address.textProperty().bindBidirectional(vm.tenant.addressProperty());
        nid.textProperty().bindBidirectional(vm.tenant.nidProperty());
        phone.textProperty().bindBidirectional(vm.tenant.contactNoProperty());

        add.disableProperty().bind(vm.nameExists
                .or(father.isEmpty())
                .or(address.isEmpty())
                .or(phone.isEmpty())
        );
    }
}
