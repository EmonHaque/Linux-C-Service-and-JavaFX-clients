package Views;

import Views.Transaction.BulkRent;
import Views.Transaction.Irregular;
import Views.Transaction.Regular;
import abstracts.View;
import abstracts.ViewContainer;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.util.ArrayList;
import java.util.List;

public class TransactionView extends View {
    private Regular regular;
    private BulkRent bulk;

    @Override
    protected String getIcon() {
        return Icons.Transact;
    }

    @Override
    protected String getTip() {
        return "Transaction";
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public List<View> initialViews() {
        bulk = new BulkRent();
        regular = new Regular();

        super.views = new ArrayList<>();
        views.add(bulk);
        views.add(regular);

        return views;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        var container = new ViewContainer(){{
            addView(regular);
            addView(new Irregular());
        }};
        setCenter(new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setPercentWidth(35);}},
                    new ColumnConstraints(){{ setPercentWidth(65);}}
            );
            getRowConstraints().add(new RowConstraints(){{ setPercentHeight(100);}});
            add(bulk, 0, 0);
            add(container, 1, 0);
            setMargin(bulk, new Insets(Constants.CardMargin,0,Constants.CardMargin, Constants.CardMargin));
        }});
    }
}
