package trees;

import Models.TransactionEditable;
import abstracts.WrapTreeCellBase;
import controls.SVGIconRegion;
import controls.texts.HiTexts;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;
import skinned.ExtendedTreeView;

import java.util.List;

public class EditTransactionTree extends ExtendedTreeView<TransactionEditable> {
    private boolean isClearing;
    public final BooleanProperty isExpandedProperty;
    public final ObjectProperty<TransactionEditable> selectedItem;

    public EditTransactionTree(ObservableList<TransactionEditable> list, StringProperty query) {
        setRoot(new TreeItem<>());
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new TransactionCell(query));
        list.addListener(this::onItemsChanged);

        isExpandedProperty = new SimpleBooleanProperty();
        selectedItem = new SimpleObjectProperty<>();
        isExpandedProperty.addListener(this::onIsExpandedChanged);
        getSelectionModel().selectedItemProperty().addListener(this::onSelectionChanged);
    }

    private void onSelectionChanged(Observable o, TreeItem<TransactionEditable> ov, TreeItem<TransactionEditable> nv) {
        if(isClearing) return;
        if (nv == null) selectedItem.set(null);
        else if (getTreeItemLevel(nv) == 1) selectedItem.set(null);
        else selectedItem.set(nv.getValue());
    }

    private void onIsExpandedChanged(ObservableValue<?> o, boolean ov, boolean nv) {
        for (var plot : getRoot().getChildren()) {
            plot.setExpanded(nv);
        }
    }

    private void onItemsChanged(ListChangeListener.Change<? extends TransactionEditable> change) {
        isClearing = true;
        getSelectionModel().clearSelection();
        isClearing = false;

        // why while?
        while (change.next()) {
            if (change.wasAdded()) {
                if (change.getRemovedSize() > 0) {
                    removeItems((List<TransactionEditable>) change.getRemoved());
                }
                addItems((List<TransactionEditable>) change.getAddedSubList());
            }
            else if (change.wasRemoved()) {
                removeItems((List<TransactionEditable>) change.getRemoved());
            }
        }
        if (selectedItem.get() != null) {
            boolean found = false;
            for (var branch : getRoot().getChildren()) {
                for (var leaf : branch.getChildren()) {
                    if (!leaf.getValue().equals(selectedItem.get())) continue;
                    found = true;
                    getSelectionModel().select(leaf);
                    break;
                }
                if(found) break;
            }
        }
    }

    private void removeItems(List<TransactionEditable> list) {
        for (var transaction : list) {
            TreeItem<TransactionEditable> plot = null;
            for (var tree : getRoot().getChildren()) {
                if (tree.getValue().getPlotName().equals(transaction.getPlotName())) {
                    plot = tree;
                    plot.getValue().setAmount(plot.getValue().getAmount() - transaction.getAmount());
                    break;
                }
            }
            TreeItem<TransactionEditable> leaf = null;
            for (var item : plot.getChildren()) {
                if (item.getValue().getId() == transaction.getId()) {
                    leaf = item;
                    break;
                }
            }
            plot.getChildren().remove(leaf);
            if (plot.getChildren().size() == 0) {
                getRoot().getChildren().remove(plot);
            }
        }
    }

    private void addItems(List<TransactionEditable> list) {
        for (var transaction : list) {
            var hasIt = false;
            TreeItem<TransactionEditable> item = null;
            for (var tree : getRoot().getChildren()) {
                if (tree.getValue().getPlotName().equals(transaction.getPlotName())) {
                    item = tree;
                    item.getValue().setAmount(item.getValue().getAmount() + transaction.getAmount());
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                item = new TreeItem<>(new TransactionEditable() {{
                    setPlotName(transaction.getPlotName());
                    setAmount(transaction.getAmount());
                }});
                item.setExpanded(true);
                getRoot().getChildren().add(item);
            }
            var leaf = new TreeItem<>(transaction);
            item.getChildren().add(leaf);
        }
    }

    private class TransactionCell extends WrapTreeCellBase<TransactionEditable> {
        private HiTexts flow;
        private Text space, tenant, control, amount;
        private SVGIconRegion icon;
        private final StringProperty query;
        private ColumnConstraints firstColumn;

        public TransactionCell(StringProperty query) {
            this.query = query;
        }

        @Override
        protected void initializeUI() {
            space = new Text() {{setFill(Color.WHITE);}};
            tenant = new Text() {{setFill(Color.WHITE);}};
            control = new Text() {{
                setFill(Color.GRAY);
                setFont(Font.font(null, FontPosture.ITALIC, -1));
            }};
            amount = new Text() {{setFill(Color.WHITE);}};

            flow = new HiTexts(space, tenant, control);
            icon = new SVGIconRegion(Icons.Cash);

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(16) {{setHalignment(HPos.CENTER);}}
                );
                add(flow, 0, 0);
                add(amount, 1, 0);
                add(icon, 2, 0);
            }};
        }

        @Override
        protected void resetValues(TransactionEditable oldValue) {
            oldValue.isCashProperty().removeListener(this::onIsCashChanged);

            space.setFont(Constants.Normal);
            amount.setFont(Constants.Normal);

            flow.queryProperty().unbind();
            flow.queryProperty().set("");
        }

        @Override
        protected void setValues(TransactionEditable newValue) {
            if (level == 1) {
                GridPane.setColumnSpan(amount, 2);
                control.textProperty().unbind();
                control.setText("");

                space.textProperty().bind(newValue.plotNameProperty().concat(" ("));
                tenant.textProperty().bind(Bindings.size(item.getChildren()).asString().concat(")"));

                space.setFont(Constants.Bold);
                amount.setFont(Constants.Bold);
                icon.setVisible(false);
            }
            else {
                GridPane.setColumnSpan(amount, 1);
                space.textProperty().bind(newValue.spaceNameProperty().concat(" - "));
                tenant.textProperty().bind(newValue.tenantNameProperty().concat(" "));
                control.textProperty().bind(newValue.controlNameProperty());
                flow.queryProperty().bind(query);

                space.setFont(Constants.Normal);
                amount.setFont(Constants.Normal);
                icon.setVisible(true);
                setIcon(newValue.getIsCash());
                newValue.isCashProperty().addListener(this::onIsCashChanged);
            }
            amount.textProperty().bind(newValue.amountProperty().asString("%,d"));
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 80 - 16;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            flow.setPrefWidth(remainder);
            return flow.prefHeight(remainder);
        }

        private void setIcon(int value) {
            switch (value) {
                case 0 -> {
                    icon.setContent(Icons.Cash);
                    icon.setFill(Color.LIGHTGREEN);
                }
                case 1 -> {
                    icon.setContent(Icons.NonCash);
                    icon.setFill(Color.LIGHTCORAL);
                }
                case 2 -> {
                    icon.setContent(Icons.Mobile);
                    icon.setFill(Color.CORNFLOWERBLUE);
                }
            }
        }

        private void onIsCashChanged(ObservableValue<?> o, Number ov, Number nv) {
            setIcon(nv.intValue());
        }
    }
}