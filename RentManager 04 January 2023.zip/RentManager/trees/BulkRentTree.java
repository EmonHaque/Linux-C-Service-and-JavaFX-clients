package trees;

import Models.Lease;
import controls.SVGRegion;
import controls.texts.HiTexts;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import skinned.ExtendedTreeView;

import java.util.Comparator;
import java.util.List;

public class BulkRentTree extends ExtendedTreeView<Lease> {
    private final TreeItem<Lease> root;
    public ObservableList<Lease> selectedItems;

    public BulkRentTree(FilteredList<Lease> leases, StringProperty query) {
        root = new TreeItem<>();
        addItems(leases);
        setRoot(root);
        setShowRoot(false);
        setCellFactory(v -> new LeaseCell(query));
        selectedItems = FXCollections.observableArrayList();
        getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        getSelectionModel().getSelectedItems().addListener(this::onSelectionChanged);
        leases.addListener(this::onItemsChanged);
    }

    private void onSelectionChanged(ListChangeListener.Change<? extends TreeItem<Lease>> change) {
        // all levels can be selected
        // if you setDisable(true) in TreeCell, you can't collapse/expand branch
        // that's an issue
        while (change.next()) {
            if (change.wasAdded()) {
                if (change.getRemovedSize() > 0) {
                    for (var tree : change.getRemoved())
                        selectedItems.remove(tree.getValue());
                }
                selectedItems.add(change.getAddedSubList().get(0).getValue());
            }
            else if (change.wasRemoved()) {
                selectedItems.remove(change.getRemoved().get(0).getValue());
            }
        }
    }

    private void onItemsChanged(ListChangeListener.Change<? extends Lease> change) {
        while (change.next()) {
            if (change.wasAdded()) {
                if (change.getRemovedSize() > 0) {
                    removeItems((List<Lease>) change.getRemoved());
                }
                addItems((List<Lease>) change.getAddedSubList());
            }
            else if (change.wasRemoved()) {
                removeItems((List<Lease>) change.getRemoved());
            }
        }
    }

    private void addItems(List<Lease> leases) {
        for (var lease : leases) {
            var hasIt = false;
            TreeItem<Lease> plot = null;
            for (var item : root.getChildren()) {
                if (item.getValue().getPlotName().equals(lease.getPlotName())) {
                    plot = item;
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                plot = new TreeItem<>(lease);
                //plot = new TreeItem<>(new Lease() {{setPlotName(lease.getPlotName());}});
                plot.setExpanded(true);
                root.getChildren().add(plot);
            }
            var leaf = new TreeItem<>(lease);
            plot.getChildren().add(leaf);
        }
    }

    private void removeItems(List<Lease> leases) {
        for (var lease : leases) {
            TreeItem<Lease> plot = null;
            TreeItem<Lease> leaf = null;
            var found = false;
            for (var group : root.getChildren()) {
                for (var item : group.getChildren()) {
                    if (!item.getValue().equals(lease)) continue;
                    leaf = item;
                    found = true;
                    break;
                }
                if (found) {
                    plot = group;
                    break;
                }
            }
            plot.getChildren().remove(leaf);
            if (plot.getChildren().size() == 0) root.getChildren().remove(plot);
        }
    }


    private class LeaseCell extends TreeCell<Lease> {
        private HiTexts hiContent;
        private Text space, tenant;
        private SVGRegion disclosureIcon;
        private Popup toolTip;
        private final StringProperty query;

        public LeaseCell(StringProperty query) {
            this.query = query;
            setPrefWidth(0);
            setPadding(new Insets(2.5, 0, 2.5, 0));
            setBackground(null);

            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            initializeUI();
            itemProperty().addListener(this::onItemChanged);

//            flow.addEventHandler(MouseEvent.MOUSE_ENTERED, this::onMouseEnter);
//            flow.addEventHandler(MouseEvent.MOUSE_EXITED, this::onMouseExit);
        }

        private void initializeUI() {
            disclosureIcon = new SVGRegion(Icons.PlusCircle);
            var disclosurePane = new StackPane(disclosureIcon);
            disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
            setDisclosureNode(disclosurePane);

            space = new Text() {{setFill(Color.WHITE);}};
            tenant = new Text() {{setFill(Color.WHITE);}};
            hiContent = new HiTexts(space, tenant);

            toolTip = new Popup();
            GridPane popGrid = new GridPane() {{
                setPadding(new Insets(10));
                setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, new CornerRadii(5), null)));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25))));
            }};
            popGrid.add(new Text("Hello") {{setFill(Color.WHITE);}}, 0, 0);
            toolTip.getContent().add(popGrid);
        }

//        private void onMouseEnter(MouseEvent e) {
//            if(!isDisabled() && !isSelected()){
//                setBackground(Background.fill(Constants.BackgroundColorLight));
//            }
//            if(!isDisabled())
//                toolTip.show(flow, e.getScreenX(), e.getScreenY());
//        }
//
//        private void onMouseExit(MouseEvent e) {
//            toolTip.hide();
//            if(!isSelected())
//                setBackground(null);
//        }

        private void onItemChanged(ObservableValue<?> o, Lease ov, Lease nv) {
            if (ov != null) {
                hiContent.queryProperty().unbind();
                hiContent.queryProperty().set("");

                disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
                disclosureIcon.setOnMouseEntered(null);
                disclosureIcon.setOnMouseExited(null);
            }
            if (nv != null) {
                var item = getTreeItem();
                var level = getTreeItemLevel(item);

                disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
                disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
                disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));

                if (level == 1) {
                    space.textProperty().bind(nv.plotNameProperty().concat(" ("));
                    tenant.textProperty().bind(Bindings.size(item.getChildren()).asString().concat(")"));
                    space.setFont(Font.font(null, FontWeight.BOLD, -1));
                    tenant.setFont(Font.font(null, FontPosture.REGULAR, -1));
                }
                else if (level == 2) {
                    space.textProperty().bind(nv.spaceNameProperty().concat(" - "));
                    tenant.textProperty().bind(nv.tenantNameProperty());
                    space.setFont(Font.font(null, FontWeight.NORMAL, -1));
                    tenant.setFont(Font.font(null, FontPosture.ITALIC, -1));
                }
                hiContent.queryProperty().bind(query);
            }
        }

        @Override
        protected void updateItem(Lease item, boolean empty) {
            super.updateItem(item, empty);
            if (isEmpty()) {
                setBackground(null);
                setGraphic(null);
                return;
            }
            setGraphic(hiContent);
            if (getTreeItemLevel(getTreeItem()) == 2) {
                setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
            }
        }
    }
}
