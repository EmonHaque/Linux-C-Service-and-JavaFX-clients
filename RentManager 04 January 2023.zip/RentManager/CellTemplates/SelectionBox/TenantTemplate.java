package CellTemplates.SelectionBox;

import Models.Tenant;
import abstracts.ListCellBase;
import controls.texts.HiText;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class TenantTemplate extends ListCellBase<Tenant> {
    private BorderPane root;
    private HiText name;
    private Text phone;
    private final StringProperty query;

    public TenantTemplate(StringProperty query) {
        super();
        this.query = query;
        setPadding(new Insets(5));
    }

    @Override
    protected void initializeUI() {
        name = new HiText();
        phone = new Text();
        root = new BorderPane() {{
            setCenter(name);
            setRight(phone);
            setAlignment(name, Pos.CENTER_LEFT);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Tenant ov, Tenant nv) {
        if (ov != null) {
            name.queryProperty().unbind();
            name.queryProperty().set("");
        }
        if (nv == null) return;

        name.textProperty().bind(nv.nameProperty());
        phone.textProperty().bind(nv.contactNoProperty());
        name.queryProperty().bind(query);

        if (nv.isHasLeft()) {
            name.setFill(Color.GRAY);
            phone.setFill(Color.GRAY);
        }
        else {
            name.setFill(Color.WHITE);
            phone.setFill(Color.WHITE);
        }
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
