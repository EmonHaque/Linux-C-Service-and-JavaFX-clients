package CellTemplates.SelectionBox;

import Models.SpaceTransaction;
import abstracts.ListCellBase;
import controls.texts.HiText;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class TransactionSpaceTemplate extends ListCellBase<SpaceTransaction> {
    private BorderPane root;
    private HiText name;
    private Text date;
    private final StringProperty query;

    public TransactionSpaceTemplate(StringProperty query) {
        super();
        this.query = query;
        setPadding(new Insets(5));
    }

    @Override
    protected void initializeUI() {
        name = new HiText();
        date = new Text();
        root = new BorderPane() {{
            setCenter(name);
            setRight(date);
            setAlignment(name, Pos.CENTER_LEFT);
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, SpaceTransaction ov, SpaceTransaction nv) {
        if (ov != null) {
            name.queryProperty().unbind();
            name.queryProperty().set("");
        }
        if (nv == null) return;

        name.textProperty().bind(nv.nameProperty());
        date.textProperty().bind(nv.startDateProperty());
        if (nv.getIsExpired()) {
            name.setFill(Color.GRAY);
            date.setFill(Color.GRAY);
        }
        else {
            name.setFill(Color.WHITE);
            date.setFill(Color.WHITE);
        }
        name.queryProperty().bind(query);
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
