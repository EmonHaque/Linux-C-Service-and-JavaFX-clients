package CellTemplates.ListView;

import Models.Lease;
import Models.Space;
import abstracts.ListCellBase;
import controls.texts.HiText;
import javafx.beans.binding.Bindings;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import ridiculous.AppData;

import java.time.format.DateTimeFormatter;
import java.util.Comparator;

public class EditSpaceTemplate extends ListCellBase<Space> {
    private BorderPane root;
    private Text vacatedOn;
    private HiText name;

    private final StringProperty query;
    private final IntegerProperty state;

    public EditSpaceTemplate(StringProperty query, IntegerProperty state) {
        super();
        this.query = query;
        this.state = state;
    }

    @Override
    protected void initializeUI() {
        name = new HiText();
        vacatedOn = new Text("");
        root = new BorderPane() {{
            setCenter(name);
            setRight(vacatedOn);
        }};
        BorderPane.setMargin(vacatedOn, new Insets(0, 5, 0, 5));
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Space ov, Space nv) {
        if(ov != null){
            name.queryProperty().unbind();
            name.queryProperty().set("");
        }
        if (nv == null) return;
        if (nv.isIsVacant()) {
            var leases = AppData.leases.stream().filter(x -> x.getSpaceId() == nv.getId()).toList();
            if (leases.size() == 0) {
                vacatedOn.setText("since beginning");
            }
            else {
                var date = leases.stream().max(Comparator.comparing(Lease::getDateEnd)).get().getDateEnd();
                vacatedOn.setText("since " + date.format(DateTimeFormatter.ofPattern("dd, MMMM, yyyy")));
            }
        }
        else vacatedOn.setText("");
        name.textProperty().bind(nv.nameProperty());
        name.queryProperty().bind(query);

        var fillBinding = Bindings.createObjectBinding(() -> {
            if (state.get() != 2) return Color.WHITE;
            return nv.isIsVacant() ? Color.GRAY : Color.WHITE;
        }, state, nv.isVacantProperty());

        name.fillProperty().bind(fillBinding);
        vacatedOn.fillProperty().bind(fillBinding);
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
