import Views.*;
import controls.MainPanel;
import controls.Window;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import ridiculous.AppData;

public class RentManager extends ClientApp {
    public static AppData appData;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    protected Image getIcon() {
        return new Image("resources/images/icon.png");
    }

    @Override
    protected String getTitle() {
        return "Rent Manager";
    }

    @Override
    protected void initializeAppData() {
        appData = new AppData(loading, stage);
    }

    @Override
    protected Window getWindow(Stage stage) {
        var panel = new MainPanel(stage);
        panel.addView(new HomeView());
        panel.addView(new AddView());
        panel.addView(new EditView());
        panel.addView(new TransactionView());
        panel.addView(new ReportView());
        panel.setTitle(getTitle());

        var window = new Window(stage, getTitle());
        window.setContent(panel);
        return window;
    }
}
