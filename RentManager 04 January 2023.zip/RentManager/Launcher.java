public class Launcher {
    public static void main(String[] args) {
        RentManager.main(args);
    }
}
