package Views.Add;

import Models.Plot;
import Models.Space;
import ViewModels.Add.AddSpaceVM;
import abstracts.View;
import controls.SelectionBox;
import controls.buttons.CommandButton;
import controls.texts.TextBox;
import controls.texts.TextBoxMultiLine;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class AddSpace extends AddBase {
    private AddSpaceVM vm;
    private SelectionBox<Plot> plot;
    private TextBox name;
    private TextBoxMultiLine description;

    @Override
    protected String getHeader() {
        return "Space";
    }


    @Override
    protected Node getUI() {
        viewModel = vm = new AddSpaceVM();
        plot = new SelectionBox<>("Plot", Icons.Plot, vm.list, true);
        plot.setSelectAddedItem(true);
        name = new TextBox("Name", Icons.Head, true);
        description = new TextBoxMultiLine("Description", Icons.Description, true);

        return new VBox(plot, name, description){{
            setSpacing(5);
            setPadding(new Insets(5, 0, 0, 0));
            setAlignment(Pos.CENTER_RIGHT);
            setVgrow(description, Priority.ALWAYS);
        }};
    }

    @Override
    protected void bind(){
        vm.space.plotIdProperty().bind(plot.selectedValueProperty());
        name.textProperty().bindBidirectional(vm.space.nameProperty());
        name.errorProperty().bind(vm.nameErrorProperty);
        description.textProperty().bindBidirectional(vm.space.descriptionProperty());

        add.disableProperty().bind(vm.nameExists.or(plot.isEmpty()).or(description.isEmpty()));
    }
}
