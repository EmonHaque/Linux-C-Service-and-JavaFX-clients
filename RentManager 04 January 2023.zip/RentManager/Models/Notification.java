package Models;

public class Notification {
}
