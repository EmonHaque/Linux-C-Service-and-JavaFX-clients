package Models;

import interfaces.IReturnNameAndId;
import javafx.beans.property.*;

public class SpaceTransaction extends IReturnNameAndId<SpaceTransaction> {
    private IntegerProperty spaceId;
    private StringProperty spaceName, startDate;

    private int plotId;
    private boolean isExpired;

    public SpaceTransaction(int plotId, int spaceId, String spaceName, String startDate, boolean isExpired) {
        this.plotId = plotId;
        this.spaceId = new SimpleIntegerProperty(spaceId);
        this.spaceName = new SimpleStringProperty(spaceName);
        this.startDate = new SimpleStringProperty(startDate);
        this.isExpired = isExpired;
    }

    @Override
    public String getName() {
        return spaceName.get();
    }

    public int getPlotId(){ return plotId; }

    public boolean getIsExpired(){ return isExpired; }

    public String getStartDate(){ return startDate.get();}

    public StringProperty startDateProperty(){ return startDate; }

    @Override
    public StringProperty nameProperty() {
        return spaceName;
    }

    @Override
    public int getId() {
        return spaceId.get();
    }

}
