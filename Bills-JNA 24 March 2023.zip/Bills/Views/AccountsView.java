package Views;

import Views.Accounts.*;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.util.ArrayList;
import java.util.List;

public class AccountsView extends View {
    private final View accounts, accountsEdit, heads, departments, mobiles;

    public AccountsView() {
        accounts = new Accounts();
        accountsEdit = new AccountEdit();
        heads = new Heads();
        departments = new Departments();
        mobiles = new Mobiles();
    }

    @Override
    protected String getIcon() {
        return Icons.ControlHead;
    }

    @Override
    protected String getTip() {
        return "Accounts";
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public List<View> initialViews() {
        super.views = new ArrayList<>();
        views.add(accounts);
        views.add(accountsEdit);
        views.add(mobiles);
        views.add(heads);
        views.add(departments);
        return super.views;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        setCenter(new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setPercentWidth(50);}},
                    new ColumnConstraints(){{ setPercentWidth(25);}},
                    new ColumnConstraints(){{ setPercentWidth(25);}}
            );
            getRowConstraints().addAll(
                    new RowConstraints(){{ setPercentHeight(50);}},
                    new RowConstraints(){{ setPercentHeight(50);}}
            );
            add(accounts, 0, 0, 1, 2);
            add(mobiles, 1, 0);
            add(accountsEdit, 1, 1);
            add(heads, 2, 0);
            add(departments, 2, 1);

            setVgap(Constants.CardMargin);
            setHgap(Constants.CardMargin);
            setPadding(new Insets(Constants.CardMargin));
        }});
    }

}
