package Model;

public class AccountPaymentSummary {
    private String accountNo, accountHolder, address;
    private double payment;

    public AccountPaymentSummary(String accountNo, String accountHolder,String address, double payment) {
        this.accountNo = accountNo;
        this.accountHolder = accountHolder;
        this.address = address;
        this.payment = payment;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountHolder() {
        return accountHolder;
    }

    public void setAccountHolder(String accountHolder) {
        this.accountHolder = accountHolder;
    }

    public double getPayment() {
        return payment;
    }

    public void setPayment(double payment) {
        this.payment = payment;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
