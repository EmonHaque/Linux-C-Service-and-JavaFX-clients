package ViewModels.Accounts;

import Enums.Function;
import Model.Account;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.concurrent.Task;
import ridiculuous.Channels;
import ridiculuous.Request;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class AccountEditVM {
    public final static ObjectProperty<Account> selected;
    static {
        selected = new SimpleObjectProperty<>();
    }
    public BooleanProperty isOnEdit, isRunning;
    public ObjectProperty<Account> edited;
    public StringProperty status;

    public AccountEditVM() {
        isOnEdit = new SimpleBooleanProperty();
        isRunning = new SimpleBooleanProperty();
        status = new SimpleStringProperty("");
        edited = new SimpleObjectProperty<>();
        isOnEdit.addListener(this::onIsOnEditChange);
    }

    private void onIsOnEditChange(Observable o, boolean ov, boolean nv){
        if(!nv) return;

        var s = selected.get();
        var clone = new Account(){{
            setId(s.getId());
            setDepartmentId(s.getDepartmentId());
            setName(s.getName());
            setHolder(s.getHolder());
            setAddress(s.getAddress());
            setIsWrong(s.isIsWrong());
        }};
        edited.set(clone);
    }

    public void save(){
        var task = new EditTask();
        status.bind(task.messageProperty());
        isRunning.bind(task.runningProperty());
        new Thread(task){{ setDaemon(true);}}.start();
    }

    private class EditTask extends Task<Void>{

        @Override
        protected Void call() throws Exception {
            var e = edited.get();
            var nameBytes = (e.getName().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
            var holderBytes = (e.getHolder().trim() + '\0').getBytes(StandardCharsets.UTF_8);
            var addressBytes = (e.getAddress().trim() + '\0').getBytes(StandardCharsets.UTF_8);
            var buffer = ByteBuffer.allocate(9 + nameBytes.length + holderBytes.length + addressBytes.length)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .putInt(e.getId())
                    .putInt(e.getDepartmentId())
                    .put(e.isIsWrong() ? (byte)1 : 0)
                    .put(nameBytes)
                    .put(holderBytes)
                    .put(addressBytes);

            var request = new Request(Function.EditAccount.ordinal(), buffer);
            var response = Channels.getInstance().getResponse(request).get();
            if (response.isSuccess()) {
                var isSuccess = response.getPacket()[0] == 1;
                var message = new String(response.getPacket(), 1, response.getPacket().length - 1, StandardCharsets.US_ASCII);
                updateMessage(message);
                Thread.sleep(500);
            }
            else {
                updateMessage("service down");
                Thread.sleep(500);
            }
            return null;
        }
    }
}
