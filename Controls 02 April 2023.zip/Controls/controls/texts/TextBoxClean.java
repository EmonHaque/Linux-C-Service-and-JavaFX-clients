package controls.texts;

import javafx.beans.binding.BooleanBinding;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.scene.control.TextField;
import javafx.scene.input.ContextMenuEvent;
import skins.ExtendedTextFieldSkin;

public class TextBoxClean extends TextField {
    
    public TextBoxClean() {
        setPadding(new Insets(0));
        setSkin(new ExtendedTextFieldSkin(this));
        setContextMenu(null);
        addEventFilter(ContextMenuEvent.CONTEXT_MENU_REQUESTED, Event::consume);
    }

    public BooleanBinding isEmpty() {return textProperty().isEmpty();}
}
