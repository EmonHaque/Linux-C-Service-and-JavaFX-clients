package controls;

import javafx.scene.layout.Background;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;

public class SVGIcon extends Region {
    private double size;
    private final SVGPath icon;

    public SVGIcon(String path) {
        size = 12;
        setMinSize(size, size);
        setMaxSize(size, size);
        setPrefSize(size, size);
        icon = new SVGPath();
        icon.setContent(path);
        icon.fillProperty().addListener(o -> setBackground(Background.fill(icon.getFill())));
        icon.setFill(Color.WHITE);
        setShape(icon);
    }

    public SVGIcon(String path, double size) {
        this(path);
        this.size = size;
        setMinSize(size, size);
        setMaxSize(size, size);
        setPrefSize(size, size);
    }

    public void setContent(String path){
        icon.setContent(path);
    }
    public void setFill(Color color){
        icon.setFill(color);
    }
}