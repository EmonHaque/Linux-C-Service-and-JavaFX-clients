package controls.columnstackchart;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;
import model.PinColors;

import java.util.ArrayList;
import java.util.List;

public class ColumnStack extends StackPane {
    private final List<Double> values;
    private final List<Column> columns;
    private final double total;
    private final DoubleProperty pinHeight;
    private boolean isLoaded;

    public ColumnStack(List<Double> values, List<PinColors> colors) {
        this.values = values;
        columns = new ArrayList<>();
        total = values.stream().mapToDouble(s -> s).sum();
        for (int i = 0; i < values.size(); i++) {
            boolean isRound = i == values.size() - 1;
            var color = colors.get(i);
            var rect = new Column(color.getNormal(), color.getHighlight(), isRound, false);
            getChildren().add(rect);
            rect.setManaged(false);
            rect.setMouseTransparent(true);
            columns.add(rect);
        }
        pinHeight = new SimpleDoubleProperty(0);
    }

    public void makePin(double width, double height) {
        if (!isLoaded) {
            isLoaded = true;
            pinHeight.addListener((o, ov, nv) -> setHeight(nv.doubleValue()));
            var key = new KeyValue(pinHeight, height, Interpolator.EASE_IN);
            var frame = new KeyFrame(Duration.millis(500), key);
            var anim = new Timeline(frame);
            anim.setDelay(Duration.millis(500));

            anim.play();
            anim.setOnFinished(e -> {
                setClip(null);
                anim.setOnFinished(null);
            });
        }
    }

    public void highlightColor() {
        for (var column : columns)
            column.highlightColor();
    }

    public void normalColor() {
        for (var column : columns)
            column.normalColor();
    }

    @Override
    protected void layoutChildren() {
        if (pinHeight.get() == 0) return;
        var height = getHeight();
        var width = getWidth();
        double y = 0;
        for (int i = 0; i < values.size(); i++) {
            var h = height / total * values.get(i);
            var pin = (Column) getChildren().get(i);
            pin.setValue(0, y, width, h);
            y += h;
        }
    }
}
