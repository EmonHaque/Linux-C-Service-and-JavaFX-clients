package dialogs;

import abstracts.DialogBase;
import controls.buttons.ActionButton;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;

public class ConfirmDialog extends DialogBase {
    private ActionButton okButton, closeButton;
    public boolean isOk;

    public ConfirmDialog(String title, String message) {
        super();
        titlelabel.setText(title);
        var messageLabel = new Label(message);
        messageLabel.setTextFill(Color.WHITE);
        root.setCenter(messageLabel);

        okButton = new ActionButton(Icons.CheckCircle, 16, "Yes");
        closeButton = new ActionButton(Icons.CloseCircle, 16, "No");
        okButton.setAction(this::confirm);
        closeButton.setAction(this::cancel);
        buttonsPane.getChildren().addAll(okButton, closeButton);
        GridPane.setHgrow(closeButton, Priority.ALWAYS);
        GridPane.setHalignment(closeButton, HPos.LEFT);
        GridPane.setHalignment(closeButton, HPos.RIGHT);
        GridPane.setMargin(okButton, new Insets(5, 0, 5, 5));
        GridPane.setMargin(closeButton, new Insets(5, 5, 5, 0));
    }

    @Override
    public void showDialog(double left, double top, double width, double height) {
        super.showDialog(left, top, width, height);
        showAndWait();
    }

    public void cancel() {
        super.closeDialog();
        isOk = false;
    }

    public void confirm() {
        super.closeDialog();
        isOk = true;
    }
}
