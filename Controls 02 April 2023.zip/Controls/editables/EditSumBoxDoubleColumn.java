package editables;

import controls.SumBoxDoubleColumn;
import javafx.beans.Observable;
import javafx.scene.Node;
import javafx.scene.layout.VBox;

public class EditSumBoxDoubleColumn extends VBox {
    private final SumBoxDoubleColumn sumBox;
    private final Node nonEditable;
    private final EditPane parent;

    public EditSumBoxDoubleColumn(SumBoxDoubleColumn sumBox, Node nonEditable, EditPane parent) {
        this.parent = parent;
        this.sumBox = sumBox;
        this.nonEditable = nonEditable;

        sumBox.managedProperty().bind(sumBox.visibleProperty());
        nonEditable.managedProperty().bind(nonEditable.visibleProperty());
        sumBox.setVisible(false);
        nonEditable.setVisible(true);

        getChildren().addAll(sumBox, nonEditable);
        parent.isOnEditProperty().addListener(this::onIsOnEditChanged);
    }

    private void onIsOnEditChanged(Observable o){
        if (parent.isOnEditProperty().get()){
            nonEditable.setVisible(false);
            sumBox.setVisible(true);
        }
        else {
            sumBox.setVisible(false);
            nonEditable.setVisible(true);
        }
    }
}
