package abstracts;

import controls.SVGRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Skin;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.skin.TreeCellSkin;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;

public abstract class WrapTreeCellBase<T> extends TreeCell<T> {
    private final SVGRegion disclosureIcon;
    private double availableWidth, newHeight;
    private boolean isHeightSet, isLoaded;
    private double indent;

    protected GridPane root;
    protected TreeItem<T> item;
    protected int level;

    public WrapTreeCellBase() {
        setBackground(null);
        setPrefWidth(0);
        setPadding(new Insets(0, Constants.CellPadding, 0, 0));
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

        disclosureIcon = new SVGRegion(Icons.PlusCircle){{
            setTranslateY(5);
            //setTranslateY(Constants.CellPadding + Screen.getPrimary().getDpi() / 96 * Screen.getPrimary().getOutputScaleY());
        }};
        setDisclosureNode(disclosureIcon);
        initializeUI();
        root.setManaged(false);
        root.setPadding(new Insets(Constants.CellPadding, 0, Constants.CellPadding, 0));
        itemProperty().addListener(this::onItemChanged);

        addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
            if (e.getClickCount() % 2 == 0 && e.getButton().equals(MouseButton.PRIMARY))
                e.consume();
        });
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        var skin = (TreeCellSkin<?>) super.createDefaultSkin();
        skin.setIndent(12);
        return skin;
    }

    protected abstract void initializeUI();

    protected abstract void resetValues(T oldValue);

    protected abstract void setValues(T newValue);

    protected abstract double setWrapWidthAndReturnDesiredHeight();

    protected double getAvailableWidth() {return availableWidth;}

    private void onItemChanged(Observable o, T ov, T nv) {
        if (ov != null) {
            resetValues(ov);
            disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
            disclosureIcon.setOnMouseEntered(null);
            disclosureIcon.setOnMouseExited(null);
        }
        if (nv != null) {
            item = getTreeItem();
            level = getTreeView().getTreeItemLevel(item);
            disclosureIcon.setContent(item.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
            disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
            disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));
            setValues(nv);
            indent = level * 12 + Constants.CellPadding;
            isHeightSet = false;
        }
    }

    @Override
    protected void updateItem(T item, boolean empty) {
        super.updateItem(item, empty);
        if (isEmpty()) {
            setGraphic(null);
            root.setBackground(null);
        }
        else {
            setGraphic(root);
            root.setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }

    private void rearrange(){
        availableWidth = getWidth() - indent - Constants.CellPadding;
        var desired = setWrapWidthAndReturnDesiredHeight();
        newHeight = desired + 2 * Constants.CellPadding;
        root.resizeRelocate(indent, 0, availableWidth, newHeight);
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if (isEmpty()) return;

        if (!isLoaded) {
            isLoaded = true;
            getTreeView().widthProperty().addListener(o -> {
                rearrange();
                Platform.runLater(() -> {
                    setPrefHeight(newHeight);
                    requestLayout();
                });
            });
            visibleProperty().addListener((o, wasVisible, isVisible) -> {
                if(!wasVisible && isVisible){
                    rearrange();
                    Platform.runLater(() -> setPrefHeight(newHeight));
                }
            });
        }
        if (!isHeightSet) {
            isHeightSet = true;
            rearrange();
            Platform.runLater(() -> setPrefHeight(newHeight));
        }
    }
}
