package abstracts;

import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;

import java.util.List;

public abstract class XYChartBase<T> extends Region {
    private final Group yMajors;
    private final FadeTransition yLabelAnim;
    private final ScaleTransition lineAnim;
    private final StackPane noInfo;
    private InvalidationListener boundListener;

    protected int numLines = 6;
    protected Group xLabels, yLabels;
    protected double startX, min, max, availableHeight, availableWidth, xLabelWidth, yLabelWidth;
    protected List<T> series;

    public ObjectProperty<List<T>> seriesProperty;

    public XYChartBase() {
        yMajors = new Group() {{setManaged(false);}};
        yLabels = new Group() {{setManaged(false);}};
        xLabels = new Group() {{setManaged(false);}};

        for (int i = 0; i < numLines; i++) {
            var line = new Line() {{
                setStroke(Color.GRAY);
                getStrokeDashArray().addAll(5d, 2d);
                setMouseTransparent(true);
                setManaged(false);
            }};
            var label = new Text() {{
                setFill(Color.WHITE);
                setMouseTransparent(true);
                setManaged(false);
            }};

            yMajors.getChildren().add(line);
            yLabels.getChildren().add(label);
        }
        yLabelAnim = new FadeTransition(Duration.millis(500), yLabels);
        lineAnim = new ScaleTransition(Duration.millis(500), yMajors);

        yLabelAnim.setDelay(Duration.millis(500));
        yLabelAnim.setFromValue(0);
        yLabelAnim.setToValue(1);
        lineAnim.setFromY(0);
        lineAnim.setToY(1);

        seriesProperty = new SimpleObjectProperty<>();
        seriesProperty.addListener(this::onSeriesChanged);

        noInfo = new StackPane(){{
            setManaged(false);
            setMouseTransparent(true);
            getChildren().add(new Text("No data\navailable") {{
                setTextAlignment(TextAlignment.CENTER);
                setFill(Color.GRAY);
                setFont(Font.font(null, FontWeight.BOLD, 16));
            }});
        }};
    }

    private void onBoundsChanged(Observable o){
        noInfo.resize(getWidth(), getHeight());
    }

    protected abstract void setMinMaxAndXLabels();

    protected abstract void reset();

    protected void onSeriesChanged(Observable o, List<T> ov, List<T> nv) {
        if(lineAnim.getStatus() == Animation.Status.RUNNING) lineAnim.stop();
        if(yLabelAnim.getStatus() == Animation.Status.RUNNING) yLabelAnim.stop();

        if(boundListener != null)
            layoutBoundsProperty().removeListener(boundListener);

        getChildren().clear();
        if (nv == null || nv.size() == 0) {
            getChildren().add(noInfo);
            noInfo.resize(getWidth(), getHeight());
            boundListener = this::onBoundsChanged;
            layoutBoundsProperty().addListener(boundListener);
            return;
        }

        xLabels.getChildren().clear();
        getChildren().addAll(yMajors, yLabels, xLabels);
        yMajors.setScaleY(0);
        yLabels.setOpacity(0);

        series = nv;
        min = 0;
        max = 0;
        xLabelWidth = 0;

        reset();
        setMinMaxAndXLabels();

        Platform.runLater(() -> {
            lineAnim.play();
            yLabelAnim.play();
        });
    }

    @Override
    protected void layoutChildren() {
        startX = yLabelWidth + 10;
        availableHeight = getHeight() - xLabelWidth;
        availableWidth = getWidth() - startX;

        var vSpace = availableHeight / (numLines - 1);

        double lineY = availableHeight;
        double labelY = lineY - 5;
        for (int i = 0; i < yMajors.getChildren().size(); i++) {
            var text = (Text) yLabels.getChildren().get(i);
            text.setY(labelY);

            var line = (Line) yMajors.getChildren().get(i);
            line.setStartY(lineY);
            line.setEndY(lineY);
            line.setEndX(getWidth());

            lineY -= vSpace;
            labelY -= vSpace;
        }
    }
}
