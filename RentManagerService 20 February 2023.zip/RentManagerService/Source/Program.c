#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

// #include <sys/resource.h>
#include "CommonDefined.h"
#include "CommonStructures.h"
#include "Structures.h"
#include "BlockingQueue.h"
#include "List.h"


pthread_mutex_t criticalReceiver;
byte isRunning;
List receivers;
BlockingQueue requests, newClients;
pthread_t newClientProcessThread;

static int server;
static pthread_mutex_t criticalSender;
static List senders;
static socklen_t addressLength;

extern void InitializeDatabase();
extern void InitializeDispatcher();
extern void InitializeBroadcaster();
extern void ShutdownDatabase();
extern void ShutdownDispatcher();
extern void ShutdownBroadcaster();

static void initialize();
static void acceptClient();
static void *processNewClient(void *);

static void shutDownProgram() {
    if (requests.isWaiting) {
        pthread_cond_signal(&requests.condition);
    }
    if (newClients.isWaiting) {
        pthread_cond_signal(&newClients.condition);
    }
    pthread_mutex_destroy(&criticalSender);
    pthread_mutex_destroy(&criticalReceiver);
    // free resources if required
}
static void onTerminate(int s) {
    isRunning = 0;
    close(server);
    Receiver **lstReceiver = receivers.data;
    for (int i = 0; i < receivers.count; i++) {
        Receiver *receiver = lstReceiver[i];
        shutdown(receiver->socket, SHUT_RDWR);
        close(receiver->socket);
    }

    Sender **lstSender = senders.data;
    for (int i = 0; i < senders.count; i++) {
        shutdown(lstSender[i]->socket, SHUT_RDWR);
        close(lstSender[i]->socket);
    }
}

int main() {
    // const rlim_t kStackSize = 5000 * 1024 * 1024;   // min stack size = 50 MB
    // struct rlimit rl;
    // getrlimit(RLIMIT_STACK, &rl);

    // if you want to gracefully exit your service instead of kill -9
    signal(SIGTERM, onTerminate);
    signal(SIGPIPE, SIG_IGN); // operation fail on closed socket

    initialize();
    acceptClient();

    // free memory in these functions
    shutDownProgram();
    ShutdownDatabase();
    ShutdownDispatcher();
    ShutdownBroadcaster();

    return 0;
}

static void initialize() {
    const char *IP = "127.0.0.1";
    const int PORT = 5557;

    struct sockaddr_in address;
    addressLength = sizeof address;

    address.sin_family = AF_INET;
    address.sin_port = htons(PORT);
    address.sin_addr.s_addr = inet_addr(IP);

    server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int));

    bind(server, &address, addressLength);
    listen(server, SOMAXCONN);
    isRunning = 1;

    pthread_create(&newClientProcessThread, 0, processNewClient, 0);

    receivers.capacity = senders.capacity = 5;
    receivers.count = senders.count = 0;
    receivers.data = malloc(receivers.capacity * SENDER_SIZE);
    senders.data = malloc(senders.capacity * SENDER_SIZE);

    requests.count = 0;
    requests.capacity = 5;
    requests.data = malloc(requests.capacity * POINTER_SIZE);
    pthread_mutex_init(&requests.lock, 0);
    pthread_cond_init(&requests.condition, 0);

    newClients.count = 0;
    newClients.capacity = 10;
    newClients.data = malloc(newClients.capacity * sizeof(NewClient));
    pthread_mutex_init(&newClients.lock, 0);
    pthread_cond_init(&newClients.condition, 0);

    pthread_mutex_init(&criticalSender, 0);
    pthread_mutex_init(&criticalReceiver, 0);

    InitializeDatabase();
    InitializeDispatcher();
    InitializeBroadcaster();
}
static void *enqueueRequest(void *p) {
    pthread_detach(pthread_self());

    int *clientAddress = p;
    int client = *clientAddress;
    char header[4];
    int packetSize, accumulated, read;
    while (1) {
        accumulated = read = 0;
        do {
            read = recv(client, &header[accumulated], 4 - accumulated, 0);
            if (read <= 0)
                goto onDisconnected;
            accumulated += read;
        } while (accumulated < 4);

        memcpy(&packetSize, header, 4);
        Request *r = malloc(REQUEST_SIZE);
        r->packet = malloc(packetSize);
        accumulated = read = 0;
        do {
            read = recv(client, &r->packet[accumulated], packetSize - accumulated, 0);
            if (read <= 0) {
                free(r->packet);
                free(r);
                goto onDisconnected;
            }
            accumulated += read;
        } while (accumulated < packetSize);

        r->sender = client;
        r->length = packetSize;
        memcpy(&r->userId, &r->packet[0], 4);
        memcpy(&r->function, &r->packet[4], 4);
        putInto(&requests, r);
    }

onDisconnected:
    if (isRunning) {
        close(client);
        pthread_mutex_lock(&criticalSender);
        Sender **list = senders.data;
        Sender *s = 0;
        for (size_t i = 0; i < senders.count; i++) {
            if (list[i]->socket == client) {
                s = list[i];
                break;
            }
        }
        removeFromList(&senders, s);
        pthread_mutex_unlock(&criticalSender);

        pthread_mutex_lock(&criticalReceiver);
        Receiver **rList = receivers.data;
        Receiver *r = 0;
        for (size_t i = 0; i < receivers.count; i++) {
            if (rList[i]->userId == s->userId) {
                r = rList[i];
                break;
            }
        }
        if(r){
            close(r->socket);
            removeFromList(&receivers, r);
        }
        pthread_mutex_unlock(&criticalReceiver);

        free(s);
        free(r);
    }
    pthread_exit(0);
}
static void *processNewClient(void *p) {
    pthread_detach(pthread_self());

    while (isRunning) {
        NewClient *client = takeOutFrom(&newClients);
        if (!client)
            break;

        char info[5];
        int accumulated = 0, read = 0;
        do {
            read = recv(client->socket, &info[accumulated], 5 - accumulated, 0);
            if (read <= 0) {
                //TO DO
            }
            accumulated += read;
        } while (accumulated < 5);

        char isReceiver = info[0];
        if (isReceiver) {
            Receiver *receiver = malloc(sizeof(Receiver));
            receiver->socket = client->socket;
            receiver->userId = info[1];

            pthread_mutex_lock(&criticalReceiver);
            addToList(&receivers, receiver);
            pthread_mutex_unlock(&criticalReceiver);

        } else {
            pthread_mutex_lock(&criticalSender);
            pthread_t requestThread;
            pthread_create(&requestThread, 0, enqueueRequest, &client->socket);
            Sender *s = malloc(SENDER_SIZE);
            s->socket = client->socket;
            s->userId = info[1];
            s->thread = requestThread;
            addToList(&senders, s);

            pthread_mutex_unlock(&criticalSender);
        }
        free(client);
    }
    pthread_exit(0);
}
static void acceptClient() {
    socklen_t flag = 1;
    while (isRunning) {
        NewClient *client = malloc(sizeof(NewClient));
        client->socket = accept(server, &client->from, &addressLength);
        if (isRunning) {
            setsockopt(client->socket, IPPROTO_TCP, TCP_NODELAY, &flag, addressLength);
            // char* ipv4 = inet_ntoa(client->from.sin_addr);
            // printf("address: %s port: %d\n", ipv4, client->from.sin_port);
            putInto(&newClients, client);
        }
    }
}