#include "CommonStructures.h"
#include "BlockingQueue.h"
#include "Messenger.h"
#include "Structures.h"
#include <pthread.h>
#include <stdio.h>

extern byte isRunning;
extern BlockingQueue personalResponses;

static BlockingQueue garbagePersonalResponses;
static pthread_t dispatcherThread, freePersonalResponseThread;

static void sendShortMessage(ResponsePersonal *r) {
    ShortMessage *message = r->data;
    if (message->isSuccess) {
        sendInt(r->sender, 1);
        sendByte(r->sender, message->isSuccess);
    } else {
        sendInt(r->sender, r->size);
        sendByte(r->sender, message->isSuccess);
        sendString(r->sender, message->text);
    }
    putInto(&garbagePersonalResponses, r);
}
static void sendTransactions(ResponsePersonal *r) {
    Transaction **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        if (sendInt(r->sender, list[i]->id) < 0)
            break;
        sendInt(r->sender, list[i]->plotId);
        sendInt(r->sender, list[i]->spaceId);
        sendInt(r->sender, list[i]->tenantId);
        sendInt(r->sender, list[i]->controlId);
        sendInt(r->sender, list[i]->headId);
        sendInt(r->sender, list[i]->amount);
        sendByte(r->sender, list[i]->isCash);
        sendString(r->sender, list[i]->date);
        sendString(r->sender, list[i]->narration);
    }
    putInto(&garbagePersonalResponses, r);
}
static void sendPlotDueChart(ResponsePersonal *r) {
    PlotwiseDue **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        if (sendString(r->sender, list[i]->month) < 0)
            break;
        sendString(r->sender, list[i]->tenant);
        sendInt(r->sender, list[i]->due);
    }
    putInto(&garbagePersonalResponses, r);
}
static void sendPlotwiseRent(ResponsePersonal *r) {
    PlotwiseRent **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        if (sendString(r->sender, list[i]->plot) < 0)
            break;
        sendString(r->sender, list[i]->tenant);
        sendString(r->sender, list[i]->month);
        sendInt(r->sender, list[i]->rent);
        sendInt(r->sender, list[i]->cash);
        sendInt(r->sender, list[i]->mobile);
        sendInt(r->sender, list[i]->kind);
        sendInt(r->sender, list[i]->total);
        sendInt(r->sender, list[i]->plotId);
    }
    putInto(&garbagePersonalResponses, r);
}
static void sendTenantDetail(ResponsePersonal *r) {
    TenantDetail *detail = r->data;
    sendInt(r->sender, r->size);
    sendInt(r->sender, detail->deposit);
    RentPayment **list = detail->payments;
    for (int i = 0; i < r->count; i++) {
        if (sendString(r->sender, list[i]->date) < 0)
            break;
        sendString(r->sender, list[i]->plot);
        sendString(r->sender, list[i]->space);
        sendString(r->sender, list[i]->tenant);
        sendInt(r->sender, list[i]->due);
        sendInt(r->sender, list[i]->cash);
        sendInt(r->sender, list[i]->mobile);
        sendInt(r->sender, list[i]->kind);
        sendInt(r->sender, list[i]->totalPaid);
    }
    putInto(&garbagePersonalResponses, r);
}
static void sendDepositDueRent(ResponsePersonal *r) {
    DepositDueRent **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        if (sendByte(r->sender, list[i]->state) < 0)
            break;
        sendInt(r->sender, list[i]->plotId);
        sendInt(r->sender, list[i]->spaceId);
        sendInt(r->sender, list[i]->tenantId);
        sendInt(r->sender, list[i]->amount);
    }
    putInto(&garbagePersonalResponses, r);
}
static void sendBalance(ResponsePersonal *r) {
    Balance **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        if (sendString(r->sender, list[i]->space) < 0)
            break;
        sendString(r->sender, list[i]->tenant);
        sendString(r->sender, list[i]->dateStart);
        sendString(r->sender, list[i]->dateEnd);
        sendInt(r->sender, list[i]->security);
        sendInt(r->sender, list[i]->rent);
        sendInt(r->sender, list[i]->due);
        sendInt(r->sender, list[i]->count);
        sendByte(r->sender, list[i]->isExpired);
    }
    putInto(&garbagePersonalResponses, r);
}
static void sendLedger(ResponsePersonal *r) {
    ReportEntry **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        if (sendString(r->sender, list[i]->date) < 0)
            break;
        sendString(r->sender, list[i]->particulars);
        sendInt(r->sender, list[i]->amount);
        sendInt(r->sender, list[i]->controlId);
    }
    putInto(&garbagePersonalResponses, r);
}
static void sendMonthlyBalance(ResponsePersonal *r) {
    MonthlyBalance **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        if (sendString(r->sender, list[i]->date) < 0)
            break;
        sendString(r->sender, list[i]->plot);
        sendString(r->sender, list[i]->tenant);
        sendInt(r->sender, list[i]->due);
        sendInt(r->sender, list[i]->lastMonthDue);
        sendInt(r->sender, list[i]->payment);
    }
    putInto(&garbagePersonalResponses, r);
}
static void sendReceiptPayment(ResponsePersonal *r) {
    ReceiptPayment **list = r->data;
    sendInt(r->sender, r->size);
    for (int i = 0; i < r->count; i++) {
        if (sendString(r->sender, list[i]->control) < 0)
            break;
        sendString(r->sender, list[i]->head);
        sendString(r->sender, list[i]->plot);
        sendString(r->sender, list[i]->space);
        sendString(r->sender, list[i]->tenant);
        sendInt(r->sender, list[i]->cash);
        sendInt(r->sender, list[i]->mobile);
        sendInt(r->sender, list[i]->kind);
        sendInt(r->sender, list[i]->total);
    }
    putInto(&garbagePersonalResponses, r);
}

static void sendLeftOrJoined(ResponsePersonal* r) {
	LeftOrJoined** list = r->data;
	sendInt(r->sender, r->size);
	for (int i = 0; i < r->count; i++) {
		if (sendByte(r->sender, list[i]->isExpired) < 0) break;
		sendInt(r->sender, list[i]->plotId);
		sendInt(r->sender, list[i]->spaceId);
		sendInt(r->sender, list[i]->tenantId);
		sendInt(r->sender, list[i]->receivable);
		sendString(r->sender, list[i]->dateStart);
		sendString(r->sender, list[i]->dateEnd);
	}
	putInto(&garbagePersonalResponses, r);
}

static void sendLastPaymentAndDue(ResponsePersonal * r){
    LastPaymentAndDue** list = r->data;
    sendInt(r->sender, r->size);
    for(int i =0; i< r->count; i++){
        if(sendString(r->sender, list[i]->date) < 0) break;
        sendInt(r->sender, list[i]->plot);
		sendInt(r->sender, list[i]->space);
		sendInt(r->sender, list[i]->securityOrPayment);
		sendInt(r->sender, list[i]->dueOrIsCash);
    }
    putInto(&garbagePersonalResponses, r);
}

static void *DispatchPersonalResponse(void *p) {
    pthread_detach(pthread_self());

    while (isRunning) {
        ResponsePersonal *r = takeOutFrom(&personalResponses);
        if (!r) break;

        switch (r->function) {
        case AddPlot:
        case AddSpace:
        case AddTenant:
        case AddHead:
        case AddLease:
        case AddTransactionsRegular:
        case AddTransactionsIrregular:
        case AddBulkRent:
        case EditPlot:
        case EditSpace:
        case EditTenant:
        case EditHead:
        case EditLease:
        case EditTransaction:
        case DeleteTransaction:
            sendShortMessage(r);
            break;
        case GetTransactions:
            sendTransactions(r);
            break;
        case GetPlotDueChart:
            sendPlotDueChart(r);
            break;
        case GetPlotwiseRent:
            sendPlotwiseRent(r);
            break;
        case GetTenantDetail:
            sendTenantDetail(r);
            break;
        case GetDepositDueRent:
            sendDepositDueRent(r);
            break;
        case GetBalance:
            sendBalance(r);
            break;
        case GetLedger:
            sendLedger(r);
            break;
        case GetMonthlyBalance:
            sendMonthlyBalance(r);
            break;
        case GetReceiptPayment:
            sendReceiptPayment(r);
            break;
        case GetLeftOrJoined: sendLeftOrJoined(r); break;
        case GetLastDueAndPayment: sendLastPaymentAndDue(r); break;
        }
    }
    pthread_exit(0);
}
static void *FreePersonalResponse(void *p) {
    pthread_detach(pthread_self());

    while (isRunning) {
        ResponsePersonal *r = takeOutFrom(&garbagePersonalResponses);
        if (!r) break;

        switch (r->function) {
        case GetPlotDueChart: {
            PlotwiseDue **list = r->data;
            for (size_t i = 0; i < r->count; i++) {
                free(list[i]->month);
                free(list[i]->tenant);
                free(list[i]);
            }
        } break;
        case GetTransactions: {
            Transaction **list = r->data;
            for (int i = 0; i < r->count; i++) {
                free(list[i]->date);
                free(list[i]->narration);
                free(list[i]);
            }
        } break;
        case GetPlotwiseRent: {
            PlotwiseRent **list = r->data;
            for (size_t i = 0; i < r->count; i++) {
                free(list[i]->plot);
                free(list[i]->tenant);
                free(list[i]->month);
                free(list[i]);
            }
        } break;
        case GetTenantDetail: {
            TenantDetail *detail = r->data;
            RentPayment **list = detail->payments;
            for (size_t i = 0; i < r->count; i++) {
                free(list[i]->date);
                free(list[i]->plot);
                free(list[i]->space);
                free(list[i]->tenant);
                free(list[i]);
            }
            free(list);
        } break;
        case GetDepositDueRent: {
            DepositDueRent **list = r->data;
            for (size_t i = 0; i < r->count; i++) {
                free(list[i]);
            }
        } break;
        case GetBalance: {
            Balance **list = r->data;
            for (size_t i = 0; i < r->count; i++) {
                free(list[i]->space);
                free(list[i]->tenant);
                free(list[i]->dateStart);
                free(list[i]->dateEnd);
                free(list[i]);
            }
        } break;
        case GetLedger: {
            ReportEntry **list = r->data;
            for (size_t i = 0; i < r->count; i++) {
                free(list[i]->date);
                free(list[i]->particulars);
                free(list[i]);
            }
        } break;
        case GetMonthlyBalance: {
            MonthlyBalance **list = r->data;
            for (size_t i = 0; i < r->count; i++) {
                free(list[i]->date);
                free(list[i]->plot);
                free(list[i]->tenant);
                free(list[i]);
            }
        } break;
        case GetReceiptPayment: {
            ReceiptPayment **list = r->data;
            for (size_t i = 0; i < r->count; i++) {
                free(list[i]->control);
                free(list[i]->head);
                free(list[i]->plot);
                free(list[i]->space);
                free(list[i]->tenant);
                free(list[i]);
            }
        } break;
        case GetLeftOrJoined:{
			LeftOrJoined** list = r->data;
			for (size_t i = 0; i < r->count; i++) {
				free(list[i]->dateStart);
				free(list[i]->dateEnd);
                free(list[i]);
			}
		} break;
        case GetLastDueAndPayment:{
            LastPaymentAndDue** list = r->data;
            for (size_t i = 0; i < r->count; i++){
                free(list[i]->date);
                free(list[i]);
            }
        } break;
        };
        
        free(r->data);
        free(r);
    }
    pthread_exit(0);
}

void InitializeDispatcher() {
    garbagePersonalResponses.count = 0;
    garbagePersonalResponses.capacity = 10;
    garbagePersonalResponses.data =
        malloc(garbagePersonalResponses.capacity * POINTER_SIZE);
    pthread_mutex_init(&garbagePersonalResponses.lock, 0);
    pthread_cond_init(&garbagePersonalResponses.condition, 0);

    pthread_create(&dispatcherThread, 0, DispatchPersonalResponse, 0);
    pthread_create(&freePersonalResponseThread, 0, FreePersonalResponse, 0);
}

void ShutdownDispatcher() {
    if (garbagePersonalResponses.isWaiting) {
        pthread_cond_signal(&garbagePersonalResponses.condition);
    }
    // free resources if required
}