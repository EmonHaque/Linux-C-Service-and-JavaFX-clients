#include "CommonFunctions.h"
#include "CommonDefined.h"
#include <string.h>

void addShortPersonalResponse(Request *r, ShortMessage *s, int size) {
    ResponsePersonal *response = malloc(RESPONSE_PERSONAL_SIZE);
    response->sender = r->sender;
    response->function = r->function;
    response->data = s;
    response->size = 1 + size + 1; // 1 for byte size for string and last 1 for '\0'
    putInto(&personalResponses, response);
}
void addLongPersonalResponse(Request *r, List l, int size) {
    ResponsePersonal *response = malloc(RESPONSE_PERSONAL_SIZE);
    response->sender = r->sender;
    response->function = r->function;
    response->size = size;
    response->data = l.data;
    response->count = l.count;
    putInto(&personalResponses, response);
}
void addPublicResponse(Request *r, void *d, int size) {
    ResponsePublic *pr = malloc(RESPONSE_PUBLIC_SIZE);
    pr->function = r->function;
    pr->userId = r->userId;
    pr->data = d;
    pr->size = size;
    putInto(&publicResponses, pr);
}
int mallocate(char *src, char **dst) {
    int length = src ? strlen(src) : 0;
    int extendedLength = length + 1;
    *dst = malloc(extendedLength);
    memcpy(*dst, src, length);
    (*dst)[length] = 0;
    return extendedLength;
}