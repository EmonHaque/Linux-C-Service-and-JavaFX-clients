#pragma once
#include <arpa/inet.h>
#include <pthread.h>

typedef struct {
	struct sockaddr_in from;
	int socket;
} NewClient;

typedef struct{
	int socket;
	int userId;
} Receiver;

typedef struct {
	int socket;
	int userId;
	pthread_t thread;
} Sender;

typedef struct {
	int sender;
	int length;
	char* packet;
	int userId;
	int function;
} Request;

typedef struct {
	int sender;
	int function;
	int size;
	void* data;
	uint count;
} ResponsePersonal;

typedef struct {
	int size;
	int function;
	int userId;
	void* data;
} ResponsePublic;

typedef struct {
	unsigned char isSuccess;
	char text[50];
} ShortMessage;