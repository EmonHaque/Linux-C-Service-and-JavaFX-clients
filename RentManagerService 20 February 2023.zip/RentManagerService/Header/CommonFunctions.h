#pragma once
#include "List.h"
#include "BlockingQueue.h"
#include "CommonStructures.h"

extern BlockingQueue personalResponses, publicResponses;

void addShortPersonalResponse(Request *r, ShortMessage *s, int size);
void addLongPersonalResponse(Request *r, List l, int size);
void addPublicResponse(Request *r, void *d, int size);
int mallocate(char *src, char **dst);