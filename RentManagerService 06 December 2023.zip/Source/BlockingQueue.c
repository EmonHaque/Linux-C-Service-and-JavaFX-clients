#include "BlockingQueue.h"
#include <malloc.h>
#include <unistd.h>

void putInto(BlockingQueue *queue, void *item) {
    pthread_mutex_lock(&queue->lock);
    void **items = queue->data;
    items[queue->count++] = item;
    if (queue->count == queue->capacity) {
        queue->capacity *= 2;
        queue->data = realloc(queue->data, queue->capacity * sizeof(void *));
    }
    pthread_mutex_unlock(&queue->lock);
    if (queue->isWaiting) pthread_cond_signal(&queue->condition);
}

void *takeOutFrom(BlockingQueue *queue) {
    void *item = 0;
    pthread_mutex_lock(&queue->lock);
    void **items = queue->data;   
    if (queue->count) {
        item = items[0];
        queue->count--;
    } else {
        queue->isWaiting = 1;
        pthread_cond_wait(&queue->condition, &queue->lock);
        queue->isWaiting = 0;
        items = queue->data; 
        if (queue->count) {
            item = items[0];
            queue->count--;
        }
    }
    if (queue->count) {
        for (int i = 0; i < queue->count; i++)
            items[i] = items[i + 1];
    }
    pthread_mutex_unlock(&queue->lock);
    return item;
}