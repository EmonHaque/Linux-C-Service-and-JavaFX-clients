package ridiculuous;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class ClientInfo {
    private byte isReceiver;
    private int userId;

    public ClientInfo(byte isReceiver, int userId) {
        this.isReceiver = isReceiver;
        this.userId = userId;
    }
    public byte[] getBytes(){
        return ByteBuffer.allocate(5)
                .order(ByteOrder.LITTLE_ENDIAN)
                .put(isReceiver)
                .putInt(userId).array();
    }
}
