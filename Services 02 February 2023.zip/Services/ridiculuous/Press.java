package ridiculuous;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.print.PageOrientation;
import javafx.print.Paper;
import javafx.print.Printer;
import javafx.print.PrinterJob;
import javafx.scene.Node;

public class Press {
    private final ObservableList<Printer> printers;
    private Printer printer;
    private PrinterJob printerJob;
    private Node printable;
    private boolean isAvailable;

    public BooleanProperty dialogTrigger;

    public Press() {
        dialogTrigger = new SimpleBooleanProperty();
        printers = FXCollections.observableArrayList(Printer.getAllPrinters());
        isAvailable = printers.size() > 0;
    }
    public void resetPrinterList(){
        printers.clear();
        printers.addAll(Printer.getAllPrinters());
        isAvailable = printers.size() > 0;
    }

    public void setSelected(Printer printer){
        this.printer = printer;
        if(printer != null){
            printerJob = PrinterJob.createPrinterJob(printer);
        }
    }
    public PrinterJob getPrinterJob(){ return printerJob; }
    public ObservableList<Printer> getPrinters(){ return printers;}
    public boolean available(){ return isAvailable; }
    public void setPrintable(Node node){ printable = node;}
    public Node getPrintable(){ return printable;}
    public void setPaper(Paper paper){
        if(printer == null) return;
        var layout = printer.createPageLayout(paper, PageOrientation.PORTRAIT, Printer.MarginType.DEFAULT);
        printerJob.getJobSettings().setPageLayout(layout);
    }
}
