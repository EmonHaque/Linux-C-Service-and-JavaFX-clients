import Controls.MainPanel;
import Controls.Window;
import Views.Objects;
import Views.Query;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import ridiculous.SQLiteWrapper;

public class SQLite extends Application {

    @Override
    public void start(Stage stage) {
        stage.getIcons().add(new Image("resources/images/icon.png"));
        var window = new Window(stage, "SQLite"){{
            setContent(new MainPanel(stage){{
                addView(new Objects());
                addView(new Query());
                setTitle("SQLite");
            }});
        }};
        window.show();
    }

    @Override
    public void stop() throws Exception {
        SQLiteWrapper.closeDatabase();
        super.stop();
    }
}
