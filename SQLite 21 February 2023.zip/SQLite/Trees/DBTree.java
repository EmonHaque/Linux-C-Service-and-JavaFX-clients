package Trees;

import Abstracts.WrapTreeCellBase;
import Controls.ExtendedTreeView;
import Enums.DBObjectType;
import Helpers.Constants;
import Model.DBObject;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.geometry.HPos;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

import java.util.List;

public class DBTree extends ExtendedTreeView<DBObject> {
    public ObjectProperty<List<DBObject>> objects;
    public BooleanProperty requestedPage;

    public DBTree() {
        objects = new SimpleObjectProperty<>();
        requestedPage =new SimpleBooleanProperty();
        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new Cell());

        objects.addListener(this::onListChange);
    }

    private void addTable(DBObject o) {
        TreeItem<DBObject> level1 = null;
        TreeItem<DBObject> level2 = null;
        boolean hasIt = false;
        for (var node : getRoot().getChildren()) {
            if (node.getValue().getName().equals("Table")) {
                level1 = node;
                hasIt = true;
                break;
            }
        }
        if (!hasIt) {
            level1 = new TreeItem<>(new DBObject() {{setName("Table");}});
            getRoot().getChildren().add(level1);
        }
        hasIt = false;
        for (var node : level1.getChildren()) {
            if (node.getValue().getName().equals(o.getName())) {
                level2 = node;
                hasIt = true;
                break;
            }
        }
        if (!hasIt) {
            level2 = new TreeItem<>(new DBObject() {{
                setName(o.getName());
                setType(DBObjectType.Table);
            }});
            level1.getChildren().add(level2);
        }
        level2.getChildren().add(new TreeItem<>(o));
    }

    private void addView(DBObject o) {
        TreeItem<DBObject> level1 = null;
        TreeItem<DBObject> level2 = null;
        boolean hasIt = false;
        for (var node : getRoot().getChildren()) {
            if (node.getValue().getName().equals("View")) {
                level1 = node;
                hasIt = true;
                break;
            }
        }
        if (!hasIt) {
            level1 = new TreeItem<>(new DBObject() {{setName("View");}});
            getRoot().getChildren().add(level1);
        }
        hasIt = false;
        for (var node : level1.getChildren()) {
            if (node.getValue().getName().equals(o.getName())) {
                level2 = node;
                hasIt = true;
                break;
            }
        }
        if (!hasIt) {
            level2 = new TreeItem<>(new DBObject() {{
                setName(o.getName());
                setType(DBObjectType.View);
            }});
            level1.getChildren().add(level2);
        }
        level2.getChildren().add(new TreeItem<>(o));
    }

    private void addIndex(DBObject o) {
        TreeItem<DBObject> level1 = null;
        TreeItem<DBObject> level2 = null;
        boolean hasIt = false;
        for (var node : getRoot().getChildren()) {
            if (node.getValue().getName().equals("Index")) {
                level1 = node;
                hasIt = true;
                break;
            }
        }
        if (!hasIt) {
            level1 = new TreeItem<>(new DBObject() {{setName("Index");}});
            getRoot().getChildren().add(level1);
        }
        hasIt = false;
        for (var node : level1.getChildren()) {
            if (node.getValue().getName().equals(o.getName())) {
                level2 = node;
                hasIt = true;
                break;
            }
        }
        if (!hasIt) {
            level2 = new TreeItem<>(new DBObject() {{
                setName(o.getName());
                setType(DBObjectType.Index);
            }});
            level1.getChildren().add(level2);
        }
        level2.getChildren().add(new TreeItem<>(o));
    }

    private void addTrigger(DBObject o) {
        TreeItem<DBObject> level1 = null;
        boolean hasIt = false;
        for (var node : getRoot().getChildren()) {
            if (node.getValue().getName().equals("Trigger")) {
                level1 = node;
                hasIt = true;
                break;
            }
        }
        if (!hasIt) {
            level1 = new TreeItem<>(new DBObject() {{setName("Trigger");}});
            getRoot().getChildren().add(level1);
        }
        level1.getChildren().add(new TreeItem<>(o));
    }

    private void onListChange(Observable o, List<DBObject> ov, List<DBObject> nv) {
        getRoot().getChildren().clear();
        if (nv != null) {
            for (var item : nv) {
                if (item.getType() == DBObjectType.Table) addTable(item);
                else if (item.getType() == DBObjectType.View) addView(item);
                else if (item.getType() == DBObjectType.Index) addIndex(item);
                else if (item.getType() == DBObjectType.Trigger) addTrigger(item);
            }
        }
    }

    private class Cell extends WrapTreeCellBase<DBObject> {
        private Text name, column;
        private ColumnConstraints firstColumn;

        @Override
        protected void initializeUI() {
            name = new Text() {{setFill(Color.WHITE);}};
            column = new Text() {{setFill(Color.WHITE);}};

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(100) {{setHalignment(HPos.RIGHT);}}
                );
                add(name, 0, 0);
                add(column, 1, 0);
            }};
            root.setOnMouseClicked(e ->{
                if(e.getClickCount() % 2 == 0){
                    if(level != 2) return;
                    var type = getItem().getType();
                    if(type == DBObjectType.Table || type == DBObjectType.View){
                        requestedPage.set(true);
                    }
                }
            });
        }

        @Override
        protected void resetValues(DBObject oldValue) {
            name.setText(null);
            column.setText(null);
            name.setFont(Constants.Normal);
        }

        @Override
        protected void setValues(DBObject newValue) {
            if (level == 1) {
                name.setText(newValue.getName() + " (" + item.getChildren().size() + ")");
                name.setFont(Constants.Bold);
            }
            else if (level == 2) {
                if (newValue.getType() == DBObjectType.Trigger)
                    name.setText(newValue.getName());
                else
                    name.setText(newValue.getName() + " (" + item.getChildren().size() + ")");
            }
            else {
                name.setText(newValue.getColumnName());
                column.setText(newValue.getDataType());
            }
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 100;
            name.setWrappingWidth(remainder);
            return name.prefHeight(remainder);
        }
    }
}
