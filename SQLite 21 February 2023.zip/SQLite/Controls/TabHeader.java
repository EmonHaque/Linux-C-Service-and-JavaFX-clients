package Controls;

import Helpers.Constants;
import Helpers.Icons;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Insets;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class TabHeader extends GridPane {
    private final Border normalBorder, selectedBorder;
    private final Text header;

    public TabHeader(String text) {
        var radi = new CornerRadii(10, 10, 0, 0, false);
        header = new Text(text) {{setFill(Color.WHITE);}};
        var close = new ActionButton(Icons.CloseCircle, 16, "close"){{ setAction(TabHeader.this::onClose);}};

        normalBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, radi, new BorderWidths(0.25)));
        selectedBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, radi, new BorderWidths(0.5, 0.5, 0, 0.5)));

        add(header, 0, 0);
        add(close, 1, 0);
        setHgap(5);
        setPadding(new Insets(2.5, 2.5, 2.5, 5));
        setBackground(Background.fill(Constants.BackgroundColor));
        setBorder(selectedBorder);
        setOnMouseClicked(this::onSelect);
    }

    public void setSelected(boolean isSelected) {
        if (isSelected) {
            setBorder(selectedBorder);
            setPadding(new Insets(2.5, 2.5, 2.5, 5));
            header.setFill(Color.WHITE);
        }
        else {
            setBorder(normalBorder);
            setPadding(new Insets(2.5, 2.5, 2, 5));
            header.setFill(Color.GRAY);
        }
    }
    private void onSelect(MouseEvent e){
        this.fireEvent(new SelectEvent(this));
    }
    private void onClose(){
        this.fireEvent(new CloseEvent(this));
    }

    public abstract class TabClickEvent extends Event{
        public static final EventType<TabClickEvent> CLICK_EVENT = new EventType(ANY);

        public TabClickEvent(EventType<? extends Event> eventType) {
            super(eventType);
        }
        public abstract void invokeHandler(TabClickHandler handler);
    }

    private class SelectEvent extends TabClickEvent{
        public static final EventType<TabClickEvent> SELECT = new EventType(CLICK_EVENT, "SelectEvent");
        private final TabHeader header;

        public SelectEvent(TabHeader header) {
            super(SELECT);
            this.header = header;
        }

        @Override
        public void invokeHandler(TabClickHandler handler) {
            handler.onSelect(header);
        }
    }

    private class CloseEvent extends TabClickEvent{
        public static final EventType<TabClickEvent> CLOSE = new EventType(CLICK_EVENT, "CloseEvent");
        private final TabHeader header;

        public CloseEvent(TabHeader header) {
            super(CLOSE);
            this.header = header;
        }

        @Override
        public void invokeHandler(TabClickHandler handler) {
            handler.onClose(header);
        }
    }

    public static abstract class TabClickHandler implements EventHandler<TabClickEvent> {
        public abstract void onSelect(TabHeader header);
        public abstract void onClose(TabHeader header);

        @Override
        public void handle(TabClickEvent event) {
            event.invokeHandler(this);
        }
    }
}
