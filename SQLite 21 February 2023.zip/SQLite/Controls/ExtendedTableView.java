package Controls;

import Helpers.Constants;
import Skins.ExtendedScrollBarSkin;
import javafx.geometry.Pos;
import javafx.scene.AccessibleAttribute;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

import java.util.Set;

public class ExtendedTableView<T> extends TableView<T> {
    private boolean isLoaded;
    private StackPane headerPane;

    public ExtendedTableView() {
        setRowFactory(v -> new TableRow<>() {
            @Override
            protected void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);
                setBorder(empty ? null : Constants.BottomBorder);
                setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
            }
        });
    }

    @Override
    protected void layoutChildren() {
        if (!isLoaded) {
            isLoaded = true;
            applySkin();
        }
        Set<Node> headers = lookupAll(".column-header");
        Set<Node> labels = lookupAll(".label");
        for (Node columnHeader : headers) {
            ((Region) columnHeader).setBackground(null);
        }
        for (Node label : labels) {
            var text = (Label) label;
            text.setTextFill(Color.WHITE);
            text.setAlignment(Pos.CENTER_LEFT);
        }
        headerPane.setBorder(headers.size() > 1 ?
                new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.5, 0, 0.5, 0)))
                : null
        );

        super.layoutChildren();
    }

    private void applySkin() {
        setBackground(null);
        var corner = (StackPane) lookup(".corner");
        headerPane = (StackPane) lookup(".column-header-background");
        var filler = (Region) headerPane.lookup(".filler");

        corner.setBackground(null);
        headerPane.setBackground(null);
        filler.setBackground(null);

        var vBar = (ScrollBar) queryAccessibleAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR);
        var hBar = (ScrollBar) queryAccessibleAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR);
        vBar.setSkin(new ExtendedScrollBarSkin(vBar));
        hBar.setSkin(new ExtendedScrollBarSkin(hBar));
    }
}
