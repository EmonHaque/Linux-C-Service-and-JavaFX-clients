package ridiculous;

import com.sun.jna.Callback;
import com.sun.jna.Native;
import com.sun.jna.ptr.PointerByReference;

public class SQLiteWrapper {
    public static final Object key;
    static {
        key = new Object();
        Native.register("resources/lib/sqlitejna.so");
    }
    public interface rowCallBack extends Callback{
        void invoke(PointerByReference values);
    }
    public interface columnCallback extends Callback{
        void invoke(int count, PointerByReference values, int length);
    }
    public interface changeCallback extends Callback{
        void invoke(int count);
    }
    public interface errorCallback extends Callback{
        void invoke(String text);
    }
    public static native void setRowCallback(rowCallBack action);
    public static native void setColumnCallback(columnCallback action);
    public static native void setChangeCallback(changeCallback action);
    public static native void setCErrorCallback(errorCallback action);
    public static native void openDatabase(String dbFile);
    public static native void execute(String query);
    public static native void cancel();
    public static native void closeDatabase();
}
