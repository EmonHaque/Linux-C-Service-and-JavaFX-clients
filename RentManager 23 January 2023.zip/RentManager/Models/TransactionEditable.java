package Models;

import javafx.beans.property.*;

import java.time.LocalDate;

public class TransactionEditable {
    private final IntegerProperty id, plotId, spaceId, tenantId, controlId, headId, amount, isCash;
    private final StringProperty plotName, spaceName, tenantName, controlName, narration;
    private final ObjectProperty<LocalDate> date;

    public TransactionEditable() {
        id = new SimpleIntegerProperty();
        plotId = new SimpleIntegerProperty();
        spaceId = new SimpleIntegerProperty();
        tenantId = new SimpleIntegerProperty();
        controlId = new SimpleIntegerProperty();
        headId = new SimpleIntegerProperty();
        amount = new SimpleIntegerProperty();
        isCash = new SimpleIntegerProperty();
        plotName = new SimpleStringProperty("");
        spaceName = new SimpleStringProperty("");
        tenantName = new SimpleStringProperty("");
        controlName = new SimpleStringProperty("");
        narration = new SimpleStringProperty("");
        date = new SimpleObjectProperty<>();
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public int getPlotId() {
        return plotId.get();
    }

    public IntegerProperty plotIdProperty() {
        return plotId;
    }

    public void setPlotId(int plotId) {
        this.plotId.set(plotId);
    }

    public String getPlotName() { return plotName.get();}

    public StringProperty plotNameProperty() {return plotName;}

    public void setPlotName(String plotName) {this.plotName.set(plotName);}

    public String getSpaceName() {
        return spaceName.get();
    }

    public StringProperty spaceNameProperty() {
        return spaceName;
    }

    public void setSpaceName(String spaceName) {
        this.spaceName.set(spaceName);
    }

    public String getTenantName() {
        return tenantName.get();
    }

    public StringProperty tenantNameProperty() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName.set(tenantName);
    }

    public String getControlName() {
        return controlName.get();
    }

    public StringProperty controlNameProperty() {
        return controlName;
    }

    public void setControlName(String controlName) {
        this.controlName.set(controlName);
    }

    public int getSpaceId() {
        return spaceId.get();
    }

    public IntegerProperty spaceIdProperty() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId.set(spaceId);
    }

    public int getTenantId() {
        return tenantId.get();
    }

    public IntegerProperty tenantIdProperty() {
        return tenantId;
    }

    public void setTenantId(int tenantId) {
        this.tenantId.set(tenantId);
    }

    public int getControlId() {
        return controlId.get();
    }

    public IntegerProperty controlIdProperty() {
        return controlId;
    }

    public void setControlId(int controlId) {
        this.controlId.set(controlId);
    }

    public int getHeadId() {
        return headId.get();
    }

    public IntegerProperty headIdProperty() {
        return headId;
    }

    public void setHeadId(int headId) {
        this.headId.set(headId);
    }

    public int getAmount() {
        return amount.get();
    }

    public IntegerProperty amountProperty() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount.set(amount);
    }

    public int getIsCash() {
        return isCash.get();
    }

    public IntegerProperty isCashProperty() {
        return isCash;
    }

    public void setIsCash(int isCash) {
        this.isCash.set(isCash);
    }

    public String getNarration() {
        return narration.get();
    }

    public StringProperty narrationProperty() {
        return narration;
    }

    public void setNarration(String narration) {
        this.narration.set(narration);
    }

    public LocalDate getDate() {
        return date.get();
    }

    public ObjectProperty<LocalDate> dateProperty() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date.set(date);
    }
}
