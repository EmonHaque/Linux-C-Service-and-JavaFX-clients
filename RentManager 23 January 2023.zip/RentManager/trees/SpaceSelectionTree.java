package trees;

import Models.Space;
import controls.texts.HiText;
import helpers.Constants;
import javafx.beans.Observable;
import javafx.beans.property.StringProperty;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.skin.TreeCellSkin;
import javafx.scene.layout.Background;
import ridiculous.AppData;
import skinned.ExtendedResizableTreeView;

import java.util.List;

public class SpaceSelectionTree extends ExtendedResizableTreeView<Space> {

    public SpaceSelectionTree(FilteredList<Space> list, StringProperty query) {
        setRoot(new TreeItem<>());
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        addItems(list);
        setCellFactory(v -> new Cell(query));
        list.addListener(this::onItemsChanged);

        getSelectionModel().selectedItemProperty().addListener((o, ov, nv) -> {
            if (nv == null) return;
            if (nv.isLeaf()) return;
            var row = getRow(nv);
            if (row == 0) getSelectionModel().select(1);
            else getSelectionModel().select(getRow(ov) > row ? row - 1 : row + 1);
        });
    }

    private void onItemsChanged(ListChangeListener.Change<? extends Space> change) {
        getSelectionModel().clearSelection();
        while (change.next()) {
            if (change.wasAdded()) {
                if (change.getRemovedSize() > 0) {
                    removeItems((List<Space>) change.getRemoved());
                }
                addItems((List<Space>) change.getAddedSubList());
            }
            else if (change.wasRemoved()) {
                removeItems((List<Space>) change.getRemoved());
            }
        }
    }

    private void addItems(List<Space> list) {
        for (var space : list) {
            var hasIt = false;
            TreeItem<Space> item = null;
            var plotName = AppData.plots.stream().filter(x -> x.getId() == space.getPlotId()).findFirst().get().getName();
            for (var plot : getRoot().getChildren()) {
                if (plot.getValue().getName().equals(plotName)) {
                    hasIt = true;
                    item = plot;
                    break;
                }
            }
            if (!hasIt) {
                item = new TreeItem<>(new Space() {{setName(plotName);}});
                item.setExpanded(true);
                getRoot().getChildren().add(item);
            }
            item.getChildren().add(new TreeItem<>(space));
        }
    }

    private void removeItems(List<Space> list) {
        for (var space : list) {
            TreeItem<Space> plot = null;
            TreeItem<Space> leaf = null;
            var plotName = AppData.plots.stream().filter(x -> x.getId() == space.getPlotId()).findFirst().get().getName();
            for (var item : getRoot().getChildren()) {
                if (item.getValue().getName().equals(plotName)) {
                    plot = item;
                    break;
                }
            }
            for (var item : plot.getChildren()) {
                if (item.getValue().getName().equals(space.getName())) {
                    leaf = item;
                    break;
                }
            }
            plot.getChildren().remove(leaf);
            if (plot.getChildren().size() == 0) {
                getRoot().getChildren().remove(plot);
            }
        }
    }

    private class Cell extends TreeCell<Space> {
        private final StringProperty query;
        private final HiText text;
        private int level;

        public Cell(StringProperty query) {
            this.query = query;
            setDisclosureNode(null);
            setBackground(null);
            setPrefWidth(0);
            setPadding(new Insets(Constants.CellPadding, 0, Constants.CellPadding, 0));
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            text = new HiText();
            itemProperty().addListener(this::onItemChanged);
        }

        @Override
        protected Skin<?> createDefaultSkin() {
            var skin = (TreeCellSkin<?>) super.createDefaultSkin();
            skin.setIndent(0);
            return skin;
        }

        private void onItemChanged(Observable o, Space ov, Space nv) {
            if (ov != null) {
                text.textProperty().unbind();
                text.queryProperty().unbind();
                text.queryProperty().set("");
                text.setBorder(null);
                text.setFont(Constants.Normal);
                text.setPadding(new Insets(0));

                setDisable(false);
            }
            if (nv != null) {
                var item = getTreeItem();
                level = getTreeView().getTreeItemLevel(item);
                if (level == 1) {
                    text.setText(nv.getName());
                    text.setFont(Constants.Bold);
                    text.setBorder(Constants.BottomBorder);
                    text.setPadding(new Insets(0, 0, 0, -10));
                    setDisable(true);
                }
                else {
                    text.textProperty().bind(nv.nameProperty());
                    text.queryProperty().bind(query);
                }
            }
        }

        @Override
        protected void updateItem(Space item, boolean empty) {
            super.updateItem(item, empty);
            if (isEmpty()) {
                setBackground(null);
                setGraphic(null);
            }
            else {
                setGraphic(text);
                if (level != 1)
                    setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
            }
        }
    }
}
