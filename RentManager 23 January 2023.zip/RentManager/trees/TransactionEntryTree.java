package trees;

import Models.Entry;
import abstracts.WrapTreeCellBase;
import controls.SVGIcon;
import controls.buttons.ActionButtonArg;
import helpers.Constants;
import helpers.Icons;
import interfaces.IExecuteArg;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.control.TreeItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

import java.time.format.DateTimeFormatter;

public class TransactionEntryTree extends ExtendedTreeView<Entry> {
    private final ObservableList<Entry> entries;
    private final TreeItem<Entry> root, receipt, payment, receivable;

    public TransactionEntryTree(ObservableList<Entry> entries, IExecuteArg<Entry> executor) {
        this.entries = entries;
        receipt = new TreeItem<>(new Entry() {{setNarration("Receipt");}}) {{setExpanded(true);}};
        payment = new TreeItem<>(new Entry() {{setNarration("Payment");}}) {{setExpanded(true);}};
        receivable = new TreeItem<>(new Entry() {{setNarration("Receivable");}}) {{setExpanded(true);}};
        root = new TreeItem<>();
        setRoot(root);
        setShowRoot(false);
        setCellFactory(v -> new EntryCell(executor));
        entries.addListener(this::onEntriesChanged);
    }

    private void onEntriesChanged(ListChangeListener.Change<? extends Entry> change) {
        while (change.next()) {
            if (change.wasAdded()) {
                var item = change.getAddedSubList().get(0);
                var node = item.getControlId() == AppData.controlIdOfReceivable ? receivable
                        : item.getControlId() == AppData.controlIdOfPayment ? payment
                        : receipt;
                if (!root.getChildren().contains(node)) {
                    root.getChildren().add(node);
                }
                addItem(node, item);
                node.getValue().setAmount(node.getValue().getAmount() + item.getAmount());
            }
            else if (change.wasRemoved()) {
                if (entries.size() == 0) {
                    clearItems();
                    return;
                }
                var item = change.getRemoved().get(0);
                var node = item.getControlId() == AppData.controlIdOfReceivable ? receivable
                        : item.getControlId() == AppData.controlIdOfPayment ? payment
                        : receipt;
                if (!root.getChildren().contains(node)) {
                    root.getChildren().add(node);
                }
                removeItem(node, item);
                node.getValue().setAmount(node.getValue().getAmount() - item.getAmount());
            }
        }
    }

    private void clearItems() {
        receivable.getChildren().clear();
        receipt.getChildren().clear();
        payment.getChildren().clear();
        receivable.getValue().setAmount(0);
        receipt.getValue().setAmount(0);
        payment.getValue().setAmount(0);
        root.getChildren().clear();
    }

    private void addItem(TreeItem<Entry> node, Entry e) {
        TreeItem<Entry> plot = null;
        var hasIt = false;
        for (var item : node.getChildren()) {
            if (item.getValue().getPlotId() == e.getPlotId()) {
                plot = item;
                plot.getValue().setAmount(plot.getValue().getAmount() + e.getAmount());
                hasIt = true;
                break;
            }
        }
        if (!hasIt) {
            plot = new TreeItem<>(new Entry() {{
                setPlotId(e.getPlotId());
                setAmount(e.getAmount());
            }}) {{setExpanded(true);}};
            node.getChildren().add(plot);
        }
        plot.getChildren().add(new TreeItem<>(e));
    }

    private void removeItem(TreeItem<Entry> node, Entry e) {
        TreeItem<Entry> plot = null;
        TreeItem<Entry> leaf = null;
        for (var item : node.getChildren()) {
            if (item.getValue().getPlotId() == e.getPlotId()) {
                plot = item;
                for (var l : plot.getChildren()) {
                    if (l.getValue().equals(e)) {
                        leaf = l;
                        break;
                    }
                }
                plot.getValue().setAmount(plot.getValue().getAmount() - e.getAmount());
                break;
            }
        }
        plot.getChildren().remove(leaf);
        if (plot.getChildren().size() == 0) {
            node.getChildren().remove(plot);
        }
        if (node.getChildren().size() == 0) {
            root.getChildren().remove(node);
        }
    }

    public BooleanBinding isEmpty() {return Bindings.isEmpty(entries);}

    private class EntryCell extends WrapTreeCellBase<Entry> {
        private final IExecuteArg<Entry> executor;
        private GridPane breakup;
        private Text particulars, date, amount, totalCash, totalKind, totalMobile, grandTotal;
        private SVGIcon isCashIcon, cashIcon, kindIcon, mobileIcon, totalIcon;
        private ActionButtonArg<Entry> button;
        private ColumnConstraints firstColumn;
        private final Popup popup;
        private final Text popText;

        public EntryCell(IExecuteArg<Entry> executor) {
            this.executor = executor;
            popup = new Popup();
            popText = new Text() {{setFill(Color.WHITE);}};
            var box = new HBox(popText) {{
                setPadding(new Insets(5));
                setBackground(Background.fill(Constants.BackgroundColor));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25))));
            }};
            popup.getContent().add(box);
        }

        @Override
        protected void initializeUI() {
            particulars = new Text() {{setFill(Color.WHITE);}};
            date = new Text() {{setFill(Color.WHITE);}};
            amount = new Text() {{setFill(Color.WHITE);}};
            isCashIcon = new SVGIcon(Icons.Cash);
            button = new ActionButtonArg<>(Icons.MinusCircle, 16, "remove");

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(90),
                        new ColumnConstraints(90) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(20) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(20) {{setHalignment(HPos.CENTER);}}
                );
                add(particulars, 0, 0);
                add(date, 1, 0);
                add(amount, 2, 0);
                add(isCashIcon, 3, 0);
                add(button, 4, 0);
            }};
            initializeBreakup();
        }

        @Override
        protected void resetValues(Entry oldValue) {
            root.removeEventHandler(MouseEvent.MOUSE_ENTERED, this::onMouseEnter);
            root.removeEventHandler(MouseEvent.MOUSE_EXITED, this::onMouseExit);

            particulars.setText(null);
            date.setText(null);
            amount.setText(null);
            button.setAction(null, null);

            root.setBorder(null);
            root.getChildren().remove(breakup);
        }

        @Override
        protected void setValues(Entry newValue) {
            if (level == 1) {
                particulars.setText(newValue.getNarration());
                particulars.setFont(Constants.Bold);
                amount.setVisible(false);
                date.setVisible(false);
                isCashIcon.setVisible(false);
                button.setVisible(false);

                int cash, kind, mobile;
                cash = kind = mobile = 0;

                for (var plot : item.getChildren()) {
                    for (var entry : plot.getChildren()) {
                        var e = entry.getValue();
                        switch (e.getIsCash()) {
                            case 0 -> cash += e.getAmount();
                            case 1 -> kind += e.getAmount();
                            case 2 -> mobile += e.getAmount();
                        }
                    }
                }
                totalCash.setText(String.format("%,d", cash));
                totalKind.setText(String.format("%,d", kind));
                totalMobile.setText(String.format("%,d", mobile));
                grandTotal.setText(String.format("%,d", newValue.getAmount()));
                root.add(breakup, 1, 0);
            }
            else if (level == 2) {
                particulars.setText(AppData.plots.stream().filter(x -> x.getId() == newValue.getPlotId()).findFirst().get().getName());
                particulars.setFont(Constants.Bold);
                amount.setVisible(false);
                date.setVisible(false);
                isCashIcon.setVisible(false);
                button.setVisible(false);

                int cash, kind, mobile;
                cash = kind = mobile = 0;

                for (var entry : item.getChildren()) {
                    var e = entry.getValue();
                    switch (e.getIsCash()) {
                        case 0 -> cash += e.getAmount();
                        case 1 -> kind += e.getAmount();
                        case 2 -> mobile += e.getAmount();
                    }
                }
                totalCash.setText(String.format("%,d", cash));
                totalKind.setText(String.format("%,d", kind));
                totalMobile.setText(String.format("%,d", mobile));
                grandTotal.setText(String.format("%,d", newValue.getAmount()));
                root.add(breakup, 1, 0);
            }
            else if (level == 3) {
                root.addEventHandler(MouseEvent.MOUSE_ENTERED, this::onMouseEnter);
                root.addEventHandler(MouseEvent.MOUSE_EXITED, this::onMouseExit);

                int index = 0;
                for (var e : item.getParent().getChildren()) {
                    if (e.getValue().equals(newValue)) break;
                    index++;
                }
                if (index == 0) {
                    root.setBorder(item.getParent().getChildren().size() == 1 ? Constants.DoubleBorder : Constants.TopBorder);
                }
                else if (index == item.getParent().getChildren().size() - 1) {
                    root.setBorder(Constants.BottomBorder);
                }
                var space = AppData.spaces.stream().filter(x -> x.getId() == newValue.getSpaceId()).findFirst().get().getName();
                var tenant = AppData.tenants.stream().filter(x -> x.getId() == newValue.getTenantId()).findFirst().get().getName();
                var head = AppData.heads.stream().filter(x -> x.getId() == newValue.getHeadId()).findFirst().get().getName();
                particulars.setText(space + " - " + tenant + " : " + head);
                date.setText(newValue.getDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy")));
                amount.setText(String.format("%,d", newValue.getAmount()));
                particulars.setFont(Constants.Normal);
                amount.setFont(Constants.Normal);

                popText.setText(newValue.getNarration());

                date.setVisible(true);
                isCashIcon.setVisible(true);
                amount.setVisible(true);
                button.setVisible(true);
                button.setAction(executor, newValue);
                switch (newValue.getIsCash()) {
                    case 0 -> {
                        isCashIcon.setContent(Icons.Cash);
                        isCashIcon.setFill(Color.LIGHTGREEN);
                    }
                    case 1 -> {
                        isCashIcon.setContent(Icons.NonCash);
                        isCashIcon.setFill(Color.LIGHTCORAL);
                    }
                    case 2 -> {
                        isCashIcon.setContent(Icons.Mobile);
                        isCashIcon.setFill(Color.CORNFLOWERBLUE);
                    }
                }
            }
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 2 * 90 - 2 * 20;
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            firstColumn.setPrefWidth(remainder);
            particulars.setWrappingWidth(remainder);
            return particulars.prefHeight(remainder);
        }

        private void initializeBreakup() {
            totalCash = new Text() {{setFill(Color.WHITE);}};
            totalKind = new Text() {{setFill(Color.WHITE);}};
            totalMobile = new Text() {{setFill(Color.WHITE);}};
            grandTotal = new Text() {{setFill(Color.WHITE);}};

            cashIcon = new SVGIcon(Icons.Cash) {{setFill(Color.LIGHTGREEN);}};
            kindIcon = new SVGIcon(Icons.NonCash) {{setFill(Color.LIGHTCORAL);}};
            mobileIcon = new SVGIcon(Icons.Mobile) {{setFill(Color.CORNFLOWERBLUE);}};
            totalIcon = new SVGIcon(Icons.Sum) {{setFill(Color.WHITE);}};

            breakup = new GridPane() {{
                getColumnConstraints().addAll(
                        new ColumnConstraints(16) {{setHalignment(HPos.RIGHT); setHgrow(Priority.ALWAYS);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(16) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(16) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(16) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}}
                );
                add(cashIcon, 0, 0);
                add(totalCash, 1, 0);
                add(kindIcon, 2, 0);
                add(totalKind, 3, 0);
                add(mobileIcon, 4, 0);
                add(totalMobile, 5, 0);
                add(totalIcon, 6, 0);
                add(grandTotal, 7, 0);
                setHgap(5);
            }};
            GridPane.setColumnSpan(breakup, 4);
            GridPane.setHalignment(breakup, HPos.RIGHT);
            GridPane.setValignment(breakup, VPos.CENTER);
            GridPane.setHgrow(breakup, Priority.ALWAYS);
        }

        private void onMouseEnter(MouseEvent e) {
            if (level == 3)
                popup.show(root, e.getScreenX() + 10, e.getScreenY() + 10);
        }

        private void onMouseExit(MouseEvent e) {
            if (popup.isShowing())
                popup.hide();
        }
    }
}
