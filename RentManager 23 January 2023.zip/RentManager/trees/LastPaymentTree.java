package trees;

import Models.LastPayment;
import abstracts.WrapTreeCellBase;
import controls.SVGIcon;
import helpers.Constants;
import helpers.Helper;
import helpers.Icons;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import skinned.ExtendedTreeView;

public class LastPaymentTree extends ExtendedTreeView<LastPayment> {
    private final ObservableList<LastPayment> list;

    public LastPaymentTree(ObservableList<LastPayment> list) {
        this.list = list;
        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new Cell());
        list.addListener(this::onItemsChanged);
    }

    private void onItemsChanged(ListChangeListener.Change<? extends LastPayment> change) {
        getRoot().getChildren().clear();
        addItems();
    }

    private void addItems() {
        TreeItem<LastPayment> node = null;
        boolean hasIt = false;

        for (LastPayment item : list) {
            for (var branch : getRoot().getChildren()) {
                if (branch.getValue().getPlot().equals(item.getPlot())) {
                    var value = branch.getValue();
                    value.setAmount(value.getAmount() + item.getAmount());
                    node = branch;
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                var newItem = new LastPayment() {{
                    setPlot(item.getPlot());
                    setAmount(item.getAmount());
                }};
                node = new TreeItem<>(newItem) {{setExpanded(true);}};
                getRoot().getChildren().add(node);
            }
            node.getChildren().add(new TreeItem<>(item));
            hasIt = false;
        }
    }

    private class Cell extends WrapTreeCellBase<LastPayment> {
        private Text name, amount;
        private TextFlow nameFlow;
        private SVGIcon icon;
        private ColumnConstraints firstColumn;

        @Override
        protected void initializeUI() {
            name = new Text() {{setFill(Color.WHITE);}};
            icon = new SVGIcon(Icons.Cash);
            amount = new Text() {{setFill(Color.WHITE);}};
            nameFlow = new TextFlow(name);

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(35) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(65) {{setHalignment(HPos.RIGHT);}}
                );
                add(nameFlow, 0, 0);
                add(icon, 1, 0);
                add(amount, 2, 0);
            }};
        }

        @Override
        protected void resetValues(LastPayment oldValue) {
            name.setText(null);
            amount.setText(null);
            root.setBorder(null);
            icon.setVisible(true);
        }

        @Override
        protected void setValues(LastPayment newValue) {
            var size = item.getParent().getChildren().size();
            amount.setText(Helper.formatNumber(newValue.getAmount()));
            if (level == 1) {
                name.setText(newValue.getPlot());
                icon.setVisible(false);
            }
            else {
                name.setText(newValue.getSpace());
                if (size == 1) {
                    root.setBorder(Constants.DoubleBorder);
                }
                else {
                    var index = item.getParent().getChildren().indexOf(item);
                    if (index == 0) root.setBorder(Constants.TopBorder);
                    else if (index == item.getParent().getChildren().size() - 1) root.setBorder(Constants.BottomBorder);
                }
                switch (newValue.getIsCash()) {
                    case 0 -> {
                        icon.setFill(Color.LIGHTGREEN);
                        icon.setContent(Icons.Cash);
                    }
                    case 1 -> {
                        icon.setFill(Color.LIGHTCORAL);
                        icon.setContent(Icons.NonCash);
                    }
                    case 2 -> {
                        icon.setFill(Color.DODGERBLUE);
                        icon.setContent(Icons.Mobile);
                    }
                }
            }
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 35 - 65;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            nameFlow.setPrefWidth(remainder);
            return nameFlow.prefHeight(remainder);
        }
    }
}
