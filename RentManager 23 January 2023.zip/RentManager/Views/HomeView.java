package Views;

import Views.Home.*;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.util.ArrayList;
import java.util.List;

public class HomeView extends View {
    private final View counts; // what's the point of these final?
    private final View plotDue;
    private final View plotRent;
    private final View rent;
    private final View rentDetail;
    private final View tenantDetail;

    public HomeView() {
        counts = new Counts();
        rent = new Rent();

        plotDue = new PlotDue();
        plotRent = new PlotRent();

        rentDetail = new RentDetail();
        tenantDetail = new TenantDetail();
    }

    @Override
    protected String getIcon() {
        return Icons.Home;
    }

    @Override
    protected String getTip() {
        return "Home";
    }
    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public List<View> initialViews() {
        super.views = new ArrayList<>();
        views.add(counts);
        views.add(rent);

        views.add(plotDue);
        views.add(plotRent);

        views.add(rentDetail);
        views.add(tenantDetail);
        return super.views;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        setCenter(new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setPercentWidth(33.33);}},
                    new ColumnConstraints(){{ setPercentWidth(33.33);}},
                    new ColumnConstraints(){{ setPercentWidth(33.34);}}
            );
            getRowConstraints().addAll(
                    new RowConstraints(){{setPercentHeight(50);}},
                    new RowConstraints(){{setPercentHeight(50);}}
            );
            add(counts, 0, 0);
            add(rent, 0, 1);
            add(plotRent, 1, 0);
            add(rentDetail, 1, 1);
            add(plotDue, 2, 0);
            add(tenantDetail, 2, 1);

            setVgap(Constants.CardMargin);
            setHgap(Constants.CardMargin);
            setPadding(new Insets(Constants.CardMargin));
        }});
    }
}
