package Views.Add;

import Models.ControlHead;
import Models.Head;
import ViewModels.Add.AddHeadVM;
import abstracts.View;
import controls.SelectionBox;
import controls.buttons.CommandButton;
import controls.texts.TextBox;
import controls.texts.TextBoxMultiLine;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class AddHead extends AddBase {
    private AddHeadVM vm;
    private SelectionBox<ControlHead> control;
    private TextBox name;
    private TextBoxMultiLine description;

    @Override
    protected String getHeader() {
        return "Head";
    }

    @Override
    protected Node getUI() {
        viewModel =  vm = new AddHeadVM();
        control = new SelectionBox<>("Control", Icons.ControlHead, vm.list, true);
        name = new TextBox("Name", Icons.Head, true);
        description = new TextBoxMultiLine("Description", Icons.Description, true);

        return new VBox(control, name, description){{
            setSpacing(5);
            setPadding(new Insets(5, 0, 0, 0));
            setAlignment(Pos.CENTER_RIGHT);
            setVgrow(description, Priority.ALWAYS);
        }};
    }

    @Override
    protected void bind(){
        vm.head.controlIdProperty().bind(control.selectedValueProperty());
        name.textProperty().bindBidirectional(vm.head.nameProperty());
        name.errorProperty().bind(vm.nameErrorProperty);
        description.textProperty().bindBidirectional(vm.head.descriptionProperty());

        add.disableProperty().bind(control.isEmpty()
                .or(vm.nameExists)
                .or(description.isEmpty())
        );
    }
}
