package Views.Add;

import Models.Plot;
import ViewModels.Add.AddPlotVM;
import controls.texts.TextBox;
import controls.texts.TextBoxMultiLine;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class AddPlot extends AddBase {
    private AddPlotVM vm;
    private TextBox name;
    private TextBoxMultiLine address;

    @Override
    protected String getHeader() {
        return "Plot";
    }

    @Override
    protected Node getUI() {
        viewModel = vm = new AddPlotVM();
        name = new TextBox("Name", Icons.Plot, true);
        address = new TextBoxMultiLine("Address", Icons.Description, true);
        return new VBox(name, address){{
            setSpacing(5);
            setPadding(new Insets(5, 0, 0, 0));
            setVgrow(address, Priority.ALWAYS);
            setAlignment(Pos.CENTER_RIGHT);
        }};
    }

    @Override
    protected void bind(){
        name.textProperty().bindBidirectional(vm.plot.nameProperty());
        name.errorProperty().bind(vm.nameErrorProperty);
        address.textProperty().bindBidirectional(vm.plot.descriptionProperty());
        add.disableProperty().bind(vm.nameExists.or(address.isEmpty()));
    }
}
