package Enums;

public enum DepositDueRentState {
    Rent,
    Deposit,
    Due
}
