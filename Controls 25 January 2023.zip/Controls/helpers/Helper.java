package helpers;

import java.text.DecimalFormat;

public class Helper {
    private static final DecimalFormat format = new DecimalFormat("#,##0;(#,##0)");

    public static String formatNumber(int number){
        if(number == 0) return "   -  ";
        return format.format(number);
    }
}
