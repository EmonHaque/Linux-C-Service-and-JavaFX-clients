package skinned;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.ListView;
import javafx.scene.control.Skin;
import skins.ExtendedListViewSkin;

public class ExtendedListView<T> extends ListView<T> {
    public ExtendedListView(){
        super();
        setBackground(null);
        setPadding(new Insets(0));
    }
    public ExtendedListView(ObservableList<T> list) {
        super(list);
        setBackground(null);
        setPadding(new Insets(0));
    }
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedListViewSkin<>(this);
    }

    public BooleanBinding isEmpty(){ return Bindings.isEmpty(getItems()); }
}