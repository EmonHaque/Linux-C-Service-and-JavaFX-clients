package model;

public class HorizontalSeries {
    private String title;
    private double value1;
    private double value2;
    private double value3;
    
    public HorizontalSeries(String title, double value1, double value2, double value3) {
        this.title = title;
        this.value1 = value1;
        this.value2 = value2;
        this.value3 = value3;
    }

    public String getTitle() {
        return title;
    }

    public double getValue1() {
        return value1;
    }

    public double getValue2() {
        return value2;
    }

    public double getValue3() {
        return value3;
    }
    @Override
    public String toString() {
        return "v1: " + value1 + " v2: " + value2 + " v3: " + value3 + " - " + title;
    }
}
