package controls.texts;

import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

import java.util.ArrayList;
import java.util.List;

public class HiTexts extends TextFlow {
    private final List<Text> items;
    private final StringProperty queryProperty;

    public HiTexts(Text ... texts) {
        items = new ArrayList<>();
        queryProperty = new SimpleStringProperty("");
        queryProperty.addListener(this::onQueryChanged);
        for(var node : texts){
            items.add(node);
            getChildren().add(node);
            node.textProperty().addListener(this::onTextChanged);
        }
    }

    public StringProperty queryProperty() { return queryProperty; }

    private void onTextChanged(Observable o, String ov, String nv){
        var q = queryProperty.get();
        if(q == null || q.isEmpty() || q.isBlank()) return;
        onQueryChanged(null, null, q);
    }

    private void onQueryChanged(ObservableValue<?> o, String ov, String newValue){
        getChildren().clear();
        if (newValue == null || newValue.isEmpty() || newValue.isBlank()){
            getChildren().addAll(items);
            return;
        }
        for (var segment : items) {
            int index = 0;
            var filter = newValue.toLowerCase();
            int filterLength = filter.length();
            var text = segment.getText().toLowerCase();

            for (int i = text.indexOf(filter); i > -1; i = text.indexOf(filter, i + 1)) {
                var unmatchedContent = segment.getText().substring(index, i);
                if (unmatchedContent.length() > 0) {
                    var unmatched = new Text(unmatchedContent);
                    unmatched.setFill(segment.getFill());
                    unmatched.setFont(segment.getFont());
                    getChildren().add(unmatched);
                }
                var match = new Text(segment.getText().substring(i, i + filterLength));
                match.setFill(Color.CORNFLOWERBLUE);
                match.setFont(Font.font(null, FontWeight.BOLD, 12));
                match.setUnderline(true);
                getChildren().add(match);
                index = i + filterLength;
            }
            if (index < text.length()) {
                var unmatched = new Text(segment.getText().substring(index));
                unmatched.setFill(segment.getFill());
                unmatched.setFont(segment.getFont());
                getChildren().add(unmatched);
            }
        }
    }
}
