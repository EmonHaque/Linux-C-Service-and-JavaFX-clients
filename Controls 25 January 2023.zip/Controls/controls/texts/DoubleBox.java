package controls.texts;

import java.text.DecimalFormat;
import java.text.ParsePosition;

import javafx.scene.control.TextFormatter;

public class DoubleBox extends TextBox {
    DecimalFormat numberFormat;

    public DoubleBox(String hint, String icon, boolean isRequired) {
        super(hint, icon, isRequired);
        numberFormat = new DecimalFormat("#.0");
        
        input.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getControlNewText().isEmpty()) {
                return change;
            }
            var position = new ParsePosition(0);
            var obj = numberFormat.parseObject(change.getControlNewText(), position);
            if (obj != null && position.getIndex() == change.getControlNewText().length()) {
                return change;
            }
            return null;
        }));
    }

}
