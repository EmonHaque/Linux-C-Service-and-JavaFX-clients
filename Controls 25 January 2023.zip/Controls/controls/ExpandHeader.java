package controls;

import controls.states.ExpandedState;
import helpers.Constants;
import javafx.beans.property.BooleanProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class ExpandHeader extends HBox {
    private final ExpandedState isExpanded;

    public ExpandHeader(String text, boolean isExpanded) {
        this.isExpanded = new ExpandedState(isExpanded);
        getChildren().add(this.isExpanded);
        getChildren().add(new Text(text){{ setFill(Color.WHITE); setFont(Font.font(null, FontWeight.BOLD, - 1));}});
        setSpacing(Constants.CellPadding);
        setAlignment(Pos.CENTER_LEFT);
        //setMargin(this.isExpanded, new Insets(0, 0, 2, 0));
    }

    public BooleanProperty isExpandedProperty(){ return isExpanded.isExpandedProperty; }
}
