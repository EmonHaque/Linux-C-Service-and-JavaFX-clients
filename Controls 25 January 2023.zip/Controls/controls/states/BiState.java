package controls.states;

import controls.SVGIcon;
import helpers.Icons;
import javafx.animation.Animation;
import javafx.animation.FillTransition;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class BiState extends GridPane {
    private final SVGIcon icon;
    private Text textLabel;
    public BooleanProperty isCheckedProperty;
    private final FillTransition anim;
    private Color original;
    public BiState(boolean isChecked) {
        if (isChecked) {
            icon = new SVGIcon(Icons.CheckCircle);
            icon.setFill(Color.LIGHTGREEN);
        }
        else {
            icon = new SVGIcon(Icons.CloseCircle);
            icon.setFill(Color.LIGHTCORAL);
        }
        icon.setMouseTransparent(true);
        addColumn(0, icon);
        setHgap(5);
        isCheckedProperty = new SimpleBooleanProperty();
        isCheckedProperty.addListener(this::onCheckedChanged);
        isCheckedProperty.set(isChecked);

        setOnMouseClicked(e -> isCheckedProperty.set(!isCheckedProperty.get()));
        anim = new FillTransition(Duration.millis(250), icon.getShape());

        setOnMouseEntered(e ->{
            original = (Color) icon.getShape().getFill();
            animate(Color.CORNFLOWERBLUE);
        });
        setOnMouseExited(e -> animate(original));
    }

    private void animate(Color color){
        if(anim.getStatus() == Animation.Status.RUNNING) anim.stop();
        anim.setToValue(color);
        anim.play();
    }

    public BiState(boolean isChecked, String text) {
        this(isChecked);
        textLabel = new Text(text);
        textLabel.setFill(Color.WHITE);
        textLabel.setMouseTransparent(true);
        addColumn(1, textLabel);
    }

    private void onCheckedChanged(ObservableValue<?> obs, boolean oldValue, boolean newValue) {
        if (newValue) {
            icon.setContent(Icons.CheckCircle);
            original = Color.LIGHTGREEN;

        }
        else {
            icon.setContent(Icons.CloseCircle);
            original = Color.LIGHTCORAL;
        }
        icon.setFill(original);
    }

    public void setChecked(boolean value) {
        isCheckedProperty.set(value);
    }

    public StringProperty textProperty() {
        // null if you don't give it text in constructor
        return textLabel.textProperty();
    }
}
