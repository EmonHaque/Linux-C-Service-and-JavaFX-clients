package editables;

import controls.buttons.CommandButton;
import helpers.Icons;
import interfaces.IExecute;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public class EditPane extends BorderPane {
    private boolean isLoaded, isCancelled;
    private final CommandButton edit, cancel, save;
    private final BooleanProperty isOnEditProperty, canEditProperty;

    public EditPane(IExecute saveAction) {
        isOnEditProperty = new SimpleBooleanProperty();
        canEditProperty = new SimpleBooleanProperty();
        edit = new CommandButton(Icons.Pencil, 16, "edit") {{
            visibleProperty().bind(canEditProperty.and(isOnEditProperty.not()));
            setAction(() -> isOnEditProperty.set(true));
        }};
        cancel = new CommandButton(Icons.CloseCircle, 16, "cancel") {{
            visibleProperty().bind(isOnEditProperty);
            setAction(() -> {
                isCancelled = true;
                isOnEditProperty.set(false);
            });
        }};
        save = new CommandButton(Icons.CheckCircle, 16, "save") {{
            visibleProperty().bind(isOnEditProperty);
            setAction(() -> {
                saveAction.execute();
                isCancelled = false;
                isOnEditProperty.set(false);
            });
        }};
        var grid = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints(),
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS); setHalignment(HPos.RIGHT);}}
            );
            add(save, 0, 0);
            add(cancel, 1, 0);
            add(edit, 1, 0);
            setPadding(new Insets(5, 0, 0, 0));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0))));
            visibleProperty().bind(canEditProperty);
        }};
        setBottom(grid);
    }

    public BooleanProperty canEditProperty() {return canEditProperty;}

    public BooleanProperty isOnEditProperty() {return isOnEditProperty;}

    public void setCanEdit(boolean value){
        canEditProperty.set(value);
    }
    public void setIsOnEdit(boolean value){
        isOnEditProperty.set(value);
    }

    public boolean canEdit(){return canEditProperty.get();}
    public boolean onEdit(){return isOnEditProperty.get();}
    public boolean isCancelled() { return  isCancelled; }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();

        if(isLoaded) return;
        isLoaded = true;
        visibleProperty().bind(canEditProperty);
    }
}
