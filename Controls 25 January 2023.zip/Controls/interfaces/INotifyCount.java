package interfaces;

import javafx.beans.property.IntegerProperty;

public interface INotifyCount {
    IntegerProperty countProperty();
}
