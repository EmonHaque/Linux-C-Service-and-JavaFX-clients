package abstracts;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;

import java.util.List;

public abstract class DualAxisChartBase<T> extends Region {
    private final Text leftTitle, rightTitle;
    private final FadeTransition y1Anim, y2Anim;
    private final ScaleTransition yMajorAnim;
    private final Group yMajors;
    private final StackPane noInfo;

    protected final int numLines = 6;
    protected final Group xLabels, y1Labels, y2Labels;
    protected double y1Min, y1Max, y2Min, y2Max, xLabelWidth, y1LabelWidth, y2LabelWidth, availableHeight, availableWidth, startX;
    protected List<T> series;

    public ObjectProperty<List<T>> seriesProperty;

    public DualAxisChartBase(String y1Title, String y2Title) {
        y1Labels = new Group() {{setManaged(false); setMouseTransparent(true);}};
        y2Labels = new Group() {{setManaged(false); setMouseTransparent(true);}};
        yMajors = new Group() {{setManaged(false); setMouseTransparent(true);}};
        xLabels = new Group() {{setManaged(false); setMouseTransparent(true);}};
        addYs();
        leftTitle = getLabel(y1Title, -90);
        rightTitle = getLabel(y2Title, 90);


        y1Anim = new FadeTransition(Duration.millis(500), y1Labels);
        y2Anim = new FadeTransition(Duration.millis(500), y2Labels);
        yMajorAnim = new ScaleTransition(Duration.millis(500), yMajors);

        y1Anim.setDelay(Duration.millis(500));
        y1Anim.setToValue(1);

        y2Anim.setDelay(Duration.millis(500));
        y2Anim.setToValue(1);

        yMajorAnim.setToY(1);

        seriesProperty = new SimpleObjectProperty<>();
        seriesProperty.addListener(this::onSeriesChanged);

        noInfo = new StackPane(){{
            setManaged(false);
            setMouseTransparent(true);
            getChildren().add(new Text("No data\navailable") {{
                setTextAlignment(TextAlignment.CENTER);
                setFill(Color.GRAY);
                setFont(Font.font(null, FontWeight.BOLD, 16));
            }});
        }};
    }

    private Text getLabel(String content, double angle){
        return new Text(content) {{
            setFill(Color.LIGHTGRAY);
            setFont(Font.font(null, FontWeight.BOLD, 14));
            setRotate(angle);
            setOpacity(0);
            setManaged(false);
            setMouseTransparent(true);
        }};
    }

    private void onBoundsChanged(Observable o){
        noInfo.resize(getWidth(), getHeight());
    }

    protected void onSeriesChanged(ObservableValue<?> o, List<T> ov, List<T> nv) {
        layoutBoundsProperty().removeListener(this::onBoundsChanged);
        getChildren().clear();
        if (nv == null || nv.size() == 0) {
            getChildren().add(noInfo);
            noInfo.resize(getWidth(), getHeight());
            layoutBoundsProperty().addListener(this::onBoundsChanged);
            return;
        }

        xLabels.getChildren().clear();
        getChildren().addAll(xLabels, leftTitle, y1Labels, rightTitle, y2Labels, yMajors);
        yMajors.setScaleY(0);
        y1Labels.setOpacity(0);
        y2Labels.setOpacity(0);
        rightTitle.setOpacity(0);
        leftTitle.setOpacity(0);

        y1Min = y2Min = 0;
        y1Max = y2Max = 0;
        xLabelWidth = 0;

        if(nv != null){
            series = nv;
            rightTitle.setOpacity(1);
            leftTitle.setOpacity(1);

            reset();
            setMinMaxAndXLabels();

            Platform.runLater(() ->{
                // if you've more than one subclass of this and all calls these at the same time
                // some will fail to animate if you don't wrap these in Platform.runLater
                yMajorAnim.play();
                y1Anim.play();
                y2Anim.play();
            });

        }
    }

    private void addYs() {
        for (int i = 0; i < numLines; i++) {
            var line = new Line() {{
                setStroke(Color.GRAY);
                getStrokeDashArray().addAll(5d, 2d);
                setManaged(false);
                setMouseTransparent(true);
            }};
            var y1Label = new Text() {{
                setFill(Color.WHITE);
                setManaged(false);
                setMouseTransparent(true);
            }};
            var y2Label = new Text() {{
                setFill(Color.WHITE);
                setManaged(false);
                setMouseTransparent(true);
            }};
            yMajors.getChildren().add(line);
            y1Labels.getChildren().add(y1Label);
            y2Labels.getChildren().add(y2Label);
        }
    }

    protected abstract void setMinMaxAndXLabels();
    protected abstract void reset();

    @Override
    protected void layoutChildren() {
        var height = getHeight();
        var width = getWidth();
        double margin = 5;

        var leftTitleWidth = leftTitle.prefHeight(-1);
        var rightTitleWidth = rightTitle.prefHeight(-1);

        startX = leftTitleWidth + y1LabelWidth + margin;
        availableHeight = height - xLabelWidth;
        availableWidth = width - leftTitleWidth - y1LabelWidth - y2LabelWidth - rightTitleWidth - 2 * margin;
        var vSpace = availableHeight / (numLines - 1);

        double lineY = availableHeight;

        for (int i = 0; i < numLines; i++) {
            var line = (Line) yMajors.getChildren().get(i);
            var y1 = (Text) y1Labels.getChildren().get(i);
            var text = (Text) y2Labels.getChildren().get(i);

            var labelY = lineY - 2;
            var endX = width - rightTitleWidth;

            line.setStartX(leftTitleWidth);
            line.setEndX(endX);
            line.setStartY(lineY);
            line.setEndY(lineY);

            y1.setX(leftTitleWidth);
            y1.setY(labelY);

            text.setX(endX - text.prefWidth(-1));
            text.setY(labelY);

            lineY -= vSpace;
        }
        leftTitle.setTranslateX(-leftTitle.prefWidth(-1) / 2);
        leftTitle.setTranslateY(availableHeight / 2 - leftTitleWidth / 2);

        rightTitle.setTranslateX(width - rightTitle.prefWidth(-1) / 2);
        rightTitle.setTranslateY(availableHeight / 2 - rightTitleWidth / 2);

    }
}
