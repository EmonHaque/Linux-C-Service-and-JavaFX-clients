package trees;

import Models.Balance;
import abstracts.WrapTreeCellBase;
import controls.texts.HiTexts;
import helpers.Constants;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.HPos;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

import java.util.Comparator;
import java.util.List;

public class BalanceTree extends ExtendedTreeView<Balance> {
    public final BooleanProperty itemsChangedProperty, isExpandedProperty;

    public BalanceTree(FilteredList<Balance> balances, StringProperty query) {
        addItems(balances);
        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new BalanceCell(query));
        balances.addListener(this::onItemsChanged);

        itemsChangedProperty = new SimpleBooleanProperty();
        isExpandedProperty = new SimpleBooleanProperty();
        isExpandedProperty.addListener(this::onIsExpandedChanged);
    }

    private void onIsExpandedChanged(ObservableValue<?> o, boolean ov, boolean nv) {
        for (var tenant : getRoot().getChildren()) {
            if(tenant.getChildren().size() > 0)
                tenant.setExpanded(nv);
        }
    }

    private void onItemsChanged(ListChangeListener.Change<? extends Balance> change) {
        while (change.next()) {
            if (change.wasAdded()) {
                if (change.getRemovedSize() > 0) {
                    removeItems((List<Balance>) change.getRemoved());
                }
                addItems((List<Balance>) change.getAddedSubList());
            }
            if (change.wasRemoved()) {
                removeItems((List<Balance>) change.getRemoved());
            }
        }
        removeSingle();
        sort(getRoot());
        itemsChangedProperty.set(!itemsChangedProperty.get());
    }

    private void addItems(List<Balance> balances) {
        for (var balance : balances) {
            var hasIt = false;
            TreeItem<Balance> tenant = null;
            for (var item : getRoot().getChildren()) {
                if (item.getValue().getTenant().equals(balance.getTenant())) {
                    tenant = item;
                    var value = tenant.getValue();

                    if (value.getSpace() != null) {
                        tenant.getChildren().add(new TreeItem<>(value));
                        var newValue = new Balance() {{
                            setTenant(value.getTenant());
                            setDue(value.getDue() + balance.getDue());
                            setRent(value.getRent() + balance.getRent());
                            setSecurity(value.getSecurity() + balance.getSecurity());
                        }};
                        tenant.setValue(newValue);
                    }
                    else {
                        value.setDue(value.getDue() + balance.getDue());
                        value.setRent(value.getRent() + balance.getRent());
                        value.setSecurity(value.getSecurity() + balance.getSecurity());
                    }
                    hasIt = true;
                }
            }
            if (!hasIt) {
                tenant = new TreeItem<>(new Balance() {{
                    setTenant(balance.getTenant());
                    setRent(balance.getRent());
                    setDue(balance.getDue());
                    setSecurity(balance.getSecurity());
                }});
                tenant.setExpanded(true);
                getRoot().getChildren().add(tenant);
            }
            tenant.getChildren().add(new TreeItem<>(balance));
        }
    }

    private void removeItems(List<Balance> balances) {
        for (var balance : balances) {
            TreeItem<Balance> tenant = null;
            TreeItem<Balance> leaf = null;
            var found = false;
            for (var group : getRoot().getChildren()) {
                if (group.getValue().getDateStart() == null) {
                    for (var item : group.getChildren()) {
                        if (!item.getValue().equals(balance)) continue;
                        leaf = item;
                        found = true;
                        break;
                    }
                    if (found) {
                        tenant = group;
                        break;
                    }
                }
                else {
                    var value = group.getValue();
                    if (value.getTenant().equals(balance.getTenant())
                            && value.getSpace().equals(balance.getSpace())
                            && value.getDateStart().equals(balance.getDateStart())) {
                        tenant = group;
                        break;
                    }
                }
            }

            if (leaf != null) {
                tenant.getChildren().remove(leaf);
                var value = tenant.getValue();
                value.setDue(value.getDue() - leaf.getValue().getDue());
                value.setRent(value.getRent() - leaf.getValue().getRent());
                value.setSecurity(value.getSecurity() - leaf.getValue().getSecurity());
                if (tenant.getChildren().size() == 0) getRoot().getChildren().remove(tenant);
            }
            else {
                getRoot().getChildren().remove(tenant);
            }
        }
    }

    private void removeSingle() {
        for (var item : getRoot().getChildren()) {
            if (item.getChildren().size() > 1) {
                item.setExpanded(isExpandedProperty.get());
                continue;
            }
            if (item.getChildren().size() == 0) continue;

            var single = item.getChildren().get(0);
            item.setValue(single.getValue());
            item.getChildren().remove(single);
        }
    }

    private void sort(TreeItem<Balance> node) {
        node.getChildren().sort(
                Comparator.comparing(x -> ((TreeItem<Balance>) x).getChildren().size()).reversed()
                        .thenComparing(x -> ((TreeItem<Balance>) x).getValue().getTenant())
                        .thenComparing(x -> ((TreeItem<Balance>) x).getValue().getSpace())
        );

        for (var item : node.getChildren()) sort(item);
    }

    private class BalanceCell extends WrapTreeCellBase<Balance> {
        private HiTexts flow;
        private Text tenant, space, from, security, rent, due;
        private Border topBorder, bottomBorder;
        private Font normal, bold;
        private final StringProperty query;
        private ColumnConstraints firstColumn;

        public BalanceCell(StringProperty query) {
            this.query = query;
        }

        @Override
        protected void initializeUI() {
            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0)));
            bottomBorder = Constants.BottomLine;

            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            tenant = new Text() {{setFill(Color.WHITE);}};
            space = new Text() {{setFill(Color.WHITE);}};
            from = new Text() {{setFill(Color.WHITE);}};
            security = new Text() {{setFill(Color.WHITE);}};
            rent = new Text() {{setFill(Color.WHITE);}};
            due = new Text() {{setFill(Color.WHITE);}};

            flow = new HiTexts(tenant, space);

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(100) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}}
                );
                add(flow, 0, 0);
                add(from, 1, 0);
                add(security, 2, 0);
                add(rent, 3, 0);
                add(due, 4, 0);
            }};
        }

        @Override
        protected void resetValues(Balance oldValue) {
            tenant.setText("");
            space.setText("");
            from.setText("");
            security.setText("");
            rent.setText("");
            due.setText("");

            flow.queryProperty().unbind();
            flow.queryProperty().set("");

            root.setBorder(null);
            security.setFont(normal);
            rent.setFont(normal);
            due.setFont(normal);
        }

        @Override
        protected void setValues(Balance newValue) {
            var size = item.getChildren().size();
            if (level == 1) {
                tenant.setText(newValue.getTenant());
                tenant.setFont(bold);

                if (size == 0) {
                    space.setVisible(true);
                    from.setVisible(true);
                    space.setText(" - " + newValue.getSpace());
                    from.setText(newValue.getDateStart());
                }
                else {
                    space.setVisible(false);
                    from.setVisible(false);
                    security.setFont(bold);
                    rent.setFont(bold);
                    due.setFont(bold);
                }
            }
            else {
                var parent = item.getParent();
                int index = parent.getChildren().indexOf(item);
                if (index == 0) root.setBorder(topBorder);
                else if (index == parent.getChildren().size() - 1) root.setBorder(bottomBorder);

                space.setVisible(true);
                from.setVisible(true);

                if (newValue.isExpired()) {
                    space.setText(newValue.getSpace() + " expired on " + newValue.getDateEnd());
                }
                else {
                    space.setText(newValue.getSpace());
                }
                from.setText(newValue.getDateStart());
            }
            security.setText(AppData.formatNumber(newValue.getSecurity()));
            rent.setText(AppData.formatNumber(newValue.getRent()));
            due.setText(AppData.formatNumber(newValue.getDue()));
            flow.queryProperty().bind(query);
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 100 - 3 * 80;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            flow.setPrefWidth(remainder);
            return flow.prefHeight(remainder);
        }
    }
}
