package trees;

import Models.LastDue;
import abstracts.WrapTreeCellBase;
import helpers.Constants;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

public class LastSecurityDueTree extends ExtendedTreeView<LastDue> {
    private final ObservableList<LastDue> list;

    public LastSecurityDueTree(ObservableList<LastDue> list) {
        this.list = list;
        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new Cell());
        list.addListener(this::onItemsChanged);
        setBorder(Constants.BottomLine);
    }

    private void onItemsChanged(ListChangeListener.Change<? extends LastDue> change) {
        getRoot().getChildren().clear();
        addItems();
    }

    private void addItems() {
        TreeItem<LastDue> node = null;
        boolean hasIt = false;

        for (var item : list) {
            for (var branch : getRoot().getChildren()) {
                if (branch.getValue().getPlot().equals(item.getPlot())) {
                    var value = branch.getValue();
                    value.setSecurity(value.getSecurity() + item.getSecurity());
                    value.setDue(value.getDue() + item.getDue());
                    node = branch;
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                var newItem = new LastDue() {{
                    setPlot(item.getPlot());
                    setSecurity(item.getSecurity());
                    setDue(item.getDue());
                }};
                node = new TreeItem<>(newItem) {{setExpanded(true);}};
                getRoot().getChildren().add(node);
            }
            node.getChildren().add(new TreeItem<>(item));
            hasIt = false;
        }
    }

    private class Cell extends WrapTreeCellBase<LastDue> {
        private Text name, security, due;
        private TextFlow nameFlow;
        private Border topBorder, doubleBorder;
        private ColumnConstraints firstColumn;

        @Override
        protected void initializeUI() {
            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0)));
            doubleBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0.25, 0)));

            name = new Text() {{setFill(Color.WHITE);}};
            security = new Text() {{setFill(Color.WHITE);}};
            due = new Text() {{setFill(Color.WHITE);}};
            nameFlow = new TextFlow(name);

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(65) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(65) {{setHalignment(HPos.RIGHT);}}
                );
                add(nameFlow, 0, 0);
                add(security, 1, 0);
                add(due, 2, 0);
            }};
        }

        @Override
        protected void resetValues(LastDue oldValue) {
            name.setText(null);
            security.setText(null);
            due.setText(null);
            root.setBorder(null);
        }

        @Override
        protected void setValues(LastDue newValue) {
            var size = item.getParent().getChildren().size();

            name.setText(level == 1 ? newValue.getPlot() : newValue.getSpace());
            security.setText(AppData.formatNumber(newValue.getSecurity()));
            due.setText(AppData.formatNumber(newValue.getDue()));

            if (level == 2) {
                if (size == 1) root.setBorder(doubleBorder);
                else {
                    var index = item.getParent().getChildren().indexOf(item);
                    if (index == 0) root.setBorder(topBorder);
                    else if (index == item.getParent().getChildren().size() - 1) root.setBorder(Constants.BottomLine);
                }
            }
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 2 * 65;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            nameFlow.setPrefWidth(remainder);
            return nameFlow.prefHeight(remainder);
        }
    }
}
