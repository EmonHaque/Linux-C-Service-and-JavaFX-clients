package trees;

import Models.MonthlyBalance;
import abstracts.WrapTreeCellBase;
import helpers.Constants;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

public class MonthlyBalanceTree extends ExtendedTreeView<MonthlyBalance> {
    public ListProperty<MonthlyBalance> itemsProperty;
    public BooleanProperty isExpandedProperty;

    public MonthlyBalanceTree() {
        itemsProperty = new SimpleListProperty<>();
        isExpandedProperty = new SimpleBooleanProperty();
        itemsProperty.addListener(this::onItemsChanged);
        isExpandedProperty.addListener(this::onIsExpandedChanged);

        setRoot(new TreeItem<>());
        setShowRoot(false);
        setCellFactory(v -> new BalanceCell());
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    }

    private void onIsExpandedChanged(ObservableValue<?> o, boolean ov, boolean nv) {
        for (var plot : getRoot().getChildren()) {
            plot.setExpanded(!plot.isExpanded());
        }
    }

    private void onItemsChanged(ObservableValue<?> o, ObservableList<MonthlyBalance> ov, ObservableList<MonthlyBalance> nv) {
        getRoot().getChildren().clear();
        if (nv == null) return;

        for (var balance : nv) {
            var hasIt = false;
            TreeItem<MonthlyBalance> item = null;
            for (var tree : getRoot().getChildren()) {
                if (tree.getValue().getPlot().equals(balance.getPlot())) {
                    item = tree;
                    var value = item.getValue();
                    value.setPayment(balance.getPayment() + value.getPayment());
                    value.setShortOrLong(balance.getShortOrLong() + value.getShortOrLong());
                    value.setDue(balance.getDue() + value.getDue());
                    value.setLastMonthDue(balance.getLastMonthDue() + value.getLastMonthDue());
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                var newItem = new MonthlyBalance() {{
                    setPlot(balance.getPlot());
                    setPayment(balance.getPayment());
                    setShortOrLong(balance.getShortOrLong());
                    setDue(balance.getDue());
                    setLastMonthDue(balance.getLastMonthDue());
                }};
                item = new TreeItem<>(newItem);
                item.setExpanded(isExpandedProperty.get());
                getRoot().getChildren().add(item);
            }
            var leaf = new TreeItem<>(balance);
            item.getChildren().add(leaf);
        }
    }

    public class BalanceCell extends WrapTreeCellBase<MonthlyBalance> {
        private Text particulars, date, due, lastDue, payment, shortOrLong;
        private TextFlow particularsFlow;
        private Font normal, bold;
        private Border topBorder, doubleBorder;
        private ColumnConstraints firstColumn;

        @Override
        protected void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);
            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0)));
            doubleBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0.25, 0)));
            particulars = new Text() {{setFill(Color.WHITE);}};
            date = new Text() {{setFill(Color.WHITE);}};
            due = new Text() {{setFill(Color.WHITE);}};
            lastDue = new Text() {{setFill(Color.WHITE);}};
            payment = new Text() {{setFill(Color.WHITE);}};
            shortOrLong = new Text() {{setFill(Color.WHITE);}};
            particularsFlow = new TextFlow(particulars);

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(80) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}}
                );
                add(particularsFlow, 0, 0);
                add(date, 1, 0);
                add(due, 2, 0);
                add(lastDue, 3, 0);
                add(payment, 4, 0);
                add(shortOrLong, 5, 0);
            }};
        }

        @Override
        protected void resetValues(MonthlyBalance oldValue) {
            particulars.setText(null);
            date.setText(null);
            due.setText(null);
            lastDue.setText(null);
            payment.setText(null);
            shortOrLong.setText(null);
            root.setBorder(null);
        }

        @Override
        protected void setValues(MonthlyBalance newValue) {
            if (level == 1) {
                particulars.setText(newValue.getPlot() + " (" + item.getChildren().size() + ")");
                particulars.setFont(bold);
                due.setFont(bold);
                lastDue.setFont(bold);
                payment.setFont(bold);
                shortOrLong.setFont(bold);
            }
            else if (level == 2) {
                var ch = item.getParent().getChildren();
                var index = ch.indexOf(item);

                if (ch.size() == 1) root.setBorder(doubleBorder);
                else if (index == 0) root.setBorder(topBorder);
                else if (index == ch.size() - 1) root.setBorder(Constants.BottomLine);

                particulars.setText(newValue.getTenant());
                particulars.setFont(normal);
                due.setFont(normal);
                lastDue.setFont(normal);
                payment.setFont(normal);
                shortOrLong.setFont(normal);
                date.setText(newValue.getDate());
            }
            due.setText(AppData.formatNumber(newValue.getDue()));
            lastDue.setText(AppData.formatNumber(newValue.getLastMonthDue()));
            payment.setText(AppData.formatNumber(newValue.getPayment()));
            shortOrLong.setText(AppData.formatNumber(newValue.getShortOrLong()));
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 5 * 80;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            particularsFlow.setPrefWidth(remainder);
            return particularsFlow.prefHeight(remainder);
        }
    }
}
