package trees;

import Models.LeftOrJoined;
import abstracts.WrapTreeCellBase;
import helpers.Constants;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import ridiculous.AppData;
import skinned.ExtendedTreeView;

import java.util.function.Function;

public class LeftOrJoinedTree extends ExtendedTreeView<LeftOrJoined> {
    public ListProperty<LeftOrJoined> itemsProperty;
    public BooleanProperty isExpandedProperty;

    public LeftOrJoinedTree() {
        setRoot(new TreeItem<>());
        setShowRoot(false);
        getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        setCellFactory(v -> new LeftOrJoinedCell());
        itemsProperty = new SimpleListProperty<>();
        isExpandedProperty = new SimpleBooleanProperty();
        itemsProperty.addListener(this::onItemsChanged);

        isExpandedProperty.addListener(o -> {
            var value = isExpandedProperty.get();
            for (var item : getRoot().getChildren()) {
                resetExpandState(item, value);
            }
        });
    }

    private void resetExpandState(TreeItem<LeftOrJoined> node, boolean value) {
        node.setExpanded(!node.isExpanded());
        for (var item : node.getChildren()) {
            if (item.isLeaf()) continue;
            resetExpandState(item, node.isExpanded());
        }
    }

    private void onItemsChanged(ObservableValue<?> o, ObservableList<LeftOrJoined> ov, ObservableList<LeftOrJoined> nv) {
        getRoot().getChildren().clear();
        for (var item : nv) addItem(getRoot(), item);
        removeSingleLeaf();
    }

    private void addItem(TreeItem<LeftOrJoined> node, LeftOrJoined entry) {
        var level = getTreeItemLevel(node);
        var hasIt = false;
        TreeItem<LeftOrJoined> item = null;
        Function<LeftOrJoined, Boolean> condition = x -> true;
        switch (level) {
            case 0 -> condition = e -> e.getStatus().equals(entry.getStatus());
            case 1 -> condition = e -> e.getPlot().equals(entry.getPlot());
            case 2 -> condition = e -> e.getTenant().equals(entry.getTenant());
        }
        for (var branch : node.getChildren()) {
            if (!condition.apply(branch.getValue())) continue;
            var value = branch.getValue();
            value.setReceivable(value.getReceivable() + entry.getReceivable());
            hasIt = true;
            item = branch;
            break;
        }
        if (!hasIt) {
            var newEntry = new LeftOrJoined() {{
                setStatus(entry.getStatus());
                setPlot(entry.getPlot());
                setTenant(entry.getTenant());
                setReceivable(entry.getReceivable());
            }};
            item = new TreeItem<>(newEntry);
            node.getChildren().add(item);
        }
        if (level == 2) item.getChildren().add(new TreeItem<>(entry));
        else addItem(item, entry);
    }

    private void removeSingleLeaf() {
        for (var leftOrJoined : getRoot().getChildren()) {
            for (var plot : leftOrJoined.getChildren()) {
                for (var tenant : plot.getChildren()) {
                    if (tenant.getChildren().size() > 1) continue;
                    var item = tenant.getChildren().get(0).getValue();
                    tenant.getChildren().clear();
                    tenant.getValue().setSpace(item.getSpace());
                    tenant.getValue().setDateStart(item.getDateStart());
                    tenant.getValue().setDateEnd(item.getDateEnd());
                }
            }
        }
    }

    private class LeftOrJoinedCell extends WrapTreeCellBase<LeftOrJoined> {
        private Font normal, bold;
        private Border topBorder, doubleBorder;
        private Text particulars, from, to, amount;
        private TextFlow particularsFlow;
        private ColumnConstraints firstColumn;

        @Override
        protected void initializeUI() {
            normal = Font.font(null, FontWeight.NORMAL, -1);
            bold = Font.font(null, FontWeight.BOLD, -1);

            topBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0)));
            doubleBorder = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0.25, 0)));

            particulars = new Text() {{setFill(Color.WHITE);}};
            from = new Text() {{setFill(Color.WHITE);}};
            to = new Text() {{setFill(Color.WHITE);}};
            amount = new Text() {{setFill(Color.WHITE);}};
            particularsFlow = new TextFlow(particulars);

            firstColumn = new ColumnConstraints();
            root = new GridPane() {{
                getColumnConstraints().addAll(
                        firstColumn,
                        new ColumnConstraints(90) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(90) {{setHalignment(HPos.CENTER);}},
                        new ColumnConstraints(80) {{setHalignment(HPos.RIGHT);}}
                );
                add(particularsFlow, 0, 0);
                add(from, 1, 0);
                add(to, 2, 0);
                add(amount, 3, 0);
            }};
        }

        @Override
        protected void resetValues(LeftOrJoined oldValue) {
            root.setBorder(null);
            particulars.setText(null);
            from.setText(null);
            to.setText(null);
            amount.setText(null);
            particulars.setFont(normal);
            amount.setFont(normal);
        }

        @Override
        protected void setValues(LeftOrJoined newValue) {
            if (level == 1) {
                int size = 0;
                for (var c : item.getChildren()) {
                    size += c.getChildren().size();
                }
                particulars.setFont(bold);
                amount.setFont(bold);
                particulars.setText(newValue.getStatus() + " (" + item.getChildren().size() + " - " + size + ")");
            }
            else if (level == 2) {
                particulars.setFont(bold);
                amount.setFont(bold);
                particulars.setText(newValue.getPlot() + " (" + item.getChildren().size() + ")");
            }
            else if (level == 3) {
                int size = item.getParent().getChildren().size();
                int index = item.getParent().getChildren().indexOf(item);

                if (size == 1) {
                    root.setBorder(item.getChildren().size() == 0 ? doubleBorder: topBorder);
                }
                else {
                    if (index == 0) root.setBorder(topBorder);
                    if (index == size - 1) root.setBorder(Constants.BottomLine);
                }
                if (item.getChildren().size() > 0) {
                    particulars.setText(newValue.getTenant());
                }
                else {
                    particulars.setText(newValue.getSpace() + " - " + newValue.getTenant());
                    from.setText(newValue.getDateStart());
                    to.setText(newValue.getDateEnd());
                }
            }
            else {
                int size = item.getParent().getChildren().size();
                int index = item.getParent().getChildren().indexOf(item);

                if (index == 0) root.setBorder(topBorder);
                if (index == size - 1) root.setBorder(Constants.BottomLine);

                particulars.setText(newValue.getSpace());
                from.setText(newValue.getDateStart());
                to.setText(newValue.getDateEnd());
            }
            amount.setText(AppData.formatNumber(newValue.getReceivable()));
        }

        @Override
        protected double setWrapWidthAndReturnDesiredHeight() {
            var remainder = getAvailableWidth() - 2 * 90 - 80;
            firstColumn.setPrefWidth(remainder);
            firstColumn.setMinWidth(remainder);
            firstColumn.setMaxWidth(remainder);
            particularsFlow.setPrefWidth(remainder);
            return particularsFlow.prefHeight(remainder);
        }
    }
}
