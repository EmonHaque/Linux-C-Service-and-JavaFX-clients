package Views.Transaction;

import CellTemplates.SelectionBox.TenantTemplate;
import CellTemplates.Visual.TenantVisual;
import Converters.IntToStringConverter;
import Models.ControlHead;
import Models.Head;
import Models.Tenant;
import ViewModels.Transaction.TransactionBaseVM;
import abstracts.View;
import controls.SelectionBox;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.daymonth.DayPicker;
import controls.states.MultiState;
import controls.texts.IntegerBox;
import controls.texts.TextBoxMultiLine;
import dialogs.ConfirmDialog;
import helpers.Constants;
import helpers.Icons;
import interfaces.IReturnNameAndId;
import interfaces.ISetSelectionBoxContent;
import javafx.beans.binding.Bindings;
import javafx.geometry.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import skinned.ExtendedSeparator;
import trees.LastPaymentTree;
import trees.LastSecurityDueTree;
import trees.TransactionEntryTree;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public abstract class TransactionBase<P extends IReturnNameAndId<P>, S extends IReturnNameAndId<S>> extends View {
    private TransactionBaseVM<P, S> vm;
    private SelectionBox<Tenant> tenant;
    private SelectionBox<P> plot;
    private SelectionBox<S> space;
    private SelectionBox<ControlHead> control;
    private SelectionBox<Head> head;
    private DayPicker date;
    private IntegerBox amount;
    private MultiState isCash;
    private TextBoxMultiLine narration;
    private TransactionEntryTree tree;
    private CommandButton addEntry, add;

    private GridPane entryGrid, infoGrid, depositDueHeader, paymentHeader;
    private LastSecurityDueTree dueTree;
    private LastPaymentTree paymentTree;

    private SpinningArc spinner;
    private Text status, paidOn;

    public abstract TransactionBaseVM<P, S> getViewModel();

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = getViewModel();
        initializeUI();
        bind();
    }

    protected ISetSelectionBoxContent<S> getVisual() {return null;}

    protected String getTemplate() {return null;}

    private void initializeUI() {
        tenant = new SelectionBox<>("Tenant", Icons.Tenant, vm.tenants, new TenantVisual(), TenantTemplate.class.getName(), true);
        plot = new SelectionBox<>("Plot", Icons.Plot, vm.plots, true);

        space = getVisual() == null ?
                new SelectionBox<>("Space", Icons.Space, vm.spaces, true) :
                new SelectionBox<>("Space", Icons.Space, vm.spaces, getVisual(), getTemplate(), true);

        control = new SelectionBox<>("Control", Icons.ControlHead, vm.controls, true);
        head = new SelectionBox<>("Head", Icons.Head, vm.heads, true);
        date = new DayPicker("Date", Icons.Month, true);

        amount = new IntegerBox("Amount", Icons.Amount, true);
        isCash = new MultiState(new String[]{Icons.Cash, Icons.NonCash, Icons.Mobile}, new String[]{"Cash", "Non cash", "Mobile"}, true) {{
            setAlignment(Pos.BOTTOM_LEFT);
        }};
        narration = new TextBoxMultiLine("Narration", Icons.Description, true){{ setMaxHeight(75);}};

        tree = new TransactionEntryTree(vm.entries, vm::removeEntry);

        addEntry = new CommandButton(Icons.PlusCircle, 16, "add");
        add = new CommandButton(Icons.Add, 16, "add");

        var amountBox = new HBox(amount, isCash, addEntry) {{
            setSpacing(10);
            setHgrow(amount, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_RIGHT);
        }};

        entryGrid = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(50);}},
                    new ColumnConstraints() {{setPercentWidth(50);}}
            );
            add(tenant, 0, 0, 2, 1);
            add(plot, 0, 1);
            add(space, 1, 1);
            add(control, 0, 2);
            add(head, 1, 2);
            add(date, 0, 3);
            add(amountBox, 1, 3);
            add(narration, 0, 4, 2, 1);

            setHgap(10);
            setVgap(10);
            setPadding(new Insets(5, 0, 0, 0));
        }};

        dueTree = new LastSecurityDueTree(vm.dues);
        paymentTree = new LastPaymentTree(vm.payments);
        depositDueHeader = getDepositDueHeader();
        paymentHeader = getPaymentHeader();

        infoGrid = new GridPane() {{
            getColumnConstraints().add(new ColumnConstraints() {{setPercentWidth(100);}});
            add(depositDueHeader, 0, 0);
            add(dueTree, 0, 1);
            add(paymentHeader, 0, 2);
            add(paymentTree, 0, 3);

            setBorder(Constants.BottomLine);
        }};

        setCenter(new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(64.5);}},
                    new ColumnConstraints() {{ setPercentWidth(1); setHalignment(HPos.CENTER);}},
                    new ColumnConstraints() {{setPercentWidth(34.5);}}
            );
            add(entryGrid, 0, 0);
            add(new ExtendedSeparator() {{setOrientation(Orientation.VERTICAL);}}, 1, 0);
            add(infoGrid, 2, 0);
            add(tree, 0, 1, 3, 1);
            add(add, 2, 2);

            setVgap(5);
            setVgrow(tree, Priority.ALWAYS);
            setHalignment(add, HPos.RIGHT);
            setValignment(add, VPos.BOTTOM);
            setMargin(add, new Insets(0, -4, 0, 0));
        }});

        status = new Text() {{setFill(Color.WHITE);}};
        spinner = new SpinningArc();
        addAction(spinner);
        addAction(status);

    }

    private void bind() {
        infoGrid.maxHeightProperty().bind(entryGrid.heightProperty());
        vm.entry.tenantIdProperty().bind(tenant.selectedValueProperty());
        vm.entry.plotIdProperty().bind(plot.selectedValueProperty());
        vm.entry.spaceIdProperty().bind(space.selectedValueProperty());
        vm.entry.controlIdProperty().bind(control.selectedValueProperty());
        vm.entry.headIdProperty().bind(head.selectedValueProperty());
        vm.entry.dateProperty().bind(date.selectedDateProperty());
        vm.entry.isCashProperty().bind(isCash.stateProperty);
        Bindings.bindBidirectional(amount.textProperty(), vm.entry.amountProperty(), new IntToStringConverter());
        Bindings.bindBidirectional(narration.textProperty(), vm.entry.narrationProperty());
        paidOn.textProperty().bind(vm.paymentDateProperty);

        addEntry.setAction(vm::addEntry);
        add.setAction(vm::add);

        addEntry.disableProperty().bind(tenant.isEmpty()
                .or(plot.isEmpty())
                .or(space.isEmpty())
                .or(control.isEmpty())
                .or(head.isEmpty())
                .or(date.isEmpty())
                .or(amount.isEmpty())
                .or(narration.isEmpty())
        );
        add.disableProperty().bind(tree.isEmpty().or(vm.isRunningProperty));

        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);

        vm.dialogTrigger.addListener((o, ov, nv) -> {
            if (nv) {
                var dialog = new ConfirmDialog("Transaction", vm.dialogMessage);
                var bound = localToScreen(getBoundsInLocal());
                dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
                vm.dialogResult = dialog.dialogResult;
                vm.dialogTrigger.set(false);
            }
        });
    }

    private GridPane getDepositDueHeader() {
        var now = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM, yyyy"));
        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(65) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(65) {{setHalignment(HPos.RIGHT);}}
            );
            add(new Text(now) {{setFill(Color.GRAY); }}, 0, 0);
            add(new Text("Deposit") {{setFill(Color.GRAY); }}, 1, 0);
            add(new Text("Due") {{setFill(Color.GRAY); }}, 2, 0);
            setBorder(Constants.BottomLine);
            setPadding(new Insets(5, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};
    }

    private GridPane getPaymentHeader() {
        return new GridPane() {{
            paidOn = new Text(){{ setFill(Color.GRAY); }};
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(35) {{setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(65) {{setHalignment(HPos.RIGHT);}}
            );
            add(paidOn, 0, 0);
            add(new Text("Mode") {{setFill(Color.GRAY); }}, 1, 0);
            add(new Text("Paid") {{setFill(Color.GRAY); }}, 2, 0);
            setBorder(Constants.BottomLine);
            setPadding(new Insets(5, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};
    }
}
