package Views.Report.RPandLJViews;

import ViewModels.Report.ReportReceiptPaymentVM;
import abstracts.View;
import controls.ExpandHeader;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.daymonth.DayPicker;
import controls.texts.TextBox;
import dialogs.PrinterSelectionDialog;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import trees.ReceiptPaymentTree;

public class ReportReceiptPayment extends View {
    private ReportReceiptPaymentVM vm;
    private Text status;
    private TextBox query;
    private DayPicker startDate, endDate;
    private CommandButton refresh, print;
    private ReceiptPaymentTree tree;
    private ExpandHeader expandHeader;
    private SpinningArc spinner;

    @Override
    protected String getHeader() {
        return "Receipt Payment";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new ReportReceiptPaymentVM();
        initializeUI();
        bind();
    }

    private void initializeUI(){
        startDate = new DayPicker("from", Icons.Month, false);
        endDate = new DayPicker("to", Icons.Month, false);
        query= new TextBox("Search", Icons.Magnify, false);
        print = new CommandButton(Icons.Print, 16, "print");
        refresh = new CommandButton(Icons.Reload, 16, "reload");

        var hBox = new HBox(startDate, endDate, query, print, refresh){{
            setSpacing(5);
            setHgrow(startDate, Priority.ALWAYS);
            setHgrow(endDate, Priority.ALWAYS);
            setHgrow(query, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_CENTER);
            setMargin(print, new Insets(0, 0, 5, 0));
            setMargin(refresh, new Insets(0, 0, 5, 0));
        }};
        tree = new ReceiptPaymentTree(vm.filteredList, query.textProperty());

        var box = new VBox(hBox, getTableHeader(), tree){{
           setSpacing(5);
            setPadding(new Insets(5,0,0,0));
           setVgrow(tree, Priority.ALWAYS);
        }};
        setCenter(box);

        spinner = new SpinningArc();
        status = new Text(){{setFill(Color.WHITE);}};
        addAction(spinner);
        addAction(status);
    }

    private void bind(){
        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);
        startDate.selectedDateProperty().bindBidirectional(vm.startDateProperty);
        endDate.selectedDateProperty().bindBidirectional(vm.endDateProperty);
        refresh.setAction(vm::updateReportable);
        print.setAction(vm::print);
        tree.isExpandedProperty.bind(expandHeader.isExpandedProperty());
        vm.queryProperty.bind(query.textProperty());

        vm.press.dialogTrigger.addListener(this::onPrintTrigger);
        print.disableProperty().bind(vm.isRunningProperty);
    }

    private void onPrintTrigger(ObservableValue<?> o, boolean ov, boolean nv) {
        if(nv){
            var dialog = new PrinterSelectionDialog(vm.press.getPrinters());
            var bound = localToScreen(getBoundsInLocal());
            dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
            vm.press.setSelected(dialog.getSelectedPrinter());
            vm.press.setPrintable(tree);
            if(dialog.getSelectedPaper() != null){
                vm.press.setPaper(dialog.getSelectedPaper());
            }
            vm.press.dialogTrigger.set(false);
        }
    }

    private Node getTableHeader(){
        var bold = Font.font(null, FontWeight.BOLD, -1);

        expandHeader = new ExpandHeader("Particulars", true);
        var cash = new Text("Cash"){{ setFill(Color.WHITE); setFont(bold); }};
        var kind = new Text("Kind"){{ setFill(Color.WHITE); setFont(bold); }};
        var mobile = new Text("Mobile"){{ setFill(Color.WHITE); setFont(bold); }};
        var total = new Text("Total"){{ setFill(Color.WHITE); setFont(bold); }};
        return new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.SOMETIMES);}},
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80)
            );
            add(expandHeader, 0, 0);
            add(cash, 1, 0);
            add(kind, 2, 0);
            add(mobile, 3, 0);
            add(total, 4, 0);

            setHalignment(cash, HPos.RIGHT);
            setHalignment(kind, HPos.RIGHT);
            setHalignment(mobile, HPos.RIGHT);
            setHalignment(total, HPos.RIGHT);

            setPadding(new Insets(5, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.BottomLine);
        }};
    }
}
