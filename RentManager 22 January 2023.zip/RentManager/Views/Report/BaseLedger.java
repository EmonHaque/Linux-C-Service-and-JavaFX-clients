package Views.Report;

import CellTemplates.ListView.LedgerTemplate;
import Models.ReportEntry;
import ViewModels.Report.BaseLedgerVM;
import abstracts.View;
import controls.SelectionBox;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.daymonth.DayPicker;
import controls.texts.TextBox;
import dialogs.PrinterSelectionDialog;
import helpers.Constants;
import helpers.Icons;
import interfaces.IReturnNameAndId;
import interfaces.ISetSelectionBoxContent;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.IntegerProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import ridiculous.AppData;
import skinned.ExtendedListView;

public abstract class BaseLedger<T extends IReturnNameAndId<T>> extends View {
    private Text status, total, receivable, receipt, balance, availableText;
    private TextBox query;
    private BaseLedgerVM<T> vm;
    private SelectionBox<T> selection;
    private DayPicker startDate, endDate;
    private CommandButton refresh, print;
    private ExtendedListView<ReportEntry> list;
    private SpinningArc spinner;

    protected abstract BaseLedgerVM<T> getViewModel();

    protected ISetSelectionBoxContent<T> getVisual() {return null;}

    protected String getTemplate() {return null;}

    @Override
    protected String getHeader() {
        return getViewModel().getHeader();
    }

    @Override
    protected String getTip() {
        return getViewModel().getHeader();
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = getViewModel();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        selection = getVisual() == null ?
                new SelectionBox<>(getHeader(), getIcon(), vm.selectionList, false) :
                new SelectionBox<>(getHeader(), getIcon(), vm.selectionList, getVisual(), getTemplate(), false);

        startDate = new DayPicker("from", Icons.Month, true);
        endDate = new DayPicker("to", Icons.Month, true);
        refresh = new CommandButton(Icons.Reload, 16, "refresh");

        availableText = new Text(){{
            setFill(Color.WHITE);
            setFont(Font.font(null, FontWeight.BOLD, -1));
        }};

        print = new CommandButton(Icons.Print, 16, "print");
        query = new TextBox("Search", Icons.Magnify, false);

        var secondRow = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(45);}},
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints()
            );
            add(availableText, 0, 0);
            add(query, 1, 0);
            add(print, 2, 0);

            setValignment(availableText, VPos.BOTTOM);
            setValignment(print, VPos.BOTTOM);
        }};

        var grid = new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setPercentWidth(58);}},
                    new ColumnConstraints() {{setPercentWidth(20);}},
                    new ColumnConstraints() {{setPercentWidth(20);}},
                    new ColumnConstraints() {{setPercentWidth(2);}}
            );
            add(selection, 0, 0);
            add(startDate, 1, 0);
            add(endDate, 2, 0);
            add(refresh, 3, 0);
            add(secondRow, 0, 1, 4, 1);
            setVgap(5);
            setHgap(5);
            setValignment(refresh, VPos.BOTTOM);
            setMargin(refresh, new Insets(0, 0, 4, 0));
            setHalignment(refresh, HPos.RIGHT);
            setAlignment(Pos.BOTTOM_CENTER);
        }};

        list = new ExtendedListView<>(vm.reportable);

        var box = new VBox(grid, getTableHeader(), list, getTableFooter()) {{
            setSpacing(5);
            setPadding(new Insets(5,0,0,0));
            setVgrow(list, Priority.ALWAYS);
        }};

        spinner = new SpinningArc();
        status = new Text() {{setFill(Color.WHITE);}};
        addAction(spinner);
        addAction(status);
        setCenter(box);
    }

    private void bind() {
        vm.particularsQueryProperty.bind(query.textProperty());
        refresh.setAction(vm::refresh);
        vm.idProperty.bind(selection.selectedValueProperty());

        startDate.startDateProperty().bind(vm.minDateProperty);
        startDate.endDateProperty().bind(vm.maxDateProperty);
        endDate.startDateProperty().bind(vm.minDateProperty);
        endDate.endDateProperty().bind(vm.maxDateProperty);

        startDate.selectedDateProperty().bindBidirectional(vm.startDateProperty);
        endDate.selectedDateProperty().bindBidirectional(vm.endDateProperty);

        availableText.textProperty().bind(vm.availablePeriodProperty);
        list.setCellFactory(v -> new LedgerTemplate(query.textProperty()));
        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);
        print.setAction(vm::print);

        total.textProperty().bind(vm.entriesProperty.asString("%,d"));
        receivable.textProperty().bind(getNumberBinding(vm.receivableProperty));
        receipt.textProperty().bind(getNumberBinding(vm.receiptProperty));
        balance.textProperty().bind(getNumberBinding(vm.balanceProperty));

        vm.press.dialogTrigger.addListener(this::onPrintTrigger);
        print.disableProperty().bind(vm.isRunningProperty);
    }

    private StringBinding getNumberBinding(IntegerProperty property){
        return Bindings.createStringBinding(() -> AppData.formatNumber(property.get()), property);
    }

    private void onPrintTrigger(ObservableValue<?> o, boolean ov, boolean nv) {
        if(nv){
            var dialog = new PrinterSelectionDialog(vm.press.getPrinters());
            var bound = localToScreen(getBoundsInLocal());
            dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
            vm.press.setSelected(dialog.getSelectedPrinter());
            if(dialog.getSelectedPaper() != null){
                vm.press.setPaper(dialog.getSelectedPaper());
            }
            vm.press.dialogTrigger.set(false);
        }
    }

    private Node getTableHeader() {
        var date = new Text("Date") {{setFill(Color.WHITE); setFont(Font.font(null, FontWeight.BOLD, -1));}};
        var particulars = new Text("Particulars") {{
            setFill(Color.WHITE); setFont(Font.font(null, FontWeight.BOLD, -1));
        }};
        var receivable = new Text("Receivable") {{
            setFill(Color.WHITE); setFont(Font.font(null, FontWeight.BOLD, -1));
        }};
        var receipt = new Text("Receipt") {{setFill(Color.WHITE); setFont(Font.font(null, FontWeight.BOLD, -1));}};
        var balance = new Text("Balance") {{setFill(Color.WHITE); setFont(Font.font(null, FontWeight.BOLD, -1));}};

        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints(90),
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80)
            );
            setBorder(Constants.BottomLine);
            add(date, 0, 0);
            add(particulars, 1, 0);
            add(receivable, 2, 0);
            add(receipt, 3, 0);
            add(balance, 4, 0);

            setHalignment(receivable, HPos.RIGHT);
            setHalignment(receipt, HPos.RIGHT);
            setHalignment(balance, HPos.RIGHT);
            setPadding(new Insets(5, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};
    }

    private Node getTableFooter() {
        total = new Text() {{setFill(Color.WHITE);}};
        receivable = new Text() {{setFill(Color.WHITE);}};
        receipt = new Text() {{setFill(Color.WHITE);}};
        balance = new Text() {{setFill(Color.WHITE);}};
        var totalFlow = new TextFlow() {{
            getChildren().addAll(
                    new Text("Total of ") {{setFill(Color.WHITE);}},
                    total,
                    new Text(" entries") {{setFill(Color.WHITE);}}
            );
        }};

        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(80),
                    new ColumnConstraints(80),
                    new ColumnConstraints(80)
            );
            add(totalFlow, 0, 0);
            add(receivable, 1, 0);
            add(receipt, 2, 0);
            add(balance, 3, 0);
            setHalignment(receivable, HPos.RIGHT);
            setHalignment(receipt, HPos.RIGHT);
            setHalignment(balance, HPos.RIGHT);
            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0))));
        }};
    }
}
