package Views.Report.BalancesViews;

import Models.Plot;
import ViewModels.Report.ReportBalanceVM;
import abstracts.View;
import controls.ExpandHeader;
import controls.SelectionBox;
import controls.SpinningArc;
import controls.buttons.CommandButton;
import controls.states.BiState;
import controls.texts.TextBox;
import dialogs.PrinterSelectionDialog;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.Observable;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import ridiculous.AppData;
import trees.BalanceTree;

import java.util.ArrayList;

public class ReportBalance extends View {
    private ReportBalanceVM vm;
    private Text status, tenants, spaces, security, rent, due;
    private SpinningArc spinner;
    private BiState hasLeft;
    private SelectionBox<Plot> selection;
    private TextBox query;
    private BalanceTree tree;
    private ExpandHeader expandHeader;
    private CommandButton refresh, print;

    @Override
    protected String getHeader() {
        return "Balance";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new ReportBalanceVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        selection = new SelectionBox<>("Plot", Icons.Plot, vm.plots, false);
        hasLeft = new BiState(false, "has left"){{ setAlignment(Pos.BOTTOM_RIGHT);}};
        refresh = new CommandButton(Icons.Reload, 16, "Reload");
        print = new CommandButton(Icons.Print, 16, "print");
        query = new TextBox("Search", Icons.Magnify, false);
        var hBox = new HBox(selection, hasLeft, refresh, print, query) {{
            setSpacing(10);
            setHgrow(selection, Priority.ALWAYS);
            setHgrow(query, Priority.ALWAYS);
            setAlignment(Pos.BOTTOM_RIGHT);
            setMargin(refresh, new Insets(0, 0, 5, 0));
            setMargin(print, new Insets(0, 0, 5, 0));
            setMargin(hasLeft, new Insets(0, 0, 5, 0));
        }};
        tree = new BalanceTree(vm.balances, query.textProperty());

        var box = new VBox(hBox, getTableHeader(), tree, getTableFooter()) {{
            setSpacing(5);
            setPadding(new Insets(5,0,0,0));
            setVgrow(tree, Priority.ALWAYS);
        }};
        setCenter(box);

        spinner = new SpinningArc();
        status = new Text() {{setFill(Color.WHITE);}};
        addAction(spinner);
        addAction(status);
    }

    private void bind() {
        refresh.setAction(vm::updateReportable);
        print.setAction(vm::print);

        vm.selectedPlotProperty.bind(selection.selectedValueProperty());
        vm.stateProperty.bind(hasLeft.isCheckedProperty);
        vm.queryProperty.bind(query.textProperty());
        status.textProperty().bind(vm.statusProperty);
        spinner.visibleProperty().bind(vm.isRunningProperty);
        print.disableProperty().bind(vm.isRunningProperty);

        vm.press.dialogTrigger.addListener(this::onPrintTrigger);
        tree.itemsChangedProperty.addListener(this::updateCount);
        tree.isExpandedProperty.bind(expandHeader.isExpandedProperty());
    }

    private void updateCount(Observable o){
        int security = 0, rent = 0, due = 0;
        var tenants = new ArrayList<String>();
        var spaces = new ArrayList<String>();

        if(hasLeft.isCheckedProperty.get()){
            for(var item : vm.balances){
                if(!tenants.contains(item.getTenant())) tenants.add(item.getTenant());
                if(!spaces.contains(item.getSpace())) spaces.add(item.getSpace());
                security += item.getSecurity();
                rent += item.getRent();
                due += item.getDue();
            }
        }
        else {
            for(var item : vm.balances){
                if(!tenants.contains(item.getTenant())) tenants.add(item.getTenant());
                if(item.isExpired()) continue;
                if(!spaces.contains(item.getSpace())) spaces.add(item.getSpace());
                security += item.getSecurity();
                rent += item.getRent();
                due += item.getDue();
            }
        }
        var totalSpace =AppData.spaces.stream().filter(x -> x.getPlotId() == selection.selectedValueProperty().get()).count();
        this.tenants.setText(String.format("%,d", tenants.size()));
        this.spaces.setText(String.format("%,d", spaces.size()) + " out of " + String.format("%,d", totalSpace));
        this.security.setText(AppData.formatNumber(security));
        this.rent.setText(AppData.formatNumber(rent));
        this.due.setText(AppData.formatNumber(due));
    }

    private void onPrintTrigger(Observable o, boolean ov, boolean nv) {
        if(nv){
            var dialog = new PrinterSelectionDialog(vm.press.getPrinters());
            var bound = localToScreen(getBoundsInLocal());
            dialog.showDialog(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight());
            vm.press.setSelected(dialog.getSelectedPrinter());
            if(dialog.getSelectedPaper() != null){
                vm.press.setPaper(dialog.getSelectedPaper());
            }
            vm.press.dialogTrigger.set(false);
        }
    }

    private Node getTableHeader() {
        var bold = Font.font(null, FontWeight.BOLD, -1);
        expandHeader = new ExpandHeader("Particulars", true);
        var from = new Text("From") {{setFill(Color.WHITE); setFont(bold);}};
        var security = new Text("Security") {{setFill(Color.WHITE); setFont(bold);}};
        var rent = new Text("Rent") {{setFill(Color.WHITE); setFont(bold);}};
        var due = new Text("Due") {{setFill(Color.WHITE); setFont(bold);}};

        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.SOMETIMES);}},
                    new ColumnConstraints(100){{ setHalignment(HPos.CENTER);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}}
            );
            add(expandHeader, 0, 0);
            add(from, 1, 0);
            add(security, 2, 0);
            add(rent, 3, 0);
            add(due, 4, 0);

            setPadding(new Insets(5, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
            setBorder(Constants.BottomLine);
        }};
    }

    private Node getTableFooter() {
        tenants = new Text() {{setFill(Color.WHITE);}};
        spaces = new Text() {{setFill(Color.WHITE);}};
        security = new Text() {{setFill(Color.WHITE);}};
        rent = new Text() {{setFill(Color.WHITE);}};
        due = new Text() {{setFill(Color.WHITE);}};

        return new GridPane() {{
            getColumnConstraints().addAll(
                    new ColumnConstraints() {{setHgrow(Priority.ALWAYS);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}},
                    new ColumnConstraints(80){{ setHalignment(HPos.RIGHT);}}
            );
            setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0.25, 0, 0, 0))));
            add(new TextFlow() {{
                getChildren().addAll(
                        new Text("Total of ") {{setFill(Color.WHITE);}},
                        tenants,
                        new Text(" tenants in "){{setFill(Color.WHITE);}},
                        spaces,
                        new Text(" spaces") {{setFill(Color.WHITE);}}
                );
            }}, 0, 0);
            add(security, 1, 0);
            add(rent, 2, 0);
            add(due, 3, 0);

            setPadding(new Insets(0, Constants.ScrollBarSize + Constants.CellPadding, 0, 0));
        }};
    }
}
