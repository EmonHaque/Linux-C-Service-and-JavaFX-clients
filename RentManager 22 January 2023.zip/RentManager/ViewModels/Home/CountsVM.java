package ViewModels.Home;

import Models.Lease;
import Models.Plot;
import Models.Space;
import Models.Tenant;
import helpers.Icons;
import javafx.beans.Observable;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.util.Pair;
import model.PieSeries;
import ridiculous.AppData;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;

public class CountsVM {
    private String[] selectionStateTexts;
    private final String[] selectionStateIcons;
    private ObservableList<PieSeries> summary;

    public IntegerProperty primaryState, secondaryState;
    public IntegerProperty totalPlot, totalInPlot;
    public ObjectProperty<Pair<String[], String[]>> secondaryStates;
    public ObjectProperty<List<PieSeries>> seriesProperty;

    public CountsVM() {
        primaryState = new SimpleIntegerProperty();
        secondaryState = new SimpleIntegerProperty();
        secondaryStates = new SimpleObjectProperty<>();
        seriesProperty = new SimpleObjectProperty<>();
        totalPlot = new SimpleIntegerProperty();
        totalInPlot = new SimpleIntegerProperty();

        primaryState.addListener(this::onPrimaryStateChanged);
        secondaryState.addListener(this::onSecondaryStateChange);

        selectionStateTexts = new String[] { "Occupied", "Vacant", "All" };
        selectionStateIcons = new String[] { Icons.Existing, Icons.LeftOrExpired, Icons.All };
    }

    private void onPrimaryStateChanged(Observable o){
        var isSecondaryZero = secondaryState.get() == 0;
        switch (primaryState.get()){
            case 0 -> selectionStateTexts = new String[] { "Occupied", "Vacant", "All" };
            case 1 -> selectionStateTexts = new String[] { "Active", "Expired", "All" };
            case 2 -> selectionStateTexts = new String[] { "Existing", "Left", "All" };
        }
        secondaryStates.set(new Pair<>(selectionStateIcons, selectionStateTexts));
        if(isSecondaryZero) onSecondaryStateChange(null);

    }

    private void onSecondaryStateChange(Observable o) {
        summary = FXCollections.observableArrayList();
        switch (primaryState.get()) {
            case 0 -> getSpaceSummary();
            case 1 -> getLeaseSummary();
            case 2 -> getTenantSummary();
        }
        seriesProperty.set(summary);
    }

    private void getSpaceSummary(){
        BiFunction<Plot, Space, Boolean> condition = null;
        switch (secondaryState.get()){
            case 0 -> condition = (plot, space) -> plot.getId() == space.getPlotId() && !space.isIsVacant();
            case 1 -> condition = (plot, space) -> plot.getId() == space.getPlotId() && space.isIsVacant();
            case 2 -> condition = (plot, space) -> plot.getId() == space.getPlotId();
        }
        int plotCount = 0, grandTotal = 0;
        for(var plot : AppData.plots){
            int total = 0;
            for(var space : AppData.spaces){
                if(condition.apply(plot, space)) total++;
            }
            summary.add(new PieSeries(plot.getId(), plot.getName(), total));
            plotCount++;
            grandTotal += total;
        }
        totalPlot.set(plotCount);
        totalInPlot.set(grandTotal);
    }

    private void getLeaseSummary(){
        BiFunction<Plot, Lease, Boolean> condition = null;
        switch (secondaryState.get()){
            case 0 -> condition = (plot, lease) -> lease.getPlotId() == plot.getId() && !lease.isIsExpired();
            case 1 -> condition = (plot, lease) -> lease.getPlotId() == plot.getId() && lease.isIsExpired();
            case 2 -> condition = (plot, lease) -> lease.getPlotId() == plot.getId();
        }
        int plotCount = 0, grandTotal = 0;
        for(var plot : AppData.plots){
            int total = 0;
            for(var lease : AppData.leases){
                if(condition.apply(plot, lease)) total++;
            }
            summary.add(new PieSeries(plot.getId(), plot.getName(), total));
            plotCount++;
            grandTotal += total;
        }
        totalPlot.set(plotCount);
        totalInPlot.set(grandTotal);
    }

    private void getTenantSummary(){
        List<Integer> tenants;
        List<Integer> contained = new ArrayList<>();
        int plotCount = 0, grandTotal = 0;
        switch (secondaryState.get()){
            case 0 -> {
                tenants = AppData.tenants.stream().filter(x -> !x.isHasLeft()).mapToInt(Tenant::getId).boxed().toList();
                for(var plot : AppData.plots){
                    contained.clear();
                    var leases = AppData.leases.stream().filter(x -> x.getPlotId() == plot.getId()).mapToInt(Lease::getTenantId).distinct().boxed().toList();
                    for(var tenant : tenants){
                        if(leases.contains(tenant) && !contained.contains(tenant))
                            contained.add(tenant);
                    }
                    summary.add(new PieSeries(plot.getId(), plot.getName(), contained.size()));
                    plotCount++;
                    grandTotal += contained.size();
                }

            }
            case 1 -> {
                tenants = AppData.tenants.stream().filter(Tenant::isHasLeft).mapToInt(Tenant::getId).boxed().toList();
                for(var plot : AppData.plots){
                    contained.clear();
                    var leases = AppData.leases.stream().filter(x -> x.getPlotId() == plot.getId()).mapToInt(Lease::getTenantId).distinct().boxed().toList();
                    for(var tenant : tenants){
                        if(leases.contains(tenant) && !contained.contains(tenant))
                            contained.add(tenant);
                    }
                    summary.add(new PieSeries(plot.getId(), plot.getName(), contained.size()));
                    plotCount++;
                    grandTotal += contained.size();
                }
            }
            case 2 ->{
                for(var plot : AppData.plots){
                    var total = AppData.leases.stream().filter(x -> x.getPlotId() == plot.getId()).mapToInt(Lease::getTenantId).distinct().boxed().toList().size();
                    summary.add(new PieSeries(plot.getId(), plot.getName(), total));
                    plotCount++;
                    grandTotal +=total;
                }
            }
        }
        totalPlot.set(plotCount);
        totalInPlot.set(grandTotal);

    }

    public void refresh(){
        onSecondaryStateChange(null);
    }
}
