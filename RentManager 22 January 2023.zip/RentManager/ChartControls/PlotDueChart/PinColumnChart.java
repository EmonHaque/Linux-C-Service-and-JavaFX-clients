package ChartControls.PlotDueChart;

import Models.PlotwiseDue;
import abstracts.DualAxisChartBase;
import abstracts.ListCellBase;
import controls.PopupDraggable;
import controls.pinchart.PinColumn;
import controls.texts.HiText;
import controls.texts.TextBox;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.Observable;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import ridiculous.AppData;
import skinned.ExtendedResizableListView;

import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.List;

public class PinColumnChart extends DualAxisChartBase<PlotwiseDue> {
    private final List<PinColumn> pins;
    private final List<String> labels;

    private record PinColumnData(String month, List<PlotwiseDue> list, int total){}

    public PinColumnChart(String y1Title, String y2Title) {
        super(y1Title, y2Title);
        pins = new ArrayList<>();
        labels = new ArrayList<>();
    }

    @Override
    protected void setMinMaxAndXLabels() {
        int index = 0;
        for (var pin : pins) {
            var columnValue = pin.getColumnValue();
            var pinValue = pin.getPinValue();

            if (y1Max < columnValue) y1Max = columnValue;
            if (y2Max < pinValue) y2Max = pinValue;
            if (y1Min > columnValue) y1Min = columnValue;
            if (y2Min > pinValue) y2Min = pinValue;

            var xLabel = new Text(labels.get(index++)) {{
                setFill(Color.WHITE);
                setRotate(-90);
                setManaged(false);
                setMouseTransparent(true);
            }};
            xLabels.getChildren().add(xLabel);

            if (xLabelWidth < xLabel.prefWidth(-1))
                xLabelWidth = xLabel.prefWidth(-1);
        }

        double y1Step = y1Max / (numLines - 1);
        double y2Step = (y2Max - y2Min) / (numLines - 1);
        double y1Current = y1Min;
        double y2Current = y2Min;
        for (int i = 0; i < numLines; i++) {
            var y1 = (Text) y1Labels.getChildren().get(i);
            var y2 = (Text) y2Labels.getChildren().get(i);
            y1.setText(String.format("%,d", (int) y1Current));
            y2.setText(String.format("%,d", (int) y2Current));

            y1LabelWidth = y1.prefWidth(-1);
            y2LabelWidth = y2.prefWidth(-1);

            y1Current += y1Step;
            y2Current += y2Step;
        }
    }

    @Override
    protected void reset() {
        for (var n : pins) {
            getChildren().remove(n);
        }
        pins.clear();
        labels.clear();
        var months = series.stream().map(PlotwiseDue::getMonth).distinct().toList();
        for(var month : months){
            var tenants = series.stream().filter( x -> x.getMonth().equals(month)).toList();
            var due = tenants.stream().mapToDouble(PlotwiseDue::getDue).sum();
            var count = tenants.size();

            labels.add(month);
            var pin = new PinColumn(count, due){{ setManaged(false); }};
            var data = new PinColumnData(month, tenants, (int)due);
            pin.setToolTip(new Tip(data));

            getChildren().add(pin);
            pins.add(pin);
        }
    }

    @Override
    protected void layoutChildren() {
        if (series == null) return;
        super.layoutChildren();

        double pinX = startX;
        double gap = 5;
        var colWidth = (availableWidth - gap * pins.size()) / pins.size();
        double xLabelX = pinX + colWidth / 2;

        double x = pinX;
        for (int i = 0; i < pins.size(); i++) {
            var text = (Text) xLabels.getChildren().get(i);
            text.setY(availableHeight + text.prefWidth(-1) / 2 + text.prefHeight(-1) / 2);
            text.setX(xLabelX - text.prefWidth(-1) / 2);

            var pin = pins.get(i);
            pin.makePin(colWidth, availableHeight, y1Min, y2Min, y1Max, y2Max);
            pin.resizeRelocate(x, availableHeight, colWidth, availableHeight);

            xLabelX += colWidth + gap;
            x += colWidth + gap;
        }
    }

    private class Tip extends PopupDraggable{
        private final FilteredList<PlotwiseDue> filteredList;
        private final Text count, total;

        public Tip(PinColumnData data) {

            var bold = Font.font(null, FontWeight.BOLD, -1);
            count = new Text(AppData.formatNumber(data.list().size())){{ setFill(Color.WHITE); setFont(bold);}};
            total = new Text(AppData.formatNumber(data.total())){{ setFill(Color.WHITE); setFont(bold);}};

            var splits = data.month().replace(" ", "").split("-");
            var month = DateFormatSymbols.getInstance().getMonths()[Integer.parseInt(splits[0]) - 1];

            var heading = new Text(month + ", " + splits[1]){{
                setFill(Color.GRAY);
                setFont(Font.font(null, FontWeight.BOLD, 16));
            }};

            var header = new GridPane(){{
                getColumnConstraints().addAll(
                        new ColumnConstraints(200),
                        new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}}
                );
                add(new Text("Tenant"){{ setFill(Color.WHITE); setFont(bold);}}, 0, 0);
                add(new Text("Due"){{ setFill(Color.WHITE); setFont(bold);}}, 1, 0);

                setPadding(new Insets(2.5, Constants.ScrollBarSize + Constants.CellPadding, 2.5, 0));
                setBorder(Constants.BottomLine);
            }};

            var totalFlow = new TextFlow(){{
                getChildren().addAll(
                        new Text("Total of "){{ setFill(Color.WHITE); setFont(bold);}},
                        count
                );
            }};
            var footer = new GridPane(){{
                getColumnConstraints().addAll(
                        new ColumnConstraints(200),
                        new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}}
                );
                add(totalFlow, 0, 0);
                add(total, 1, 0);

                setPadding(new Insets(2.5, Constants.ScrollBarSize + Constants.CellPadding, 2.5, 0));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25, 0, 0, 0))));
            }};

            var query = new TextBox("Search", Icons.Magnify, false);
            var source = FXCollections.observableList(data.list(), o -> new Observable[]{ query.textProperty()});
            filteredList = new FilteredList<>(source, x -> {
                var q = query.getText();
                return q == null || q.isEmpty() || q.isBlank() || x.getTenant().toLowerCase().contains(query.getText().toLowerCase());
            });
            var listView = new ExtendedResizableListView<>(filteredList){{
                setMaxHeight(400);
            }};
            listView.setCellFactory(v -> new Cell(query.textProperty()));

            var box = new VBox(heading, query, header, listView, footer){{
                setPadding(new Insets(5));
                setSpacing(5);
                setBackground(Background.fill(Constants.BackgroundColor));
                setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.5))));
                setVgrow(listView, Priority.SOMETIMES);
            }};
            getContent().add(box);

            filteredList.addListener(this::onListChange);

            heading.requestFocus();
        }

        private void onListChange(ListChangeListener.Change<? extends PlotwiseDue> change){
            int count = 0, total = 0;
            for(var item : filteredList){
                count++;
                total += item.getDue();
            }
            this.count.setText(AppData.formatNumber(count));
            this.total.setText(AppData.formatNumber(total));
        }

        private class Cell extends ListCellBase<PlotwiseDue>{
            private GridPane root;
            private HiText name;
            private Text total;
            private final StringProperty query;

            public Cell(StringProperty query) {
                this.query = query;
            }

            @Override
            protected void initializeUI() {
                name = new HiText();
                total = new Text(){{setFill(Color.WHITE);}};

                root = new GridPane(){{
                    getColumnConstraints().addAll(
                            new ColumnConstraints(200),
                            new ColumnConstraints(75){{ setHalignment(HPos.RIGHT);}}
                    );
                    add(name, 0, 0);
                    add(total, 1, 0);
                }};
            }

            @Override
            protected void onItemChanged(ObservableValue<?> o, PlotwiseDue ov, PlotwiseDue nv) {
                if(ov != null){
                    name.queryProperty().unbind();
                    name.queryProperty().set("");
                }
                if(nv != null){
                    name.setText(nv.getTenant());
                    total.setText(AppData.formatNumber(nv.getDue()));
                    name.queryProperty().bind(query);
                }
            }

            @Override
            protected Node getRootNode() {
                return root;
            }
        }
    }
}
