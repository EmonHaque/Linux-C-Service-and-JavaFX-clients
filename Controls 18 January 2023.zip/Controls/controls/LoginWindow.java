package controls;

import controls.buttons.ActionButton;
import controls.buttons.CommandButton;
import controls.texts.PasswordBox;
import controls.texts.TextBox;
import helpers.Constants;
import helpers.Icons;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import ridiculuous.*;

import java.io.IOException;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.ExecutionException;

public class LoginWindow extends Stage {
    private double Xoffset, Yoffset;
    private final Text loginStatus, serviceStatus;
    private final TextBox userName;
    private final PasswordBox password;
    private final CommandButton login, service;
    private final String title;
    public BooleanProperty isSuccessProperty;

    public LoginWindow(String title, Image icon) {
        this.title = title;
        initStyle(StageStyle.TRANSPARENT);
        getIcons().add(icon);
        setResizable(false);

        var appName = new Text(title);
        loginStatus = new Text();
        serviceStatus = new Text();
        var logInto = new Text("Log into");

        appName.setFont(Font.font(null, FontWeight.BOLD, 24));
        logInto.setFont(Font.font(18));
        appName.setFill(Color.WHITE);
        loginStatus.setFill(Color.WHITE);
        serviceStatus.setFill(Color.WHITE);
        logInto.setFill(Color.WHITE);
        var image = new ImageView(icon);
        userName = new TextBox("Name", Icons.User, false);
        password = new PasswordBox("Password", Icons.Password, false);

        login = new CommandButton(Icons.SendCircle, 48, "log in");
        service = new CommandButton(Icons.ConnectSocket, 16, "connect");
        login.setAction(this::onLogin);
        service.setAction(this::onLoggedIn);
        service.setVisible(false);
        login.disableProperty().bind(userName.textProperty().isEmpty().or(password.textProperty.isEmpty()));

        var box = new VBox(logInto, image, appName, userName, password, login, loginStatus);
        box.setAlignment(Pos.CENTER);
        box.setSpacing(10);
        VBox.setMargin(userName, new Insets(10, 0, 10, 0));
        VBox.setMargin(login, new Insets(40, 0, 0, 0));

        var border = new BorderPane();
        border.setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, new CornerRadii(10, false), null)));
        border.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(10), new BorderWidths(0.5))));
        border.setPadding(new Insets(5, 20, 10, 20));

        var close = new ActionButton(Icons.CloseCircle, 16, "close");
        close.setAction(Platform::exit);

        var bottom = new BorderPane();
        bottom.setCenter(serviceStatus);
        bottom.setRight(service);

        border.setTop(close);
        border.setCenter(box);
        border.setBottom(bottom);

        BorderPane.setMargin(close, new Insets(0, -15, 0, 0));
        BorderPane.setMargin(service, new Insets(0, -15, 0, 0));
        BorderPane.setMargin(box, new Insets(0, 0, 100, 0));
        BorderPane.setAlignment(close, Pos.CENTER_RIGHT);

        var scene = new Scene(border, 400, 800);
        scene.setFill(Color.TRANSPARENT);
        setScene(scene);

        addEventHandler(MouseEvent.MOUSE_PRESSED, this::onPress);
        addEventHandler(MouseEvent.MOUSE_DRAGGED, this::onDrag);
        addEventHandler(MouseEvent.MOUSE_RELEASED, e -> getScene().setCursor(Cursor.DEFAULT));

        isSuccessProperty = new SimpleBooleanProperty();
    }

    private void onLogin() {
        var user = new User(title, userName.getText(), password.getText());
        var task = new LoginTask(user.getBytes());

        login.disableProperty().unbind();
        login.disableProperty().bind(task.runningProperty());

        loginStatus.textProperty().bind(task.messageProperty());
        new Thread(task).start();
    }

    private void onLoggedIn() {
        var task = new ServiceTask();
        service.disableProperty().bind(task.runningProperty());
        serviceStatus.textProperty().bind(task.messageProperty());
        new Thread(task).start();
    }

    private void onPress(MouseEvent e) {
        getScene().setCursor(Cursor.CLOSED_HAND);
        Xoffset = getX() - e.getScreenX();
        Yoffset = getY() - e.getScreenY();
    }

    private void onDrag(MouseEvent e) {
        if (!e.isPrimaryButtonDown())
            return;

        setX(e.getScreenX() + Xoffset);
        setY(e.getScreenY() + Yoffset);
    }

    private class ServiceTask extends Task<Boolean> {

        @Override
        protected Boolean call() throws Exception {
            boolean result = false;
            updateMessage("connecting to " + title + " Service ...");
            Thread.sleep(1000);
            try {
                Channels.getInstance().sender = new Socket(Addresses.RentManagerIP, Addresses.RentManagerPort);
                var info = new ClientInfo((byte)0, Channels.getInstance().userId);
                Channels.getInstance().sender.getOutputStream().write(info.getBytes());
                Channels.getInstance().sender.getOutputStream().flush();

                updateMessage("connected successfully ...");
                Thread.sleep(1000);
                result = true;
            } catch (Exception e) {
                updateMessage(title + " Service down ...");
                Thread.sleep(1000);

                updateMessage("try later ...");
                Thread.sleep(1000);
                Platform.runLater(() -> service.setVisible(true));
            }

            return result;
        }

        @Override
        protected void succeeded() {
            try {
                var isConnected = get();
                if(isConnected){
                    isSuccessProperty.set(true);
                }
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private class LoginTask extends Task<LoginResult> {
        private final byte[] array;

        public LoginTask(byte[] array) {
            this.array = array;
        }

        @Override
        protected LoginResult call() throws Exception {
            LoginResult result = null;
            updateMessage("connecting to Login Service ...");
            Thread.sleep(1000);
            try {
                Channels.getInstance().signatory = new Socket(Addresses.LoginIP, Addresses.LoginPort);
                updateMessage("sending login info ...");
                Thread.sleep(1000);

                Channels.getInstance().signatory.getOutputStream().write(array, 0, array.length);
                updateMessage("waiting for result ...");
                Thread.sleep(1000);
                var sizeBuffer = Channels.getInstance().signatory.getInputStream().readNBytes(4);
                int size = ByteBuffer.wrap(sizeBuffer).order(ByteOrder.LITTLE_ENDIAN).getInt();

                var array = Channels.getInstance().signatory.getInputStream().readNBytes(size);
                result = new LoginResult(array);

                if (result.isSuccess()) {
                    updateMessage("successfully logged in ...");
                    Thread.sleep(1000);
                }
                else {
                    updateMessage("incorrect info ...");
                    Thread.sleep(1000);
                }

            } catch (Exception e) {
                updateMessage("Login Service down ...");
                Thread.sleep(1000);
                updateMessage("try later ...");
                throw new RuntimeException(e);
            }
            return result;
        }

        @Override
        protected void succeeded() {
            try {
                var result = get();
                login.disableProperty().unbind();
                if (result.isSuccess()) {
                    Channels.getInstance().role = result.getRole();
                    Channels.getInstance().userId = result.getUserid();
                    login.setDisable(true);
                    onLoggedIn();
                }
                else {
                    updateMessage("try again ...");
                    login.disableProperty().bind(userName.textProperty().isEmpty().or(password.textProperty.isEmpty()));
                }
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }
    }
}
