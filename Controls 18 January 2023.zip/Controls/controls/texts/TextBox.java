package controls.texts;

import abstracts.HintedControlBase;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Priority;
import skinned.ExtendedTextField;

public class TextBox extends HintedControlBase {
    protected ExtendedTextField input;

    public TextBox(String hint, String icon, boolean isRequired) {
        super(hint, icon, isRequired);
        input = new ExtendedTextField();
        input.setText("");

        add(input, 1, 0);
        setHgrow(input, Priority.ALWAYS);
        setFocusTraversable(false);

        input.focusedProperty().addListener(this::onFocusChanged);
        input.textProperty().addListener(this::onTextChanged);
        setOnMouseClicked(this::onClicked);
    }
    private void onClicked(MouseEvent e){
        input.requestFocus();
        input.end();
    }

    protected void onTextChanged(ObservableValue<?> observable, String oldValue, String newValue) {
        if (textIsNullOrEmpty(newValue)) {
            if (isHintMoved && !input.isFocused()) {
                moveHintDown();
            }
        }
        else {
            if (!isHintMoved) {
                moveHintUp();
            }
        }
    }

    protected void onFocusChanged(ObservableValue<?> observable, Boolean oldValue, Boolean newValue) {
        if (newValue) {
            setFocusColor();
            if (!isHintMoved)
                moveHintUp(); 
        }
        else {
            resetFocusColor();
            if (textIsNullOrEmpty(input.getText())) {
                if (isHintMoved)
                    moveHintDown();
            }
        }
    }

    protected boolean textIsNullOrEmpty(String text) {
        return text.isEmpty() || text.isBlank();
//        return text == null || text.isEmpty() || text.isBlank();
    }

    public StringProperty textProperty(){ return input.textProperty();}

    public String getText() {
        return input.getText();
    }

    public void setText(String value) {
        input.setText(value);
    }

    public BooleanBinding isEmpty(){
        return textProperty().isEmpty(); }
}
