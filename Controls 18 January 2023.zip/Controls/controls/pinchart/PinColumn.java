package controls.pinchart;

import controls.columnstackchart.Column;
import javafx.animation.*;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Scale;
import javafx.stage.Popup;
import javafx.util.Duration;

public class PinColumn extends StackPane {
    private boolean isLoaded, isPinned;
    private final double radius = 3;
    private double ballY;
    private final Column column;
    private final PinSegment pin;
    private final Circle ball;

    private TranslateTransition ballAnim;
    private final DoubleProperty pinHeightProperty, columnHeightProperty;

    private Popup popup;
    private final double pinValue, columnValue;
    private final Rectangle pinClip, columnClip;

    public PinColumn(double pinValue, double columnValue) {
        this.pinValue = pinValue;
        this.columnValue = columnValue;

        getTransforms().add(new Scale(1, -1));

        column = new Column(Color.GREEN, Color.CORAL, true, columnValue < 0) {{
            setManaged(false);
            setMouseTransparent(true);
        }};
        pin = new PinSegment(Color.CORAL, Color.WHITE) {{
            setManaged(false);
            setMouseTransparent(true);
        }};
        ball = new Circle() {{
            setFill(Color.CORNFLOWERBLUE);
            setRadius(radius);
            setManaged(false);
            setMouseTransparent(true);
        }};
        getChildren().addAll(column, pin, ball);

        pinHeightProperty = new SimpleDoubleProperty(0);
        columnHeightProperty = new SimpleDoubleProperty(0);
        pinClip = new Rectangle();
        columnClip = new Rectangle();

        pin.setClip(pinClip);
        column.setClip(columnClip);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseClicked(this::onClicked);
        setOnMouseExited(this::onMouseExited);
    }

    public double getColumnValue() {return columnValue;}

    public double getPinValue() {return pinValue;}

    public void makePin(double width, double height, double y1Min, double y2Min, double y1Max, double y2Max) {
        var midPoint = width / 2;
        double y1Factor = height / (y1Max - y1Min);
        var columnHeight = y1Factor * columnValue;
        double negativeHeight = 0;
        if (y1Min < 0) {
            var absMin = Math.abs(y1Min);
            var spread = y1Max - y1Min;
            negativeHeight = height / spread * absMin;
        }
        double y2Factor = height / y2Max;
        var pinHeight = y2Factor * pinValue;

        ball.setCenterX(midPoint);
        ball.setCenterY(pinHeight);
        ballY = pinHeight;

        pin.setValue(midPoint, 0, pinHeight - radius / 2);
        column.setValue(0, negativeHeight, width, columnHeight);

        pinClip.setWidth(width);
        columnClip.setWidth(width);
        columnClip.setY(negativeHeight);

        if (!isLoaded) {
            isLoaded = true;
            pinHeightProperty.addListener((o, ov, nv) -> {
                pinClip.setHeight(nv.doubleValue());
            });
           columnHeightProperty.addListener((o, ov, nv) -> {
                if(nv.doubleValue() < 0){
                    columnClip.setTranslateY(nv.intValue());
                    columnClip.setHeight(-1 * nv.doubleValue());

                }
                else columnClip.setHeight(nv.doubleValue());
            });

            var pinKey = new KeyValue(pinHeightProperty, height, Interpolator.EASE_IN);
            var pinFrame = new KeyFrame(Duration.millis(500), pinKey);
            var pinAnim = new Timeline(pinFrame);
            pinAnim.setDelay(Duration.millis(500));


            var columnKey = new KeyValue(columnHeightProperty, columnHeight, Interpolator.EASE_IN);
            var columnFrame = new KeyFrame(Duration.millis(500), columnKey);
            var columnAnim = new Timeline(columnFrame);
            columnAnim.setDelay(Duration.millis(500));

            pinAnim.play();
            columnAnim.play();

            ball.setOpacity(0);
            pinAnim.setOnFinished(e -> {
                pin.setClip(null);
                ball.setOpacity(1);
                ball.setTranslateY(height - ballY);
                ballAnim.play();
                pinAnim.setOnFinished(null);
            });

            ballAnim = new TranslateTransition(Duration.millis(500), ball);
            ballAnim.setToY(0);
        }
    }

    private void onMouseEntered(MouseEvent e) {
        if (isPinned) return;
        column.highlightColor();
        pin.highlightColor();
        if(popup == null) return;

        popup.show(this, e.getScreenX() + 20, e.getScreenY() + 20);
    }

    private void onClicked(MouseEvent e) {isPinned = !isPinned;}

    private void onMouseExited(MouseEvent e) {
        if (isPinned) return;
        column.normalColor();
        pin.normalColor();
        if(popup == null) return;
        popup.hide();
    }

    public void setToolTip(Popup popup){
        this.popup = popup;
    }
}
