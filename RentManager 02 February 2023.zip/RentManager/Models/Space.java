package Models;

import interfaces.IReturnNameAndId;
import javafx.beans.property.*;

public class Space extends IReturnNameAndId<Space> {
    private final IntegerProperty id, plotId;
    private final StringProperty name, description;
    private final BooleanProperty isVacant;

    public Space() {
        id = new SimpleIntegerProperty();
        plotId = new SimpleIntegerProperty();
        name = new SimpleStringProperty("");
        description = new SimpleStringProperty("");
        isVacant = new SimpleBooleanProperty();
    }

    public Space(int id, int plotId, String name, String description, boolean isVacant) {
        this.id = new SimpleIntegerProperty(id);
        this.plotId = new SimpleIntegerProperty(plotId);
        this.name = new SimpleStringProperty(name);
        this.description = new SimpleStringProperty(description);
        this.isVacant = new SimpleBooleanProperty(isVacant);
    }

    @Override
    public int getId() {
        return id.getValue();
    }

    @Override
    public String getName() {
        return name.get();
    }

    public String getDescription() {return description.get();}

    public boolean getIsVacant() {return isVacant.get();}

    public void setIsVacant(boolean value) {isVacant.set(value);}

    public int getPlotId() {
        return plotId.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public IntegerProperty plotIdProperty() {
        return plotId;
    }

    public void setPlotId(int plotId) {
        this.plotId.set(plotId);
    }

    public StringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public void setDescription(String description) {
        this.description.set(description);
    }

    public boolean isIsVacant() {
        return isVacant.get();
    }

    public BooleanProperty isVacantProperty() {
        return isVacant;
    }
}
