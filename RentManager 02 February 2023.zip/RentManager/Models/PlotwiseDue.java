package Models;

public class PlotwiseDue {
    private String month, tenant;
    private int due;

    public PlotwiseDue(String month, String tenant, int due) {
        this.month = month;
        this.tenant = tenant;
        this.due = due;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    public int getDue() {
        return due;
    }

    public void setDue(int due) {
        this.due = due;
    }
}
