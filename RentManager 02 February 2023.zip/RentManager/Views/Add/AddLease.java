package Views.Add;

import CellTemplates.ListView.ReceivableTemplate;
import CellTemplates.SelectionBox.TenantTemplate;
import CellTemplates.Visual.TenantVisual;
import Converters.IntToStringConverter;
import Models.*;
import ViewModels.Add.AddLeaseVM;
import controls.SelectionBox;
import controls.buttons.CommandButton;
import controls.daymonth.DayPicker;
import controls.texts.IntegerBox;
import controls.texts.TextBoxMultiLine;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import skinned.ExtendedListView;
import skinned.ExtendedSeparator;

public class AddLease extends AddBase {
    private AddLeaseVM vm;
    private SelectionBox<Plot> plot;
    private SelectionBox<Space> space;
    private SelectionBox<Tenant> tenant;
    private SelectionBox<Head> head;
    private TextBoxMultiLine business;
    private IntegerBox amount;
    private ExtendedListView<Receivable> receivables;
    private CommandButton addHead;
    private DayPicker from;

    @Override
    protected String getHeader() {
        return "Lease";
    }

    @Override
    protected Node getUI() {
        viewModel = vm = new AddLeaseVM();
        plot = new SelectionBox<>("Plot", Icons.Plot, vm.plots, true) {{setSelectAddedItem(true);}};
        space = new SelectionBox<>("Space", Icons.Space, vm.spaces, true) {{setSelectAddedItem(true);}};
        tenant = new SelectionBox<>("Tenant", Icons.Tenant, vm.tenants, new TenantVisual(), TenantTemplate.class.getName(), true) {{setSelectAddedItem(true);}};
        from = new DayPicker("From", Icons.Month, true);
        business = new TextBoxMultiLine("Business", Icons.Description, true) {{setMinHeight(100);}};

        head = new SelectionBox<>("Head", Icons.Head, vm.heads, true) {{setSelectAddedItem(true);}};
        amount = new IntegerBox("Amount", Icons.Amount, true);
        addHead = new CommandButton(Icons.PlusCircle, 16, "add");

        var amountBox = new HBox(amount, addHead) {{
            setSpacing(5);
            setAlignment(Pos.BOTTOM_RIGHT);
            setHgrow(amount, Priority.ALWAYS);
        }};

        receivables = new ExtendedListView<>(vm.receivables) {{
            setMaxHeight(300);
            setCellFactory(v -> new ReceivableTemplate(vm::removeReceivable));
        }};
        add = new CommandButton(Icons.Add, 16, "add");

        var text = new HBox(new Text("Receivables") {{
            setFill(Color.GRAY);
            setFont(Font.font(null, FontWeight.BOLD, -1));
        }});

       return new VBox(plot, space, tenant, from, business, text, new ExtendedSeparator(), head, amountBox, receivables) {{
            setSpacing(5);
            setPadding(new Insets(5, 0, 0, 0));
            setMargin(text, new Insets(15, 0, 0, 0));
            setVgrow(business, Priority.ALWAYS);
            setVgrow(receivables, Priority.SOMETIMES);
            setAlignment(Pos.CENTER_RIGHT);
        }};
    }

    @Override
    protected void bind() {
        vm.lease.plotIdProperty().bind(plot.selectedValueProperty());
        vm.lease.spaceIdProperty().bind(space.selectedValueProperty());
        vm.lease.tenantIdProperty().bind(tenant.selectedValueProperty());
        vm.lease.dateStartProperty().bind(from.selectedDateProperty());
        vm.lease.businessProperty().bindBidirectional(business.textProperty());
        vm.receivable.headIdProperty().bind(head.selectedValueProperty());
        Bindings.bindBidirectional(amount.textProperty(), vm.receivable.amountProperty(), new IntToStringConverter());

        addHead.disableProperty().bind(head.isEmpty().or(amount.isEmpty()));
        add.disableProperty().bind(plot.isEmpty()
                .or(space.isEmpty())
                .or(tenant.isEmpty())
                .or(from.isEmpty())
                .or(business.isEmpty())
                .or(receivables.isEmpty())
        );

        addHead.setAction(vm::addReceivable);
    }
}
