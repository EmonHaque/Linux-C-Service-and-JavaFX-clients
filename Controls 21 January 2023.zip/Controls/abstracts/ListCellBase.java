package abstracts;

import helpers.Constants;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;

public abstract class ListCellBase<T> extends ListCell<T> {

    public ListCellBase() {
        setBackground(null);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        setPadding(new Insets(2.5, Constants.CellRightPadding, 2.5, 0));
        setPrefWidth(0);
        initializeUI();
        itemProperty().addListener(this::onItemChanged);
        hoverProperty().addListener(this::onHover);
    }
    protected abstract void initializeUI();
    protected abstract void onItemChanged(ObservableValue<?> o, T ov, T nv);
    protected abstract Node getRootNode();

    private void onHover(ObservableValue<?> o, boolean ov, boolean nv){
        if (nv && !isEmpty()) {
            if(!isSelected())
                setBackground(Background.fill(Constants.BackgroundColorLight));
        } else {
            if(!isSelected())
                setBackground(null);
        }
    }

    @Override
    protected void updateItem(T item, boolean empty) {
        super.updateItem(item, empty);
        if(empty){
            setGraphic(null);
            setBackground(null);
        }
        else{
            setGraphic(getRootNode());
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}
