package ridiculuous;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class User {
    private String appName;
    private String userName;
    private String password;

    public User(String appName, String userName, String password) {
        this.appName = appName;
        this.userName = userName;
        this.password = password;
    }

    public byte[] getBytes(){
        var appBytes = (appName + '\0').getBytes(StandardCharsets.US_ASCII);
        var userBytes = (userName + '\0').getBytes(StandardCharsets.US_ASCII);
        var passBytes = (password + '\0').getBytes(StandardCharsets.US_ASCII);
        var size = appBytes.length + userBytes.length + passBytes.length;

        var buffer = ByteBuffer.allocate(4 + size);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        buffer.putInt(size);
        buffer.put(appBytes);
        buffer.put(userBytes);
        buffer.put(passBytes);
        //buffer.flip();
        return buffer.array();
    }
}
