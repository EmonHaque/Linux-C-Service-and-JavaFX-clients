package ridiculuous;

public class Addresses {
    public static String LoginIP = "127.0.0.1";
    public static String RentManagerIP = "127.0.0.1";
    public static String BillIP = "127.0.0.1";

    public static int LoginPort = 5556;
    public static int RentManagerPort = 5557;
    public static int BillPort = 5558;
}
