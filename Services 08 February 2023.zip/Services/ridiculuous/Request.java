package ridiculuous;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class Request {
    private int method;
    private ByteBuffer bytes;

    public Request(int method, ByteBuffer bytes) {
        this.method = method;
        this.bytes = bytes;
    }

    public byte[] getBytes() {
        return ByteBuffer.allocate(12 + bytes.array().length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(8 + bytes.array().length)
                .putInt(Channels.getInstance().userId)
                .putInt(method)
                .put(bytes.array())
                .array();
    }
}
