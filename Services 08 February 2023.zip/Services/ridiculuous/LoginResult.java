package ridiculuous;

import enums.Role;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class LoginResult {
    private Role role;
    private int userid;
    private  boolean isSuccess;

    public LoginResult(byte[] array) {
        var buffer = ByteBuffer.wrap(array).order(ByteOrder.LITTLE_ENDIAN);
        role = Role.values()[buffer.getInt()];
        userid = buffer.getInt();
        isSuccess = buffer.get() != 0;
    }

    public Role getRole() {
        return role;
    }

    public int getUserid() {
        return userid;
    }

    public boolean isSuccess() {
        return isSuccess;
    }
}
