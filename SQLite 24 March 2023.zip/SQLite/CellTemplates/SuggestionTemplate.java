package CellTemplates;

import Abstracts.ListCellBase;
import Controls.HiText;
import Controls.SVGIcon;
import Helpers.Icons;
import Model.Suggestion;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class SuggestionTemplate extends ListCellBase<Suggestion> {
    private SVGIcon icon;
    private HiText name;
    private Text type;
    private BorderPane root;
    private final StringProperty query;

    public SuggestionTemplate(StringProperty query) {
        this.query = query;
    }

    @Override
    protected void initializeUI() {
        icon = new SVGIcon(Icons.Keyword);
        name = new HiText();
        type = new Text(){{ setFill(Color.GRAY);}};
        root = new BorderPane(){{
            setLeft(icon);
            setCenter(name);
            setRight(type);
            setAlignment(name, Pos.CENTER_LEFT);
            setAlignment(icon, Pos.CENTER_LEFT);
            setMargin(name, new Insets(0, 10, 0, 0));
            setMargin(icon, new Insets(0, 5, 0, 5));
        }};
    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Suggestion ov, Suggestion nv) {
        if(ov != null){
            name.queryProperty().unbind();
            name.queryProperty().set("");
            type.setText(null);
        }
        if(nv != null){
            switch (nv.getType()){
                case JSON -> {
                    icon.setContent(Icons.JSON);
                    type.setText("JSON Function");
                }
                case Math -> {
                    icon.setContent(Icons.Math);
                    type.setText("Math Function");
                }
                case Scalar -> {
                    icon.setContent(Icons.Scalar);
                    type.setText("Scalar Function");
                }
                case Window -> {
                    icon.setContent(Icons.Window);
                    type.setText("Window Function");
                }
                case Keyword -> {
                    icon.setContent(Icons.Keyword);
                    type.setText("Keyword");
                }
                case DataType -> {
                    icon.setContent(Icons.DataType);
                    type.setText("Data Tpe");
                }
                case DateTime -> {
                    icon.setContent(Icons.DateTime);
                    type.setText("DateTime Function");
                }
                case Aggregate -> {
                    icon.setContent(Icons.Sum);
                    type.setText("Aggregate Function");
                }
                case Table ->{
                    icon.setContent(Icons.Table);
                    type.setText("Table");
                }
                case View ->{
                    icon.setContent(Icons.View);
                    type.setText("View");
                }
                case Column ->{
                    icon.setContent(Icons.Column);
                    type.setText("Column");
                }
            }
            name.setText(nv.getValue());
            name.queryProperty().bind(query);
        }
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
