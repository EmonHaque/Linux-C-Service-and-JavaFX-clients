package ViewModels.Edit;

import Enums.Function;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import Models.ControlHead;
import Models.Head;
import ridiculous.AppData;
import ridiculous.Jar;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;

public class EditHeadVM extends EditBaseVM<Head> {
    public FilteredList<ControlHead> controls, editControls;
    public IntegerProperty selectedControlProperty;

    public EditHeadVM() {
        edited = new Head();
        controls = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.controlHeads));
        editControls = new FilteredList<>(FXCollections.synchronizedObservableList(AppData.controlHeads));
        var nameAscending = Comparator.comparing(Head::getName);

        selectedControlProperty = new SimpleIntegerProperty();
        var source = new Jar<>(AppData.heads, o -> new Observable[]{
                o.controlIdProperty(),
                queryProperty,
                selectedControlProperty
        });
        editableList = new FilteredList<>(source.sorted(nameAscending), this::filter);
        selectedControlProperty.addListener(this::onQueryEditableListChanged);
    }

    private boolean filter(Head head) {
        var isMatch = head.getControlId() == selectedControlProperty.get();
        if(!isMatch) return false;
        return head.getName().toLowerCase().contains(trimmedQuery);
    }

    @Override
    protected int function() {
        return Function.EditHead.ordinal();
    }

    @Override
    protected ByteBuffer buffer() {
        var nameBytes = (edited.getName().trim() + '\0').getBytes(StandardCharsets.US_ASCII);
        var descBytes = (edited.getDescription().trim() + '\0').getBytes(StandardCharsets.US_ASCII);

        return ByteBuffer.allocate(8 + nameBytes.length + descBytes.length)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(edited.getId())
                .putInt(edited.getControlId())
                .put(nameBytes)
                .put(descBytes);
    }

    @Override
    public void cloneSelected() {
        edited = new Head(
                selected.getId(),
                selected.getControlId(),
                selected.getName(),
                selected.getDescription()
        );
    }
}
