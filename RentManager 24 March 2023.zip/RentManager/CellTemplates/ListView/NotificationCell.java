package CellTemplates.ListView;

import Models.Notification;
import abstracts.ListCellBase;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class NotificationCell extends ListCellBase<Notification> {
    private GridPane root;
    private Text category, message;

    @Override
    protected void initializeUI() {
        category = new Text(){{ setFill(Color.WHITE);}};
        message = new Text(){{ setFill(Color.WHITE);}};
        root = new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(100),
                    new ColumnConstraints(){{ setHgrow(Priority.SOMETIMES);}}
            );
            add(category, 0, 0);
            add(message, 1, 0);
        }};

    }

    @Override
    protected void onItemChanged(ObservableValue<?> o, Notification ov, Notification nv) {
        if(nv != null){
            category.textProperty().bind(nv.categoryProperty());
            message.textProperty().bind(nv.messageProperty());
            root.backgroundProperty().bind(Bindings.createObjectBinding(() ->
                 Background.fill(nv.isIsRead()? null : Color.DARKBLUE), nv.isReadProperty())
            );
        }
    }

    @Override
    protected Node getRootNode() {
        return root;
    }
}
