package Views.Report;

import CellTemplates.Visual.SpaceVisual;
import Models.Space;
import ViewModels.Report.BaseLedgerVM;
import ViewModels.Report.SpaceLedgerVM;
import helpers.Icons;
import interfaces.ISetSelectionBoxContent;

public class SpaceLedger extends BaseLedger<Space> {

    @Override
    protected String getIcon() {
        return Icons.Space;
    }

    @Override
    protected ISetSelectionBoxContent<Space> getVisual() {
        return new SpaceVisual();
    }

    @Override
    protected BaseLedgerVM<Space> getViewModel() {
        return new SpaceLedgerVM();
    }
}
