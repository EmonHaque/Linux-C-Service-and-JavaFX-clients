package Views;

import Views.Add.*;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.util.ArrayList;
import java.util.List;


public class AddView extends View {
    private final View plot, space, tenant, head, lease;

    public AddView() {
        plot = new AddPlot();
        space = new AddSpace();
        tenant = new AddTenant();
        head = new AddHead();
        lease = new AddLease();
    }

    @Override
    protected String getIcon() {
        return Icons.Add;
    }

    @Override
    protected String getTip() {
        return "Add";
    }

    @Override
    public boolean isContainer() {
        return true;
    }
    @Override
    public List<View> initialViews() {
        super.views = new ArrayList<>();
        views.add(plot);
        views.add(space);

        views.add(tenant);
        views.add(head);

        views.add(lease);
        return super.views;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        setCenter(new GridPane(){{
            getColumnConstraints().addAll(
                    new ColumnConstraints(){{ setPercentWidth(33.33);}},
                    new ColumnConstraints(){{ setPercentWidth(33.33);}},
                    new ColumnConstraints(){{ setPercentWidth(33.34);}}
            );
            getRowConstraints().addAll(
                    new RowConstraints(){{setPercentHeight(50);}},
                    new RowConstraints(){{setPercentHeight(50);}}
            );
            add(plot, 0, 0);
            add(space, 1, 0);
            add(lease, 2, 0, 1, 2);
            add(tenant, 0, 1);
            add(head, 1, 1);

            setVgap(Constants.CardMargin);
            setHgap(Constants.CardMargin);
            setPadding(new Insets(Constants.CardMargin));
        }});
    }
}
